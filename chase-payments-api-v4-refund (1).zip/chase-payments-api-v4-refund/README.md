# chase-payments-api

Spring Boot 4.0.8 / Java 25 facade over the **J.P. Morgan Online Payments API**
(<https://developer.payments.jpmorgan.com/docs/commerce/online-payments/capabilities/online-payments/how-to/auth-and-capture-payment>)
with a built-in **stub** of the Chase endpoints, because the real endpoint is not reachable yet.

## Design

```
client ──> /api/v1/payments (facade)  ──> PaymentService ──> ChasePaymentsGateway ──> Chase API
                                                                   │                      (or)
                                                                   └── same HTTP calls ──> /stub/jpm/** (JpmStubService)
```

* The stub is a real HTTP stand-in under `/stub/jpm`. Default `chase.base-url` points at it, so the whole
  RestClient / OAuth / header path is exercised. Going live = change env vars, set `CHASE_STUB_ENABLED=false`.
* Facade endpoints

| Method | Path | Chase call |
|---|---|---|
| POST | `/api/v1/payments` | `POST /payments` (captureMethod NOW / DELAYED / MANUAL) |
| POST | `/api/v1/payments/{id}/captures` | `POST /payments/{id}/captures` (full, partial, multi) |
| GET | `/api/v1/payments/{id}` | `GET /payments/{id}` |
| GET | `/api/v1/payments?requestId=` | `GET /payments?requestId=` |

Full contract: `docs/openapi.yaml`.

* **Idempotency / unknown outcomes.** `requestId` is supplied by the caller and forwarded as `request-id`.
  4xx from Chase = definitely not processed. Timeout / I-O / 408 / 429 / 5xx = unknown: the service first asks Chase
  `GET /payments?requestId=`; only if that cannot settle it does the facade answer **504**. Retry with the *same* requestId.
* Declines are **HTTP 200 with `status=DECLINED`** (a business result, not an error).
* Amounts are major units in the facade (`12.34`), minor units on the Chase wire; the currency's fraction digits are used (JPY = 0).
* Luhn and expiry are checked locally before the card leaves the service.
* The PAN is never logged or echoed (`toString` is masked, responses carry only the masked number).

## Stub scenarios (the table holds the complete JSON responses)

The stub keeps only the transaction **state** (ids, amounts, states). **Every response body the caller sees is the
complete JSON stored in `jpm_stub_scenario.response_json`**, with `${placeholders}` filled from that state. Field names
and response codes follow the J.P. Morgan "Authorize and capture a payment" page and its Online Payments response-codes
page (`responseStatus` SUCCESS / DENIED / ERROR, `APPROVED`, `PARTIAL_APPROVAL`, `ACCEPTED`, `INSUFFICIENT_FUNDS`,
`CARD_EXPIRED`, `SERVER_ERROR`, `TIMEOUT`, ...). The table is read on every request: edit a row and the next call changes.

One row = "when a card ending in `card_last4` reaches `step`, do `effect` and answer with `response_json`".
Card `*` is the **default row** for every card without its own row (keep it; it cannot be deleted through the API).

| column | meaning |
|---|---|
| card_last4, step | key: last four digits (or `*`) and `AUTHORIZE` / `CAPTURE` / `REFUND` |
| effect | AUTHORIZE: `APPROVE` (record an authorization), `DECLINE` (record a closed, denied one), `NONE` (record nothing). CAPTURE: `APPLY` or `NONE`. REFUND: `APPLY`, `DECLINE` or `NONE` |
| http_status | status sent to the caller. 400+ with `APPROVE`/`APPLY` = **lost response** (work done, caller sees the error); 400+ with `NONE` = nothing done |
| approved_percent | below 100 = partial approval, used only when the request sent `partialAuthorizationSupport=SUPPORTED` (otherwise the default row applies) |
| delay_ms | wait before answering (0-60000) |
| response_json | the complete body. NULL = use the default row's JSON |

Placeholders (numbers and booleans unquoted, strings quoted): `transactionId requestId paymentRequestId authorizationId
approvalCode now captureTime transactionState paymentRequestStatus authStatusCode captureMethod currency amount
approvedAmount requestedAmount captureAmount totalAuthorizedAmount remainingAuthAmount remainingRefundableAmount
isAmountFinal cardType cardTypeName maskedAccountNumber`. An unknown `${name}` is left as typed so the typo is visible.

Seed rows (added by `schema.sql` only when missing; the file also holds the full JSON of each):

| last4 | step | effect / http | response |
|---|---|---|---|
| * | AUTHORIZE | APPROVE / 200 | `APPROVED` "Transaction approved by Issuer" (default) |
| * | CAPTURE | APPLY / 200 | `ACCEPTED` "Transaction accepted" (default) |
| 0002 | AUTHORIZE | DECLINE / 200 | DENIED `DECLINED` |
| 0051 | AUTHORIZE | DECLINE / 200 | DENIED `INSUFFICIENT_FUNDS` |
| 0054 | AUTHORIZE | DECLINE / 200 | DENIED `CARD_EXPIRED` |
| 0036 | AUTHORIZE | APPROVE / 200, 50% | `PARTIAL_APPROVAL`, `partialAuthorization: true` |
| 0119 | AUTHORIZE | APPROVE / 500 | ERROR `SERVER_ERROR`, transaction recorded (recovery by request-id) |
| 0408 | AUTHORIZE | NONE / 504 | ERROR `TIMEOUT`, nothing recorded |
| 0503 | AUTHORIZE | NONE / 503 | ERROR `SERVICE_UNAVAILABLE`, nothing recorded |
| 0900 | AUTHORIZE | APPROVE / 200, 5 s | default JSON after a delay |
| 0777 | CAPTURE | NONE / 400 | ERROR, capture refused, authorization stays usable |
| 0778 | CAPTURE | APPLY / 500 | ERROR, capture applied (lost response) |
| * | REFUND | APPLY / 200 | `APPROVED` (default refund) |
| 0881 | REFUND | DECLINE / 200 | DENIED `DECLINED`, nothing refunded |
| 0882 | REFUND | NONE / 504 | ERROR `TIMEOUT`, nothing refunded |
| 0883 | REFUND | APPLY / 500 | ERROR `SERVER_ERROR`, refund applied (lost response) |

**Database.** Default is in-memory H2 (rows reset on restart). For k8s set `SPRING_DATASOURCE_URL`,
`SPRING_DATASOURCE_USERNAME`, `SPRING_DATASOURCE_PASSWORD` to a Postgres. If you already ran v2/v3 against that Postgres,
run `DROP TABLE jpm_stub_scenario;` once so the new layout is created (the `step` CHECK now allows `REFUND`).

**Change responses**

```sql
INSERT INTO jpm_stub_scenario (card_last4, step, effect, response_json, note) VALUES ('0555', 'AUTHORIZE', 'DECLINE',
'{"transactionId":"${transactionId}","requestId":"${requestId}","transactionState":"CLOSED","responseStatus":"DENIED",
  "responseCode":"LOST_STOLEN_CARD","responseMessage":"Pick up card","amount":0,"currency":"${currency}"}', 'lost card');
UPDATE jpm_stub_scenario SET response_json = '{ ...whole new body... }' WHERE card_last4 = '0555' AND step = 'AUTHORIZE';
DELETE FROM jpm_stub_scenario WHERE card_last4 = '0555';
```

```bash
# REST (tester with only the API endpoint): the BODY is the complete response JSON, settings are query parameters
curl https://<host>/stub/jpm/admin/scenarios
curl -X PUT "https://<host>/stub/jpm/admin/scenarios/0555/AUTHORIZE?effect=DECLINE" -H 'Content-Type: application/json' \
  -d '{"transactionId":"${transactionId}","requestId":"${requestId}","transactionState":"CLOSED","responseStatus":"DENIED","responseCode":"LOST_STOLEN_CARD","responseMessage":"Pick up card","amount":0,"currency":"${currency}"}'
curl -X PUT "https://<host>/stub/jpm/admin/scenarios/0556/AUTHORIZE?effect=NONE&httpStatus=503&delayMs=3000" \
  -H 'Content-Type: application/json' -d '{"responseStatus":"ERROR","responseCode":"SERVICE_UNAVAILABLE","responseMessage":"down"}'
curl -X DELETE https://<host>/stub/jpm/admin/scenarios/0555/AUTHORIZE
```

The JSON is only checked to be an object, not parsed: a malformed body shows up as a parse error in the facade, so test a
new row once. The admin endpoints have **no authentication**: dev/test only. Idempotent per `request-id`; DELAYED
captures settle when read after `captureTime`; transactions are held in memory, so run **one replica**.
`POST /stub/jpm/admin/reset` clears stored transactions (not the table).

## Refund API (stub)

Follows the J.P. Morgan "Refund a payment" page. `POST {base}/refunds` with the `request-id` header (idempotency key: a
replay returns the first answer and never refunds twice) and the same bearer token as the other stub calls.
Lookups: `GET /refunds/{transactionId}` and `GET /refunds?requestId=`.

| refund type | request | what the stub does |
|---|---|---|
| full | `paymentMethodType.transactionReference.transactionReferenceId` = original `transactionId`, no `amount` | refunds everything still refundable |
| partial (repeatable) | the same plus `amount` (minor units) | refunds `amount`; `remainingRefundableAmount` shows the balance; repeat until it is 0 |
| standalone | `paymentMethodType.card` (`accountNumberType`, `accountNumber`, `expiry`), `amount`, `currency`; no reference | refunds straight to the card, no original payment needed |

Not included (kept simple): refunding a single capture of a multi-capture payment by `captureId`.

```bash
curl -X POST https://<host>/stub/jpm/api/v2/refunds -H "Authorization: Bearer $TOKEN" -H 'request-id: rfd-001' \
  -H 'Content-Type: application/json' \
  -d '{"amount": 900, "currency": "USD",
       "paymentMethodType": {"transactionReference": {"transactionReferenceId": "<transactionId of the payment>"}}}'
```

The response is the `REFUND` row's `response_json` with placeholders filled from the request and the original payment:
`${transactionId}` (the refund's own id), `${requestId}`, `${transactionReferenceId}`, `${amount}` (refunded),
`${currency}`, `${remainingRefundableAmount}`, `${approvalCode}`, `${hostReferenceId}`, `${transactionDate}`,
`${paymentRequestId}`, `${cardType}`, `${cardTypeName}`, `${maskedAccountNumber}`. The row is chosen by the card of the
ORIGINAL payment (referenced refund) or the card in the request (standalone), so authorize with `0881` / `0882` / `0883`
to get a refund decline / timeout / lost response. `transactionState` is `AUTHORIZED` in the default template, as in the
docs' example; edit the row's JSON if you prefer `CLOSED`.

Rules enforced in code (plain `{"responseMessage": ...}` error bodies):

| situation | HTTP |
|---|---|
| unknown `transactionReferenceId` | 404 |
| nothing refundable (not captured yet, or already fully refunded) | 409 |
| amount above the remaining refundable amount, or not positive | 422 |
| referenced refund more than 13 months after the original payment | 400 |
| standalone refund without card, amount or currency (or no reference and no card) | 400 |

REST example to change a refund scenario: `PUT /stub/jpm/admin/scenarios/0555/REFUND?effect=DECLINE` with the full JSON as the body.

## Run

```
mvn spring-boot:run
curl -s localhost:8080/api/v1/payments -H 'Content-Type: application/json' -d '{
  "requestId":"order-1001","amount":12.34,"currency":"USD",
  "card":{"number":"4111111111111111","expiryMonth":12,"expiryYear":2030}}'

# two-step
curl -s localhost:8080/api/v1/payments -H 'Content-Type: application/json' -d '{
  "requestId":"order-1002","amount":100.00,"currency":"USD","captureMethod":"MANUAL",
  "card":{"number":"4111111111111111","expiryMonth":12,"expiryYear":2030}}'
curl -s localhost:8080/api/v1/payments/stub-txn-000002/captures -H 'Content-Type: application/json' \
  -d '{"requestId":"cap-1002","amount":40.00,"finalCapture":false}'
```

## Going live – confirm in the JPM portal (assumptions)

The fetched page documents the payloads but **not**: base URL, token URL/scope, required headers, error body shape.
Assumed (from memory, unverified): OAuth2 client-credentials, headers `request-id` and `merchant-id`, paths under
`{base}/payments`. Change `chase.*` in `application.yaml`, and adjust `RestChasePaymentsGateway.headers()` if the portal differs.

## Production notes

* Passing a raw PAN through your service puts it in **PCI DSS scope**. Prefer tokenisation / hosted fields where possible.
* Secrets (`CHASE_CLIENT_ID/SECRET`) via env or a secret store, never in the repo.
* Stub state is in-memory and per-instance; set `CHASE_STUB_ENABLED=false` outside dev/test.

## Verification status

`JpmStubService`, `PaymentService`, `CardValidator` and the model records were compiled and their 49 unit tests passed
using stand-in annotations (Maven Central was not reachable here). The Spring-specific classes
(controllers, `ScenarioRepository` (JDBC), `RestChasePaymentsGateway`, `ChaseTokenProvider`, config) were **not compiled** against real Spring 4 jars –
run `mvn verify` first.
