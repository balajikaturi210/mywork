package com.zbp.chasepay.client.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

/** Wire records for the J.P. Morgan Online Payments API (/payments, /payments/{id}/captures). */
public final class ChaseModel {

    private ChaseModel() {
    }

    // ---------------------------------------------------------------- requests

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record ChaseAuthorizeRequest(
            String captureMethod,          // NOW | DELAYED | MANUAL
            String captureTime,            // ISO-8601, only for DELAYED
            long amount,                   // minor units
            String currency,
            Boolean isAmountFinal,
            String partialAuthorizationSupport, // SUPPORTED | NOT_SUPPORTED
            Merchant merchant,
            PaymentMethodType paymentMethodType) {
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record ChaseCaptureRequest(
            String captureMethod,          // NOW
            Long amount,                   // null = full capture
            Boolean isAmountFinal,
            MultiCapture multiCapture) {
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record MultiCapture(int multiCaptureSequenceNumber, int multiCaptureRecordCount, boolean isFinalCapture) {
    }

    /** POST /refunds. Referenced refund: paymentMethodType.transactionReference; standalone: paymentMethodType.card. */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record ChaseRefundRequest(
            Long amount,                   // minor units; null = full refund (referenced refunds only)
            String currency,
            String initiatorType,          // standalone: CARDHOLDER | MERCHANT
            String accountOnFile,          // standalone: NOT_STORED | ...
            Merchant merchant,
            RefundPaymentMethod paymentMethodType) {
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record RefundPaymentMethod(TransactionReference transactionReference, RefundCard card) {
    }

    /** the original transactionId */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record TransactionReference(String transactionReferenceId) {
    }

    /** card of a standalone refund; the number is never printed */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record RefundCard(String accountNumberType, String accountNumber, Expiry expiry) {
        @Override
        public String toString() {
            return "RefundCard[" + (accountNumber == null ? "" : "****" + accountNumber.substring(Math.max(0, accountNumber.length() - 4))) + "]";
        }
    }

    // --------------------------------------------------------------- shared

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Merchant(String merchantId, MerchantSoftware merchantSoftware, String merchantCategoryCode) {
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record MerchantSoftware(String companyName, String productName, String version) {
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record PaymentMethodType(Card card) {
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Card(String accountNumber, Expiry expiry, String cardType, String cardTypeName,
                       String maskedAccountNumber) {
        /** never print the PAN */
        @Override
        public String toString() {
            return "Card[" + (accountNumber == null ? maskedAccountNumber : "****" + last4(accountNumber)) + "]";
        }

        private static String last4(String s) {
            return s.length() <= 4 ? s : s.substring(s.length() - 4);
        }
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Expiry(int month, int year) {
    }

    // -------------------------------------------------------------- response

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record ChasePaymentResponse(
            String transactionId,
            String requestId,
            String transactionState,       // AUTHORIZED | CLOSED | PENDING ...
            String responseStatus,         // SUCCESS | DENIED | ERROR
            String responseCode,           // APPROVED | PARTIAL_APPROVAL | ACCEPTED | ...
            String responseMessage,
            String captureMethod,
            String captureTime,
            Boolean isVoid,
            String approvalCode,
            Long amount,
            String currency,
            Long remainingAuthAmount,
            Long remainingRefundableAmount,
            PaymentMethodType paymentMethodType,
            Merchant merchant,
            ChasePaymentRequest paymentRequest) {
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record ChasePaymentRequest(String paymentRequestId, String paymentRequestStatus,
                                 List<Authorization> authorizations) {
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Authorization(String authorizationId, Long amount, String transactionStatusCode,
                                String authorizationType) {
    }

    /** error body shape is an assumption - parsed leniently */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record ChaseErrorResponse(String responseStatus, String responseCode, String responseMessage) {
    }
}
