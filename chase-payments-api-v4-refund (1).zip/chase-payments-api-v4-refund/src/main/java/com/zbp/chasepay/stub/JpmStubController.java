package com.zbp.chasepay.stub;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.zbp.chasepay.client.model.ChaseModel.*;
import com.zbp.chasepay.config.ChaseProperties;
import com.zbp.chasepay.stub.ScenarioRepository.Effect;
import com.zbp.chasepay.stub.ScenarioRepository.Scenario;
import com.zbp.chasepay.stub.ScenarioRepository.Step;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/** Fake JPM endpoints, active only when chase.stub.enabled=true. Base: /stub/jpm */
@RestController
@RequestMapping("/stub/jpm")
@ConditionalOnProperty(name = "chase.stub.enabled", havingValue = "true", matchIfMissing = true)
public class JpmStubController {

    static final String TOKEN_PREFIX = "stub-token-";

    public record TokenResponse(@JsonProperty("access_token") String accessToken,
                                @JsonProperty("token_type") String tokenType,
                                @JsonProperty("expires_in") long expiresIn) {
    }

    private final JpmStubService stub;
    private final ScenarioRepository scenarios;
    private final ChaseProperties props;
    private final AtomicLong tokenSeq = new AtomicLong();

    public JpmStubController(JpmStubService stub, ScenarioRepository scenarios, ChaseProperties props) {
        this.stub = stub;
        this.scenarios = scenarios;
        this.props = props;
    }

    // ---- admin (dev/test only, no authentication): the same rows you can edit with SQL ----

    @GetMapping("/admin/scenarios")
    public List<Scenario> listScenarios() {
        return scenarios.findAll();
    }

    /**
     * add or replace the row for one card and step, e.g. PUT /admin/scenarios/0555/AUTHORIZE?effect=DECLINE
     * The request BODY is the complete response JSON (with ${placeholders}); query parameters: effect (required),
     * httpStatus (200), approvedPercent (100), delayMs (0), note. An empty body = use the default row's JSON.
     */
    @PutMapping("/admin/scenarios/{last4}/{step}")
    public ResponseEntity<?> putScenario(@PathVariable String last4, @PathVariable Step step,
                                         @RequestParam Effect effect,
                                         @RequestParam(defaultValue = "200") int httpStatus,
                                         @RequestParam(defaultValue = "100") int approvedPercent,
                                         @RequestParam(defaultValue = "0") int delayMs,
                                         @RequestParam(required = false) String note,
                                         @RequestBody(required = false) String responseJson) {
        try {
            scenarios.upsert(new Scenario(last4, step, effect, httpStatus, approvedPercent, delayMs,
                    responseJson == null || responseJson.isBlank() ? null : responseJson.strip(), note));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
        return ResponseEntity.ok(scenarios.findAll());
    }

    /** the card/step is approved normally again */
    @DeleteMapping("/admin/scenarios/{last4}/{step}")
    public ResponseEntity<?> deleteScenario(@PathVariable String last4, @PathVariable Step step) {
        if (ScenarioRepository.DEFAULT_CARD.equals(last4)) {
            return ResponseEntity.badRequest().body(Map.of("error", "the default row (*) cannot be deleted; PUT a new one instead"));
        }
        return scenarios.delete(last4, step) ? ResponseEntity.ok(scenarios.findAll()) : ResponseEntity.notFound().build();
    }

    /** forget all stored transactions */
    @PostMapping("/admin/reset")
    public Map<String, String> reset() {
        stub.reset();
        return Map.of("status", "cleared");
    }

    @PostMapping(value = "/oauth2/token", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public ResponseEntity<?> token(@RequestParam Map<String, String> form) {
        if (!"client_credentials".equals(form.get("grant_type"))
                || !props.clientId().equals(form.get("client_id"))
                || !props.clientSecret().equals(form.get("client_secret"))) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "invalid_client"));
        }
        return ResponseEntity.ok(new TokenResponse(TOKEN_PREFIX + tokenSeq.incrementAndGet(), "Bearer", 3600));
    }

    @PostMapping("/api/v2/payments")
    public ResponseEntity<?> authorize(@RequestHeader(value = "Authorization", required = false) String auth,
                                       @RequestHeader(value = "request-id", required = false) String requestId,
                                       @RequestBody ChaseAuthorizeRequest body) {
        return guarded(auth, () -> json(stub.authorize(requestId, body)));
    }

    @PostMapping("/api/v2/payments/{id}/captures")
    public ResponseEntity<?> capture(@RequestHeader(value = "Authorization", required = false) String auth,
                                     @RequestHeader(value = "request-id", required = false) String requestId,
                                     @PathVariable String id, @RequestBody ChaseCaptureRequest body) {
        return guarded(auth, () -> json(stub.capture(requestId, id, body)));
    }

    /** refund: referenced (transactionReferenceId = original transactionId) or standalone (card + amount + currency) */
    @PostMapping("/api/v2/refunds")
    public ResponseEntity<?> refund(@RequestHeader(value = "Authorization", required = false) String auth,
                                    @RequestHeader(value = "request-id", required = false) String requestId,
                                    @RequestBody ChaseRefundRequest body) {
        return guarded(auth, () -> json(stub.refund(requestId, body)));
    }

    @GetMapping("/api/v2/refunds/{id}")
    public ResponseEntity<?> refundById(@RequestHeader(value = "Authorization", required = false) String auth,
                                        @PathVariable String id) {
        return guarded(auth, () -> stub.refundById(id).<ResponseEntity<?>>map(b -> json(new JpmStubService.StubResponse(200, b)))
                .orElseGet(() -> ResponseEntity.status(404).body(Map.of("responseMessage", "not found"))));
    }

    @GetMapping("/api/v2/refunds")
    public ResponseEntity<?> refundByRequestId(@RequestHeader(value = "Authorization", required = false) String auth,
                                               @RequestParam String requestId) {
        return guarded(auth, () -> stub.refundByRequestId(requestId).<ResponseEntity<?>>map(b -> json(new JpmStubService.StubResponse(200, b)))
                .orElseGet(() -> ResponseEntity.status(404).body(Map.of("responseMessage", "not found"))));
    }

    @GetMapping("/api/v2/payments/{id}")
    public ResponseEntity<?> byId(@RequestHeader(value = "Authorization", required = false) String auth,
                                  @PathVariable String id) {
        return guarded(auth, () -> stub.byId(id).<ResponseEntity<?>>map(b -> json(new JpmStubService.StubResponse(200, b)))
                .orElseGet(() -> ResponseEntity.status(404).body(Map.of("responseMessage", "not found"))));
    }

    @GetMapping("/api/v2/payments")
    public ResponseEntity<?> byRequestId(@RequestHeader(value = "Authorization", required = false) String auth,
                                         @RequestParam String requestId) {
        return guarded(auth, () -> stub.byRequestId(requestId).<ResponseEntity<?>>map(b -> json(new JpmStubService.StubResponse(200, b)))
                .orElseGet(() -> ResponseEntity.status(404).body(Map.of("responseMessage", "not found"))));
    }

    private ResponseEntity<?> guarded(String auth, java.util.function.Supplier<ResponseEntity<?>> action) {
        if (auth == null || !auth.startsWith("Bearer " + TOKEN_PREFIX)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("responseMessage", "invalid token"));
        }
        try {
            return action.get();
        } catch (StubException e) {
            return e.body() != null
                    ? ResponseEntity.status(e.status()).contentType(MediaType.APPLICATION_JSON).body(e.body())
                    : ResponseEntity.status(e.status()).body(Map.of("responseMessage", e.getMessage()));
        }
    }

    /** the body is the table's JSON, sent exactly as stored (placeholders filled) */
    private static ResponseEntity<String> json(JpmStubService.StubResponse r) {
        return ResponseEntity.status(r.status()).contentType(MediaType.APPLICATION_JSON).body(r.body());
    }
}
