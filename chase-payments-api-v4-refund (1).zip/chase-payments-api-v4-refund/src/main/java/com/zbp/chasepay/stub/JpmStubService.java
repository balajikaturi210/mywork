package com.zbp.chasepay.stub;

import com.zbp.chasepay.client.model.ChaseModel.*;
import com.zbp.chasepay.stub.ScenarioRepository.Effect;
import com.zbp.chasepay.stub.ScenarioRepository.Scenario;
import com.zbp.chasepay.stub.ScenarioRepository.Step;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * In-memory imitation of the J.P. Morgan Online Payments API.
 * <p>
 * The stub holds only the transaction STATE (amounts, ids, states). Everything the caller sees is the complete JSON
 * body stored in table jpm_stub_scenario (column response_json), with ${placeholders} filled from that state.
 * The row is chosen by the last four digits of the card and the step (AUTHORIZE / CAPTURE); card '*' is the default
 * row for every other card. The table is read on every request. Idempotent per request-id. DELAYED captures happen
 * lazily when the stub is read after captureTime.
 * Refunds (POST /refunds): full or partial (repeatable) against the original transactionId, or standalone with a card.
 */
@Service
@ConditionalOnProperty(name = "chase.stub.enabled", havingValue = "true", matchIfMissing = true)
public class JpmStubService {

    public static final int DEFAULT_DELAY_MINUTES = 120;

    /** HTTP status plus the complete JSON body to send */
    public record StubResponse(int status, String body) {
    }

    private static final Pattern PLACEHOLDER = Pattern.compile("\\$\\{(\\w+)}");

    private static final class Txn {
        String id, requestId, state, captureMethod, approvalCode, authId, paymentRequestId, paymentRequestStatus;
        String authStatusCode, currency, brand, brandName, masked, last4;
        String template;                        // response_json used to render this transaction from now on
        Instant captureTime;
        long requested, amount, remainingAuth, refundable, lastCapture;
        boolean finalAmount;
        Instant createdAt;
    }

    /** one refund */
    private static final class Ref {
        String id, requestId, referenceId, currency, brand, brandName, masked, paymentRequestId, approvalCode, json;
        long amount, remainingAfter;
        Instant at;
    }

    private final Clock clock;
    private final ScenarioRepository scenarios;           // the jpm_stub_scenario table
    private final Map<String, Txn> byId = new HashMap<>();
    private final Map<String, Txn> byRequestId = new HashMap<>();
    private final Map<String, String> captureRequestIds = new HashMap<>();
    private final Map<String, Ref> refundById = new HashMap<>();
    private final Map<String, Ref> refundByRequestId = new HashMap<>();
    private long seq = 0, refSeq = 0;

    public JpmStubService(Clock clock, ScenarioRepository scenarios) {
        this.clock = clock;
        this.scenarios = scenarios;
    }

    /** forget every stored transaction; ids restart at stub-txn-000001 */
    public synchronized void reset() {
        byId.clear();
        byRequestId.clear();
        captureRequestIds.clear();
        refundById.clear();
        refundByRequestId.clear();
        seq = 0;
        refSeq = 0;
    }

    // ------------------------------------------------------------- authorize

    public StubResponse authorize(String requestId, ChaseAuthorizeRequest req) {
        Scenario def = defaultRow(Step.AUTHORIZE);
        String last4 = last4Of(req);
        Scenario sc = last4 == null ? def : scenarios.find(last4, Step.AUTHORIZE).orElse(def);
        pause(sc);                                       // delay_ms, outside the lock
        return doAuthorize(requestId, req, sc, def);
    }

    private synchronized StubResponse doAuthorize(String requestId, ChaseAuthorizeRequest req, Scenario sc,
                                                  Scenario def) {
        if (requestId == null || requestId.isBlank()) {
            throw new StubException(400, "request-id header is required");
        }
        Txn existing = byRequestId.get(requestId);
        if (existing != null) {
            return new StubResponse(200, render(existing));  // idempotent replay, never failed again
        }
        Card card = req.paymentMethodType() == null ? null : req.paymentMethodType().card();
        if (card == null || card.accountNumber() == null || card.accountNumber().length() < 4
                || req.amount() <= 0 || req.currency() == null) {
            throw new StubException(400, "amount, currency and card are required");
        }
        if (sc.approvedPercent() < 100 && !"SUPPORTED".equals(req.partialAuthorizationSupport())) {
            sc = def;                                    // partial row, but caller did not allow it: normal approval
        }
        boolean fail = sc.httpStatus() >= 400;           // the caller will get an error status

        Txn t = newTxn(requestId, req, card.accountNumber());
        if (sc.effect() == Effect.NONE) {                // nothing recorded: render the error body and fail
            throw new StubException(sc.httpStatus(), "stub scenario " + sc.cardLast4() + "/AUTHORIZE (nothing recorded)",
                    fill(sc.responseJson(), values(t)));
        }
        if (sc.effect() == Effect.DECLINE) {
            t.template = sc.responseJson();
        } else {                                         // APPROVE
            boolean partial = sc.approvedPercent() < 100;
            t.approvalCode = "A" + (100001 + seq);
            t.amount = partial ? Math.max(1, req.amount() * sc.approvedPercent() / 100) : req.amount();
            t.remainingAuth = t.amount;
            t.authStatusCode = "AUTHORIZED";
            // a lost-response row answers with an error, but the recorded transaction looks like a normal approval
            t.template = fail || sc.responseJson() == null ? def.responseJson() : sc.responseJson();
            switch (t.captureMethod) {
                case "NOW" -> close(t);
                case "DELAYED" -> {
                    t.state = "AUTHORIZED";
                    t.paymentRequestStatus = "PENDING";
                    t.captureTime = req.captureTime() != null ? Instant.parse(req.captureTime())
                            : clock.instant().plusSeconds(DEFAULT_DELAY_MINUTES * 60L);
                }
                case "MANUAL" -> {
                    t.state = "AUTHORIZED";
                    t.paymentRequestStatus = "PENDING";
                }
                default -> throw new StubException(400, "unknown captureMethod " + t.captureMethod);
            }
        }
        seq++;
        byId.put(t.id, t);
        byRequestId.put(requestId, t);

        if (fail) {                                      // recorded, but the caller sees the row's error JSON
            throw new StubException(sc.httpStatus(), "stub scenario " + sc.cardLast4() + "/AUTHORIZE (transaction recorded)",
                    fill(sc.responseJson(), values(t)));
        }
        return new StubResponse(sc.httpStatus(), render(t));
    }

    // --------------------------------------------------------------- capture

    public StubResponse capture(String requestId, String id, ChaseCaptureRequest req) {
        Scenario def = defaultRow(Step.CAPTURE);
        String last4;
        synchronized (this) {
            Txn known = byId.get(id);
            last4 = known == null ? null : known.last4;
        }
        Scenario sc = last4 == null ? def : scenarios.find(last4, Step.CAPTURE).orElse(def);
        pause(sc);
        return doCapture(requestId, id, req, sc, def);
    }

    private synchronized StubResponse doCapture(String requestId, String id, ChaseCaptureRequest req, Scenario sc,
                                                Scenario def) {
        Txn t = byId.get(id);
        if (t == null) {
            throw new StubException(404, "transaction not found");
        }
        if (requestId != null && captureRequestIds.containsKey(requestId)) {
            return new StubResponse(200, render(t));     // idempotent replay of the capture
        }
        boolean fail = sc.httpStatus() >= 400;
        if (sc.effect() == Effect.NONE) {                // refused: nothing is applied
            throw new StubException(sc.httpStatus(), "stub scenario " + sc.cardLast4() + "/CAPTURE (nothing applied)",
                    fill(sc.responseJson(), values(t)));
        }
        settleIfDue(t);
        if (!"AUTHORIZED".equals(t.state)) {
            throw new StubException(409, "transaction is " + t.state + ", cannot capture");
        }
        long amt = req.amount() == null ? t.remainingAuth : req.amount();
        if (amt <= 0 || amt > t.remainingAuth) {
            throw new StubException(422, "capture amount exceeds remaining authorization");
        }
        t.remainingAuth -= amt;
        t.refundable += amt;
        t.lastCapture = amt;
        boolean fin = req.amount() == null || t.remainingAuth == 0
                || Boolean.TRUE.equals(req.isAmountFinal())
                || (req.multiCapture() != null && req.multiCapture().isFinalCapture());
        t.finalAmount = fin;
        if (fin) {
            t.remainingAuth = 0;
            t.state = "CLOSED";
            t.paymentRequestStatus = "CLOSED";
            t.authStatusCode = "CAPTURED";
        } else {
            t.paymentRequestStatus = "OPEN";
        }
        t.captureMethod = req.captureMethod() == null ? t.captureMethod : req.captureMethod();
        t.template = fail || sc.responseJson() == null ? def.responseJson() : sc.responseJson();
        if (requestId != null) {
            captureRequestIds.put(requestId, t.id);
        }
        if (fail) {                                      // applied, but the caller sees the row's error JSON
            throw new StubException(sc.httpStatus(), "stub scenario " + sc.cardLast4() + "/CAPTURE (capture applied)",
                    fill(sc.responseJson(), values(t)));
        }
        return new StubResponse(sc.httpStatus(), render(t));
    }

    // ---------------------------------------------------------------- refund

    private static final int REFUND_WINDOW_MONTHS = 13;

    public StubResponse refund(String requestId, ChaseRefundRequest req) {
        Scenario def = defaultRow(Step.REFUND);
        RefundPaymentMethod pm = req.paymentMethodType();
        String refId = pm == null || pm.transactionReference() == null ? null : pm.transactionReference().transactionReferenceId();
        String last4 = null;
        synchronized (this) {
            Txn known = refId == null ? null : byId.get(refId);
            if (known != null) {
                last4 = known.last4;                     // referenced refund: the card of the original payment
            } else if (pm != null && pm.card() != null && pm.card().accountNumber() != null
                    && pm.card().accountNumber().length() >= 4) {
                String pan = pm.card().accountNumber();  // standalone refund: the card in the request
                last4 = pan.substring(pan.length() - 4);
            }
        }
        Scenario sc = last4 == null ? def : scenarios.find(last4, Step.REFUND).orElse(def);
        pause(sc);
        return doRefund(requestId, req, refId, sc, def);
    }

    private synchronized StubResponse doRefund(String requestId, ChaseRefundRequest req, String refId, Scenario sc,
                                               Scenario def) {
        if (requestId == null || requestId.isBlank()) {
            throw new StubException(400, "request-id header is required");
        }
        Ref existing = refundByRequestId.get(requestId);
        if (existing != null) {
            return new StubResponse(200, fill(existing.json, refundValues(existing)));   // idempotent replay
        }
        Ref r = new Ref();
        r.requestId = requestId;
        r.referenceId = refId;
        r.at = clock.instant();
        r.id = "stub-rfd-%06d".formatted(refSeq + 1);
        r.approvalCode = "R" + (100001 + refSeq);
        Txn t = null;
        if (refId != null) {                             // referenced refund (full or partial)
            t = byId.get(refId);
            if (t == null) {
                throw new StubException(404, "original transaction not found: " + refId);
            }
            if (t.createdAt.atZone(ZoneOffset.UTC).plusMonths(REFUND_WINDOW_MONTHS)
                    .isBefore(clock.instant().atZone(ZoneOffset.UTC))) {
                throw new StubException(400, "refund window of " + REFUND_WINDOW_MONTHS + " months has passed");
            }
            settleIfDue(t);
            if (t.refundable <= 0) {
                throw new StubException(409, "nothing left to refund (not captured yet, or already fully refunded)");
            }
            r.amount = req.amount() == null ? t.refundable : req.amount();
            if (r.amount <= 0 || r.amount > t.refundable) {
                throw new StubException(422, "refund amount exceeds the remaining refundable amount (" + t.refundable + ")");
            }
            r.currency = t.currency;
            r.brand = t.brand;
            r.brandName = t.brandName;
            r.masked = t.masked;
            r.paymentRequestId = t.paymentRequestId;
        } else {                                         // standalone refund: card, amount and currency in the request
            RefundCard c = req.paymentMethodType() == null ? null : req.paymentMethodType().card();
            if (c == null || c.accountNumber() == null || c.accountNumber().length() < 4
                    || req.amount() == null || req.amount() <= 0 || req.currency() == null) {
                throw new StubException(400, "a standalone refund needs card, amount and currency "
                        + "(or paymentMethodType.transactionReference.transactionReferenceId)");
            }
            Txn tmp = newTxn(requestId, new ChaseAuthorizeRequest(null, null, 1, req.currency(), null, null, null,
                    new PaymentMethodType(new Card(c.accountNumber(), null, null, null, null))), c.accountNumber());
            r.amount = req.amount();
            r.currency = req.currency();
            r.brand = tmp.brand;
            r.brandName = tmp.brandName;
            r.masked = tmp.masked;
            r.paymentRequestId = "stub-pr-rfd-%06d".formatted(refSeq + 1);
        }

        String json = sc.responseJson() != null ? sc.responseJson() : def.responseJson();
        boolean fail = sc.httpStatus() >= 400;
        if (sc.effect() == Effect.DECLINE) {
            r.amount = 0;                                // declined: nothing is refunded
        }
        r.remainingAfter = t == null ? 0 : t.refundable - (sc.effect() == Effect.APPLY ? r.amount : 0);
        if (sc.effect() == Effect.NONE) {                // nothing refunded, nothing recorded: just the stored body
            throw new StubException(sc.httpStatus(), "stub scenario " + sc.cardLast4() + "/REFUND (nothing refunded)",
                    fill(json, refundValues(r)));
        }
        if (sc.effect() == Effect.APPLY && t != null) {  // take the money back
            t.refundable -= r.amount;
        }
        r.json = fail ? def.responseJson() : json;       // a lost-response row records a normal approval
        refSeq++;
        refundById.put(r.id, r);
        refundByRequestId.put(requestId, r);

        if (fail) {                                      // refunded, but the caller sees the stored error JSON
            throw new StubException(sc.httpStatus(), "stub scenario " + sc.cardLast4() + "/REFUND (refund applied)",
                    fill(json, refundValues(r)));
        }
        return new StubResponse(sc.httpStatus(), fill(r.json, refundValues(r)));
    }

    public synchronized Optional<String> refundById(String id) {
        Ref r = refundById.get(id);
        return r == null ? Optional.empty() : Optional.of(fill(r.json, refundValues(r)));
    }

    public synchronized Optional<String> refundByRequestId(String requestId) {
        Ref r = refundByRequestId.get(requestId);
        return r == null ? Optional.empty() : Optional.of(fill(r.json, refundValues(r)));
    }

    // ---------------------------------------------------------------- lookup

    public synchronized Optional<String> byId(String id) {
        Txn t = byId.get(id);
        if (t == null) {
            return Optional.empty();
        }
        settleIfDue(t);
        return Optional.of(render(t));
    }

    public synchronized Optional<String> byRequestId(String requestId) {
        Txn t = byRequestId.get(requestId);
        if (t == null) {
            return Optional.empty();
        }
        settleIfDue(t);
        return Optional.of(render(t));
    }

    // -------------------------------------------------------------- internals

    private Scenario defaultRow(Step step) {
        return scenarios.find(ScenarioRepository.DEFAULT_CARD, step).orElseThrow(() -> new StubException(500,
                "jpm_stub_scenario has no default row ('*', " + step + ") - re-run schema.sql"));
    }

    private Txn newTxn(String requestId, ChaseAuthorizeRequest req, String pan) {
        Txn t = new Txn();
        t.id = "stub-txn-%06d".formatted(seq + 1);
        t.requestId = requestId;
        t.currency = req.currency();
        t.requested = req.amount();
        t.createdAt = clock.instant();
        t.captureMethod = req.captureMethod() == null ? "NOW" : req.captureMethod();
        t.paymentRequestId = "stub-pr-%06d".formatted(seq + 1);
        t.authId = "stub-auth-%06d".formatted(seq + 1);
        t.authStatusCode = "DECLINED";
        t.paymentRequestStatus = "CLOSED";
        t.last4 = pan.substring(pan.length() - 4);
        t.state = "CLOSED";
        applyBrand(t, pan);
        return t;
    }

    private static String last4Of(ChaseAuthorizeRequest req) {
        Card card = req.paymentMethodType() == null ? null : req.paymentMethodType().card();
        String pan = card == null ? null : card.accountNumber();
        return pan == null || pan.length() < 4 ? null : pan.substring(pan.length() - 4);
    }

    private static void pause(Scenario sc) {
        if (sc.delayMs() > 0) {
            try {
                Thread.sleep(sc.delayMs());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private void settleIfDue(Txn t) {
        if ("DELAYED".equals(t.captureMethod) && "AUTHORIZED".equals(t.state)
                && t.captureTime != null && !clock.instant().isBefore(t.captureTime)) {
            t.refundable += t.remainingAuth;
            t.lastCapture = t.remainingAuth;
            close(t);
        }
    }

    private void close(Txn t) {
        t.refundable = Math.max(t.refundable, t.amount);
        t.lastCapture = t.lastCapture == 0 ? t.amount : t.lastCapture;
        t.remainingAuth = 0;
        t.state = "CLOSED";
        t.paymentRequestStatus = "CLOSED";
        t.authStatusCode = "CAPTURED";
        t.finalAmount = true;
    }

    private static void applyBrand(Txn t, String pan) {
        switch (pan.charAt(0)) {
            case '4' -> { t.brand = "VISA"; t.brandName = "Visa"; }
            case '5', '2' -> { t.brand = "MC"; t.brandName = "Mastercard"; }
            case '3' -> { t.brand = "AMEX"; t.brandName = "American Express"; }
            case '6' -> { t.brand = "DISC"; t.brandName = "Discover"; }
            default -> { t.brand = "OTHER"; t.brandName = "Other"; }
        }
        t.masked = "X".repeat(Math.max(0, pan.length() - 4)) + pan.substring(pan.length() - 4);
    }

    // ------------------------------------------------- JSON from the table

    private String render(Txn t) {
        return fill(t.template, values(t));
    }

    /** the values a response_json template can use as ${name} */
    private Map<String, String> values(Txn t) {
        Map<String, String> v = new HashMap<>();
        v.put("transactionId", t.id);
        v.put("requestId", t.requestId);
        v.put("paymentRequestId", t.paymentRequestId);
        v.put("authorizationId", t.authId);
        v.put("approvalCode", t.approvalCode == null ? "" : t.approvalCode);
        v.put("now", clock.instant().toString());
        v.put("captureTime", t.captureTime == null ? "" : t.captureTime.toString());
        v.put("transactionState", t.state);
        v.put("paymentRequestStatus", t.paymentRequestStatus);
        v.put("authStatusCode", t.authStatusCode);
        v.put("captureMethod", t.captureMethod);
        v.put("currency", t.currency);
        v.put("amount", String.valueOf(t.amount));
        v.put("approvedAmount", String.valueOf(t.amount));
        v.put("requestedAmount", String.valueOf(t.requested));
        v.put("captureAmount", String.valueOf(t.lastCapture));
        v.put("totalAuthorizedAmount", String.valueOf(t.amount));
        v.put("remainingAuthAmount", String.valueOf(t.remainingAuth));
        v.put("remainingRefundableAmount", String.valueOf(t.refundable));
        v.put("isAmountFinal", String.valueOf(t.finalAmount));
        v.put("cardType", t.brand);
        v.put("cardTypeName", t.brandName);
        v.put("maskedAccountNumber", t.masked);
        return v;
    }

    /** the values a REFUND response_json can use as ${name} */
    private Map<String, String> refundValues(Ref r) {
        Map<String, String> v = new HashMap<>();
        v.put("transactionId", r.id);
        v.put("requestId", r.requestId);
        v.put("transactionReferenceId", r.referenceId == null ? "" : r.referenceId);
        v.put("amount", String.valueOf(r.amount));
        v.put("currency", r.currency);
        v.put("remainingRefundableAmount", String.valueOf(r.remainingAfter));
        v.put("approvalCode", r.approvalCode);
        v.put("hostReferenceId", "stub-host-" + r.id);
        v.put("transactionDate", r.at.toString());
        v.put("paymentRequestId", r.paymentRequestId);
        v.put("cardType", r.brand);
        v.put("cardTypeName", r.brandName);
        v.put("maskedAccountNumber", r.masked);
        return v;
    }

    /** replace every ${name}; an unknown name is left as typed so the mistake is visible in the output */
    static String fill(String template, Map<String, String> values) {
        Matcher m = PLACEHOLDER.matcher(template);
        StringBuilder out = new StringBuilder();
        while (m.find()) {
            String v = values.get(m.group(1));
            m.appendReplacement(out, Matcher.quoteReplacement(v == null ? m.group() : v));
        }
        m.appendTail(out);
        return out.toString();
    }
}
