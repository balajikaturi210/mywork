package com.zbp.chasepay;

import com.zbp.chasepay.client.model.ChaseModel.*;
import com.zbp.chasepay.stub.ScenarioRepository;
import com.zbp.chasepay.stub.ScenarioRepository.Effect;
import com.zbp.chasepay.stub.ScenarioRepository.Scenario;
import com.zbp.chasepay.stub.ScenarioRepository.Step;
import com.zbp.chasepay.stub.JpmStubService;
import com.zbp.chasepay.stub.StubException;
import org.junit.jupiter.api.Test;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class JpmStubServiceTest {

    static final class MutableClock extends Clock {
        Instant now = Instant.parse("2026-10-14T10:00:00Z");
        public java.time.ZoneId getZone() { return ZoneOffset.UTC; }
        public Clock withZone(java.time.ZoneId z) { return this; }
        public Instant instant() { return now; }
    }


    private static Scenario row(String last4, Step step, Effect effect, int http, int pct, String json) {
        return new Scenario(last4, step, effect, http, pct, 0, json, null);
    }

    /** the REAL seed rows: read from src/main/resources/schema.sql, so the shipped JSON templates are what is tested */
    static Map<String, Scenario> seed() {
        Map<String, Scenario> m = new java.util.concurrent.ConcurrentHashMap<>();
        try (var in = JpmStubServiceTest.class.getResourceAsStream("/schema.sql")) {
            String sql = new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
            java.util.regex.Matcher st = java.util.regex.Pattern
                    .compile("\\nSELECT (.*?)\\nWHERE NOT EXISTS", java.util.regex.Pattern.DOTALL).matcher(sql);
            while (st.find()) {
                java.util.List<String> v = sqlValues(st.group(1));
                Scenario s = new Scenario(v.get(0), Step.valueOf(v.get(1)), Effect.valueOf(v.get(2)),
                        Integer.parseInt(v.get(3)), Integer.parseInt(v.get(4)), Integer.parseInt(v.get(5)),
                        v.get(6), v.get(7));
                m.put(s.cardLast4() + ":" + s.step(), s);
            }
        } catch (java.io.IOException e) {
            throw new IllegalStateException(e);
        }
        return m;
    }

    /** splits  'a', 'b''c', 5, NULL  into [a, b'c, 5, null] */
    private static java.util.List<String> sqlValues(String line) {
        java.util.List<String> out = new java.util.ArrayList<>();
        int i = 0;
        while (i < line.length()) {
            char c = line.charAt(i);
            if (c == '\'') {
                StringBuilder b = new StringBuilder();
                i++;
                while (true) {
                    char d = line.charAt(i++);
                    if (d == '\'') {
                        if (i < line.length() && line.charAt(i) == '\'') { b.append('\''); i++; } else break;
                    } else b.append(d);
                }
                out.add(b.toString());
            } else if (Character.isLetterOrDigit(c)) {
                int st = i;
                while (i < line.length() && Character.isLetterOrDigit(line.charAt(i))) i++;
                String w = line.substring(st, i);
                out.add(w.equals("NULL") ? null : w);
            } else {
                i++;
            }
        }
        return out;
    }

    static ChasePaymentResponse authz(JpmStubService s, String rid, ChaseAuthorizeRequest r) {
        return StubJson.toResponse(s.authorize(rid, r).body());
    }

    static ChasePaymentResponse cap(JpmStubService s, String rid, String id, ChaseCaptureRequest r) {
        return StubJson.toResponse(s.capture(rid, id, r).body());
    }

    static java.util.Optional<ChasePaymentResponse> byIdR(JpmStubService s, String id) {
        return s.byId(id).map(StubJson::toResponse);
    }

    static java.util.Optional<ChasePaymentResponse> byRidR(JpmStubService s, String rid) {
        return s.byRequestId(rid).map(StubJson::toResponse);
    }

    /** stands in for the table: same class, find() answers from a map instead of JDBC */
    static ScenarioRepository fakeTable(Map<String, Scenario> rows) {
        return new ScenarioRepository(null) {
            @Override public java.util.Optional<Scenario> find(String last4, Step step) {
                return java.util.Optional.ofNullable(rows.get(last4 + ":" + step));
            }
        };
    }

    private final MutableClock clock = new MutableClock();
    private final JpmStubService stub = new JpmStubService(clock, fakeTable(seed()));

    private static ChaseAuthorizeRequest auth(String method, String pan, long amount, String partial, String captureTime) {
        return new ChaseAuthorizeRequest(method, captureTime, amount, "USD", true, partial, null,
                new PaymentMethodType(new Card(pan, new Expiry(12, 2030), null, null, null)));
    }

    @Test
    void captureNowIsClosedAndRefundable() {
        ChasePaymentResponse r = authz(stub, "r1", auth("NOW", "4111111111111111", 1000, "NOT_SUPPORTED", null));
        assertEquals("SUCCESS", r.responseStatus());
        assertEquals("CLOSED", r.transactionState());
        assertEquals(1000L, r.amount());
        assertEquals(0L, r.remainingAuthAmount());
        assertEquals(1000L, r.remainingRefundableAmount());
        assertEquals("Visa", r.paymentMethodType().card().cardTypeName());
        assertEquals("XXXXXXXXXXXX1111", r.paymentMethodType().card().maskedAccountNumber());
        assertNull(r.paymentMethodType().card().accountNumber(), "PAN must never be echoed");
    }

    @Test
    void sameRequestIdIsIdempotent() {
        ChasePaymentResponse a = authz(stub, "r1", auth("NOW", "4111111111111111", 1000, null, null));
        ChasePaymentResponse b = authz(stub, "r1", auth("NOW", "4111111111111111", 1000, null, null));
        assertEquals(a.transactionId(), b.transactionId());
    }

    @Test
    void declineTrigger() {
        ChasePaymentResponse r = authz(stub, "r2", auth("NOW", "4000000000000002", 500, null, null));
        assertEquals("DENIED", r.responseStatus());
        assertEquals("DECLINED", r.responseCode());
        assertEquals(0L, r.amount());
    }

    @Test
    void partialApprovalTrigger() {
        ChasePaymentResponse r = authz(stub, "r3", auth("MANUAL", "4000000000000036", 1000, "SUPPORTED", null));
        assertEquals("PARTIAL_APPROVAL", r.responseCode());
        assertEquals(500L, r.amount());
        assertEquals("AUTHORIZED", r.transactionState());
    }

    @Test
    void lostResponseRecordsTransactionButThrows500() {
        StubException e = assertThrows(StubException.class,
                () -> authz(stub, "r4", auth("NOW", "4000000000000119", 700, null, null)));
        assertEquals(500, e.status());
        assertTrue(byRidR(stub, "r4").isPresent(), "lookup by requestId must find the lost transaction");
    }

    @Test
    void timeoutTriggerRecordsNothing() {
        StubException e = assertThrows(StubException.class,
                () -> authz(stub, "r5", auth("NOW", "4000000000000408", 700, null, null)));
        assertEquals(504, e.status());
        assertTrue(byRidR(stub, "r5").isEmpty());
    }

    @Test
    void manualFullCapture() {
        ChasePaymentResponse a = authz(stub, "r6", auth("MANUAL", "5555555555554444", 2000, null, null));
        assertEquals("AUTHORIZED", a.transactionState());
        assertEquals(2000L, a.remainingAuthAmount());
        ChasePaymentResponse c = cap(stub, "c6", a.transactionId(), new ChaseCaptureRequest("NOW", null, null, null));
        assertEquals("CLOSED", c.transactionState());
        assertEquals(0L, c.remainingAuthAmount());
        assertEquals(2000L, c.remainingRefundableAmount());
    }

    @Test
    void multiCaptureKeepsAuthOpenUntilFinal() {
        ChasePaymentResponse a = authz(stub, "r7", auth("MANUAL", "4111111111111111", 3000, null, null));
        ChasePaymentResponse c1 = cap(stub, "c7a", a.transactionId(),
                new ChaseCaptureRequest(null, 1000L, null, new MultiCapture(1, 2, false)));
        assertEquals("AUTHORIZED", c1.transactionState());
        assertEquals(2000L, c1.remainingAuthAmount());
        ChasePaymentResponse c2 = cap(stub, "c7b", a.transactionId(),
                new ChaseCaptureRequest(null, 2000L, null, new MultiCapture(2, 2, true)));
        assertEquals("CLOSED", c2.transactionState());
        assertEquals(3000L, c2.remainingRefundableAmount());
    }

    @Test
    void captureMoreThanRemainingIsRejected() {
        ChasePaymentResponse a = authz(stub, "r8", auth("MANUAL", "4111111111111111", 1000, null, null));
        StubException e = assertThrows(StubException.class, () -> cap(stub, "c8", a.transactionId(),
                new ChaseCaptureRequest("NOW", 1001L, true, null)));
        assertEquals(422, e.status());
    }

    @Test
    void captureOfClosedTransactionConflicts() {
        ChasePaymentResponse a = authz(stub, "r9", auth("NOW", "4111111111111111", 1000, null, null));
        StubException e = assertThrows(StubException.class, () -> cap(stub, "c9", a.transactionId(),
                new ChaseCaptureRequest("NOW", null, null, null)));
        assertEquals(409, e.status());
    }

    @Test
    void delayedCaptureHappensAfterCaptureTime() {
        ChasePaymentResponse a = authz(stub, "r10", auth("DELAYED", "4111111111111111", 900, null, null));
        assertEquals("AUTHORIZED", a.transactionState());
        clock.now = clock.now.plus(Duration.ofMinutes(119));
        assertEquals("AUTHORIZED", byIdR(stub, a.transactionId()).orElseThrow().transactionState());
        clock.now = clock.now.plus(Duration.ofMinutes(2));
        ChasePaymentResponse after = byIdR(stub, a.transactionId()).orElseThrow();
        assertEquals("CLOSED", after.transactionState());
        assertEquals(900L, after.remainingRefundableAmount());
    }

    @Test
    void unlistedCardIsApprovedAndPartialNeedsSupport() {
        // 0036 = PARTIAL, but only when the caller said SUPPORTED
        ChasePaymentResponse full = authz(stub, "u1", auth("MANUAL", "4000000000000036", 1000, "NOT_SUPPORTED", null));
        assertEquals(1000L, full.amount());
        assertEquals("APPROVED", authz(stub, "u2", auth("NOW", "4222222222222222", 1000, null, null)).responseCode());
    }

    @Test
    void captureRejectedLeavesAuthorizationUsable() {
        ChasePaymentResponse a = authz(stub, "c1", auth("MANUAL", "4000000000000777", 5000, null, null));
        StubException e = assertThrows(StubException.class,
                () -> cap(stub, "cap-1", a.transactionId(), new ChaseCaptureRequest("NOW", null, null, null)));
        assertEquals(400, e.status());
        assertEquals("capture rejected (stub scenario)", StubJson.obj(e.body()).get("responseMessage"));
        assertEquals("AUTHORIZED", byIdR(stub, a.transactionId()).orElseThrow().transactionState());
        assertEquals(5000L, byIdR(stub, a.transactionId()).orElseThrow().remainingAuthAmount());
    }

    @Test
    void captureLostResponseIsAppliedButFails() {
        ChasePaymentResponse a = authz(stub, "c2", auth("MANUAL", "4000000000000778", 5000, null, null));
        StubException e = assertThrows(StubException.class,
                () -> cap(stub, "cap-2", a.transactionId(), new ChaseCaptureRequest("NOW", null, null, null)));
        assertEquals(500, e.status());
        assertEquals("CLOSED", byIdR(stub, a.transactionId()).orElseThrow().transactionState());
        // replaying the same capture request-id returns the result instead of failing again
        assertEquals("CLOSED", cap(stub, "cap-2", a.transactionId(), new ChaseCaptureRequest("NOW", null, null, null)).transactionState());
    }

    @Test
    void lostResponseReplayReturnsTheStoredResult() {
        assertThrows(StubException.class, () -> authz(stub, "l1", auth("NOW", "4000000000000119", 700, null, null)));
        assertEquals("SUCCESS", authz(stub, "l1", auth("NOW", "4000000000000119", 700, null, null)).responseStatus());
    }

    @Test
    void resetClearsStoredTransactions() {
        authz(stub, "z1", auth("NOW", "4111111111111111", 1000, null, null));
        stub.reset();
        assertTrue(byRidR(stub, "z1").isEmpty());
        assertEquals("stub-txn-000001", authz(stub, "z2", auth("NOW", "4111111111111111", 1000, null, null)).transactionId());
    }

    @Test
    void changingTheTableChangesTheNextCall() {
        Map<String, Scenario> rows = seed();
        JpmStubService s = new JpmStubService(clock, fakeTable(rows));
        assertEquals("SUCCESS", authz(s, "t1", auth("NOW", "4000000000000555", 100, null, null)).responseStatus());
        rows.put("0555:AUTHORIZE", row("0555", Step.AUTHORIZE, Effect.NONE, 504,100,
                "{\"responseStatus\":\"ERROR\",\"responseCode\":\"TIMEOUT\",\"responseMessage\":\"slow\"}"));  // INSERT
        StubException e = assertThrows(StubException.class, () -> authz(s, "t2", auth("NOW", "4000000000000555", 100, null, null)));
        assertEquals(504, e.status());
        assertEquals("slow", StubJson.obj(e.body()).get("responseMessage"));
        rows.remove("0555:AUTHORIZE");                                                                                 // DELETE
        assertEquals("SUCCESS", authz(s, "t3", auth("NOW", "4000000000000555", 100, null, null)).responseStatus());
    }

    @Test
    void wholeResponseComesFromTheRowIncludingCustomFields() {
        Map<String, Scenario> rows = seed();
        rows.put("0555:AUTHORIZE", row("0555", Step.AUTHORIZE, Effect.DECLINE, 200, 100,
                "{\"transactionId\":\"${transactionId}\",\"responseStatus\":\"DENIED\",\"responseCode\":\"LOST_STOLEN_CARD\","
                        + "\"responseMessage\":\"Pick up card\",\"echo\":\"${requestId}/${maskedAccountNumber}\",\"amt\":${requestedAmount}}"));
        JpmStubService s = new JpmStubService(clock, fakeTable(rows));
        String body = s.authorize("c1", auth("NOW", "4000000000000555", 1234, null, null)).body();
        Map<String, Object> m = StubJson.obj(body);
        assertEquals("LOST_STOLEN_CARD", m.get("responseCode"));
        assertEquals("c1/XXXXXXXXXXXX0555", m.get("echo"));
        assertEquals(1234L, m.get("amt"));
        assertFalse(body.contains("4000000000000555"));
    }

    @Test
    void seededDeclineRowsReturnTheirOwnCodes() {
        ChasePaymentResponse r = authz(stub, "d1", auth("NOW", "4000000000000051", 100, null, null));
        assertEquals("DENIED", r.responseStatus());
        assertEquals("INSUFFICIENT_FUNDS", r.responseCode());
        assertEquals("CARD_EXPIRED", authz(stub, "d2", auth("NOW", "4000000000000054", 100, null, null)).responseCode());
    }

    @Test
    void everySeededTemplateRendersToValidJson() {
        // for each row the stub is driven through, the body must parse; unreplaced ${...} would break parsing
        for (String pan : new String[]{"4111111111111111", "4000000000000002", "4000000000000036", "4000000000000051"}) {
            String body = stub.authorize("v-" + pan, auth("MANUAL", pan, 1000, "SUPPORTED", null)).body();
            assertFalse(body.contains("${"), body);
            StubJson.obj(body);
        }
        for (Scenario s : seed().values()) {
            if (s.responseJson() != null) {
                assertTrue(s.responseJson().strip().startsWith("{"));
            }
        }
    }

    @Test
    void errorRowRecordsOrNotAccordingToEffect() {
        assertEquals(500, assertThrows(StubException.class,
                () -> authz(stub, "e1", auth("NOW", "4000000000000119", 100, null, null))).status());
        assertTrue(byRidR(stub, "e1").isPresent());                       // effect APPROVE: recorded
        assertEquals("SUCCESS", byRidR(stub, "e1").orElseThrow().responseStatus());
        StubException t = assertThrows(StubException.class,
                () -> authz(stub, "e2", auth("NOW", "4000000000000408", 100, null, null)));
        assertEquals(504, t.status());
        assertEquals("TIMEOUT", StubJson.obj(t.body()).get("responseCode"));
        assertTrue(byRidR(stub, "e2").isEmpty());                         // effect NONE: nothing recorded
    }

    @Test
    void missingDefaultRowIsReportedClearly() {
        JpmStubService s = new JpmStubService(clock, fakeTable(new java.util.concurrent.ConcurrentHashMap<>()));
        StubException e = assertThrows(StubException.class, () -> authz(s, "x", auth("NOW", "4111111111111111", 100, null, null)));
        assertEquals(500, e.status());
        assertTrue(e.getMessage().contains("default row"));
    }

    @Test
    void scenarioRowValidatesItself() {
        assertThrows(IllegalArgumentException.class, () -> row("12", Step.AUTHORIZE, Effect.APPROVE, 200, 100, null));
        assertThrows(IllegalArgumentException.class, () -> row("0001", Step.AUTHORIZE, Effect.APPLY, 200, 100, null));
        assertThrows(IllegalArgumentException.class, () -> row("0001", Step.CAPTURE, Effect.DECLINE, 200, 100, null));
        assertThrows(IllegalArgumentException.class, () -> row("0001", Step.AUTHORIZE, Effect.DECLINE, 200, 100, null));
        assertThrows(IllegalArgumentException.class, () -> row("0001", Step.AUTHORIZE, Effect.APPROVE, 500, 100, null));
        assertThrows(IllegalArgumentException.class, () -> row("0001", Step.AUTHORIZE, Effect.APPROVE, 200, 0, null));
        assertThrows(IllegalArgumentException.class, () -> row("0001", Step.AUTHORIZE, Effect.APPROVE, 200, 100, "not json"));
        row("*", Step.AUTHORIZE, Effect.APPROVE, 200, 100, null);   // fine: default-row key, JSON optional
    }
}
