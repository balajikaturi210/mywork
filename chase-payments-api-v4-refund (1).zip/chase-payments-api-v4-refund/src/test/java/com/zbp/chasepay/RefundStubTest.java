package com.zbp.chasepay;

import com.zbp.chasepay.client.model.ChaseModel.*;
import com.zbp.chasepay.stub.JpmStubService;
import com.zbp.chasepay.stub.ScenarioRepository.Effect;
import com.zbp.chasepay.stub.ScenarioRepository.Scenario;
import com.zbp.chasepay.stub.ScenarioRepository.Step;
import com.zbp.chasepay.stub.StubException;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/** Refund API of the stub: full, partial (repeatable), standalone, table scenarios, 13-month window. */
class RefundStubTest {

    private final JpmStubServiceTest.MutableClock clock = new JpmStubServiceTest.MutableClock();
    private final JpmStubService stub = new JpmStubService(clock, JpmStubServiceTest.fakeTable(JpmStubServiceTest.seed()));

    private ChasePaymentResponse pay(JpmStubService s, String rid, String pan, long amount, String method) {
        return StubJson.toResponse(s.authorize(rid, new ChaseAuthorizeRequest(method, null, amount, "USD", true, null, null,
                new PaymentMethodType(new Card(pan, new Expiry(12, 2030), null, null, null)))).body());
    }

    private static ChaseRefundRequest ref(String id, Long amount) {
        return new ChaseRefundRequest(amount, "USD", null, null, null,
                new RefundPaymentMethod(new TransactionReference(id), null));
    }

    private Map<String, Object> refund(String rid, ChaseRefundRequest r) {
        return StubJson.obj(stub.refund(rid, r).body());
    }

    @Test
    void fullRefundUsesRequestFieldsAndTableFields() {
        ChasePaymentResponse a = pay(stub, "p1", "4111111111111111", 1000, "NOW");
        Map<String, Object> m = refund("r1", ref(a.transactionId(), null));
        assertEquals("SUCCESS", m.get("responseStatus"));            // from the table
        assertEquals("APPROVED", m.get("responseCode"));
        assertEquals(1000L, m.get("amount"));                         // from the original payment
        assertEquals("USD", m.get("currency"));
        assertEquals("r1", m.get("requestId"));
        assertEquals(a.transactionId(), m.get("transactionReferenceId"));
        assertEquals(0L, m.get("remainingRefundableAmount"));
        assertTrue(m.get("transactionId").toString().startsWith("stub-rfd-"));
    }

    @Test
    void severalPartialRefundsUntilNothingIsLeft() {
        ChasePaymentResponse a = pay(stub, "p2", "4111111111111111", 1000, "NOW");
        assertEquals(400L, refund("r2a", ref(a.transactionId(), 600L)).get("remainingRefundableAmount"));
        assertEquals(100L, refund("r2b", ref(a.transactionId(), 300L)).get("remainingRefundableAmount"));
        assertEquals(422, assertThrows(StubException.class, () -> stub.refund("r2c", ref(a.transactionId(), 200L))).status());
        assertEquals(0L, refund("r2d", ref(a.transactionId(), null)).get("remainingRefundableAmount"));   // the last 100
        assertEquals(409, assertThrows(StubException.class, () -> stub.refund("r2e", ref(a.transactionId(), null))).status());
        assertEquals(0L, StubJson.toResponse(stub.byId(a.transactionId()).orElseThrow()).remainingRefundableAmount());
    }

    @Test
    void uncapturedAuthorizationCannotBeRefunded() {
        ChasePaymentResponse a = pay(stub, "p3", "4111111111111111", 500, "MANUAL");
        assertEquals(409, assertThrows(StubException.class, () -> stub.refund("r3", ref(a.transactionId(), null))).status());
        stub.capture("c3", a.transactionId(), new ChaseCaptureRequest("NOW", 200L, true, null));   // partial capture
        assertEquals(200L, refund("r3b", ref(a.transactionId(), null)).get("amount"));            // only captured money
    }

    @Test
    void standaloneRefundNeedsCardAmountAndCurrency() {
        ChaseRefundRequest ok = new ChaseRefundRequest(900L, "USD", "CARDHOLDER", "NOT_STORED", null,
                new RefundPaymentMethod(null, new RefundCard("PAN", "5555555555554444", new Expiry(12, 2030))));
        String body = stub.refund("s1", ok).body();
        Map<String, Object> m = StubJson.obj(body);
        assertEquals(900L, m.get("amount"));
        assertEquals("SUCCESS", m.get("responseStatus"));
        assertFalse(body.contains("5555555555554444"));
        assertTrue(body.contains("XXXXXXXXXXXX4444"));
        assertEquals("", m.get("transactionReferenceId"));
        assertEquals(400, assertThrows(StubException.class, () -> stub.refund("s2", new ChaseRefundRequest(null, "USD", null, null, null,
                new RefundPaymentMethod(null, new RefundCard("PAN", "5555555555554444", null))))).status());
        assertEquals(400, assertThrows(StubException.class, () -> stub.refund("s3", ref(null, null))).status());
    }

    @Test
    void unknownReferenceIsNotFound() {
        assertEquals(404, assertThrows(StubException.class, () -> stub.refund("n1", ref("nope", null))).status());
    }

    @Test
    void refundIsIdempotentAndCanBeLookedUp() {
        ChasePaymentResponse a = pay(stub, "p5", "4111111111111111", 1000, "NOW");
        Map<String, Object> first = refund("r5", ref(a.transactionId(), 400L));
        Map<String, Object> again = refund("r5", ref(a.transactionId(), 400L));       // replay: not refunded twice
        assertEquals(first.get("transactionId"), again.get("transactionId"));
        assertEquals(500L, refund("r5b", ref(a.transactionId(), 100L)).get("remainingRefundableAmount"));   // 1000-400-100
        assertTrue(stub.refundByRequestId("r5").isPresent());
        assertTrue(stub.refundById((String) first.get("transactionId")).isPresent());
        assertTrue(stub.refundByRequestId("missing").isEmpty());
    }

    @Test
    void declinedRefundRowChangesNothing() {
        ChasePaymentResponse a = pay(stub, "p6", "4000000000000881", 1000, "NOW");     // card 0881
        Map<String, Object> m = refund("r6", ref(a.transactionId(), 300L));
        assertEquals("DENIED", m.get("responseStatus"));
        assertEquals("DECLINED", m.get("responseCode"));
        assertEquals(0L, m.get("amount"));
        assertEquals(1000L, m.get("remainingRefundableAmount"));
        assertEquals(1000L, StubJson.toResponse(stub.byId(a.transactionId()).orElseThrow()).remainingRefundableAmount());
    }

    @Test
    void refundTimeoutRefundsNothingAndLostResponseRefunds() {
        ChasePaymentResponse t = pay(stub, "p7", "4000000000000882", 1000, "NOW");     // 0882: 504, nothing refunded
        StubException e = assertThrows(StubException.class, () -> stub.refund("r7", ref(t.transactionId(), 300L)));
        assertEquals(504, e.status());
        assertEquals("TIMEOUT", StubJson.obj(e.body()).get("responseCode"));
        assertTrue(stub.refundByRequestId("r7").isEmpty());
        assertEquals(1000L, StubJson.toResponse(stub.byId(t.transactionId()).orElseThrow()).remainingRefundableAmount());

        ChasePaymentResponse l = pay(stub, "p8", "4000000000000883", 1000, "NOW");     // 0883: 500 but applied
        assertEquals(500, assertThrows(StubException.class, () -> stub.refund("r8", ref(l.transactionId(), 300L))).status());
        assertTrue(stub.refundByRequestId("r8").isPresent());                          // recovery by request-id
        assertEquals(700L, StubJson.obj(stub.refundByRequestId("r8").get()).get("remainingRefundableAmount"));
        assertEquals("SUCCESS", StubJson.obj(stub.refundByRequestId("r8").get()).get("responseStatus"));
    }

    @Test
    void referencedRefundAfter13MonthsIsRejected() {
        ChasePaymentResponse a = pay(stub, "p9", "4111111111111111", 1000, "NOW");
        clock.now = clock.now.plusSeconds(60L * 60 * 24 * 31 * 14);                     // about 14 months later
        assertEquals(400, assertThrows(StubException.class, () -> stub.refund("r9", ref(a.transactionId(), null))).status());
    }

    @Test
    void refundResponseComesFromTheRowSoItCanBeChanged() {
        Map<String, Scenario> rows = JpmStubServiceTest.seed();
        rows.put("0555:REFUND", new Scenario("0555", Step.REFUND, Effect.APPLY, 200, 100, 0,
                "{\"responseStatus\":\"SUCCESS\",\"responseCode\":\"APPROVED\",\"responseMessage\":\"custom\",\"amount\":${amount},\"echo\":\"${requestId}/${maskedAccountNumber}\"}", null));
        JpmStubService s = new JpmStubService(clock, JpmStubServiceTest.fakeTable(rows));
        ChasePaymentResponse a = pay(s, "pa", "4000000000000555", 500, "NOW");
        Map<String, Object> m = StubJson.obj(s.refund("ra", ref(a.transactionId(), null)).body());
        assertEquals("custom", m.get("responseMessage"));
        assertEquals("ra/XXXXXXXXXXXX0555", m.get("echo"));
        assertEquals(500L, m.get("amount"));
    }

    @Test
    void refundRowValidatesItself() {
        assertThrows(IllegalArgumentException.class, () -> new Scenario("0001", Step.REFUND, Effect.APPROVE, 200, 100, 0, "{}", null));
        assertThrows(IllegalArgumentException.class, () -> new Scenario("0001", Step.REFUND, Effect.DECLINE, 200, 100, 0, null, null));
        new Scenario("0001", Step.REFUND, Effect.DECLINE, 200, 100, 0, "{}", null);   // fine
    }
}
