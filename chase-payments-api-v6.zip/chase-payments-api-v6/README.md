# chase-payments-api

Spring Boot 4.0.8 / Java 25 facade over the **J.P. Morgan Online Payments API**
(<https://developer.payments.jpmorgan.com/docs/commerce/online-payments/capabilities/online-payments/how-to/auth-and-capture-payment>)
with a built-in **stub** of the Chase endpoints, because the real endpoint is not reachable yet.

## Design

```
client ──> /api/v1/payments (facade)  ──> PaymentService ──> ChasePaymentsGateway ──> Chase API
                                                                   │                      (or)
                                                                   └── same HTTP calls ──> /stub/jpm/** (JpmStubService)
```

* The stub is a real HTTP stand-in under `/stub/jpm`. Default `chase.base-url` points at it, so the whole
  RestClient / OAuth / header path is exercised. Going live = change env vars, set `CHASE_STUB_ENABLED=false`.
* Facade endpoints

| Method | Path | Chase call |
|---|---|---|
| POST | `/api/v1/payments` | `POST /payments` (captureMethod NOW / DELAYED / MANUAL) |
| POST | `/api/v1/payments/{id}/captures` | `POST /payments/{id}/captures` (full, partial, multi) |
| GET | `/api/v1/payments/{id}` | `GET /payments/{id}` |
| GET | `/api/v1/payments?requestId=` | `GET /payments?requestId=` |

Full contract: `docs/openapi.yaml`.

* **Idempotency / unknown outcomes.** `requestId` is supplied by the caller and forwarded as `request-id`.
  4xx from Chase = definitely not processed. Timeout / I-O / 408 / 429 / 5xx = unknown: the service first asks Chase
  `GET /payments?requestId=`; only if that cannot settle it does the facade answer **504**. Retry with the *same* requestId.
* Declines are **HTTP 200 with `status=DECLINED`** (a business result, not an error).
* Amounts are major units in the facade (`12.34`), minor units on the Chase wire; the currency's fraction digits are used (JPY = 0).
* Luhn and expiry are checked locally before the card leaves the service.
* The PAN is never logged or echoed (`toString` is masked, responses carry only the masked number).

## Stub scenarios (one row per card, only the non-request fields stored)

The stub covers authorize, capture and **refund** (`POST /refunds`, see "Refund API" below).

Each response is built in two parts:

1. **From the request / the stored transaction** (written by the code, nothing to configure): `transactionId`,
   `requestId`, `transactionState`, `captureMethod`, `amount`, `currency`, remaining amounts, card type and masked
   number, `merchantId`, `paymentRequest` (ids and statuses).
2. **From the table**: the JSON in `auth_json` (authorize), `capture_json` (capture) or `refund_json` (refund) with the fields the request cannot
   supply: `responseStatus`, `responseCode`, `responseMessage`, and anything extra you add. If a field name is in the
   stored JSON it **replaces** the request-based one (e.g. `"amount": 500`).

The last four digits of the card pick the row (**one scenario per card**); card `*` is the default row for every other
card. The table is read on every request, so an edited row works on the next call.

| column | meaning |
|---|---|
| card_last4 | the card's last four digits, or `*` for the default row |
| auth_http_status, auth_json | HTTP status and extra JSON for the authorize response (400+ = error body) |
| approved_percent | below 100 = partial approval, only when the request sends `partialAuthorizationSupport=SUPPORTED` |
| capture_http_status, capture_json | the same for the capture response |
| refund_http_status, refund_json | the same for the refund response |
| lost_response | `Y` = the work is done (authorization recorded / capture applied) even though an error is returned |
| delay_ms | wait before answering |

`auth_json` / `capture_json` NULL = the default row's JSON. A stored `"responseStatus": "DENIED"` makes the authorization
a decline (nothing reserved). Field names and codes follow the J.P. Morgan "Authorize and capture a payment" and
Online Payments response-code pages.

Example: a request `{"captureMethod":"MANUAL","amount":1234,"currency":"USD", card ...4444}` on the default row returns

```json
{"transactionId": "stub-txn-000001", "requestId": "<your request-id>", "transactionState": "AUTHORIZED",
 "captureMethod": "MANUAL", "isVoid": false, "approvalCode": "A100001", "amount": 1234, "currency": "USD",
 "remainingAuthAmount": 1234, "remainingRefundableAmount": 0, "paymentMethodType": {...masked card...},
 "merchant": {...}, "paymentRequest": {...},
 "responseStatus": "SUCCESS", "responseCode": "APPROVED", "responseMessage": "Transaction approved by Issuer"}
```

(the last three fields come from the table, the rest from the request).

Seed rows (added by `schema.sql` only when missing):

| last4 | what happens |
|---|---|
| * | default: `APPROVED` / capture `ACCEPTED` |
| 0002 | DENIED `DECLINED` |
| 0051 | DENIED `INSUFFICIENT_FUNDS` |
| 0054 | DENIED `CARD_EXPIRED` |
| 0036 | 50% partial approval (`PARTIAL_APPROVAL`) |
| 0119 | HTTP 500 `SERVER_ERROR`, authorization recorded (lost response) |
| 0408 | HTTP 504 `TIMEOUT`, nothing recorded |
| 0503 | HTTP 503 `SERVICE_UNAVAILABLE`, nothing recorded |
| 0900 | normal approval after 5 seconds |
| 0777 | authorize fine, capture refused (400), authorization stays usable |
| 0778 | authorize fine, capture applied but caller sees HTTP 500 |
| 0881 | refund declined (DENIED `DECLINED`), nothing refunded |
| 0882 | refund HTTP 504 `TIMEOUT`, nothing refunded |
| 0883 | refund HTTP 500 but applied (lost response) |

**Database.** Default is in-memory H2 (rows reset on restart). For k8s set `SPRING_DATASOURCE_URL`,
`SPRING_DATASOURCE_USERNAME`, `SPRING_DATASOURCE_PASSWORD` to a Postgres. If you ran an older version against that
Postgres, run `DROP TABLE jpm_stub_scenario;` once so the new layout is created.

**Change scenarios**

```sql
INSERT INTO jpm_stub_scenario (card_last4, auth_json, note) VALUES ('0555',
 '{"responseStatus": "DENIED", "responseCode": "LOST_STOLEN_CARD", "responseMessage": "Pick up card"}', 'lost card');
UPDATE jpm_stub_scenario SET auth_http_status = 503, lost_response = 'N',
 auth_json = '{"responseStatus": "ERROR", "responseCode": "SERVICE_UNAVAILABLE", "responseMessage": "down"}'
 WHERE card_last4 = '0555';
DELETE FROM jpm_stub_scenario WHERE card_last4 = '0555';
```

```bash
# REST (tester with only the API endpoint): body = the JSON fields, settings = query parameters, all optional
curl https://<host>/stub/jpm/admin/scenarios
curl -X PUT "https://<host>/stub/jpm/admin/scenarios/0555/AUTHORIZE" -H 'Content-Type: application/json' \
  -d '{"responseStatus":"DENIED","responseCode":"LOST_STOLEN_CARD","responseMessage":"Pick up card"}'
curl -X PUT "https://<host>/stub/jpm/admin/scenarios/0556/AUTHORIZE?httpStatus=503&delayMs=3000" -H 'Content-Type: application/json' \
  -d '{"responseStatus":"ERROR","responseCode":"SERVICE_UNAVAILABLE","responseMessage":"down"}'
curl -X PUT "https://<host>/stub/jpm/admin/scenarios/0556/CAPTURE?httpStatus=500&lostResponse=true" -H 'Content-Type: application/json' \
  -d '{"responseStatus":"ERROR","responseCode":"SERVER_ERROR","responseMessage":"capture lost"}'
curl -X PUT "https://<host>/stub/jpm/admin/scenarios/0555/REFUND" -H 'Content-Type: application/json' \
  -d '{"responseStatus":"DENIED","responseCode":"DECLINED","responseMessage":"Refund declined"}'
curl -X DELETE https://<host>/stub/jpm/admin/scenarios/0555
```

The stored JSON is only checked to be an object, not parsed, so test a new row once. The admin endpoints have **no
authentication**: dev/test only. Idempotent per `request-id`; DELAYED captures settle when read after `captureTime`;
transactions are held in memory, so run **one replica**. `POST /stub/jpm/admin/reset` clears stored transactions.

## Refund API (stub)

Follows the J.P. Morgan "Refund a payment" page. Endpoint `POST {base}/refunds` with the `request-id` header (idempotency
key, a replay returns the first answer and never refunds twice) and the same bearer token as the other stub calls.
Lookups: `GET /refunds/{transactionId}` and `GET /refunds?requestId=`.

| refund type | request | what the stub does |
|---|---|---|
| full | `paymentMethodType.transactionReference.transactionReferenceId` = original `transactionId`, no `amount` | refunds everything still refundable |
| partial (repeatable) | the same plus `amount` (minor units) | refunds `amount`; `remainingRefundableAmount` shows the balance; more partial refunds are fine until it is 0 |
| multi-capture | `transactionReferenceId` = a `captureId` (listed under `paymentRequest.captures`) | limited to what is left of THAT capture |
| standalone | `paymentMethodType.card` (`accountNumberType`, `accountNumber`, `expiry`), `amount`, `currency`, optional `initiatorType`, `accountOnFile`; no reference | refunds straight to the card, no original payment needed |

```bash
curl -X POST https://<host>/stub/jpm/api/v2/refunds -H "Authorization: Bearer $TOKEN" -H 'request-id: rfd-001' \
  -H 'Content-Type: application/json' \
  -d '{"amount": 900, "currency": "USD", "merchant": {"merchantSoftware": {"companyName": "Payment Company", "productName": "app", "version": "1"}},
       "paymentMethodType": {"transactionReference": {"transactionReferenceId": "<transactionId from the authorize/capture response>"}}}'
```

Response: request-based fields (`transactionId` of the refund, `requestId`, `transactionReferenceId`, `amount`, `currency`,
`remainingRefundableAmount`, `approvalCode`, `hostReferenceId`, `transactionDate`, `merchant`, masked `paymentMethodType`,
`paymentRequest` with `captures` and `refunds`) plus the table fields (`responseStatus`, `responseCode`,
`responseMessage`, ...) from the `refund_json` of the card. For a referenced refund the card is the one of the ORIGINAL
payment, so use the seed cards 0881 / 0882 / 0883 when authorizing to get a refund decline / timeout / lost response.
`transactionState` of a refund defaults to `AUTHORIZED` as in the docs' example; put `"transactionState": "CLOSED"` in
`refund_json` if you prefer (stored fields replace request-based ones).

Rules the stub enforces (errors are plain `{"responseMessage": ...}` bodies, not table-driven):

| situation | HTTP |
|---|---|
| unknown `transactionReferenceId` | 404 |
| nothing refundable (authorization not captured yet, or already fully refunded) | 409 |
| amount above the remaining refundable amount of the payment / capture, or not positive | 422 |
| referenced refund more than 13 months after the original payment | 400 |
| standalone refund without card, amount or currency (or no reference and no card) | 400 |

Decline: a stored `"responseStatus": "DENIED"` returns the decline and changes nothing. `lost_response = 'Y'` with a
500 refunds first, then returns the error, so recovery by `GET /refunds?requestId=` can be tested.

## Run

```
mvn spring-boot:run
curl -s localhost:8080/api/v1/payments -H 'Content-Type: application/json' -d '{
  "requestId":"order-1001","amount":12.34,"currency":"USD",
  "card":{"number":"4111111111111111","expiryMonth":12,"expiryYear":2030}}'

# two-step
curl -s localhost:8080/api/v1/payments -H 'Content-Type: application/json' -d '{
  "requestId":"order-1002","amount":100.00,"currency":"USD","captureMethod":"MANUAL",
  "card":{"number":"4111111111111111","expiryMonth":12,"expiryYear":2030}}'
curl -s localhost:8080/api/v1/payments/stub-txn-000002/captures -H 'Content-Type: application/json' \
  -d '{"requestId":"cap-1002","amount":40.00,"finalCapture":false}'
```

## Going live – confirm in the JPM portal (assumptions)

The fetched page documents the payloads but **not**: base URL, token URL/scope, required headers, error body shape.
Assumed (from memory, unverified): OAuth2 client-credentials, headers `request-id` and `merchant-id`, paths under
`{base}/payments`. Change `chase.*` in `application.yaml`, and adjust `RestChasePaymentsGateway.headers()` if the portal differs.

## Production notes

* Passing a raw PAN through your service puts it in **PCI DSS scope**. Prefer tokenisation / hosted fields where possible.
* Secrets (`CHASE_CLIENT_ID/SECRET`) via env or a secret store, never in the repo.
* Stub state is in-memory and per-instance; set `CHASE_STUB_ENABLED=false` outside dev/test.

## Verification status

`JpmStubService`, `PaymentService`, `CardValidator` and the model records were compiled and their 49 unit tests passed
using stand-in annotations (Maven Central was not reachable here). The Spring-specific classes
(controllers, `ScenarioRepository` (JDBC), `RestChasePaymentsGateway`, `ChaseTokenProvider`, config) were **not compiled** against real Spring 4 jars –
run `mvn verify` first.
