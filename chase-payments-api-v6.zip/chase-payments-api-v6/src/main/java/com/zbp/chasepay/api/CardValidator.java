package com.zbp.chasepay.api;

import java.time.Clock;
import java.time.YearMonth;

/** Cheap local checks before a card ever leaves the building. */
public final class CardValidator {

    private CardValidator() {
    }

    public static boolean luhn(String pan) {
        int sum = 0;
        boolean dbl = false;
        for (int i = pan.length() - 1; i >= 0; i--) {
            int d = pan.charAt(i) - '0';
            if (d < 0 || d > 9) {
                return false;
            }
            if (dbl) {
                d *= 2;
                if (d > 9) {
                    d -= 9;
                }
            }
            sum += d;
            dbl = !dbl;
        }
        return pan.length() >= 12 && sum % 10 == 0;
    }

    public static boolean expired(int month, int year, Clock clock) {
        return YearMonth.of(year, month).isBefore(YearMonth.now(clock));
    }

    public static void validate(String pan, int month, int year, Clock clock) {
        if (!luhn(pan)) {
            throw new PaymentValidationException("Card number failed the Luhn check");
        }
        if (expired(month, year, clock)) {
            throw new PaymentValidationException("Card is expired");
        }
    }
}
