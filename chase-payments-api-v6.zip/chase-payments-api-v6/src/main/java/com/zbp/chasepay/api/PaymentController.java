package com.zbp.chasepay.api;

import com.zbp.chasepay.api.PaymentDtos.*;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;

/** Facade API: /api/v1/payments */
@RestController
@RequestMapping("/api/v1/payments")
public class PaymentController {

    private final PaymentService service;

    public PaymentController(PaymentService service) {
        this.service = service;
    }

    /** Authorize (and capture, when captureMethod = NOW). Declines return 200 with status=DECLINED. */
    @PostMapping
    public ResponseEntity<PaymentResult> pay(@Valid @RequestBody PaymentRequest request) {
        PaymentResult r = service.pay(request);
        if (r.transactionId() == null) {
            return ResponseEntity.ok(r);
        }
        return ResponseEntity.created(URI.create("/api/v1/payments/" + r.transactionId())).body(r);
    }

    /** Capture a MANUAL authorization: full, partial or multi-capture style. */
    @PostMapping("/{transactionId}/captures")
    public PaymentResult capture(@PathVariable String transactionId, @Valid @RequestBody CaptureRequest request) {
        return service.capture(transactionId, request);
    }

    @GetMapping("/{transactionId}")
    public PaymentResult get(@PathVariable String transactionId) {
        return service.get(transactionId);
    }

    @GetMapping
    public PaymentResult getByRequestId(@RequestParam String requestId) {
        return service.getByRequestId(requestId);
    }
}
