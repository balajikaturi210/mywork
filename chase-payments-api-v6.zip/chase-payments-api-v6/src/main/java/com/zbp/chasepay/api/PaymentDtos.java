package com.zbp.chasepay.api;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;

/** Facade API contract (major-unit amounts; the minor-unit conversion happens in PaymentService). */
public final class PaymentDtos {

    private PaymentDtos() {
    }

    public record CardInput(
            @NotBlank @Pattern(regexp = "\\d{12,19}", message = "must be 12-19 digits") String number,
            @Min(1) @Max(12) int expiryMonth,
            @Min(2000) @Max(2100) int expiryYear) {
        /** never print the PAN */
        @Override
        public String toString() {
            return "CardInput[****" + (number == null || number.length() < 4 ? "" : number.substring(number.length() - 4)) + "]";
        }
    }

    public record PaymentRequest(
            @NotBlank @Size(max = 64) String requestId,   // caller-supplied idempotency key
            @NotNull @DecimalMin("0.01") BigDecimal amount,
            @NotBlank @Pattern(regexp = "[A-Z]{3}") String currency,
            @NotNull @Valid CardInput card,
            /** NOW (default) | MANUAL | DELAYED */
            @Pattern(regexp = "NOW|MANUAL|DELAYED") String captureMethod,
            /** only for DELAYED; Chase default is 120 */
            @Min(1) Integer captureDelayMinutes,
            Boolean allowPartialApproval) {
    }

    public record CaptureRequest(
            @NotBlank @Size(max = 64) String requestId,
            /** null = capture the full remaining authorization */
            @DecimalMin("0.01") BigDecimal amount,
            Boolean finalCapture) {
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record PaymentResult(
            String transactionId,
            String requestId,
            /** APPROVED | PARTIALLY_APPROVED | DECLINED */
            String status,
            String transactionState,
            String responseCode,
            String responseMessage,
            String captureMethod,
            String approvalCode,
            BigDecimal amount,
            String currency,
            BigDecimal remainingAuthAmount,
            String cardBrand,
            String maskedCard) {
    }
}
