package com.zbp.chasepay.api;

public class PaymentNotFoundException extends RuntimeException {
    public PaymentNotFoundException(String what) {
        super("Payment not found: " + what);
    }
}
