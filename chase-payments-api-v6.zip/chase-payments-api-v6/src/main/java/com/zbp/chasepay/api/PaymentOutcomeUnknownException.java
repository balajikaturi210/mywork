package com.zbp.chasepay.api;

/** Chase did not answer and a lookup by requestId could not settle it either. Caller may retry with the SAME requestId. */
public class PaymentOutcomeUnknownException extends RuntimeException {
    public PaymentOutcomeUnknownException(String requestId, Throwable cause) {
        super("Outcome unknown for requestId " + requestId + "; retry with the same requestId", cause);
    }
}
