package com.zbp.chasepay.api;

import com.zbp.chasepay.api.PaymentDtos.*;
import com.zbp.chasepay.client.ChaseApiException;
import com.zbp.chasepay.client.ChasePaymentsGateway;
import com.zbp.chasepay.client.ChaseUnavailableException;
import com.zbp.chasepay.client.model.ChaseModel.*;
import com.zbp.chasepay.config.ChaseProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.util.Currency;
import java.util.Optional;

/**
 * Orchestrates authorize / capture / lookup against Chase.
 * Unknown outcomes (timeout, 5xx) are resolved with GET /payments?requestId= before anything is reported.
 */
@Service
public class PaymentService {

    private static final Logger log = LoggerFactory.getLogger(PaymentService.class);

    private final ChasePaymentsGateway gateway;
    private final ChaseProperties props;
    private final Clock clock;

    public PaymentService(ChasePaymentsGateway gateway, ChaseProperties props, Clock clock) {
        this.gateway = gateway;
        this.props = props;
        this.clock = clock;
    }

    // ------------------------------------------------------------ authorize

    public PaymentResult pay(PaymentRequest in) {
        CardInput c = in.card();
        CardValidator.validate(c.number(), c.expiryMonth(), c.expiryYear(), clock);
        String method = in.captureMethod() == null ? "NOW" : in.captureMethod();
        String captureTime = null;
        if ("DELAYED".equals(method) && in.captureDelayMinutes() != null) {
            captureTime = Instant.now(clock).plusSeconds(in.captureDelayMinutes() * 60L).toString();
        }
        long minor = toMinor(in.amount(), in.currency());

        ChaseAuthorizeRequest req = new ChaseAuthorizeRequest(
                method, captureTime, minor, in.currency(), true,
                Boolean.TRUE.equals(in.allowPartialApproval()) ? "SUPPORTED" : "NOT_SUPPORTED",
                new Merchant(null, new MerchantSoftware(props.software().companyName(),
                        props.software().productName(), props.software().version()), null),
                new PaymentMethodType(new Card(c.number(), new Expiry(c.expiryMonth(), c.expiryYear()),
                        null, null, null)));

        ChasePaymentResponse res;
        try {
            res = gateway.authorize(in.requestId(), req);
        } catch (ChaseApiException e) {
            return declinedFromError(in, e);
        } catch (ChaseUnavailableException e) {
            res = resolveUnknown(in.requestId(), e);
        }
        return toResult(res);
    }

    // -------------------------------------------------------------- capture

    public PaymentResult capture(String transactionId, CaptureRequest in) {
        ChasePaymentResponse auth = gateway.retrieveById(transactionId)
                .orElseThrow(() -> new PaymentNotFoundException(transactionId));
        String currency = auth.currency();
        Long minor = in.amount() == null ? null : toMinor(in.amount(), currency);
        if (minor != null && auth.remainingAuthAmount() != null && minor > auth.remainingAuthAmount()) {
            throw new PaymentValidationException("Capture amount exceeds the remaining authorization");
        }
        ChaseCaptureRequest req = new ChaseCaptureRequest("NOW", minor,
                minor == null ? null : (in.finalCapture() == null ? Boolean.TRUE : in.finalCapture()), null);

        ChasePaymentResponse res;
        try {
            res = gateway.capture(in.requestId(), transactionId, req);
        } catch (ChaseApiException e) {
            throw new PaymentValidationException("Chase rejected the capture: " + e.status() + " " + e.body());
        } catch (ChaseUnavailableException e) {
            res = resolveUnknown(in.requestId(), e);
        }
        return toResult(res);
    }

    // --------------------------------------------------------------- lookup

    public PaymentResult get(String transactionId) {
        return toResult(gateway.retrieveById(transactionId)
                .orElseThrow(() -> new PaymentNotFoundException(transactionId)));
    }

    public PaymentResult getByRequestId(String requestId) {
        return toResult(gateway.retrieveByRequestId(requestId)
                .orElseThrow(() -> new PaymentNotFoundException("requestId=" + requestId)));
    }

    // ------------------------------------------------------------ internals

    /** Did Chase actually process it? Ask by requestId; if it still cannot say, the outcome is unknown. */
    private ChasePaymentResponse resolveUnknown(String requestId, ChaseUnavailableException cause) {
        log.warn("Chase outcome unknown for requestId={} ({}); checking by requestId", requestId, cause.getMessage());
        try {
            Optional<ChasePaymentResponse> found = gateway.retrieveByRequestId(requestId);
            if (found.isPresent()) {
                return found.get();
            }
        } catch (ChaseApiException | ChaseUnavailableException e) {
            log.warn("Lookup by requestId={} failed: {}", requestId, e.getMessage());
        }
        // Not found is still not proof the request never arrived (replication lag) - report unknown.
        throw new PaymentOutcomeUnknownException(requestId, cause);
    }

    private PaymentResult declinedFromError(PaymentRequest in, ChaseApiException e) {
        // 4xx with a declined-style body is a business decline; anything else is a bad request.
        if (e.status() == 402 || e.status() == 422) {
            return new PaymentResult(null, in.requestId(), "DECLINED", null, "DECLINED",
                    e.body(), null, null, null, in.currency(), null, null, null);
        }
        throw new PaymentValidationException("Chase rejected the request: " + e.status() + " " + e.body());
    }

    static PaymentResult toResult(ChasePaymentResponse r) {
        String code = r.responseCode();
        String status = "SUCCESS".equals(r.responseStatus())
                ? ("PARTIAL_APPROVAL".equals(code) ? "PARTIALLY_APPROVED" : "APPROVED")
                : "DECLINED";
        Card card = r.paymentMethodType() == null ? null : r.paymentMethodType().card();
        String currency = r.currency();
        return new PaymentResult(r.transactionId(), r.requestId(), status, r.transactionState(), code,
                r.responseMessage(), r.captureMethod(), r.approvalCode(),
                fromMinor(r.amount(), currency), currency, fromMinor(r.remainingAuthAmount(), currency),
                card == null ? null : card.cardTypeName(), card == null ? null : card.maskedAccountNumber());
    }

    static long toMinor(BigDecimal amount, String currency) {
        int digits = Currency.getInstance(currency).getDefaultFractionDigits();
        try {
            return amount.setScale(digits, java.math.RoundingMode.UNNECESSARY).movePointRight(digits).longValueExact();
        } catch (ArithmeticException e) {
            throw new PaymentValidationException("Amount has too many decimals for " + currency);
        }
    }

    static BigDecimal fromMinor(Long minor, String currency) {
        if (minor == null || currency == null) {
            return null;
        }
        int digits = Currency.getInstance(currency).getDefaultFractionDigits();
        return BigDecimal.valueOf(minor, digits);
    }
}
