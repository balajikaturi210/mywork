package com.zbp.chasepay.client;

/** Chase answered with a 4xx: the request was definitely NOT processed. */
public class ChaseApiException extends RuntimeException {
    private final int status;
    private final String body;

    public ChaseApiException(int status, String body) {
        super("Chase rejected request: HTTP " + status + " " + body);
        this.status = status;
        this.body = body;
    }

    public int status() {
        return status;
    }

    public String body() {
        return body;
    }
}
