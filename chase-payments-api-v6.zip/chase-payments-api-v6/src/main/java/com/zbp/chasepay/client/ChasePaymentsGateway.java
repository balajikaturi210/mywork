package com.zbp.chasepay.client;

import com.zbp.chasepay.client.model.ChaseModel.ChaseAuthorizeRequest;
import com.zbp.chasepay.client.model.ChaseModel.ChaseCaptureRequest;
import com.zbp.chasepay.client.model.ChaseModel.ChasePaymentResponse;

import java.util.Optional;

/** Port to the J.P. Morgan Online Payments API. */
public interface ChasePaymentsGateway {

    /** POST /payments */
    ChasePaymentResponse authorize(String requestId, ChaseAuthorizeRequest request);

    /** POST /payments/{transactionId}/captures */
    ChasePaymentResponse capture(String requestId, String transactionId, ChaseCaptureRequest request);

    /** GET /payments/{transactionId} */
    Optional<ChasePaymentResponse> retrieveById(String transactionId);

    /** GET /payments?requestId=... - used to resolve an unknown outcome */
    Optional<ChasePaymentResponse> retrieveByRequestId(String requestId);
}
