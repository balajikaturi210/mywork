package com.zbp.chasepay.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.zbp.chasepay.config.ChaseProperties;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClient;

import java.time.Clock;
import java.time.Instant;

/** OAuth2 client-credentials token, cached and refreshed 60 s before expiry. (Token URL/scope: confirm in portal.) */
@Component
public class ChaseTokenProvider {

    @JsonIgnoreProperties(ignoreUnknown = true)
    record TokenResponse(@JsonProperty("access_token") String accessToken,
                         @JsonProperty("expires_in") long expiresIn) {
    }

    private final RestClient rest;
    private final ChaseProperties props;
    private final Clock clock;
    private String token;
    private Instant expiresAt = Instant.EPOCH;

    public ChaseTokenProvider(RestClient chaseRestClient, ChaseProperties props, Clock clock) {
        this.rest = chaseRestClient;
        this.props = props;
        this.clock = clock;
    }

    public synchronized String token() {
        if (token == null || clock.instant().isAfter(expiresAt.minusSeconds(60))) {
            refresh();
        }
        return token;
    }

    /** drop the cached token (called after a 401) */
    public synchronized void invalidate() {
        token = null;
        expiresAt = Instant.EPOCH;
    }

    private void refresh() {
        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.add("grant_type", "client_credentials");
        form.add("client_id", props.clientId());
        form.add("client_secret", props.clientSecret());
        form.add("scope", props.scope());
        try {
            TokenResponse r = rest.post().uri(props.tokenUrl())
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                    .body(form).retrieve().body(TokenResponse.class);
            if (r == null || r.accessToken() == null) {
                throw new ChaseUnavailableException("Empty token response", null);
            }
            token = r.accessToken();
            expiresAt = clock.instant().plusSeconds(r.expiresIn());
        } catch (ChaseUnavailableException e) {
            throw e;
        } catch (RuntimeException e) {
            throw new ChaseUnavailableException("Token request failed: " + e.getMessage(), e);
        }
    }
}
