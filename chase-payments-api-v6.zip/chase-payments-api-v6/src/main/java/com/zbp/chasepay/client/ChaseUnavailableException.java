package com.zbp.chasepay.client;

/** Timeout / I/O error / 5xx / 408: Chase MAY have processed the request - outcome unknown. */
public class ChaseUnavailableException extends RuntimeException {
    public ChaseUnavailableException(String message, Throwable cause) {
        super(message, cause);
    }
}
