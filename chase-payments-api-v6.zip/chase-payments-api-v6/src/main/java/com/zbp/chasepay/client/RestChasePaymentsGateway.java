package com.zbp.chasepay.client;

import com.zbp.chasepay.client.model.ChaseModel.ChaseAuthorizeRequest;
import com.zbp.chasepay.client.model.ChaseModel.ChaseCaptureRequest;
import com.zbp.chasepay.client.model.ChaseModel.ChasePaymentResponse;
import com.zbp.chasepay.config.ChaseProperties;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.util.Optional;
import java.util.function.Function;

/**
 * Real HTTP implementation. The same class talks to the in-process stub when chase.base-url points at it.
 * 4xx -> ChaseApiException (definitely not processed); 408/5xx/I-O -> ChaseUnavailableException (unknown).
 */
@Component
public class RestChasePaymentsGateway implements ChasePaymentsGateway {

    private final RestClient rest;
    private final ChaseProperties props;
    private final ChaseTokenProvider tokens;

    public RestChasePaymentsGateway(RestClient chaseRestClient, ChaseProperties props, ChaseTokenProvider tokens) {
        this.rest = chaseRestClient;
        this.props = props;
        this.tokens = tokens;
    }

    @Override
    public ChasePaymentResponse authorize(String requestId, ChaseAuthorizeRequest request) {
        return call(token -> rest.post().uri(props.baseUrl() + "/payments")
                .headers(h -> headers(h, token, requestId))
                .contentType(MediaType.APPLICATION_JSON).body(request)
                .exchange((req, res) -> read(res)));
    }

    @Override
    public ChasePaymentResponse capture(String requestId, String transactionId, ChaseCaptureRequest request) {
        return call(token -> rest.post().uri(props.baseUrl() + "/payments/{id}/captures", transactionId)
                .headers(h -> headers(h, token, requestId))
                .contentType(MediaType.APPLICATION_JSON).body(request)
                .exchange((req, res) -> read(res)));
    }

    @Override
    public Optional<ChasePaymentResponse> retrieveById(String transactionId) {
        return lookup(token -> rest.get().uri(props.baseUrl() + "/payments/{id}", transactionId)
                .headers(h -> headers(h, token, null))
                .exchange((req, res) -> read(res)));
    }

    @Override
    public Optional<ChasePaymentResponse> retrieveByRequestId(String requestId) {
        return lookup(token -> rest.get().uri(props.baseUrl() + "/payments?requestId={r}", requestId)
                .headers(h -> headers(h, token, null))
                .exchange((req, res) -> read(res)));
    }

    // ------------------------------------------------------------------ internals

    /** status + raw body, so that status handling is in one place */
    private record Raw(int status, ChasePaymentResponse ok, String error) {
    }

    private Raw read(org.springframework.web.client.RestClient.RequestHeadersSpec.ConvertibleClientHttpResponse res) throws java.io.IOException {
        int status = res.getStatusCode().value();
        if (status >= 200 && status < 300) {
            return new Raw(status, res.bodyTo(ChasePaymentResponse.class), null);
        }
        return new Raw(status, null, res.bodyTo(String.class));
    }

    private void headers(HttpHeaders h, String token, String requestId) {
        h.setBearerAuth(token);
        h.set("merchant-id", props.merchantId());
        if (requestId != null) {
            h.set("request-id", requestId);
        }
        h.setAccept(java.util.List.of(MediaType.APPLICATION_JSON));
    }

    private ChasePaymentResponse call(Function<String, Raw> op) {
        Raw raw = withAuthRetry(op);
        return parse(raw);
    }

    private Optional<ChasePaymentResponse> lookup(Function<String, Raw> op) {
        Raw raw = withAuthRetry(op);
        if (raw.status() == 404) {
            return Optional.empty();
        }
        return Optional.of(parse(raw));
    }

    private Raw withAuthRetry(Function<String, Raw> op) {
        try {
            Raw raw = op.apply(tokens.token());
            if (raw.status() == 401) {            // token revoked/expired early: refresh once
                tokens.invalidate();
                raw = op.apply(tokens.token());
            }
            return raw;
        } catch (ChaseUnavailableException e) {
            throw e;
        } catch (RestClientException | IllegalStateException e) {
            throw new ChaseUnavailableException("Chase call failed: " + e.getMessage(), e);
        }
    }

    private ChasePaymentResponse parse(Raw raw) {
        int s = raw.status();
        if (s >= 200 && s < 300) {
            if (raw.ok() == null) {
                throw new ChaseUnavailableException("Empty Chase response body", null);
            }
            return raw.ok();
        }
        if (s == 408 || s == 429 || s >= 500) {
            throw new ChaseUnavailableException("Chase HTTP " + s, null);
        }
        throw new ChaseApiException(s, raw.error());
    }
}
