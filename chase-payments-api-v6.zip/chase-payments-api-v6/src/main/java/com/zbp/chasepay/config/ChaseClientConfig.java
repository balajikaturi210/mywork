package com.zbp.chasepay.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

import java.time.Clock;

@Configuration
public class ChaseClientConfig {

    /**
     * RestClient with timeouts. Without them a hung call to the payment provider would hold a request thread
     * forever - and for a payment, "no answer" is the worst case (see the outcome-unknown handling in PaymentService).
     */
    @Bean
    RestClient chaseRestClient(ChaseProperties props) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(props.connectTimeoutMs());
        factory.setReadTimeout(props.readTimeoutMs());
        return RestClient.builder().requestFactory(factory).build();
    }

    @Bean
    Clock clock() {
        return Clock.systemUTC();
    }
}
