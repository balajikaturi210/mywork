package com.zbp.chasepay.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/** chase.* - how to reach the J.P. Morgan Payments API (or the stub). */
@ConfigurationProperties(prefix = "chase")
public record ChaseProperties(
        String baseUrl,
        String tokenUrl,
        String clientId,
        String clientSecret,
        String scope,
        String merchantId,
        Software software,
        int connectTimeoutMs,
        int readTimeoutMs,
        Stub stub) {

    /** sent as merchant.merchantSoftware on every authorization */
    public record Software(String companyName, String productName, String version) {
    }

    public record Stub(boolean enabled) {
    }

    /** the secret must never reach a log line */
    @Override
    public String toString() {
        return "ChaseProperties[baseUrl=" + baseUrl + ", tokenUrl=" + tokenUrl + ", clientId=" + clientId
                + ", merchantId=" + merchantId + ", stub=" + stub + "]";
    }
}
