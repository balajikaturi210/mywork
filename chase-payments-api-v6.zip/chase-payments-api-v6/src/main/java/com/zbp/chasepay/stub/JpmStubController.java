package com.zbp.chasepay.stub;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.zbp.chasepay.client.model.ChaseModel.*;
import com.zbp.chasepay.config.ChaseProperties;
import com.zbp.chasepay.stub.ScenarioRepository.Scenario;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/** Fake JPM endpoints, active only when chase.stub.enabled=true. Base: /stub/jpm */
@RestController
@RequestMapping("/stub/jpm")
@ConditionalOnProperty(name = "chase.stub.enabled", havingValue = "true", matchIfMissing = true)
public class JpmStubController {

    static final String TOKEN_PREFIX = "stub-token-";

    public record TokenResponse(@JsonProperty("access_token") String accessToken,
                                @JsonProperty("token_type") String tokenType,
                                @JsonProperty("expires_in") long expiresIn) {
    }

    private final JpmStubService stub;
    private final ScenarioRepository scenarios;
    private final ChaseProperties props;
    private final AtomicLong tokenSeq = new AtomicLong();

    public JpmStubController(JpmStubService stub, ScenarioRepository scenarios, ChaseProperties props) {
        this.stub = stub;
        this.scenarios = scenarios;
        this.props = props;
    }

    // ---- admin (dev/test only, no authentication): the same rows you can edit with SQL ----

    @GetMapping("/admin/scenarios")
    public List<Scenario> listScenarios() {
        return scenarios.findAll();
    }

    /**
     * set one step of a card's row. PUT /admin/scenarios/{last4}/AUTHORIZE, /CAPTURE or /REFUND ; the BODY is the JSON with the
     * response fields that do NOT come from the request (responseStatus, responseCode, responseMessage, ...).
     * Query parameters (all optional, an omitted one keeps the row's current value): httpStatus, approvedPercent
     * (AUTHORIZE only), lostResponse, delayMs, note. A card with no row yet starts from the defaults.
     */
    @PutMapping("/admin/scenarios/{last4}/{step}")
    public ResponseEntity<?> putScenario(@PathVariable String last4, @PathVariable String step,
                                         @RequestParam(required = false) Integer httpStatus,
                                         @RequestParam(required = false) Integer approvedPercent,
                                         @RequestParam(required = false) Boolean lostResponse,
                                         @RequestParam(required = false) Integer delayMs,
                                         @RequestParam(required = false) String note,
                                         @RequestBody(required = false) String json) {
        try {
            Scenario cur = scenarios.find(last4)
                    .orElse(new Scenario(last4, 200, null, 100, 200, null, 200, null, false, 0, null));
            String body = json == null || json.isBlank() ? null : json.strip();
            String st = step.toUpperCase();
            if (!st.equals("AUTHORIZE") && !st.equals("CAPTURE") && !st.equals("REFUND")) {
                return ResponseEntity.badRequest().body(Map.of("error", "step must be AUTHORIZE, CAPTURE or REFUND"));
            }
            boolean auth = st.equals("AUTHORIZE"), cap = st.equals("CAPTURE"), ref = st.equals("REFUND");
            scenarios.upsert(new Scenario(last4,
                    auth && httpStatus != null ? httpStatus : cur.authHttpStatus(),
                    auth ? body : cur.authJson(),
                    auth && approvedPercent != null ? approvedPercent : cur.approvedPercent(),
                    cap && httpStatus != null ? httpStatus : cur.captureHttpStatus(),
                    cap ? body : cur.captureJson(),
                    ref && httpStatus != null ? httpStatus : cur.refundHttpStatus(),
                    ref ? body : cur.refundJson(),
                    lostResponse != null ? lostResponse : cur.lostResponse(),
                    delayMs != null ? delayMs : cur.delayMs(),
                    note != null ? note : cur.note()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
        return ResponseEntity.ok(scenarios.findAll());
    }

    /** the card is approved normally again (uses the default row) */
    @DeleteMapping("/admin/scenarios/{last4}")
    public ResponseEntity<?> deleteScenario(@PathVariable String last4) {
        if (ScenarioRepository.DEFAULT_CARD.equals(last4)) {
            return ResponseEntity.badRequest().body(Map.of("error", "the default row (*) cannot be deleted; PUT to change it"));
        }
        return scenarios.delete(last4) ? ResponseEntity.ok(scenarios.findAll()) : ResponseEntity.notFound().build();
    }

    /** forget all stored transactions */
    @PostMapping("/admin/reset")
    public Map<String, String> reset() {
        stub.reset();
        return Map.of("status", "cleared");
    }

    @PostMapping(value = "/oauth2/token", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public ResponseEntity<?> token(@RequestParam Map<String, String> form) {
        if (!"client_credentials".equals(form.get("grant_type"))
                || !props.clientId().equals(form.get("client_id"))
                || !props.clientSecret().equals(form.get("client_secret"))) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "invalid_client"));
        }
        return ResponseEntity.ok(new TokenResponse(TOKEN_PREFIX + tokenSeq.incrementAndGet(), "Bearer", 3600));
    }

    @PostMapping("/api/v2/payments")
    public ResponseEntity<?> authorize(@RequestHeader(value = "Authorization", required = false) String auth,
                                       @RequestHeader(value = "request-id", required = false) String requestId,
                                       @RequestBody ChaseAuthorizeRequest body) {
        return guarded(auth, () -> json(stub.authorize(requestId, body)));
    }

    @PostMapping("/api/v2/payments/{id}/captures")
    public ResponseEntity<?> capture(@RequestHeader(value = "Authorization", required = false) String auth,
                                     @RequestHeader(value = "request-id", required = false) String requestId,
                                     @PathVariable String id, @RequestBody ChaseCaptureRequest body) {
        return guarded(auth, () -> json(stub.capture(requestId, id, body)));
    }

    /** refund: referenced (transactionReferenceId = transactionId or captureId) or standalone (card + amount) */
    @PostMapping("/api/v2/refunds")
    public ResponseEntity<?> refund(@RequestHeader(value = "Authorization", required = false) String auth,
                                    @RequestHeader(value = "request-id", required = false) String requestId,
                                    @RequestBody ChaseRefundRequest body) {
        return guarded(auth, () -> json(stub.refund(requestId, body)));
    }

    @GetMapping("/api/v2/refunds/{id}")
    public ResponseEntity<?> refundById(@RequestHeader(value = "Authorization", required = false) String auth,
                                        @PathVariable String id) {
        return guarded(auth, () -> stub.refundById(id).<ResponseEntity<?>>map(b -> json(new JpmStubService.StubResponse(200, b)))
                .orElseGet(() -> ResponseEntity.status(404).body(Map.of("responseMessage", "not found"))));
    }

    @GetMapping("/api/v2/refunds")
    public ResponseEntity<?> refundByRequestId(@RequestHeader(value = "Authorization", required = false) String auth,
                                               @RequestParam String requestId) {
        return guarded(auth, () -> stub.refundByRequestId(requestId).<ResponseEntity<?>>map(b -> json(new JpmStubService.StubResponse(200, b)))
                .orElseGet(() -> ResponseEntity.status(404).body(Map.of("responseMessage", "not found"))));
    }

    @GetMapping("/api/v2/payments/{id}")
    public ResponseEntity<?> byId(@RequestHeader(value = "Authorization", required = false) String auth,
                                  @PathVariable String id) {
        return guarded(auth, () -> stub.byId(id).<ResponseEntity<?>>map(b -> json(new JpmStubService.StubResponse(200, b)))
                .orElseGet(() -> ResponseEntity.status(404).body(Map.of("responseMessage", "not found"))));
    }

    @GetMapping("/api/v2/payments")
    public ResponseEntity<?> byRequestId(@RequestHeader(value = "Authorization", required = false) String auth,
                                         @RequestParam String requestId) {
        return guarded(auth, () -> stub.byRequestId(requestId).<ResponseEntity<?>>map(b -> json(new JpmStubService.StubResponse(200, b)))
                .orElseGet(() -> ResponseEntity.status(404).body(Map.of("responseMessage", "not found"))));
    }

    private ResponseEntity<?> guarded(String auth, java.util.function.Supplier<ResponseEntity<?>> action) {
        if (auth == null || !auth.startsWith("Bearer " + TOKEN_PREFIX)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("responseMessage", "invalid token"));
        }
        try {
            return action.get();
        } catch (StubException e) {
            return e.body() != null
                    ? ResponseEntity.status(e.status()).contentType(MediaType.APPLICATION_JSON).body(e.body())
                    : ResponseEntity.status(e.status()).body(Map.of("responseMessage", e.getMessage()));
        }
    }

    /** the body is the table's JSON, sent exactly as stored (placeholders filled) */
    private static ResponseEntity<String> json(JpmStubService.StubResponse r) {
        return ResponseEntity.status(r.status()).contentType(MediaType.APPLICATION_JSON).body(r.body());
    }
}
