package com.zbp.chasepay.stub;

import com.zbp.chasepay.client.model.ChaseModel.*;
import com.zbp.chasepay.stub.ScenarioRepository.Scenario;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * In-memory imitation of the J.P. Morgan Online Payments API.
 * <p>
 * Every response is built in two parts:
 * <ol>
 *   <li>fields that come from the request / the stored transaction (ids, requestId, amount, currency, captureMethod,
 *       card type and masked number, merchantId, states, remaining amounts), written by {@link #render};</li>
 *   <li>the remaining fields from the JSON stored in table jpm_stub_scenario for the card (auth_json /
 *       capture_json): responseStatus, responseCode, responseMessage and anything else. A field present in the stored
 *       JSON replaces the request-based one.</li>
 * </ol>
 * One row per card (last four digits); card '*' is the default row. The table is read on every request.
 * Refunds (POST /refunds) work on what was captured: referenced by transactionId or captureId, partial or full, several
 * times until nothing is left, or standalone with a card. Idempotent per request-id. DELAYED captures happen lazily when the stub is read after captureTime.
 */
@Service
@ConditionalOnProperty(name = "chase.stub.enabled", havingValue = "true", matchIfMissing = true)
public class JpmStubService {

    public static final int DEFAULT_DELAY_MINUTES = 120;

    /** HTTP status plus the complete JSON body to send */
    public record StubResponse(int status, String body) {
    }

    private static final class Txn {
        String id, requestId, state = "CLOSED", captureMethod, approvalCode, authId, paymentRequestId;
        String paymentRequestStatus = "CLOSED", authStatusCode, currency, brand, brandName, masked, last4, merchantId;
        String json;                            // stored fragment used to render this transaction from now on
        Instant captureTime;
        long amount, remainingAuth, refundable, lastCapture;
        boolean finalAmount, captured;
        Instant createdAt;
        List<Cap> captures = new ArrayList<>();
        List<Ref> refunds = new ArrayList<>();      // approved refunds only
    }

    /** one capture of an authorization; remaining = what can still be refunded from it */
    private static final class Cap {
        final String id;
        final long amount;
        long remaining;

        Cap(String id, long amount) {
            this.id = id;
            this.amount = amount;
            this.remaining = amount;
        }
    }

    private static final class Ref {
        String id, requestId, referenceId, state = "AUTHORIZED", currency, brand, brandName, masked, merchantId, json;
        String approvalCode, paymentRequestId;
        Txn txn;                                    // null = standalone refund
        long amount, remainingAfter;
        Instant at;
        boolean approved;
    }

    private final Clock clock;
    private final ScenarioRepository scenarios;           // the jpm_stub_scenario table
    private final Map<String, Txn> byId = new HashMap<>();
    private final Map<String, Txn> byRequestId = new HashMap<>();
    private final Map<String, String> captureRequestIds = new HashMap<>();
    private final Map<String, Txn> byCaptureId = new HashMap<>();
    private final Map<String, Ref> refundById = new HashMap<>();
    private final Map<String, Ref> refundByRequestId = new HashMap<>();
    private long seq = 0, capSeq = 0, refSeq = 0;

    public JpmStubService(Clock clock, ScenarioRepository scenarios) {
        this.clock = clock;
        this.scenarios = scenarios;
    }

    /** forget every stored transaction; ids restart at stub-txn-000001 */
    public synchronized void reset() {
        byId.clear();
        byRequestId.clear();
        captureRequestIds.clear();
        byCaptureId.clear();
        refundById.clear();
        refundByRequestId.clear();
        seq = 0;
        capSeq = 0;
        refSeq = 0;
    }

    // ------------------------------------------------------------- authorize

    public StubResponse authorize(String requestId, ChaseAuthorizeRequest req) {
        Scenario def = defaultRow();
        String last4 = last4Of(req);
        Scenario sc = last4 == null ? def : scenarios.find(last4).orElse(def);
        pause(sc);                                       // delay_ms, outside the lock
        return doAuthorize(requestId, req, sc, def);
    }

    private synchronized StubResponse doAuthorize(String requestId, ChaseAuthorizeRequest req, Scenario sc,
                                                  Scenario def) {
        if (requestId == null || requestId.isBlank()) {
            throw new StubException(400, "request-id header is required");
        }
        Txn existing = byRequestId.get(requestId);
        if (existing != null) {
            return new StubResponse(200, render(existing));  // idempotent replay, never failed again
        }
        Card card = req.paymentMethodType() == null ? null : req.paymentMethodType().card();
        if (card == null || card.accountNumber() == null || card.accountNumber().length() < 4
                || req.amount() <= 0 || req.currency() == null) {
            throw new StubException(400, "amount, currency and card are required");
        }
        if (sc.approvedPercent() < 100 && !"SUPPORTED".equals(req.partialAuthorizationSupport())) {
            sc = def;                                    // partial row, but the caller did not allow it
        }
        String json = sc.authJson() != null ? sc.authJson() : def.authJson();
        boolean fail = sc.authHttpStatus() >= 400;       // the caller will get an error status
        if (fail && !sc.lostResponse()) {                // nothing recorded: just the stored error JSON
            throw new StubException(sc.authHttpStatus(), "stub scenario " + sc.cardLast4() + " (nothing recorded)",
                    errorBody(json, "requestId", requestId));
        }

        Txn t = newTxn(requestId, req, card.accountNumber());
        if (!isDenied(json)) {                           // approved: reserve the amount
            boolean partial = sc.approvedPercent() < 100;
            t.approvalCode = "A" + (100001 + seq);
            t.amount = partial ? Math.max(1, req.amount() * sc.approvedPercent() / 100) : req.amount();
            t.remainingAuth = t.amount;
            t.authId = "stub-auth-%06d".formatted(seq + 1);
            t.authStatusCode = "AUTHORIZED";
            switch (t.captureMethod) {
                case "NOW" -> {
                    addCapture(t, t.amount);
                    close(t);
                }
                case "DELAYED" -> {
                    t.state = "AUTHORIZED";
                    t.paymentRequestStatus = "PENDING";
                    t.captureTime = req.captureTime() != null ? Instant.parse(req.captureTime())
                            : clock.instant().plusSeconds(DEFAULT_DELAY_MINUTES * 60L);
                }
                case "MANUAL" -> {
                    t.state = "AUTHORIZED";
                    t.paymentRequestStatus = "PENDING";
                }
                default -> throw new StubException(400, "unknown captureMethod " + t.captureMethod);
            }
        }
        // a lost-response row answers with an error, but what is recorded looks like a normal approval
        t.json = fail ? def.authJson() : json;
        seq++;
        byId.put(t.id, t);
        byRequestId.put(requestId, t);

        if (fail) {                                      // recorded, but the caller sees the stored error JSON
            throw new StubException(sc.authHttpStatus(), "stub scenario " + sc.cardLast4() + " (transaction recorded)",
                    errorBody(json, "requestId", requestId));
        }
        return new StubResponse(sc.authHttpStatus(), render(t));
    }

    // --------------------------------------------------------------- capture

    public StubResponse capture(String requestId, String id, ChaseCaptureRequest req) {
        Scenario def = defaultRow();
        String last4;
        synchronized (this) {
            Txn known = byId.get(id);
            last4 = known == null ? null : known.last4;
        }
        Scenario sc = last4 == null ? def : scenarios.find(last4).orElse(def);
        pause(sc);
        return doCapture(requestId, id, req, sc, def);
    }

    private synchronized StubResponse doCapture(String requestId, String id, ChaseCaptureRequest req, Scenario sc,
                                                Scenario def) {
        Txn t = byId.get(id);
        if (t == null) {
            throw new StubException(404, "transaction not found");
        }
        if (requestId != null && captureRequestIds.containsKey(requestId)) {
            return new StubResponse(200, render(t));     // idempotent replay of the capture
        }
        String json = sc.captureJson() != null ? sc.captureJson() : def.captureJson();
        boolean fail = sc.captureHttpStatus() >= 400;
        if (fail && !sc.lostResponse()) {                // refused: nothing is applied
            throw new StubException(sc.captureHttpStatus(), "stub scenario " + sc.cardLast4() + " (nothing applied)",
                    errorBody(json, "transactionId", t.id));
        }
        settleIfDue(t);
        if (!"AUTHORIZED".equals(t.state)) {
            throw new StubException(409, "transaction is " + t.state + ", cannot capture");
        }
        long amt = req.amount() == null ? t.remainingAuth : req.amount();
        if (amt <= 0 || amt > t.remainingAuth) {
            throw new StubException(422, "capture amount exceeds remaining authorization");
        }
        t.remainingAuth -= amt;
        addCapture(t, amt);
        boolean fin = req.amount() == null || t.remainingAuth == 0
                || Boolean.TRUE.equals(req.isAmountFinal())
                || (req.multiCapture() != null && req.multiCapture().isFinalCapture());
        t.finalAmount = fin;
        if (fin) {
            t.remainingAuth = 0;
            t.state = "CLOSED";
            t.paymentRequestStatus = "CLOSED";
            t.authStatusCode = "CAPTURED";
        } else {
            t.paymentRequestStatus = "OPEN";
        }
        t.captureMethod = req.captureMethod() == null ? t.captureMethod : req.captureMethod();
        t.json = fail ? def.captureJson() : json;
        if (requestId != null) {
            captureRequestIds.put(requestId, t.id);
        }
        if (fail) {                                      // applied, but the caller sees the stored error JSON
            throw new StubException(sc.captureHttpStatus(), "stub scenario " + sc.cardLast4() + " (capture applied)",
                    errorBody(json, "transactionId", t.id));
        }
        return new StubResponse(sc.captureHttpStatus(), render(t));
    }

    // ---------------------------------------------------------------- refund

    private static final int REFUND_WINDOW_MONTHS = 13;

    public StubResponse refund(String requestId, ChaseRefundRequest req) {
        Scenario def = defaultRow();
        RefundPaymentMethod pm = req.paymentMethodType();
        String refId = pm == null || pm.transactionReference() == null ? null : pm.transactionReference().transactionReferenceId();
        String last4;
        synchronized (this) {
            Txn known = refId == null ? null : byId.containsKey(refId) ? byId.get(refId) : byCaptureId.get(refId);
            last4 = known != null ? known.last4
                    : pm != null && pm.card() != null && pm.card().accountNumber() != null
                    && pm.card().accountNumber().length() >= 4
                    ? pm.card().accountNumber().substring(pm.card().accountNumber().length() - 4) : null;
        }
        Scenario sc = last4 == null ? def : scenarios.find(last4).orElse(def);
        pause(sc);
        return doRefund(requestId, req, refId, sc, def);
    }

    private synchronized StubResponse doRefund(String requestId, ChaseRefundRequest req, String refId, Scenario sc,
                                               Scenario def) {
        if (requestId == null || requestId.isBlank()) {
            throw new StubException(400, "request-id header is required");
        }
        Ref existing = refundByRequestId.get(requestId);
        if (existing != null) {
            return new StubResponse(200, renderRefund(existing));    // idempotent replay
        }
        String json = sc.refundJson() != null ? sc.refundJson() : def.refundJson();
        boolean fail = sc.refundHttpStatus() >= 400;
        if (fail && !sc.lostResponse()) {                            // nothing refunded: just the stored error JSON
            throw new StubException(sc.refundHttpStatus(), "stub scenario " + sc.cardLast4() + " (nothing refunded)",
                    errorBody(json, "requestId", requestId));
        }

        Ref r = new Ref();
        r.requestId = requestId;
        r.referenceId = refId;
        r.at = clock.instant();
        r.merchantId = req.merchant() != null && req.merchant().merchantId() != null ? req.merchant().merchantId() : "stub-merchant";
        Cap cap = null;
        long available;
        if (refId != null) {                                         // referenced refund
            Txn t = byId.get(refId);
            if (t == null) {
                t = byCaptureId.get(refId);
                if (t == null) {
                    throw new StubException(404, "original transaction or capture not found: " + refId);
                }
                for (Cap c : t.captures) {
                    if (c.id.equals(refId)) {
                        cap = c;
                    }
                }
            }
            if (t.createdAt.atZone(ZoneOffset.UTC).plusMonths(REFUND_WINDOW_MONTHS)
                    .isBefore(clock.instant().atZone(ZoneOffset.UTC))) {
                throw new StubException(400, "refund window of " + REFUND_WINDOW_MONTHS + " months has passed");
            }
            available = cap != null ? cap.remaining : t.refundable;
            if (available <= 0) {
                throw new StubException(409, "nothing left to refund (not captured, or already fully refunded)");
            }
            r.amount = req.amount() == null ? available : req.amount();
            if (r.amount <= 0 || r.amount > available) {
                throw new StubException(422, "refund amount exceeds the remaining refundable amount (" + available + ")");
            }
            r.txn = t;
            r.currency = t.currency;
            r.brand = t.brand;
            r.brandName = t.brandName;
            r.masked = t.masked;
            r.paymentRequestId = t.paymentRequestId;
        } else {                                                     // standalone refund: card + amount in the request
            RefundCard c = req.paymentMethodType() == null ? null : req.paymentMethodType().card();
            if (c == null || c.accountNumber() == null || c.accountNumber().length() < 4
                    || req.amount() == null || req.amount() <= 0 || req.currency() == null) {
                throw new StubException(400, "a standalone refund needs card, amount and currency "
                        + "(or send paymentMethodType.transactionReference.transactionReferenceId)");
            }
            r.amount = req.amount();
            r.currency = req.currency();
            Txn tmp = newTxn(requestId, new ChaseAuthorizeRequest(null, null, 1, req.currency(), null, null, null,
                    new PaymentMethodType(new Card(c.accountNumber(), null, null, null, null))), c.accountNumber());
            r.brand = tmp.brand;
            r.brandName = tmp.brandName;
            r.masked = tmp.masked;
            r.paymentRequestId = "stub-pr-rfd-%06d".formatted(refSeq + 1);
        }

        r.approved = !isDenied(json);
        r.id = "stub-rfd-%06d".formatted(++refSeq);
        r.approvalCode = "R" + (100000 + refSeq);
        r.json = fail ? def.refundJson() : json;
        if (r.approved) {                                            // take the money back from what was captured
            if (r.txn != null) {
                if (cap != null) {
                    cap.remaining -= r.amount;
                    r.txn.refundable -= r.amount;
                } else {
                    long left = r.amount;
                    for (Cap c : r.txn.captures) {
                        long take = Math.min(c.remaining, left);
                        c.remaining -= take;
                        left -= take;
                    }
                    r.txn.refundable -= r.amount;
                }
                r.remainingAfter = cap != null ? cap.remaining : r.txn.refundable;
                r.txn.refunds.add(r);
            }
        } else {
            r.amount = 0;
            r.remainingAfter = r.txn == null ? 0 : cap != null ? cap.remaining : r.txn.refundable;
        }
        refundById.put(r.id, r);
        refundByRequestId.put(requestId, r);

        if (fail) {                                                  // refunded, but the caller sees the stored error JSON
            throw new StubException(sc.refundHttpStatus(), "stub scenario " + sc.cardLast4() + " (refund applied)",
                    errorBody(json, "requestId", requestId));
        }
        return new StubResponse(sc.refundHttpStatus(), renderRefund(r));
    }

    public synchronized Optional<String> refundById(String id) {
        Ref r = refundById.get(id);
        return r == null ? Optional.empty() : Optional.of(renderRefund(r));
    }

    public synchronized Optional<String> refundByRequestId(String requestId) {
        Ref r = refundByRequestId.get(requestId);
        return r == null ? Optional.empty() : Optional.of(renderRefund(r));
    }

    // ---------------------------------------------------------------- lookup

    public synchronized Optional<String> byId(String id) {
        Txn t = byId.get(id);
        if (t == null) {
            return Optional.empty();
        }
        settleIfDue(t);
        return Optional.of(render(t));
    }

    public synchronized Optional<String> byRequestId(String requestId) {
        Txn t = byRequestId.get(requestId);
        if (t == null) {
            return Optional.empty();
        }
        settleIfDue(t);
        return Optional.of(render(t));
    }

    // -------------------------------------------------------------- internals

    private Scenario defaultRow() {
        return scenarios.find(ScenarioRepository.DEFAULT_CARD).orElseThrow(() -> new StubException(500,
                "jpm_stub_scenario has no default row ('*') - re-run schema.sql"));
    }

    private Txn newTxn(String requestId, ChaseAuthorizeRequest req, String pan) {
        Txn t = new Txn();
        t.id = "stub-txn-%06d".formatted(seq + 1);
        t.requestId = requestId;
        t.currency = req.currency();
        t.captureMethod = req.captureMethod() == null ? "NOW" : req.captureMethod();
        t.paymentRequestId = "stub-pr-%06d".formatted(seq + 1);
        t.merchantId = req.merchant() != null && req.merchant().merchantId() != null
                ? req.merchant().merchantId() : "stub-merchant";
        t.createdAt = clock.instant();
        t.last4 = pan.substring(pan.length() - 4);
        switch (pan.charAt(0)) {
            case '4' -> { t.brand = "VISA"; t.brandName = "Visa"; }
            case '5', '2' -> { t.brand = "MC"; t.brandName = "Mastercard"; }
            case '3' -> { t.brand = "AMEX"; t.brandName = "American Express"; }
            case '6' -> { t.brand = "DISC"; t.brandName = "Discover"; }
            default -> { t.brand = "OTHER"; t.brandName = "Other"; }
        }
        t.masked = "X".repeat(Math.max(0, pan.length() - 4)) + pan.substring(pan.length() - 4);
        return t;
    }

    private static String last4Of(ChaseAuthorizeRequest req) {
        Card card = req.paymentMethodType() == null ? null : req.paymentMethodType().card();
        String pan = card == null ? null : card.accountNumber();
        return pan == null || pan.length() < 4 ? null : pan.substring(pan.length() - 4);
    }

    private static void pause(Scenario sc) {
        if (sc.delayMs() > 0) {
            try {
                Thread.sleep(sc.delayMs());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    /** a capture adds refundable money; every capture gets its own captureId (usable as a refund reference) */
    private void addCapture(Txn t, long amount) {
        Cap c = new Cap("stub-cap-%06d".formatted(++capSeq), amount);
        t.captures.add(c);
        byCaptureId.put(c.id, t);
        t.refundable += amount;
        t.lastCapture = amount;
        t.captured = true;
    }

    private void settleIfDue(Txn t) {
        if ("DELAYED".equals(t.captureMethod) && "AUTHORIZED".equals(t.state)
                && t.captureTime != null && !clock.instant().isBefore(t.captureTime)) {
            addCapture(t, t.remainingAuth);
            close(t);
        }
    }

    private void close(Txn t) {
        t.remainingAuth = 0;
        t.state = "CLOSED";
        t.paymentRequestStatus = "CLOSED";
        t.authStatusCode = "CAPTURED";
        t.finalAmount = true;
    }

    // ------------------------------------------- response = request fields + stored JSON

    private static boolean isDenied(String json) {
        return json.replaceAll("\\s", "").contains("\"responseStatus\":\"DENIED\"");
    }

    /** the response for a transaction: request-based fields, then the stored fields */
    private String render(Txn t) {
        List<String> f = new ArrayList<>();
        f.add(field("transactionId", str(t.id)));
        f.add(field("requestId", str(t.requestId)));
        f.add(field("transactionState", str(t.state)));
        f.add(field("captureMethod", str(t.captureMethod)));
        if (t.captureTime != null) {
            f.add(field("captureTime", str(t.captureTime.toString())));
        }
        f.add(field("isVoid", "false"));
        if (t.approvalCode != null) {
            f.add(field("approvalCode", str(t.approvalCode)));
        }
        f.add(field("amount", String.valueOf(t.captured ? t.lastCapture : t.amount)));
        f.add(field("currency", str(t.currency)));
        if (t.captured) {
            f.add(field("isAmountFinal", String.valueOf(t.finalAmount)));
            f.add(field("totalAuthorizedAmount", String.valueOf(t.amount)));
        }
        f.add(field("remainingAuthAmount", String.valueOf(t.remainingAuth)));
        f.add(field("remainingRefundableAmount", String.valueOf(t.refundable)));
        f.add(field("paymentMethodType", "{\"card\": {\"cardType\": " + str(t.brand) + ", \"cardTypeName\": "
                + str(t.brandName) + ", \"maskedAccountNumber\": " + str(t.masked) + "}}"));
        f.add(field("merchant", "{\"merchantId\": " + str(t.merchantId) + ", \"merchantCategoryCode\": \"5999\"}"));
        String auths = t.authId == null ? "" : ", \"authorizations\": [{\"authorizationId\": " + str(t.authId)
                + ", \"amount\": " + t.amount + ", \"transactionStatusCode\": " + str(t.authStatusCode)
                + ", \"authorizationType\": \"AUTHORIZATION\"}]";
        f.add(field("paymentRequest", "{\"paymentRequestId\": " + str(t.paymentRequestId)
                + ", \"paymentRequestStatus\": " + str(t.paymentRequestStatus) + auths + capturesJson(t)
                + refundsJson(t) + "}"));
        return merge(f, t.json);
    }

    private static String capturesJson(Txn t) {
        if (t.captures.isEmpty()) {
            return "";
        }
        List<String> l = new ArrayList<>();
        for (Cap c : t.captures) {
            l.add("{\"captureId\": " + str(c.id) + ", \"amount\": " + c.amount
                    + ", \"transactionStatusCode\": \"CLOSED\", \"captureRemainingRefundableAmount\": " + c.remaining + "}");
        }
        return ", \"captures\": [" + String.join(", ", l) + "]";
    }

    private static String refundsJson(Txn t) {
        if (t.refunds.isEmpty()) {
            return "";
        }
        List<String> l = new ArrayList<>();
        for (Ref r : t.refunds) {
            l.add("{\"refundId\": " + str(r.id) + ", \"amount\": " + r.amount + ", \"transactionStatusCode\": \"CLOSED\"}");
        }
        return ", \"refunds\": [" + String.join(", ", l) + "]";
    }

    /** refund response: request-based fields, then the stored fields (transactionState defaults to the docs' example) */
    private String renderRefund(Ref r) {
        List<String> f = new ArrayList<>();
        f.add(field("transactionId", str(r.id)));
        f.add(field("requestId", str(r.requestId)));
        f.add(field("transactionState", str(r.state)));
        if (r.referenceId != null) {
            f.add(field("transactionReferenceId", str(r.referenceId)));
        }
        f.add(field("amount", String.valueOf(r.amount)));
        f.add(field("currency", str(r.currency)));
        f.add(field("remainingRefundableAmount", String.valueOf(r.remainingAfter)));
        f.add(field("approvalCode", str(r.approvalCode)));
        f.add(field("hostReferenceId", str("stub-host-" + r.id)));
        f.add(field("transactionDate", str(r.at.toString())));
        f.add(field("merchant", "{\"merchantId\": " + str(r.merchantId) + ", \"merchantCategoryCode\": \"5999\"}"));
        f.add(field("paymentMethodType", "{\"card\": {\"cardType\": " + str(r.brand) + ", \"cardTypeName\": "
                + str(r.brandName) + ", \"maskedAccountNumber\": " + str(r.masked) + "}}"));
        String detail = r.txn != null ? capturesJson(r.txn) + refundsJson(r.txn)
                : r.approved ? ", \"refunds\": [{\"refundId\": " + str(r.id) + ", \"amount\": " + r.amount
                + ", \"transactionStatusCode\": \"CLOSED\"}]" : "";
        f.add(field("paymentRequest", "{\"paymentRequestId\": " + str(r.paymentRequestId)
                + ", \"paymentRequestStatus\": \"CLOSED\"" + detail + "}"));
        return merge(f, r.json);
    }

    /** error body: the stored JSON plus one identifying field from the request */
    private static String errorBody(String json, String key, String value) {
        return merge(List.of(field(key, str(value))), json);
    }

    /**
     * {request-based fields..., stored fields...}. A request-based field is left out when the stored JSON names it,
     * so the stored value wins and no key appears twice.
     */
    static String merge(List<String> requestFields, String storedJson) {
        String inner = storedJson == null ? "" : storedJson.strip();
        if (inner.startsWith("{") && inner.endsWith("}")) {
            inner = inner.substring(1, inner.length() - 1).strip();
        }
        List<String> parts = new ArrayList<>();
        for (String f : requestFields) {
            String key = f.substring(0, f.indexOf(':'));      // "\"name\""
            if (!inner.contains(key)) {
                parts.add(f);
            }
        }
        if (!inner.isEmpty()) {
            parts.add(inner);
        }
        return "{" + String.join(", ", parts) + "}";
    }

    private static String field(String name, String jsonValue) {
        return "\"" + name + "\": " + jsonValue;
    }

    private static String str(String s) {
        return "\"" + (s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"")) + "\"";
    }
}
