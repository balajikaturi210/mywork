package com.zbp.chasepay.stub;

/** Carries an HTTP status (and optionally a complete JSON body from the scenario table) for the controller. */
public class StubException extends RuntimeException {
    private final int status;
    private final String body;

    public StubException(int status, String message) {
        this(status, message, null);
    }

    public StubException(int status, String message, String body) {
        super(message);
        this.status = status;
        this.body = body;
    }

    public int status() {
        return status;
    }

    /** the complete response body to return as-is, or null = build a small {"responseMessage": ...} body */
    public String body() {
        return body;
    }
}
