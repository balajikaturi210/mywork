package com.zbp.chasepay;

import com.zbp.chasepay.api.CardValidator;
import com.zbp.chasepay.api.PaymentValidationException;
import org.junit.jupiter.api.Test;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

import static org.junit.jupiter.api.Assertions.*;

class CardValidatorTest {

    private final Clock clock = Clock.fixed(Instant.parse("2026-10-14T00:00:00Z"), ZoneOffset.UTC);

    @Test
    void luhn() {
        assertTrue(CardValidator.luhn("4111111111111111"));
        assertTrue(CardValidator.luhn("378282246310005"));
        assertFalse(CardValidator.luhn("4111111111111112"));
        assertFalse(CardValidator.luhn("41111111111A1111"));
    }

    @Test
    void expiry() {
        assertFalse(CardValidator.expired(10, 2026, clock));   // current month is still valid
        assertTrue(CardValidator.expired(9, 2026, clock));
        assertFalse(CardValidator.expired(1, 2030, clock));
    }

    @Test
    void validateThrows() {
        assertThrows(PaymentValidationException.class, () -> CardValidator.validate("4111111111111112", 12, 2030, clock));
        assertThrows(PaymentValidationException.class, () -> CardValidator.validate("4111111111111111", 1, 2020, clock));
        CardValidator.validate("4111111111111111", 12, 2030, clock);
    }
}
