package com.zbp.chasepay;

import com.zbp.chasepay.api.*;
import com.zbp.chasepay.api.PaymentDtos.*;
import com.zbp.chasepay.client.ChaseApiException;
import com.zbp.chasepay.client.ChasePaymentsGateway;
import com.zbp.chasepay.client.ChaseUnavailableException;
import com.zbp.chasepay.client.model.ChaseModel.*;
import com.zbp.chasepay.config.ChaseProperties;
import com.zbp.chasepay.stub.JpmStubService;
import com.zbp.chasepay.stub.StubException;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/** Service wired straight onto the stub (no HTTP, no Spring context). */
class PaymentServiceTest {

    private final Clock clock = Clock.fixed(Instant.parse("2026-10-14T10:00:00Z"), ZoneOffset.UTC);
    private final JpmStubService stub = new JpmStubService(clock, JpmStubServiceTest.fakeTable(JpmStubServiceTest.seed()));
    private final ChaseProperties props = new ChaseProperties("x", "x", "id", "secret", "scope", "m",
            new ChaseProperties.Software("zbp", "payments", "1"), 1000, 1000, new ChaseProperties.Stub(true));

    /** Gateway adapter: maps StubException like the real REST gateway maps HTTP statuses. */
    private class StubGateway implements ChasePaymentsGateway {
        boolean failFirstAuthorizeAfterRecording = false;   // models 'timeout after Chase processed it'
        boolean lookupBroken = false;

        private <T> T map(java.util.function.Supplier<T> s) {
            try {
                return s.get();
            } catch (StubException e) {
                if (e.status() >= 500 || e.status() == 408) throw new ChaseUnavailableException("HTTP " + e.status(), null);
                throw new ChaseApiException(e.status(), e.getMessage());
            }
        }

        public ChasePaymentResponse authorize(String rid, ChaseAuthorizeRequest r) {
            ChasePaymentResponse res = map(() -> StubJson.toResponse(stub.authorize(rid, r).body()));
            if (failFirstAuthorizeAfterRecording) {
                failFirstAuthorizeAfterRecording = false;
                throw new ChaseUnavailableException("timeout", null);
            }
            return res;
        }

        public ChasePaymentResponse capture(String rid, String id, ChaseCaptureRequest r) {
            return map(() -> StubJson.toResponse(stub.capture(rid, id, r).body()));
        }

        public Optional<ChasePaymentResponse> retrieveById(String id) {
            return stub.byId(id).map(StubJson::toResponse);
        }

        public Optional<ChasePaymentResponse> retrieveByRequestId(String rid) {
            if (lookupBroken) throw new ChaseUnavailableException("down", null);
            return stub.byRequestId(rid).map(StubJson::toResponse);
        }
    }

    private final StubGateway gw = new StubGateway();
    private final PaymentService service = new PaymentService(gw, props, clock);

    private static PaymentRequest req(String rid, String amount, String pan, String method) {
        return new PaymentRequest(rid, new BigDecimal(amount), "USD", new CardInput(pan, 12, 2030), method, null, false);
    }

    @Test
    void approvedPaymentConvertsAmountsAndMasksCard() {
        PaymentResult r = service.pay(req("a1", "12.34", "4111111111111111", null));
        assertEquals("APPROVED", r.status());
        assertEquals(0, new BigDecimal("12.34").compareTo(r.amount()));
        assertEquals("CLOSED", r.transactionState());
        assertEquals("XXXXXXXXXXXX1111", r.maskedCard());
        assertFalse(r.toString().contains("4111111111111111"));
    }

    @Test
    void declineIsAResultNotAnException() {
        PaymentResult r = service.pay(req("a2", "5.00", "4000000000000002", null));
        assertEquals("DECLINED", r.status());
    }

    @Test
    void luhnFailureNeverReachesChase() {
        assertThrows(PaymentValidationException.class, () -> service.pay(req("a3", "5.00", "4111111111111112", null)));
        assertTrue(stub.byRequestId("a3").isEmpty());
    }

    @Test
    void unknownOutcomeIsResolvedByRequestId() {
        gw.failFirstAuthorizeAfterRecording = true;
        PaymentResult r = service.pay(req("a4", "20.00", "4111111111111111", null));
        assertEquals("APPROVED", r.status());
        assertNotNull(r.transactionId());
    }

    @Test
    void lostResponseTriggerIsRecoveredByLookup() {
        PaymentResult r = service.pay(req("a5", "20.00", "4000000000000119", null));
        assertEquals("APPROVED", r.status());
    }

    @Test
    void unknownAndUnresolvableThrows504Exception() {
        gw.failFirstAuthorizeAfterRecording = true;
        gw.lookupBroken = true;
        assertThrows(PaymentOutcomeUnknownException.class, () -> service.pay(req("a6", "20.00", "4111111111111111", null)));
    }

    @Test
    void timeoutBeforeProcessingIsStillUnknownNotFailure() {
        assertThrows(PaymentOutcomeUnknownException.class, () -> service.pay(req("a7", "20.00", "4000000000000408", null)));
    }

    @Test
    void manualAuthThenPartialCaptureThenRest() {
        PaymentResult a = service.pay(req("a8", "100.00", "4111111111111111", "MANUAL"));
        assertEquals("AUTHORIZED", a.transactionState());
        PaymentResult c = service.capture(a.transactionId(), new CaptureRequest("c8", new BigDecimal("40.00"), false));
        assertEquals("AUTHORIZED", c.transactionState());
        assertEquals(0, new BigDecimal("60.00").compareTo(c.remainingAuthAmount()));
        PaymentResult c2 = service.capture(a.transactionId(), new CaptureRequest("c8b", null, null));
        assertEquals("CLOSED", c2.transactionState());
    }

    @Test
    void captureOverRemainingIsValidationError() {
        PaymentResult a = service.pay(req("a9", "10.00", "4111111111111111", "MANUAL"));
        assertThrows(PaymentValidationException.class,
                () -> service.capture(a.transactionId(), new CaptureRequest("c9", new BigDecimal("10.01"), true)));
    }

    @Test
    void unknownTransactionIsNotFound() {
        assertThrows(PaymentNotFoundException.class, () -> service.get("nope"));
    }

    @Test
    void tooManyDecimalsRejected() {
        assertThrows(PaymentValidationException.class, () -> service.pay(req("a10", "1.234", "4111111111111111", null)));
    }

    @Test
    void zeroDecimalCurrencyUsesWholeUnits() {
        PaymentRequest jpy = new PaymentRequest("a11", new BigDecimal("500"), "JPY",
                new CardInput("4111111111111111", 12, 2030), null, null, false);
        PaymentResult r = service.pay(jpy);
        assertEquals(0, new BigDecimal("500").compareTo(r.amount()));
    }
}
