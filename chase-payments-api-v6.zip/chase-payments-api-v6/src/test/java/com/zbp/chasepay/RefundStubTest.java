package com.zbp.chasepay;

import com.zbp.chasepay.client.model.ChaseModel.*;
import com.zbp.chasepay.stub.JpmStubService;
import com.zbp.chasepay.stub.StubException;
import org.junit.jupiter.api.Test;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/** Refund API of the stub: referenced (full / partial / multiple / per capture), standalone, scenarios, window. */
class RefundStubTest {

    private final JpmStubServiceTest.MutableClock clock = new JpmStubServiceTest.MutableClock();
    private final JpmStubService stub = new JpmStubService(clock, JpmStubServiceTest.fakeTable(JpmStubServiceTest.seed()));

    private ChasePaymentResponse payAndCapture(String rid, String pan, long amount) {
        ChasePaymentResponse a = StubJson.toResponse(stub.authorize(rid, new ChaseAuthorizeRequest("NOW", null, amount, "USD",
                true, null, null, new PaymentMethodType(new Card(pan, new Expiry(12, 2030), null, null, null)))).body());
        return a;
    }

    private static ChaseRefundRequest ref(String id, Long amount) {
        return new ChaseRefundRequest(amount, "USD", null, null, null,
                new RefundPaymentMethod(new TransactionReference(id), null));
    }

    private Map<String, Object> refund(String rid, ChaseRefundRequest r) {
        return StubJson.obj(stub.refund(rid, r).body());
    }

    @Test
    void fullRefundReturnsEverythingAndUsesRequestFields() {
        ChasePaymentResponse a = payAndCapture("p1", "4111111111111111", 1000);
        Map<String, Object> m = refund("r1", ref(a.transactionId(), null));
        assertEquals("SUCCESS", m.get("responseStatus"));           // from the table
        assertEquals("APPROVED", m.get("responseCode"));
        assertEquals(1000L, m.get("amount"));                        // from the original payment
        assertEquals("USD", m.get("currency"));
        assertEquals("r1", m.get("requestId"));
        assertEquals(a.transactionId(), m.get("transactionReferenceId"));
        assertEquals(0L, m.get("remainingRefundableAmount"));
        assertTrue(m.get("transactionId").toString().startsWith("stub-rfd-"));
    }

    @Test
    void severalPartialRefundsUntilNothingIsLeft() {
        ChasePaymentResponse a = payAndCapture("p2", "4111111111111111", 1000);
        assertEquals(400L, refund("r2a", ref(a.transactionId(), 600L)).get("remainingRefundableAmount"));
        assertEquals(100L, refund("r2b", ref(a.transactionId(), 300L)).get("remainingRefundableAmount"));
        StubException over = assertThrows(StubException.class, () -> stub.refund("r2c", ref(a.transactionId(), 200L)));
        assertEquals(422, over.status());
        assertEquals(0L, refund("r2d", ref(a.transactionId(), null)).get("remainingRefundableAmount"));   // refund the rest (100)
        assertEquals(409, assertThrows(StubException.class, () -> stub.refund("r2f", ref(a.transactionId(), null))).status());
        // the payment now lists its refunds
        String lookup = stub.byId(a.transactionId()).orElseThrow();
        assertTrue(lookup.contains("\"refunds\""));
        assertEquals(0L, StubJson.toResponse(lookup).remainingRefundableAmount());
    }

    @Test
    void uncapturedAuthorizationCannotBeRefunded() {
        ChasePaymentResponse a = StubJson.toResponse(stub.authorize("p3", new ChaseAuthorizeRequest("MANUAL", null, 500, "USD",
                true, null, null, new PaymentMethodType(new Card("4111111111111111", new Expiry(12, 2030), null, null, null)))).body());
        assertEquals(409, assertThrows(StubException.class, () -> stub.refund("r3", ref(a.transactionId(), null))).status());
    }

    @Test
    void multiCaptureRefundIsLimitedToThatCapture() {
        ChasePaymentResponse a = StubJson.toResponse(stub.authorize("p4", new ChaseAuthorizeRequest("MANUAL", null, 1000, "USD",
                true, null, null, new PaymentMethodType(new Card("4111111111111111", new Expiry(12, 2030), null, null, null)))).body());
        stub.capture("c4a", a.transactionId(), new ChaseCaptureRequest("NOW", 300L, false, new MultiCapture(1, 2, false)));
        stub.capture("c4b", a.transactionId(), new ChaseCaptureRequest("NOW", 200L, true, new MultiCapture(2, 2, true)));
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> caps = (List<Map<String, Object>>) ((Map<String, Object>) StubJson.obj(stub.byId(a.transactionId()).orElseThrow())
                .get("paymentRequest")).get("captures");
        assertEquals(2, caps.size());
        String firstCapture = (String) caps.get(0).get("captureId");
        assertEquals(422, assertThrows(StubException.class, () -> stub.refund("r4a", ref(firstCapture, 400L))).status());
        assertEquals(100L, refund("r4b", ref(firstCapture, 200L)).get("remainingRefundableAmount"));   // 300 - 200 left on that capture
    }

    @Test
    void standaloneRefundNeedsCardAmountAndCurrency() {
        ChaseRefundRequest ok = new ChaseRefundRequest(900L, "USD", "CARDHOLDER", "NOT_STORED", null,
                new RefundPaymentMethod(null, new RefundCard("PAN", "5555555555554444", new Expiry(12, 2030))));
        String body = stub.refund("s1", ok).body();
        Map<String, Object> m = StubJson.obj(body);
        assertEquals(900L, m.get("amount"));
        assertEquals("SUCCESS", m.get("responseStatus"));
        assertFalse(body.contains("5555555555554444"));
        assertTrue(body.contains("XXXXXXXXXXXX4444"));
        assertFalse(m.containsKey("transactionReferenceId"));
        assertEquals(400, assertThrows(StubException.class, () -> stub.refund("s2",
                new ChaseRefundRequest(null, "USD", null, null, null, new RefundPaymentMethod(null, new RefundCard("PAN", "5555555555554444", null))))).status());
        assertEquals(400, assertThrows(StubException.class, () -> stub.refund("s3", ref(null, null))).status());
    }

    @Test
    void unknownReferenceIsNotFound() {
        assertEquals(404, assertThrows(StubException.class, () -> stub.refund("n1", ref("nope", null))).status());
    }

    @Test
    void refundIsIdempotentAndCanBeLookedUp() {
        ChasePaymentResponse a = payAndCapture("p5", "4111111111111111", 1000);
        Map<String, Object> first = refund("r5", ref(a.transactionId(), 400L));
        Map<String, Object> again = refund("r5", ref(a.transactionId(), 400L));       // replay: not refunded twice
        assertEquals(first.get("transactionId"), again.get("transactionId"));
        assertEquals(500L, refund("r5b", ref(a.transactionId(), 100L)).get("remainingRefundableAmount"));   // 1000-400-100
        assertTrue(stub.refundByRequestId("r5").isPresent());
        assertTrue(stub.refundById((String) first.get("transactionId")).isPresent());
        assertTrue(stub.refundByRequestId("missing").isEmpty());
    }

    @Test
    void declinedRefundRowChangesNothing() {
        ChasePaymentResponse a = payAndCapture("p6", "4000000000000881", 1000);      // card 0881: refund declined
        Map<String, Object> m = refund("r6", ref(a.transactionId(), 300L));
        assertEquals("DENIED", m.get("responseStatus"));
        assertEquals("DECLINED", m.get("responseCode"));
        assertEquals(0L, m.get("amount"));
        assertEquals(1000L, m.get("remainingRefundableAmount"));
    }

    @Test
    void refundTimeoutRowRefundsNothingAndLostResponseRowRefunds() {
        ChasePaymentResponse t = payAndCapture("p7", "4000000000000882", 1000);       // 0882: 504, nothing refunded
        StubException e = assertThrows(StubException.class, () -> stub.refund("r7", ref(t.transactionId(), 300L)));
        assertEquals(504, e.status());
        assertEquals("TIMEOUT", StubJson.obj(e.body()).get("responseCode"));
        assertTrue(stub.refundByRequestId("r7").isEmpty());

        ChasePaymentResponse l = payAndCapture("p8", "4000000000000883", 1000);       // 0883: 500 but applied
        StubException lost = assertThrows(StubException.class, () -> stub.refund("r8", ref(l.transactionId(), 300L)));
        assertEquals(500, lost.status());
        assertTrue(stub.refundByRequestId("r8").isPresent());                         // recovery by request-id works
        assertEquals(700L, StubJson.obj(stub.refundByRequestId("r8").get()).get("remainingRefundableAmount"));
    }

    @Test
    void referencedRefundAfter13MonthsIsRejected() {
        ChasePaymentResponse a = payAndCapture("p9", "4111111111111111", 1000);
        clock.now = clock.now.plusSeconds(60L * 60 * 24 * 31 * 14);                    // about 14 months later
        assertEquals(400, assertThrows(StubException.class, () -> stub.refund("r9", ref(a.transactionId(), null))).status());
    }

    @Test
    void refundResponseCanBeOverriddenFromTheTable() {
        Map<String, com.zbp.chasepay.stub.ScenarioRepository.Scenario> rows = JpmStubServiceTest.seed();
        rows.put("0555", new com.zbp.chasepay.stub.ScenarioRepository.Scenario("0555", 200, null, 100, 200, null, 200,
                "{\"responseStatus\": \"SUCCESS\", \"responseCode\": \"APPROVED\", \"responseMessage\": \"custom\", \"transactionState\": \"CLOSED\"}",
                false, 0, null));
        JpmStubService s = new JpmStubService(clock, JpmStubServiceTest.fakeTable(rows));
        ChasePaymentResponse a = StubJson.toResponse(s.authorize("pa", new ChaseAuthorizeRequest("NOW", null, 500, "USD", true, null, null,
                new PaymentMethodType(new Card("4000000000000555", new Expiry(12, 2030), null, null, null)))).body());
        String body = s.refund("ra", ref(a.transactionId(), null)).body();
        Map<String, Object> m = StubJson.obj(body);
        assertEquals("custom", m.get("responseMessage"));
        assertEquals("CLOSED", m.get("transactionState"));                              // table value replaces the default
        assertEquals(1, body.split("\"transactionState\"", -1).length - 1);
    }
}
