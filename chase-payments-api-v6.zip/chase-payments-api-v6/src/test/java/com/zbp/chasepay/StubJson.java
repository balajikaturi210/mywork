package com.zbp.chasepay;

import com.zbp.chasepay.client.model.ChaseModel.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Tiny JSON reader for tests (no Jackson needed): turns the stub's JSON text into maps / lists / values. */
final class StubJson {

    private final String s;
    private int i;

    private StubJson(String s) {
        this.s = s;
    }

    static Object parse(String json) {
        StubJson p = new StubJson(json);
        Object v = p.value();
        p.ws();
        if (p.i != json.length()) {
            throw new IllegalArgumentException("trailing characters at " + p.i);
        }
        return v;
    }

    @SuppressWarnings("unchecked")
    static Map<String, Object> obj(String json) {
        return (Map<String, Object>) parse(json);
    }

    /** the stub's JSON mapped onto the facade's response record (what the real REST gateway does with Jackson) */
    @SuppressWarnings("unchecked")
    static ChasePaymentResponse toResponse(String json) {
        Map<String, Object> m = obj(json);
        Map<String, Object> card = m.get("paymentMethodType") == null ? null
                : (Map<String, Object>) ((Map<String, Object>) m.get("paymentMethodType")).get("card");
        Map<String, Object> pr = (Map<String, Object>) m.get("paymentRequest");
        List<Authorization> auths = new ArrayList<>();
        if (pr != null && pr.get("authorizations") != null) {
            for (Object o : (List<Object>) pr.get("authorizations")) {
                Map<String, Object> a = (Map<String, Object>) o;
                auths.add(new Authorization((String) a.get("authorizationId"), lng(a.get("amount")),
                        (String) a.get("transactionStatusCode"), (String) a.get("authorizationType")));
            }
        }
        return new ChasePaymentResponse(
                (String) m.get("transactionId"), (String) m.get("requestId"), (String) m.get("transactionState"),
                (String) m.get("responseStatus"), (String) m.get("responseCode"), (String) m.get("responseMessage"),
                (String) m.get("captureMethod"), (String) m.get("captureTime"), (Boolean) m.get("isVoid"),
                (String) m.get("approvalCode"), lng(m.get("amount")), (String) m.get("currency"),
                lng(m.get("remainingAuthAmount")), lng(m.get("remainingRefundableAmount")),
                card == null ? null : new PaymentMethodType(new Card(null, null, (String) card.get("cardType"),
                        (String) card.get("cardTypeName"), (String) card.get("maskedAccountNumber"))),
                new Merchant("stub-merchant", null, "5999"),
                pr == null ? null : new ChasePaymentRequest((String) pr.get("paymentRequestId"),
                        (String) pr.get("paymentRequestStatus"), auths));
    }

    private static Long lng(Object o) {
        return o == null ? null : ((Number) o).longValue();
    }

    // ---- recursive-descent parser ----
    private Object value() {
        ws();
        char c = s.charAt(i);
        if (c == '{') {
            i++;
            Map<String, Object> m = new LinkedHashMap<>();
            ws();
            if (s.charAt(i) == '}') { i++; return m; }
            while (true) {
                ws();
                String k = string();
                ws();
                expect(':');
                m.put(k, value());
                ws();
                if (s.charAt(i) == ',') { i++; continue; }
                expect('}');
                return m;
            }
        }
        if (c == '[') {
            i++;
            List<Object> l = new ArrayList<>();
            ws();
            if (s.charAt(i) == ']') { i++; return l; }
            while (true) {
                l.add(value());
                ws();
                if (s.charAt(i) == ',') { i++; continue; }
                expect(']');
                return l;
            }
        }
        if (c == '"') return string();
        if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
        if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
        if (s.startsWith("null", i)) { i += 4; return null; }
        int st = i;
        while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
        if (st == i) throw new IllegalArgumentException("bad JSON at " + i + ": " + s.substring(i, Math.min(s.length(), i + 20)));
        String n = s.substring(st, i);
        return n.contains(".") || n.contains("e") || n.contains("E") ? (Object) Double.valueOf(n) : (Object) Long.valueOf(n);
    }

    private String string() {
        expect('"');
        StringBuilder b = new StringBuilder();
        while (s.charAt(i) != '"') {
            char c = s.charAt(i++);
            if (c == '\\') {
                char e = s.charAt(i++);
                switch (e) {
                    case 'n' -> b.append('\n');
                    case 't' -> b.append('\t');
                    case 'u' -> { b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; }
                    default -> b.append(e);
                }
            } else {
                b.append(c);
            }
        }
        i++;
        return b.toString();
    }

    private void expect(char c) {
        if (s.charAt(i) != c) throw new IllegalArgumentException("expected " + c + " at " + i);
        i++;
    }

    private void ws() {
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
    }
}
