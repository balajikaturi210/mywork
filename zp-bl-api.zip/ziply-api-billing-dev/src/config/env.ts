import logger from "../logger/logger";
import dotenv from "dotenv";
const envFile = process.env.NODE_ENV === "production" ? "prod.env":
 process.env.NODE_ENV === "uat" ? "uat.env" : "dev.env";
logger.info(process.env.NODE_ENV , "NODE_ENV............................")
console.log(process.env.NODE_ENV , "NODE_ENV............................")
dotenv.config({ path: envFile });