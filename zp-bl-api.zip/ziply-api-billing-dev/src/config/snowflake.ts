const snowflake = require("snowflake-sdk");
import "dotenv/config";
import { getTraceId } from "../utils/logger";
import logger, {
  eventLog,
  categoryOpt,
  eventOpt,
  inbound,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "config/snowflake";
const httpLogRes = logRes();
const inboundLog = inbound();

const connectionConfig = {
  account: process.env.SF_ACCOUNT, // E.g., 'xy12345.us-east-1'
  username: process.env.SF_USER,
  password: process.env.SF_PASSWORD,
  warehouse: process.env.SF_WAREHOUSE,
  database: process.env.SF_DATABASE,
  schema: process.env.SF_SCHEMA,
  role: process.env.SF_ROLE,
};

let sfconnector: any | null = null;
let isConnected = false;
let connectingPromise: Promise<any> | null = null;

function createConnection() {
  return snowflake.createConnection(connectionConfig);
}

function resetConnection(destroyConnection: boolean = true) {
  if (
    destroyConnection &&
    sfconnector &&
    typeof sfconnector.destroy === "function"
  ) {
    try {
      sfconnector.destroy((destroyErr: any) => {
        if (destroyErr) {
          logger.error({
            event: "SNOWFLAKE_DESTROY_FAILED",
            message: destroyErr.message,
          });
        }
      });
    } catch {
      // Ignore destroy errors; reconnect path will replace the connector.
    }
  }
  sfconnector = null;
  isConnected = false;
}

async function ensureConnection(): Promise<any> {
  if (sfconnector && isConnected) {
    return sfconnector;
  }

  if (connectingPromise) {
    return connectingPromise;
  }

  sfconnector = createConnection();
  connectingPromise = new Promise((resolve, reject) => {
    sfconnector.connect((err: any, conn: any) => {
      connectingPromise = null;
      if (err) {
        resetConnection(false);
        logger.error({
          event: "SNOWFLAKE_CONNECT_FAILED",
          message: err.message,
        });
        reject(err);
        return;
      }

      isConnected = true;
      logger.info({
        event: "SNOWFLAKE_CONNECT_SUCCESS",
        connection_id: conn.getId(),
      });
      resolve(conn);
    });
  });

  return connectingPromise;
}

function executeQuery<T = any>(
  conn: any,
  sqlText: string,
  binds: any[],
): Promise<T[]> {
  return new Promise((resolve, reject) => {
    conn.execute({
      sqlText,
      binds,
      complete: function (err: any, stmt: any, rows: any) {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      },
    });
  });
}

function isTerminatedConnectionError(err: any) {
  const msg = String(err?.message || "").toLowerCase();
  return msg.includes("terminated connection");
}

export function runQuery<T = any>(sqlText: string,  binds: any[] = []): Promise<T[]> {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  const start = Date.now();
  logEvent.action = "runQuery";
  return (async () => {
    try {
      const conn = await ensureConnection();
      const rows = await executeQuery<T>(conn, sqlText, binds);
      logger.info({
        trace_id: traceId,
        event: "QUERY_SUCCESS",
        message: "Snowflake query executed",
        duration_ms: Date.now() - start,
        status: "SUCCESS",
      });
      return rows;
    } catch (err: any) {
      if (isTerminatedConnectionError(err)) {
        logger.error({
          trace_id: traceId,
          event: "SNOWFLAKE_CONNECTION_TERMINATED",
          message: err.message,
          status: "RECONNECTING",
        });

        // Reset and retry once with a fresh connector.
        resetConnection();
        try {
          const conn = await ensureConnection();
          const rows = await executeQuery<T>(conn, sqlText, binds);
          logger.info({
            trace_id: traceId,
            event: "QUERY_SUCCESS_AFTER_RECONNECT",
            message: "Snowflake query executed after reconnect",
            duration_ms: Date.now() - start,
            status: "SUCCESS",
          });
          return rows;
        } catch (retryErr: any) {
          logger.error({
            trace_id: traceId,
            event: "QUERY_FAILED_AFTER_RECONNECT",
            message: retryErr.message,
            sql: sqlText,
            duration_ms: Date.now() - start,
            status: "FAILED",
          });
          throw new Error(`Query failed: ${retryErr.message}`);
        }
      }

      logger.error({
        trace_id: traceId,
        event: "QUERY_FAILED",
        message: err.message,
        sql: sqlText,
        duration_ms: Date.now() - start,
        status: "FAILED",
      });
      throw new Error(`Query failed: ${err.message}`);
    }
  })();
}

export default sfconnector;
