import { Pool, type PoolConfig } from "pg";
import "dotenv/config";

const zbpDatabase = process.env.ZBP_DB_NAME?.trim();

if (!zbpDatabase) {
  throw new Error("Database service is currently unavailable. Please try again later");
}

const connection: PoolConfig = {
  user: process.env.ZBP_DB_USER || process.env.DB_USER,
  host: process.env.ZBP_DB_HOST || process.env.DB_HOST,
  database: zbpDatabase,
  password: process.env.ZBP_DB_PASSWORD || process.env.DB_PASSWORD,
  port: Number(process.env.ZBP_DB_PORT || process.env.DB_PORT),
};

const zbpPool = new Pool({ ...connection, options: "-c search_path=zbp,public" });

/** The longest any search statement may run; the database itself stops it and reports error 57014. */
export const SEARCH_STATEMENT_TIMEOUT_MS = 20_000;

/**
 * A small separate pool for heavy, read-only searches over the large payment tables. Every connection starts with a
 * statement timeout and read-only transactions, so one slow search cannot hold a connection indefinitely or write,
 * and the main pool above is left exactly as it was.
 */
export const zbpSearchPool = new Pool({
  ...connection,
  max: 5,
  statement_timeout: SEARCH_STATEMENT_TIMEOUT_MS,
  options: "-c search_path=zbp,public -c default_transaction_read_only=on",
});

export default zbpPool;
