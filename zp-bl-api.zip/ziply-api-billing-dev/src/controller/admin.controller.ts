import { Request, Response } from "express";
import logger from "../logger/logger";
import {
  getAdjustmentTransactionsByAdjustmentIdService,
  getPaymentBatchCreatedUsersService,
  getPaymentBatchDpiAutopayRecordsService,
  getPaymentBatchDpiRecordsByFileService,
  getPaymentBatchPde0018RecordsByFileService,
  getPaymentBatchErrorRecordsService,
  getPaymentBatchErrorRecordsByFileService,
  getPaymentBatchFileDetailsService,
  getPaymentBatchFileNamesService,
  getPaymentBatchFilesService,
  getPaymentBatchFifthThirdRecordsByFileService,
  getPaymentBatchFiservRecordsByFileService,
  getPaymentBatchSourcesService,
  getPaymentBatchTransService,
  getPaymentBatchTransactionsByBatchRecordIdService,
  getPaymentTransactionsByPaymentIdService,
  getZbpAccountWhitelistByFileService,
  searchPaymentBatchFilesService,
} from "../service/admin.service";
import { getTraceId } from "../utils/logger";

const parsePositiveInteger = (
  value: unknown,
  fallback: number,
): number | undefined => {
  if (value === undefined) {
    return fallback;
  }

  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : undefined;
};

const parsePageParams = (
  req: Request,
): { page?: number; perPage?: number; error?: string } => {
  const page = parsePositiveInteger(req.query.page, 1);
  const requestedPerPage = parsePositiveInteger(req.query.perPage, 10);

  if (page === undefined || requestedPerPage === undefined) {
    return { error: "page and perPage must be positive integers" };
  }

  return { page, perPage: Math.min(requestedPerPage, 100) };
};

const parseOptionalPositiveInteger = (
  value: unknown,
): { value?: number; invalid: boolean } => {
  if (value === undefined || value === null || value === "") {
    return { invalid: false };
  }

  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed <= 0) {
    return { invalid: true };
  }

  return { value: parsed, invalid: false };
};

const parseRequiredPositiveInteger = (
  value: unknown,
): { value?: number; error?: string } => {
  if (value === undefined || value === null || value === "") {
    return { error: "must be a positive integer" };
  }

  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed <= 0) {
    return { error: "must be a positive integer" };
  }

  return { value: parsed };
};

const parseAdjustmentIdentifier = (
  value: unknown,
): { value?: string; error?: string } => {
  const normalized = String(value ?? "").trim();
  if (!normalized) {
    return { error: "must be a numeric value or ADJ-<number>" };
  }

  if (/^\d+$/.test(normalized) || /^ADJ-\d+$/i.test(normalized)) {
    return { value: normalized.toUpperCase() };
  }

  return { error: "must be a numeric value or ADJ-<number>" };
};

export const getPaymentBatchFiles = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const pageParams = parsePageParams(req);
  if (pageParams.error || pageParams.page === undefined || pageParams.perPage === undefined) {
    res.status(400).json({ message: pageParams.error });
    return;
  }

  try {
    const source = req.query.source ? String(req.query.source).trim() : undefined;
    const fileStatus = req.query.file_status
      ? String(req.query.file_status).trim()
      : undefined;

    const result = await getPaymentBatchFilesService(
      {
        source: source || undefined,
        fileStatus: fileStatus || undefined,
      },
      pageParams.page,
      pageParams.perPage,
    );

    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchFiles_FAILED",
      message: error?.message || String(error),
    });
    res.status(500).json({
      message: "Failed to fetch payment batch files",
      error: error?.message,
    });
  }
};

export const getPaymentBatchErrorRecords = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const pageParams = parsePageParams(req);
  if (pageParams.error || pageParams.page === undefined || pageParams.perPage === undefined) {
    res.status(400).json({ message: pageParams.error });
    return;
  }

  const parsedFileId = parseOptionalPositiveInteger(req.query.file_id);
  if (parsedFileId.invalid) {
    res.status(400).json({ message: "file_id must be a positive integer" });
    return;
  }

  try {
    const result = await getPaymentBatchErrorRecordsService(
      {
        fileId: parsedFileId.value,
      },
      pageParams.page,
      pageParams.perPage,
    );
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchErrorRecords_FAILED",
      message: error?.message || String(error),
    });
    res.status(500).json({
      message: "Failed to fetch payment batch error records",
      error: error?.message,
    });
  }
};

export const getPaymentBatchDpiAutopayRecords = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const pageParams = parsePageParams(req);
  if (pageParams.error || pageParams.page === undefined || pageParams.perPage === undefined) {
    res.status(400).json({ message: pageParams.error });
    return;
  }

  const parsedFileId = parseOptionalPositiveInteger(req.query.file_id);
  if (parsedFileId.invalid) {
    res.status(400).json({ message: "file_id must be a positive integer" });
    return;
  }

  try {
    const status = req.query.status ? String(req.query.status).trim() : undefined;
    const accountNum = req.query.account_num
      ? String(req.query.account_num).trim()
      : undefined;

    const result = await getPaymentBatchDpiAutopayRecordsService(
      {
        status: status || undefined,
        accountNum: accountNum || undefined,
        fileId: parsedFileId.value,
      },
      pageParams.page,
      pageParams.perPage,
    );

    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchDpiAutopayRecords_FAILED",
      message: error?.message || String(error),
    });
    res.status(500).json({
      message: "Failed to fetch payment batch DPI autopay records",
      error: error?.message,
    });
  }
};

export const getPaymentBatchTrans = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const pageParams = parsePageParams(req);
  if (pageParams.error || pageParams.page === undefined || pageParams.perPage === undefined) {
    res.status(400).json({ message: pageParams.error });
    return;
  }

  const parsedPaymentId = parseOptionalPositiveInteger(req.query.payment_id);
  if (parsedPaymentId.invalid) {
    res.status(400).json({ message: "payment_id must be a positive integer" });
    return;
  }

  try {
    const destination = req.query.destination
      ? String(req.query.destination).trim()
      : undefined;
    const status = req.query.status ? String(req.query.status).trim() : undefined;

    const result = await getPaymentBatchTransService(
      {
        paymentId: parsedPaymentId.value,
        destination: destination || undefined,
        status: status || undefined,
      },
      pageParams.page,
      pageParams.perPage,
    );

    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchTrans_FAILED",
      message: error?.message || String(error),
    });
    res.status(500).json({
      message: "Failed to fetch payment batch trans records",
      error: error?.message,
    });
  }
};

export const searchPaymentBatchFiles = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();

  try {
    const body = (req.body ?? {}) as Record<string, unknown>;

    const fileName = body.fileName ? String(body.fileName).trim() : undefined;
    const source = body.source ? String(body.source).trim() : undefined;
    const createdBy = body.createdBy ? String(body.createdBy).trim() : undefined;
    const dateFrom = body.dateFrom ? String(body.dateFrom).trim() : undefined;
    const dateTo = body.dateTo ? String(body.dateTo).trim() : undefined;

    if ((dateFrom && !dateTo) || (!dateFrom && dateTo)) {
      res.status(400).json({
        message: "dateFrom and dateTo must be provided together",
      });
      return;
    }

    if (dateFrom && dateTo) {
      const from = new Date(dateFrom);
      const to = new Date(dateTo);

      if (Number.isNaN(from.getTime()) || Number.isNaN(to.getTime())) {
        res.status(400).json({
          message: "dateFrom and dateTo must be valid dates",
        });
        return;
      }

      if (from > to) {
        res.status(400).json({
          message: "dateFrom cannot be after dateTo",
        });
        return;
      }
    }

    const rows = await searchPaymentBatchFilesService({
      fileName: fileName || undefined,
      source: source || undefined,
      createdBy: createdBy || undefined,
      dateFrom,
      dateTo,
    });

    res.status(200).json(rows);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "searchPaymentBatchFiles_FAILED",
      message: error?.message || String(error),
    });
    res.status(500).json({
      message: "Failed to search payment batch files",
      error: error?.message,
    });
  }
};

export const getPaymentBatchFileNames = async (
  _req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();

  try {
    const result = await getPaymentBatchFileNamesService();
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchFileNames_FAILED",
      message: error?.message || String(error),
    });
    res.status(500).json({
      message: "Failed to fetch payment batch file names",
      error: error?.message,
    });
  }
};

export const getPaymentBatchSources = async (
  _req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();

  try {
    const result = await getPaymentBatchSourcesService();
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchSources_FAILED",
      message: error?.message || String(error),
    });
    res.status(500).json({
      message: "Failed to fetch payment batch sources",
      error: error?.message,
    });
  }
};

export const getPaymentBatchCreatedUsers = async (
  _req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();

  try {
    const result = await getPaymentBatchCreatedUsersService();
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchCreatedUsers_FAILED",
      message: error?.message || String(error),
    });
    res.status(500).json({
      message: "Failed to fetch payment batch created users",
      error: error?.message,
    });
  }
};

export const getPaymentBatchFileDetails = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const parsedFileId = parseRequiredPositiveInteger(req.params.fileId);
  if (parsedFileId.error || parsedFileId.value === undefined) {
    res.status(400).json({ message: `fileId ${parsedFileId.error}` });
    return;
  }

  try {
    const result = await getPaymentBatchFileDetailsService(parsedFileId.value);
    if (!result) {
      res.status(404).json({ message: "Payment batch file not found" });
      return;
    }

    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchFileDetails_FAILED",
      message: error?.message || String(error),
      fileId: req.params.fileId,
    });
    res.status(500).json({
      message: "Failed to fetch payment batch file details",
      error: error?.message,
    });
  }
};

export const getPaymentBatchDpiRecordsByFile = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const parsedFileId = parseRequiredPositiveInteger(req.params.fileId);
  if (parsedFileId.error || parsedFileId.value === undefined) {
    res.status(400).json({ message: `fileId ${parsedFileId.error}` });
    return;
  }

  try {
    const result = await getPaymentBatchDpiRecordsByFileService(parsedFileId.value);
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchDpiRecordsByFile_FAILED",
      message: error?.message || String(error),
      fileId: req.params.fileId,
    });
    res.status(500).json({
      message: "Failed to fetch payment batch DPI records",
      error: error?.message,
    });
  }
};

export const getPaymentBatchFiservRecordsByFile = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const parsedFileId = parseRequiredPositiveInteger(req.params.fileId);
  if (parsedFileId.error || parsedFileId.value === undefined) {
    res.status(400).json({ message: `fileId ${parsedFileId.error}` });
    return;
  }

  try {
    const result = await getPaymentBatchFiservRecordsByFileService(parsedFileId.value);
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchFiservRecordsByFile_FAILED",
      message: error?.message || String(error),
      fileId: req.params.fileId,
    });
    res.status(500).json({
      message: "Failed to fetch payment batch fiserv records",
      error: error?.message,
    });
  }
};

export const getPaymentBatchFifthThirdRecordsByFile = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const parsedFileId = parseRequiredPositiveInteger(req.params.fileId);
  if (parsedFileId.error || parsedFileId.value === undefined) {
    res.status(400).json({ message: `fileId ${parsedFileId.error}` });
    return;
  }

  try {
    const result = await getPaymentBatchFifthThirdRecordsByFileService(parsedFileId.value);
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchFifthThirdRecordsByFile_FAILED",
      message: error?.message || String(error),
      fileId: req.params.fileId,
    });
    res.status(500).json({
      message: "Failed to fetch payment batch fifth-third records",
      error: error?.message,
    });
  }
};

export const getZbpAccountWhitelistByFile = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const parsedFileId = parseRequiredPositiveInteger(req.params.fileId);
  if (parsedFileId.error || parsedFileId.value === undefined) {
    res.status(400).json({ message: `fileId ${parsedFileId.error}` });
    return;
  }

  try {
    const result = await getZbpAccountWhitelistByFileService(parsedFileId.value);
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getZbpAccountWhitelistByFile_FAILED",
      message: error?.message || String(error),
      fileId: req.params.fileId,
    });
    res.status(500).json({
      message: "Failed to fetch payment batch whitelist records",
      error: error?.message,
    });
  }
};

export const getPaymentBatchPde0018RecordsByFile = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const parsedFileId = parseRequiredPositiveInteger(req.params.fileId);
  if (parsedFileId.error || parsedFileId.value === undefined) {
    res.status(400).json({ message: `fileId ${parsedFileId.error}` });
    return;
  }

  try {
    const result = await getPaymentBatchPde0018RecordsByFileService(parsedFileId.value);
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchPde0018RecordsByFile_FAILED",
      message: error?.message || String(error),
      fileId: req.params.fileId,
    });
    res.status(500).json({
      message: "Failed to fetch payment batch PDE0018 records",
      error: error?.message,
    });
  }
};

export const getPaymentBatchErrorRecordsByFile = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const parsedFileId = parseRequiredPositiveInteger(req.params.fileId);
  if (parsedFileId.error || parsedFileId.value === undefined) {
    res.status(400).json({ message: `fileId ${parsedFileId.error}` });
    return;
  }

  try {
    const result = await getPaymentBatchErrorRecordsByFileService(parsedFileId.value);
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchErrorRecordsByFile_FAILED",
      message: error?.message || String(error),
      fileId: req.params.fileId,
    });
    res.status(500).json({
      message: "Failed to fetch payment batch error records",
      error: error?.message,
    });
  }
};

export const getPaymentBatchTransactionsByBatchRecordId = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const parsedBatchRecordId = parseRequiredPositiveInteger(req.params.batchRecordId);
  if (parsedBatchRecordId.error || parsedBatchRecordId.value === undefined) {
    res.status(400).json({ message: `batchRecordId ${parsedBatchRecordId.error}` });
    return;
  }

  try {
    const result = await getPaymentBatchTransactionsByBatchRecordIdService(parsedBatchRecordId.value);
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchTransactionsByBatchRecordId_FAILED",
      message: error?.message || String(error),
      batchRecordId: req.params.batchRecordId,
    });
    res.status(500).json({
      message: "Failed to fetch batch transactions",
      error: error?.message,
    });
  }
};

export const getPaymentTransactionsByPaymentId = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const parsedPaymentId = parseRequiredPositiveInteger(req.params.paymentId);
  if (parsedPaymentId.error || parsedPaymentId.value === undefined) {
    res.status(400).json({ message: `paymentId ${parsedPaymentId.error}` });
    return;
  }

  try {
    const result = await getPaymentTransactionsByPaymentIdService(parsedPaymentId.value);
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentTransactionsByPaymentId_FAILED",
      message: error?.message || String(error),
      paymentId: req.params.paymentId,
    });
    res.status(500).json({
      message: "Failed to fetch payment transactions",
      error: error?.message,
    });
  }
};

export const getAdjustmentTransactionsByAdjustmentId = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const parsedAdjustmentId = parseAdjustmentIdentifier(req.params.adjustmentId);
  if (parsedAdjustmentId.error || !parsedAdjustmentId.value) {
    res.status(400).json({ message: `adjustmentId ${parsedAdjustmentId.error}` });
    return;
  }

  try {
    const result = await getAdjustmentTransactionsByAdjustmentIdService(parsedAdjustmentId.value);
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getAdjustmentTransactionsByAdjustmentId_FAILED",
      message: error?.message || String(error),
      adjustmentId: req.params.adjustmentId,
    });
    res.status(500).json({
      message: "Failed to fetch adjustment transactions",
      error: error?.message,
    });
  }
};
