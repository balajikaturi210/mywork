import { Request, Response } from "express";
import { getARAgingService } from "../service/arAging.services";

import { getTraceId } from "../utils/logger";

import logger, {
  eventLog,
  inbound,
  categoryOpt,
  eventOpt,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "controller/arAging.controller";
const inboundLog = inbound();
const httpLogReq = logReq();
const httpLogRes = logRes();

export const getARAging = async (req: Request, res: Response) => {
   const logEvent = JSON.parse(JSON.stringify(eventData));
    let traceId = getTraceId();
    logEvent.action = "getARAging";
    const as_of = (req.query.as_of as string) || "";

    let segment = (req.query.segment as string) || "ALL";
    const aging_by = (req.query.aging_by as string) || "due-date";
    const incl_dbt = (req.query.debit_adj as string) || "1";

    // default as_of logic (same as Flask)
    let finalAsOf = as_of;
    if (!finalAsOf) {
      const today = new Date();
      const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
      const lastMonthEnd = new Date(firstDay.getTime() - 86400000);
      finalAsOf = lastMonthEnd.toISOString().split("T")[0];
    }
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const data = await getARAgingService({
      as_of: finalAsOf,
      segment,
      aging_by,
      incl_dbt,
      traceId
    });
    logger.info({
       message: `getARAging completed `,
       event: {
         ...logEvent,
         ...categoryOpt.web,
         ...(data ? eventOpt.successEnd : eventOpt.failureError),
       },
       ...inboundLog,
       http: {
         response: { body: { content: JSON.stringify({ data }) } },
       },
       ziply: { finalAsOf,
      segment,
      aging_by,
      incl_dbt,
      traceId},
     });

    return res.status(200).json(data);
  } catch (error:any) {
      httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
 logger.error({
      message: `getARAging: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
  ziply: { finalAsOf,
      segment,
      aging_by,
      incl_dbt,
      traceId},
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    return res.status(500).json({
      message: "Failed to fetch AR aging data",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};
