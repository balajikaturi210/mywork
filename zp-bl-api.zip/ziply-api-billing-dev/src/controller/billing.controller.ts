import { Request, Response } from "express";
import { getTraceId, logger } from "../utils/logger";
import {
  getAccountReceivableService,
  getAccountHistoryService,
  getAccountService,
  getGtvBillingAccountDetails,
  getPaymentMethodsService,
  getPaymentsService,
  getTreatmentService,
} from "../service/billing.service";
import {
  BillingReceivableServiceRequest,
  BillingServiceError,
  BillingServiceRequest,
  BillingTreatmentServiceRequest,
  GetAccountHistoryRequest,
  GetAccountRequest,
  GetAccountReceivableRequest,
  GetPaymentMethodsRequest,
  GetPaymentsRequest,
  GetTreatmentRequest,
} from "../types/billing.types";

const normalizeTnForDpi = (
  value: unknown,
  fieldName: "telephoneNumber" | "workingTelephoneNumber",
): string => {
  const normalized = String(value ?? "").trim();

  if (!normalized) {
    throw new BillingServiceError(
      `${fieldName} is required and must be 10 digits`,
      400,
    );
  }

  if (!/^\d+$/.test(normalized)) {
    throw new BillingServiceError(
      `${fieldName} must contain only digits`,
      400,
    );
  }

  if (normalized.length !== 10) {
    throw new BillingServiceError(
      `${fieldName} is required and must be 10 digits`,
      400,
    );
  }

  return normalized;
};

const normalizeGetAccountRequest = (
  payload: GetAccountRequest,
): BillingServiceRequest => {
  const telephoneNumber = normalizeTnForDpi(payload.telephoneNumber, "telephoneNumber");
  const environment = String(payload.environment || "")
    .trim()
    .toUpperCase() as "NW" | "CA";
  const crisId = Number(
    payload.crisId
      ?? payload.crsid
      ?? 0,
  );
  const universalServiceNumberRaw =
    payload.universalServiceNumber === undefined
      ? undefined
      : Number(payload.universalServiceNumber);
  const trackingIdRaw =
    payload.trackingId
    ?? "1";
  const trackingId = String(trackingIdRaw).trim() || "1";

  if (environment !== "NW" && environment !== "CA") {
    throw new BillingServiceError("environment must be NW or CA", 400);
  }

  if (!Number.isFinite(crisId) || crisId <= 0) {
    throw new BillingServiceError("crisId is required and must be a positive number", 400);
  }

  return {
    telephoneNumber,
    environment,
    crisId,
    universalServiceNumber:
      universalServiceNumberRaw !== undefined
      && Number.isFinite(universalServiceNumberRaw)
      && universalServiceNumberRaw > 0
        ? universalServiceNumberRaw
        : undefined,
    userId: String(payload.userId ?? "KET446"),
    applicationId: String(payload.applicationId ?? "CXP"),
    sequenceNumber: Number(payload.sequenceNumber ?? 0),
    trackingId,
  };
};

const normalizeYnFlag = (value: unknown, fallback: "Y" | "N"): "Y" | "N" => {
  const normalized = String(value ?? fallback).trim().toUpperCase();
  return normalized === "Y" ? "Y" : "N";
};

const normalizeGetAccountReceivableRequest = (
  payload: GetAccountReceivableRequest,
): BillingReceivableServiceRequest => {
  const workingTelephoneNumber = normalizeTnForDpi(
    payload.workingTelephoneNumber,
    "workingTelephoneNumber",
  );
  const environment = String(payload.environment || "")
    .trim()
    .toUpperCase() as "NW" | "CA";
  const crisId = Number(payload.crisId ?? 0);

  if (environment !== "NW" && environment !== "CA") {
    throw new BillingServiceError("environment must be NW or CA", 400);
  }

  if (!Number.isFinite(crisId) || crisId <= 0) {
    throw new BillingServiceError("crisId is required and must be a positive number", 400);
  }

  return {
    crisId,
    environment,
    userId: String(payload.userId ?? "s_cxpapi"),
    workingTelephoneNumber,
    sequenceNumber: Number(payload.sequenceNumber ?? 0),
    includeAcctRcvDetail: normalizeYnFlag(payload.includeAcctRcvDetail, "N"),
    includeAcctRcvSummary: normalizeYnFlag(payload.includeAcctRcvSummary, "N"),
    includeCurrentBalance: normalizeYnFlag(payload.includeCurrentBalance, "N"),
    includePaymentHistory: normalizeYnFlag(payload.includePaymentHistory, "N"),
    includeAdjustmentHistory: normalizeYnFlag(payload.includeAdjustmentHistory, "Y"),
    maximumAdjustmentHistoryQty: Number(payload.maximumAdjustmentHistoryQty ?? 500),
    summaryNumberFlag_C_F01SUMF: normalizeYnFlag(payload.summaryNumberFlag_C_F01SUMF, "N"),
  };
};

const normalizeGetTreatmentRequest = (
  payload: GetTreatmentRequest,
): BillingTreatmentServiceRequest => {
  const environment = String(payload.environment || "")
    .trim()
    .toUpperCase() as "NW" | "CA";
  const crisId = Number(payload.crisId ?? 0);
  const sequenceNumber = Number(payload.sequenceNumber ?? 0);
  const debugDelay =
    payload.debugDelay === undefined ? undefined : Number(payload.debugDelay);
  const universalServiceNumber =
    payload.universalServiceNumber === undefined
      ? undefined
      : Number(payload.universalServiceNumber);
  const workingTelephoneNumberRaw = String(payload.workingTelephoneNumber ?? "").trim();
  const workingTelephoneNumber = workingTelephoneNumberRaw
    ? normalizeTnForDpi(workingTelephoneNumberRaw, "workingTelephoneNumber")
    : undefined;

  if (environment !== "NW" && environment !== "CA") {
    throw new BillingServiceError("environment must be NW or CA", 400);
  }

  if (!Number.isFinite(crisId) || crisId <= 0) {
    throw new BillingServiceError("crisId is required and must be a positive number", 400);
  }

  if (!workingTelephoneNumber && universalServiceNumber === undefined) {
    throw new BillingServiceError(
      "Either workingTelephoneNumber or universalServiceNumber is required",
      400,
    );
  }

  return {
    crisId,
    environment,
    userId: String(payload.userId ?? "KET446"),
    sequenceNumber: Number.isFinite(sequenceNumber) ? sequenceNumber : 0,
    debugDelay: debugDelay !== undefined && Number.isFinite(debugDelay) ? debugDelay : undefined,
    universalServiceNumber:
      universalServiceNumber !== undefined && Number.isFinite(universalServiceNumber)
        ? universalServiceNumber
        : undefined,
    workingTelephoneNumber,
  };
};

const normalizeBillingAccountId = (value: unknown): string => {
  const billingAccountId = String(value ?? "").trim();

  if (!billingAccountId || !/^\d+$/.test(billingAccountId)) {
    throw new BillingServiceError(
      "Invalid billing_account_id. It must contain digits only.",
      400,
    );
  }

  return billingAccountId;
};

const normalizePaymentMethodsRequest = (req: Request): GetPaymentMethodsRequest => {
  const billingAccountId = normalizeBillingAccountId(req.params.billing_account_id);
  const sortRaw = String(req.query.sort ?? "id").trim();

  return {
    billingAccountId,
    sort: sortRaw || "id",
  };
};

const normalizePaymentsRequest = (req: Request): GetPaymentsRequest => {
  const billingAccountId = normalizeBillingAccountId(req.params.billing_account_id);

  return { billingAccountId };
};

const normalizeAccountHistoryRequest = (req: Request): GetAccountHistoryRequest => {
  const billingAccountId = normalizeBillingAccountId(req.params.billing_account_id);

  return { billingAccountId };
};

export const getAccount = async (req: Request, res: Response): Promise<void> => {
  const traceId = getTraceId();

  try {
    const request = normalizeGetAccountRequest(req.body as GetAccountRequest);

    logger.info({
      traceId,
      event: "BILLING_GET_ACCOUNT_REQUEST",
      environment: request.environment,
      telephoneNumber: request.telephoneNumber,
    });

    const result = await getAccountService(request);

    res.status(200).json(result);
  } catch (error) {
    const known = error as BillingServiceError;
    const statusCode = known?.statusCode || 500;
    const message = known?.message || "Failed to fetch account data";

    logger.error({
      traceId,
      event: "BILLING_GET_ACCOUNT_FAILED",
      message,
      details: known?.details,
    });

    res.status(statusCode).json({ message });
  }
};

export const getAccountReceivable = async (req: Request, res: Response): Promise<void> => {
  const traceId = getTraceId();

  try {
    const request = normalizeGetAccountReceivableRequest(req.body as GetAccountReceivableRequest);

    logger.info({
      traceId,
      event: "BILLING_GET_ACCOUNT_RECEIVABLE_REQUEST",
      environment: request.environment,
      workingTelephoneNumber: request.workingTelephoneNumber,
      crisId: request.crisId,
    });

    const result = await getAccountReceivableService(request);

    res.status(200).json(result);
  } catch (error) {
    const known = error as BillingServiceError;
    const statusCode = known?.statusCode || 500;
    const message = known?.message || "Failed to fetch account receivable data";

    logger.error({
      traceId,
      event: "BILLING_GET_ACCOUNT_RECEIVABLE_FAILED",
      message,
      details: known?.details,
    });

    res.status(statusCode).json({ message });
  }
};

export const getTreatment = async (req: Request, res: Response): Promise<void> => {
  const traceId = getTraceId();

  try {
    const request = normalizeGetTreatmentRequest(req.body as GetTreatmentRequest);

    logger.info({
      traceId,
      event: "BILLING_GET_TREATMENT_REQUEST",
      environment: request.environment,
      crisId: request.crisId,
      workingTelephoneNumber: request.workingTelephoneNumber,
    });

    const result = await getTreatmentService(request);

    res.status(200).json(result);
  } catch (error) {
    const known = error as BillingServiceError;
    const statusCode = known?.statusCode || 500;
    const message = known?.message || "Failed to fetch treatment data";

    logger.error({
      traceId,
      event: "BILLING_GET_TREATMENT_FAILED",
      message,
      details: known?.details,
    });

    res.status(statusCode).json({ message });
  }
};

export const getPaymentMethods = async (req: Request, res: Response): Promise<void> => {
  const traceId = getTraceId();

  try {
    const request = normalizePaymentMethodsRequest(req);

    logger.info({
      traceId,
      event: "PAYMENT_CORE_GET_PAYMENT_METHODS_API_REQUEST",
      billingAccountId: request.billingAccountId,
      sort: request.sort,
    });

    const result = await getPaymentMethodsService(request);
    res.status(200).json(result);
  } catch (error) {
    const known = error as BillingServiceError;
    const statusCode = known?.statusCode || 500;
    const message = known?.message || "Failed to fetch recurring payment methods";

    logger.error({
      traceId,
      event: "PAYMENT_CORE_GET_PAYMENT_METHODS_API_FAILED",
      message,
      details: known?.details,
    });

    res.status(statusCode).json({ message });
  }
};

export const getPayments = async (req: Request, res: Response): Promise<void> => {
  const traceId = getTraceId();

  try {
    const request = normalizePaymentsRequest(req);

    logger.info({
      traceId,
      event: "PAYMENT_CORE_GET_PAYMENTS_API_REQUEST",
      billingAccountId: request.billingAccountId,
    });

    const result = await getPaymentsService(request);
    res.status(200).json(result);
  } catch (error) {
    const known = error as BillingServiceError;
    const statusCode = known?.statusCode || 500;
    const message = known?.message || "Failed to fetch payments";

    logger.error({
      traceId,
      event: "PAYMENT_CORE_GET_PAYMENTS_API_FAILED",
      message,
      details: known?.details,
    });

    res.status(statusCode).json({ message });
  }
};

export const getAccountHistory = async (req: Request, res: Response): Promise<void> => {
  const traceId = getTraceId();

  try {
    const request = normalizeAccountHistoryRequest(req);

    logger.info({
      traceId,
      event: "PAYMENT_CORE_GET_ACCOUNT_HISTORY_API_REQUEST",
      billingAccountId: request.billingAccountId,
    });

    const result = await getAccountHistoryService(request);
    res.status(200).json(result);
  } catch (error) {
    const known = error as BillingServiceError;
    const statusCode = known?.statusCode || 500;
    const message = known?.message || "Failed to fetch account history";

    logger.error({
      traceId,
      event: "PAYMENT_CORE_GET_ACCOUNT_HISTORY_API_FAILED",
      message,
      details: known?.details,
    });

    res.status(statusCode).json({ message });
  }
};


export const getGtvAccount = async (req: Request, res: Response): Promise<void> => {
  const traceId = getTraceId();

  try {
    const accountNumberParam = req.params.accountNumber;
    const accountNumber = Array.isArray(accountNumberParam)
      ? accountNumberParam[0]
      : accountNumberParam;

    const result = await getGtvBillingAccountDetails(accountNumber);

    res.status(200).json(result);
  } catch (error) {
    const known = error as BillingServiceError;
    const statusCode = known?.statusCode || 500;
    const message = known?.message || "Failed to fetch account data";

    logger.error({
      traceId,
      event: "BILLING_GET_ACCOUNT_FAILED",
      message,
      details: known?.details,
    });

    res.status(statusCode).json({ message });
  }
};
