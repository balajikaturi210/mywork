import os from "os";
import { Request, Response, NextFunction } from "express";
import multer from "multer";
import logger from "../logger/logger";
import { CabsFilters } from "../types/cabs.types";
import { LoadInProgressError, startSnapshot } from "../service/cabs/cabs.loader";
import {
  exportDetailsCsv, getCircuitUsoc, getDetails, getFilterOptions, getSnapshot, getSummary, listSnapshots, resolveSnapshotId,
} from "../service/cabs/cabs.queries";

const MAX_FILE_MB = Number(process.env.CABS_MAX_FILE_MB || 200);

const uploader = multer({ dest: os.tmpdir(), limits: { fileSize: MAX_FILE_MB * 1024 * 1024, files: 4 } }).fields([
  { name: "billing_file", maxCount: 1 },
  { name: "aging_file", maxCount: 1 },
  { name: "bdt_file", maxCount: 1 },
  { name: "bdt_small_file", maxCount: 1 },
]);

export const cabsUploadMiddleware = (req: Request, res: Response, next: NextFunction) => {
  uploader(req, res, (err: unknown) => {
    if (!err) return next();
    const e = err as { code?: string; message?: string };
    const status = e.code === "LIMIT_FILE_SIZE" ? 413 : 400;
    res.status(status).json({ error: e.code === "LIMIT_FILE_SIZE" ? `A file is larger than ${MAX_FILE_MB} MB` : (e.message ?? "Upload failed") });
  });
};

const fail = (res: Response, action: string, err: unknown, status = 500) => {
  const message = err instanceof Error ? err.message : String(err);
  logger.error({ message: `CABS ${action} failed: ${message}` });
  res.status(status).json({ error: message });
};

const str = (v: unknown): string | undefined => (typeof v === "string" && v.trim() !== "" ? v.trim() : undefined);
const int = (v: unknown): number | undefined => {
  const n = Number(v);
  return str(v) !== undefined && Number.isInteger(n) ? n : undefined;
};

const filtersOf = (q: Request["query"]): CabsFilters => ({
  co: str(q.co), ixc: str(q.ixc), ban: str(q.ban), status: str(q.status), critical: str(q.critical),
  min_past_due: str(q.min_past_due) !== undefined && Number.isFinite(Number(q.min_past_due)) ? Number(q.min_past_due) : undefined,
  aging_bucket: str(q.aging_bucket), bdt_status: str(q.bdt_status), search: str(q.search),
});

const EXTENSIONS: Record<string, RegExp> = { billing_file: /\.xlsx$/i, aging_file: /\.xlsx$/i, bdt_file: /\.csv$/i, bdt_small_file: /\.csv$/i };

export const cabsUpload = async (req: Request, res: Response) => {
  const files = (req.files ?? {}) as Record<string, Express.Multer.File[]>;
  const missing = Object.keys(EXTENSIONS).filter((f) => !files[f]?.[0]?.originalname);
  if (missing.length) return res.status(400).json({ error: `Missing required file(s): ${missing.join(", ")}` });
  const wrong = Object.entries(EXTENSIONS).filter(([f, ext]) => !ext.test(files[f][0].originalname)).map(([f]) => f);
  if (wrong.length) {
    return res.status(400).json({ error: `Wrong file type for: ${wrong.join(", ")} (the billing and aging files are .xlsx, the BDT files .csv)` });
  }
  try {
    const pick = (f: string) => ({ path: files[f][0].path, originalname: files[f][0].originalname });
    const id = await startSnapshot(str(req.body?.label) ?? null,
      { billing: pick("billing_file"), aging: pick("aging_file"), bdt: pick("bdt_file"), bdtSmall: pick("bdt_small_file") }, null);
    res.status(202).json(await getSnapshot(id));
  } catch (err) {
    fail(res, "upload", err, err instanceof LoadInProgressError ? 409 : 500);
  }
};

export const cabsSnapshots = async (_req: Request, res: Response) => {
  try {
    res.json(await listSnapshots());
  } catch (err) {
    fail(res, "snapshots", err);
  }
};

export const cabsSnapshot = async (req: Request, res: Response) => {
  try {
    const snap = await getSnapshot(Number(req.params.id));
    if (!snap) return res.status(404).json({ error: "Snapshot not found" });
    res.json(snap);
  } catch (err) {
    fail(res, "snapshot", err);
  }
};

const withSnapshot = (handler: (snapshotId: number, req: Request, res: Response) => Promise<unknown>, action: string, missingBody: unknown) =>
  async (req: Request, res: Response) => {
    try {
      const snapshotId = await resolveSnapshotId(int(req.query.snapshot_id));
      if (!snapshotId) return res.status(404).json(missingBody);
      await handler(snapshotId, req, res);
    } catch (err) {
      fail(res, action, err);
    }
  };

const NONE = { error: "No CABS snapshot uploaded yet" };

export const cabsSummary = withSnapshot(async (id, req, res) => res.json(await getSummary(id, filtersOf(req.query))), "summary", NONE);

export const cabsDetails = withSnapshot(async (id, req, res) =>
  res.json(await getDetails(id, filtersOf(req.query), int(req.query.page) ?? 1, int(req.query.page_size) ?? 100, str(req.query.sort), str(req.query.dir))),
  "details", NONE);

export const cabsDetailsExport = withSnapshot(async (id, req, res) => {
  const csv = await exportDetailsCsv(id, filtersOf(req.query));
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", `attachment; filename="cabs_circuit_report_${id}.csv"`);
  res.send(csv);
}, "export", NONE);

export const cabsFilterOptions = withSnapshot(async (id, req, res) => {
  const q = filtersOf(req.query);
  res.json(await getFilterOptions(id, { co: q.co, ixc: q.ixc, bdt_status: q.bdt_status, ban: q.ban }));
}, "filter-options", { co: [], ixc: [], bdt_status: [], ban: [] });

export const cabsCircuitUsoc = withSnapshot(async (id, req, res) => {
  const co = str(req.query.co);
  const circuit = str(req.query.circuit);
  if (!co || !circuit) return res.status(400).json({ error: "snapshot_id, co, and circuit are required" });
  res.json(await getCircuitUsoc(id, co, circuit));
}, "circuit-usoc", { error: "snapshot_id, co, and circuit are required" });
