import { Request, Response } from "express";
import { getTraceId } from "../utils/logger";
import { getCustomerJourneyService } from "../service/customerJourney.services";

import logger, {
  eventLog,
  inbound,
  categoryOpt,
  eventOpt,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "controller/surcharge.controller";
const inboundLog = inbound();
const httpLogReq = logReq();
const httpLogRes = logRes();

export const getCustomerJourney = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getARAging";
  const account_num = ((req.query.account_num as string) || "").trim();
  if (!account_num) {
      res.status(400).json({ message: "account_num required" });
      return;
  }
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const result = await getCustomerJourneyService(account_num,traceId);

   logger.info({
        message: `getCustomerJourney completed `,
        event: {
          ...logEvent,
          ...categoryOpt.web,
          ...(result ? eventOpt.successEnd : eventOpt.failureError),
        },
        ...inboundLog,
        http: {
          response: { body: { content: JSON.stringify({ result }) } },
        },
        ziply: { account_num },
      });
  

    res.json(result);
  } catch (error: any) {
  
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
 logger.error({
      message: `getCustomerJourney: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
  ziply: { account_num},
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch customer journey",
      error: error.message,
    });
  }
};
