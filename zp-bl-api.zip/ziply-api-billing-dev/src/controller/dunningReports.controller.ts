import { Request, Response } from "express";
import {
  getDDCurrentService,
  getDDResolutionService,
  getDdCurrentDownloadService,
} from "../service/dunningReports.services";
import { getTraceId } from "../utils/logger";
import { createObjectCsvStringifier } from "csv-writer";
import { getISODate } from "../utils/helper";

import logger, {
  eventLog,
  inbound,
  categoryOpt,
  eventOpt,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "controller/dunningReports.controller";
const inboundLog = inbound();
const httpLogReq = logReq();
const httpLogRes = logRes();

export const getDDCurrent = async (req: Request, res: Response) => {
  const minBal = Number(req.query.min_bal || 100);
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getDDCurrent";
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const data = await getDDCurrentService({
      min_bal: minBal,
      traceId,
    });

    logger.info({
      message: `getDDCurrent completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { minBal },
    });
    return res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getDDCurrent: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { minBal },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    return res.status(500).json({
      message: "Failed to fetch DD Current data",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const getDDResolution = async (req: Request, res: Response) => {
  const months = Number(req.query.months || 6);
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getDDResolution";
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });

    const result = await getDDResolutionService(months, traceId);
    logger.info({
      message: `getDDResolution completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(result ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ result }) } },
      },
      ziply: { months },
    });

    return res.status(200).json(result);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getDDResolution: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { months },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    return res.status(500).json({
      error: "Failed Fetch DD Resolution",
      message: error?.message,
    });
  }
};

export const getCurrentDownload = async (req: Request, res: Response) => {
  let traceId = getTraceId();
  const bucket = (req.query.bucket as string) || "";
  const min_bal = req.query.min_bal ? Number(req.query.min_bal) : 100;
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getCurrentDownload";
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });

    const rows = await getDdCurrentDownloadService({
      bucket,
      min_bal,
      traceId
    });

      logger.info({
      message: `getCurrentDownload completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(rows ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ rows }) } },
      },
      ziply: { bucket,
      min_bal },
    });

    const cols = [
      "account_num",
      "first_name",
      "last_name",
      "segment",
      "category",
      "balance",
      "due_date",
      "days_past_due",
      "bucket",
      "dunning_plan",
      "bill_cycle",
    ];

    const csv = createObjectCsvStringifier({
      header: cols.map((c) => ({
        id: c.toUpperCase(),
        title: c.toUpperCase(),
      })),
    });

    const csvData = csv.getHeaderString() + csv.stringifyRecords(rows);

    const fname = `dd_current_${bucket || "ALL"}_${getISODate()}.csv`;

    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", `attachment; filename="${fname}"`);

    logger.info({
      traceId,
      message: "CSV generated",
      file: fname,
    });

    return res.status(200).send(csvData);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getCurrentDownload: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { bucket,
      min_bal },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });

    return res.status(500).json({
      error: "Failed to Download Report",
      message: error?.message,
    });
  }
};
