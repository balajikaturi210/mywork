import { Request, Response } from "express";
import {
  getNpdWriteoffTrendService,
  getNpdMissingWriteoffTrendService,
  getNPDWriteoffAccountsService,
  getWriteoffPaymentsService,
  getNpdMissingWriteoffAccountsService,
  getWriteoffDayAccountsService,
} from "../service/npdWriteOff.services";
import { getTraceId } from "../utils/logger";
import { DAY_REGEX, MONTH_REGEX } from "../constants/helper.contants";

import logger, {
  eventLog,
  inbound,
  categoryOpt,
  eventOpt,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "controller/npdWriteOff.controller";
const inboundLog = inbound();
const httpLogReq = logReq();
const httpLogRes = logRes();

export const getNpdWriteoffTrend = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getNpdWriteoffTrend";
  try {
    httpLogReq.http.request.method = "GET";
    const data = await getNpdWriteoffTrendService(traceId);
    logger.info({
      message: `getNpdWriteoffTrend completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
    });

    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getNpdWriteoffTrend: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch NPD writeoff trend",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const getNpdMissingWriteoffTrend = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getNpdMissingWriteoffTrend";
  try {
    httpLogReq.http.request.method = "GET";
    const data = await getNpdMissingWriteoffTrendService(traceId);
    logger.info({
      message: `getNpdMissingWriteoffTrend completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
    });

    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getNpdMissingWriteoffTrend: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });

    res.status(500).json({
      message: "Failed to fetch NPD missing writeoff trend",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const getNPDWriteoffAccounts = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getNPDWriteoffAccounts";
  const month = String(req.query.month || "");
  if (!MONTH_REGEX.test(month)) {
    throw new Error("invalid month — expected YYYY-MM");
  }
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const data = await getNPDWriteoffAccountsService(month, traceId);

    logger.info({
      message: `getNPDWriteoffAccounts completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { month },
    });

    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getNPDWriteoffAccounts: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { month },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });

    if (error.message.includes("invalid month")) {
      res.status(400).json({
        error: error.message,
      });
      return;
    }

    res.status(500).json({
      message: "Failed to fetch NPD writeoff accounts",
      error: error.message,
    });
  }
};

export const getWriteoffPayments = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const days = Number(req.query.days ?? 30);
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getWriteoffPayments";
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });

    const data = await getWriteoffPaymentsService(days, traceId);
    logger.info({
      message: `getWriteoffPayments completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { days },
    });

    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getWriteoffPayments: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { days },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });

    res.status(500).json({
      message: "Failed to fetch writeoff payments",
      error: error.message,
    });
  }
};

export const getNpdMissingWriteoffAccounts = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getNpdMissingWriteoffAccounts";
  const month = String(req.query.month || "");
  if (!MONTH_REGEX.test(month)) {
    throw new Error("invalid month — expected YYYY-MM");
  }
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const data = await getNpdMissingWriteoffAccountsService(month, traceId);
    logger.info({
      message: `getNpdMissingWriteoffAccounts completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { month },
    });

    res.status(200).json(data);
  } catch (error: any) {
    if (error.message.includes("invalid month")) {
      res.status(400).json({ error: error.message });
      return;
    }

    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getNpdMissingWriteoffAccounts: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { month },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });

    res.status(500).json({
      message: "Failed to fetch missing writeoff accounts",
      error: error.message,
    });
  }
};

export const getWriteoffDayAccounts = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getWriteoffDayAccounts";
  const day = String(req.query.day || "");

  if (!DAY_REGEX.test(day)) {
    throw new Error("invalid day — expected YYYY-MM-DD");
  }
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });

    const data = await getWriteoffDayAccountsService(day, traceId);
    logger.info({
      message: `getWriteoffDayAccounts completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { day },
    });

    res.status(200).json(data);
  } catch (error: any) {
    if (error.message === "day parameter required") {
      res.status(400).json({ error: error.message });
      return;
    }

    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getWriteoffDayAccounts: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { day },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });

    res.status(500).json({
      message: "Failed to fetch writeoff day accounts",
      error: error.message,
    });
  }
};
