import { Request, Response } from "express";
import {
  getNpdWriteoffBacklogService,
  getNpdWriteoffPlanEntriesService,
  getNpdWriteoffUecTrendService,
} from "../service/npdWriteOffUec.services";
import { NpdWriteoffValidationError, parseMonths } from "../utils/npdWriteOffUec";
import { getTraceId } from "../utils/logger";
import logger, { eventLog, inbound, categoryOpt, eventOpt } from "../logger/logger";

const eventData = eventLog();
eventData.module = "controller/npdWriteOffUec.controller";
const inboundLog = inbound();

/** Shared handler: validates `months`, runs the service, answers 200 / 400 / 500. */
const handle =
  <T>(action: string, defaultMonths: number, run: (months: number, traceId: string) => Promise<T>) =>
  async (req: Request, res: Response): Promise<void> => {
    const logEvent = { ...JSON.parse(JSON.stringify(eventData)), action };
    const traceId = getTraceId();
    let months: number;
    try {
      months = parseMonths(req.query.months, defaultMonths);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
      return;
    }
    try {
      const data = await run(months, traceId);
      logger.info({
        message: `${action} completed`,
        event: { ...logEvent, ...categoryOpt.web, ...eventOpt.successEnd },
        ...inboundLog,
      });
      res.status(200).json(data);
    } catch (error: any) {
      logger.error({
        message: `${action}: Error for requestId: ${traceId} ${error?.message}`,
        event: { ...logEvent, ...categoryOpt.web, ...eventOpt.failureError },
        ...inboundLog,
        error: { message: error?.message, code: error?.code, type: error?.constructor?.name },
      });
      res.status(error instanceof NpdWriteoffValidationError ? 400 : 500).json({
        message: `Failed: ${action}`,
        error: error instanceof Error ? error.message : "Unknown error",
      });
    }
  };

export const getNpdWriteoffUecTrend = handle("getNpdWriteoffUecTrend", 12, getNpdWriteoffUecTrendService);
export const getNpdWriteoffBacklog = handle("getNpdWriteoffBacklog", 6, getNpdWriteoffBacklogService);
export const getNpdWriteoffPlanEntries = handle("getNpdWriteoffPlanEntries", 12, getNpdWriteoffPlanEntriesService);
