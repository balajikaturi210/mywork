import { Request, Response } from "express";
import {
  getSummaryService,
  getAutoPayService,
  getPaymentFailureDaily,
  getStatusTrendService,
  getQ1DeactivationBalanceService,
  getSuspendRestoreCohortService,
  getCohortAccountsService,
} from "../service/overview.services";
import logger, {
  eventLog,
  inbound,
  categoryOpt,
  eventOpt,
  logReq,
  logRes,
} from "../logger/logger";
import { getTraceId } from "../utils/logger";
const eventData = eventLog();
eventData.module = "controller/overview.controller";
const inboundLog = inbound();
const httpLogReq = logReq();
const httpLogRes = logRes();

export const getSummary = async (req: Request, res: Response) => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getSummary";
  try {
    httpLogReq.http.request.method = "GET";
    const data = await getSummaryService(traceId);
    logger.info({
      message: `getSummary completed`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
    });
    return res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getSummary: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    return res
      .status(500)
      .json({
        message: "Failed to fetch Summary Details",
        error: error.message,
      });
  }
};

export const getAutopay = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getAutopay";
  try {
    httpLogReq.http.request.method = "GET";
    const data = await getAutoPayService(traceId);
    logger.info({
      message: `getAutopay completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
    });

    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getAutopay: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch Autopay Details",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const getDailyPaymentFailureDetails = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getDailyPaymentFailureDetails";
  const days = Number(req.query.days) || 7;
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });

    const data = await getPaymentFailureDaily(days, traceId);
    logger.info({
      message: `getDailyPaymentFailureDetails completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { days },
    });

    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getDailyPaymentFailureDetails: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { days },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch payment failure daily report",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const getStatusTrend = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getStatusTrend";
  const days = Number(req.query.days) || 56;
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });

    const data = await getStatusTrendService(days, traceId);
    logger.info({
      message: `getStatusTrend completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { days },
    });
    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getStatusTrend: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { days },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch status trend",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const getQ1DeactivationBalance = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getQ1DeactivationBalance";
  try {
    httpLogReq.http.request.method = "GET";
    const data = await getQ1DeactivationBalanceService(traceId);
    logger.info({
      message: `getQ1DeactivationBalance completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
    });

    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getQ1DeactivationBalance: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch Q1 deactivation balance",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const getSuspendRestoreCohort = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getSuspendRestoreCohort";
  const days = Number(req.query.days) || 56;
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });

    const data = await getSuspendRestoreCohortService(days, traceId);

    logger.info({
      message: `getSuspendRestoreCohort completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { days },
    });

    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getSuspendRestoreCohort: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { days },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch suspend restore cohort",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const getCohortAccounts = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getCohortAccounts";
  const suspend_date = String(req.query.suspend_date || "");
  const bucket = String(req.query.bucket || "suspended");
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const data = await getCohortAccountsService(suspend_date, bucket, traceId);
    logger.info({
      message: `getCohortAccounts completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { suspend_date, bucket },
    });

    res.status(200).json(data);
  } catch (error: any) {
    if (error.message === "suspend_date required") {
      res.status(400).json({ error: error.message });
      return;
    }

    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getCohortAccounts: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { suspend_date, bucket },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });

    res.status(500).json({
      message: "Failed to fetch cohort accounts",
      error: error.message,
    });
  }
};
