import { Request, Response } from "express";
import { getPaymentBankDetailsService } from "../service/paymentBankDetails.services";
import { PaymentCoreServiceError } from "../types/paymentCore.types";
import { PaymentDetailValidationError, parsePaymentId } from "../utils/paymentDetail";

/** GET /payments/:paymentId/bank-details: just the bank name and routing number of a bank payment, from Payment Core. */
export const getPaymentBankDetails = async (req: Request, res: Response): Promise<void> => {
  let paymentId: string;
  try {
    paymentId = parsePaymentId(req.params.paymentId);
  } catch (error) {
    res.status(400).json({ message: error instanceof PaymentDetailValidationError ? error.message : "Invalid payment id" });
    return;
  }

  try {
    const details = await getPaymentBankDetailsService(paymentId);
    if (!details) {
      res.status(404).json({ message: "Bank details not found" });
      return;
    }
    res.status(200).json(details);
  } catch (error) {
    // The service has already logged the cause; the screen only needs to know the details are unavailable.
    res.status(error instanceof PaymentCoreServiceError && error.statusCode === 504 ? 504 : 502).json({ message: "Bank details are unavailable" });
  }
};
