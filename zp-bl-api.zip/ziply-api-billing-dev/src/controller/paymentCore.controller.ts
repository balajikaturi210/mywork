import { Request, Response } from "express";
import { getTraceId } from "../utils/logger";
import logger from "../logger/logger";
import {
  accountAdjustmentService,
  createCreditAdjustmentService,
  createDebitAdjustmentService,
  getAdjustmentReasonService,
  getBillingAccountPaymentsService,
  getAccountAdjustmentService,
  getInvoicePdfService,
  getInvoicesService,
  getChargeBreakdownService,
  getPaymentHistoryService,
  reverseAccountAdjustmentService,
  updateAdjustmentsService,
} from "../service/paymentCore.service";
import {
  AccountAdjustmentRequest,
  GetAccountAdjustmentRequest,
  GetAdjustmentReasonRequest,
  GetInvoicePdfRequest,
  GetInvoicesRequest,
  GetChargeBreakdownRequest,
  PaymentCoreServiceError,
  ReverseAccountAdjustmentRequest,
  UpdateAdjustmentsRequest,
} from "../types/paymentCore.types";

const normalizeNumericString = (value: unknown, fieldName: string): string => {
  const normalized = String(value ?? "").trim();
  if (!normalized || !/^\d+$/.test(normalized)) {
    throw new PaymentCoreServiceError(
      `${fieldName} must contain only digits`,
      400,
    );
  }
  return normalized;
};

const normalizeVpmAccountNum = (value: unknown): string => {
  return normalizeNumericString(value, "account_num/accountNumber");
};

const normalizeInvoiceSource = (value: unknown): "DPI" | "GTV" | undefined => {
  if (value === undefined || value === null || String(value).trim() === "") {
    return undefined;
  }

  const normalized = String(Array.isArray(value) ? value[0] : value)
    .trim()
    .toUpperCase();

  if (normalized === "DPI" || normalized === "GTV") {
    return normalized;
  }

  throw new PaymentCoreServiceError("source must be either DPI or GTV", 400);
};

const getHeaderValue = (req: Request, headerName: string): string | undefined => {
  const value = req.header(headerName);
  if (!value) return undefined;
  const normalized = String(value).trim();
  return normalized || undefined;
};

const resolveAccountNumQuery = (req: Request): unknown =>
  req.query.account_num ?? req.query.accountNumber;

const resolveInvoiceIdQuery = (req: Request): unknown =>
  req.query.invoice_id ?? req.query.invoiceId;

const normalizeQueryParams = (query: Request["query"]): Record<string, string> => {
  const normalized: Record<string, string> = {};

  for (const [key, value] of Object.entries(query)) {
    if (value === undefined) continue;
    if (Array.isArray(value)) {
      if (value.length > 0 && value[0] !== undefined) {
        normalized[key] = String(value[0]);
      }
      continue;
    }
    normalized[key] = String(value);
  }

  return normalized;
};

const normalizeAdjustmentTypeFilter = (
  query: Request["query"],
): "CREDIT" | "DEBIT" | undefined => {
  const raw = query.adj_type ?? query.adjustmentType ?? query.adjustment_type;

  if (raw === undefined || raw === null || String(raw).trim() === "") {
    return undefined;
  }

  const normalized = String(Array.isArray(raw) ? raw[0] : raw)
    .trim()
    .toUpperCase();

  if (normalized === "CREDIT" || normalized === "DEBIT") {
    return normalized;
  }

  throw new PaymentCoreServiceError(
    "adj_type must be either CREDIT or DEBIT",
    400,
  );
};

const getFirstDefined = (...values: unknown[]): unknown =>
  values.find((value) => value !== undefined && value !== null && String(value).trim() !== "");

const sendServiceErrorResponse = (
  res: Response,
  knownError: PaymentCoreServiceError,
): void => {
  const statusCode = knownError.statusCode || 500;
  const isClientError = statusCode >= 400 && statusCode < 500;
  const code = String(knownError.upstreamStatus ?? statusCode);

  res.status(statusCode).json({
    Error: {
      code,
      message: isClientError
        ? "Request could not be processed."
        : "Unexpected error occurred.",
    },
  });
};

const assertRequiredPayloadField = (
  payload: Record<string, unknown>,
  fieldName: string,
): void => {
  const value = payload[fieldName];
  if (value === undefined || value === null || String(value).trim() === "") {
    throw new PaymentCoreServiceError(`${fieldName} is required`, 400);
  }
};

const normalizeAdjustmentId = (value: unknown): number | string | undefined => {
  if (value === undefined || value === null) {
    return undefined;
  }

  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }

  const text = String(value).trim();
  if (!text) {
    return undefined;
  }

  const adjPrefixed = /^ADJ-(\d+)$/i.exec(text);
  if (adjPrefixed) {
    return Number(adjPrefixed[1]);
  }

  if (/^\d+$/.test(text)) {
    return Number(text);
  }

  return text;
};

const normalizeAccountAdjustmentPayload = (
  payload: Record<string, unknown>,
  mode: "create" | "reverse",
): Record<string, unknown> => {
  const customer =
    payload.customer && typeof payload.customer === "object"
      ? (payload.customer as Record<string, unknown>)
      : undefined;
  const adjustments = Array.isArray(payload.adjustments)
    ? payload.adjustments
    : undefined;
  const firstAdjustment =
    adjustments && adjustments.length > 0 && adjustments[0] && typeof adjustments[0] === "object"
      ? (adjustments[0] as Record<string, unknown>)
      : undefined;

  const normalized: Record<string, unknown> = {
    accountNumber: getFirstDefined(payload.accountNumber, customer?.accountNumber),
    amount: getFirstDefined(payload.amount, firstAdjustment?.amount),
    chargeCode: getFirstDefined(payload.chargeCode, firstAdjustment?.chargeCode),
    effectiveDate: getFirstDefined(payload.effectiveDate, payload.adjustmentDate),
    postBy: getFirstDefined(payload.postBy, "MYACCOUNT"),
    creditType: getFirstDefined(payload.creditType, "CREDIT"),
    notes: getFirstDefined(payload.notes),
  };

  const description = getFirstDefined(payload.description, firstAdjustment?.description);
  if (description !== undefined) {
    normalized.description = description;
  }

  if (mode === "reverse") {
    const adjustmentId = normalizeAdjustmentId(getFirstDefined(payload.adjustmentId));
    const reverseChargeCode = getFirstDefined(payload.reverseChargeCode);
    const reverseEffectiveDate = getFirstDefined(payload.reverseEffectiveDate);

    if (adjustmentId !== undefined) {
      normalized.adjustmentId = adjustmentId;
    }
    if (reverseChargeCode !== undefined) {
      normalized.reverseChargeCode = reverseChargeCode;
    }
    if (reverseEffectiveDate !== undefined) {
      normalized.reverseEffectiveDate = reverseEffectiveDate;
    }
  }

  assertRequiredPayloadField(normalized, "accountNumber");
  assertRequiredPayloadField(normalized, "amount");
  assertRequiredPayloadField(normalized, "chargeCode");
  assertRequiredPayloadField(normalized, "effectiveDate");

  if (mode === "reverse") {
    assertRequiredPayloadField(normalized, "adjustmentId");
    assertRequiredPayloadField(normalized, "reverseChargeCode");
    assertRequiredPayloadField(normalized, "reverseEffectiveDate");
  }

  return normalized;
};

const normalizeCreditAdjustmentPayload = (
  payload: unknown,
): Record<string, unknown> => {
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    throw new PaymentCoreServiceError("Request body must be a valid JSON object", 400);
  }

  return payload as Record<string, unknown>;
};

const normalizeUpdateAdjustmentsPayload = (
  payload: unknown,
): Record<string, unknown> => {
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    throw new PaymentCoreServiceError("Request body must be a valid JSON object", 400);
  }

  const normalizedPayload = {
    ...(payload as Record<string, unknown>),
  };

  const paymentTypeRaw = normalizedPayload.payment_type;
  const allowedPaymentTypes = ["CREDIT", "DEBIT", "REFUND", "CANCEL"] as const;
  const normalizedPaymentType = String(paymentTypeRaw ?? "").trim().toUpperCase();

  if (!allowedPaymentTypes.includes(normalizedPaymentType as (typeof allowedPaymentTypes)[number])) {
    throw new PaymentCoreServiceError(
      "payment_type must be one of CREDIT, DEBIT, REFUND, CANCEL",
      400,
    );
  }

  normalizedPayload.payment_type = normalizedPaymentType;

  if (normalizedPayload.cancel_payment === undefined) {
    normalizedPayload.cancel_payment = false;
  }

  return normalizedPayload;
};

export const getPaymentHistory = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const billingAccountId = String(req.params.billingAccountId || "").trim();

  if (!/^\d+$/.test(billingAccountId)) {
    res.status(400).json({
      message: "billingAccountId must contain only digits",
    });
    return;
  }

  try {
    const data = await getBillingAccountPaymentsService(billingAccountId);
    res.status(200).json(data);
  } catch (error) {
    const knownError =
      error instanceof PaymentCoreServiceError
        ? error
        : new PaymentCoreServiceError("Failed to fetch payment history", 500);

    logger.error({
      trace_id: traceId,
      event: "getPaymentHistory_FAILED",
      message: knownError.message,
      billingAccountId,
      upstreamStatus: knownError.upstreamStatus,
    });

    sendServiceErrorResponse(res, knownError);
  }
};

export const getPaymentTransactionHistory = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const accountNumCandidate = resolveAccountNumQuery(req);
  const expand = String(req.query.expand || "current_status_entry").trim() || "current_status_entry";

  if (accountNumCandidate === undefined || accountNumCandidate === null || String(accountNumCandidate).trim() === "") {
    res.status(400).json({
      message: "account_num/accountNumber is required",
    });
    return;
  }

  const accountNum = normalizeNumericString(accountNumCandidate, "account_num/accountNumber");

  try {
    const data = await getPaymentHistoryService(accountNum, expand);
    res.status(200).json(data);
  } catch (error) {
    const knownError =
      error instanceof PaymentCoreServiceError
        ? error
        : new PaymentCoreServiceError("Failed to fetch payment transaction history", 500);

    logger.error({
      trace_id: traceId,
      event: "getPaymentTransactionHistory_FAILED",
      message: knownError.message,
      accountNum,
      expand,
      upstreamStatus: knownError.upstreamStatus,
    });

    sendServiceErrorResponse(res, knownError);
  }
};

export const getInvoices = async (req: Request, res: Response): Promise<void> => {
  const traceId = getTraceId();

  try {
    const apiKeyOverride =
      getHeaderValue(req, "apikey") || getHeaderValue(req, "x-api-key");
    const authorizationOverride = getHeaderValue(req, "authorization");
    const accountNumQuery = resolveAccountNumQuery(req);
    const source = normalizeInvoiceSource(req.query.source);

    const request: GetInvoicesRequest = {
      accountNum: normalizeVpmAccountNum(accountNumQuery),
      ...(source ? { source } : {}),
      apiKeyOverride,
      authorizationOverride,
    };

    const data = await getInvoicesService(request);
    res.status(200).json(data);
  } catch (error) {
    const knownError =
      error instanceof PaymentCoreServiceError
        ? error
        : new PaymentCoreServiceError("Failed to fetch invoices", 500);

    logger.error({
      trace_id: traceId,
      event: "getInvoices_FAILED",
      message: knownError.message,
      accountNum: resolveAccountNumQuery(req),
      upstreamStatus: knownError.upstreamStatus,
      details: knownError.details,
    });

    sendServiceErrorResponse(res, knownError);
  }
};

export const getChargeBreakdown = async (req: Request, res: Response): Promise<void> => {
  const traceId = getTraceId();

  try {
    const source = String(req.query.source ?? "").trim().toUpperCase();
    const request: GetChargeBreakdownRequest = {
      invoiceId: normalizeNumericString(resolveInvoiceIdQuery(req), "invoice_id/invoiceId"),
      ...(source ? { source } : {}),
    };

    const data = await getChargeBreakdownService(request);
    res.status(200).json(data);
  } catch (error) {
    const knownError =
      error instanceof PaymentCoreServiceError
        ? error
        : new PaymentCoreServiceError("Failed to fetch charge breakdown", 500);

    logger.error({
      trace_id: traceId,
      event: "getChargeBreakdown_FAILED",
      message: knownError.message,
      invoiceId: resolveInvoiceIdQuery(req),
      upstreamStatus: knownError.upstreamStatus,
      details: knownError.details,
    });

    sendServiceErrorResponse(res, knownError);
  }
};

export const getInvoicePdf = async (req: Request, res: Response): Promise<void> => {
  const traceId = getTraceId();

  try {
    const apiKeyOverride =
      getHeaderValue(req, "apikey") || getHeaderValue(req, "x-api-key");
    const authorizationOverride = getHeaderValue(req, "authorization");
    const invoiceIdQuery = resolveInvoiceIdQuery(req);
    const accountNumQuery = resolveAccountNumQuery(req);

    const accountNumRaw = String(accountNumQuery ?? "").trim();
    const request: GetInvoicePdfRequest = {
      invoiceId: normalizeNumericString(invoiceIdQuery, "invoice_id/invoiceId"),
      ...(accountNumRaw
        ? {
            accountNum: normalizeVpmAccountNum(accountNumRaw),
          }
        : {}),
      apiKeyOverride,
      authorizationOverride,
    };

    const result = await getInvoicePdfService(request);
    res.setHeader("Content-Type", result.contentType || "application/pdf");
    if (result.contentDisposition) {
      res.setHeader("Content-Disposition", result.contentDisposition);
    }

    res.status(200).send(result.data);
  } catch (error) {
    const knownError =
      error instanceof PaymentCoreServiceError
        ? error
        : new PaymentCoreServiceError("Failed to fetch invoice PDF", 500);

    logger.error({
      trace_id: traceId,
      event: "getInvoicePdf_FAILED",
      message: knownError.message,
      invoiceId: resolveInvoiceIdQuery(req),
      accountNum: resolveAccountNumQuery(req),
      upstreamStatus: knownError.upstreamStatus,
      details: knownError.details,
    });

    sendServiceErrorResponse(res, knownError);
  }
};

export const accountAdjustment = async (req: Request, res: Response): Promise<void> => {
  const traceId = getTraceId();

  try {
    const apiKeyOverride =
      getHeaderValue(req, "apikey") || getHeaderValue(req, "x-api-key");
    const authorizationOverride = getHeaderValue(req, "authorization");

    const request: AccountAdjustmentRequest = {
      payload: normalizeAccountAdjustmentPayload(
        (req.body as Record<string, unknown>) || {},
        "create",
      )
    };

    const data = await accountAdjustmentService(request);
    res.status(200).json(data);
  } catch (error) {
    const knownError =
      error instanceof PaymentCoreServiceError
        ? error
        : new PaymentCoreServiceError("Failed to create account adjustment", 500);

    logger.error({
      trace_id: traceId,
      event: "accountAdjustment_FAILED",
      message: knownError.message,
      upstreamStatus: knownError.upstreamStatus,
      details: knownError.details,
    });

    sendServiceErrorResponse(res, knownError);
  }
};

export const createCreditAdjustment = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();

  try {
    const request: AccountAdjustmentRequest = {
      payload: normalizeCreditAdjustmentPayload(req.body),
    };

    const data = await createCreditAdjustmentService(request);
    res.status(200).json(data);
  } catch (error) {
    const knownError =
      error instanceof PaymentCoreServiceError
        ? error
        : new PaymentCoreServiceError("Failed to create credit adjustment", 500);

    logger.error({
      trace_id: traceId,
      event: "createCreditAdjustment_FAILED",
      message: knownError.message,
      upstreamStatus: knownError.upstreamStatus,
      details: knownError.details,
    });

    sendServiceErrorResponse(res, knownError);
  }
};

export const createDebitAdjustment = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();

  try {
    const request: AccountAdjustmentRequest = {
      payload: normalizeCreditAdjustmentPayload(req.body),
    };

    const data = await createDebitAdjustmentService(request);
    res.status(200).json(data);
  } catch (error) {
    const knownError =
      error instanceof PaymentCoreServiceError
        ? error
        : new PaymentCoreServiceError("Failed to create debit adjustment", 500);

    logger.error({
      trace_id: traceId,
      event: "createDebitAdjustment_FAILED",
      message: knownError.message,
      upstreamStatus: knownError.upstreamStatus,
      details: knownError.details,
    });

    sendServiceErrorResponse(res, knownError);
  }
};

export const getAccountAdjustment = async (
  req: Request,
  res: Response,
): Promise<void> => {
  return handleGetAccountAdjustmentByType(req, res);
};

const buildGetAccountAdjustmentRequest = (
  req: Request,
  forcedAdjustmentType?: "CREDIT" | "DEBIT",
): GetAccountAdjustmentRequest => {
  const params = normalizeQueryParams(req.query);
  const adjustmentType = forcedAdjustmentType ?? normalizeAdjustmentTypeFilter(req.query);
  if (!adjustmentType) {
    throw new PaymentCoreServiceError("adj_type is required and must be either CREDIT or DEBIT", 400);
  }

  delete params.adj_type;
  delete params.adjustmentType;
  delete params.adjustment_type;
  delete params.where;

  const source = String(
    params.source ?? params.account_type ?? params.accountType ?? "",
  )
    .trim()
    .toUpperCase();

  const telephoneNumberRaw = String(
    params.telephone_number ?? params.telephoneNumber ?? "",
  ).trim();

  if (source === "DPI" && !telephoneNumberRaw) {
    throw new PaymentCoreServiceError(
      "telephone_number is required for DPI accounts",
      400,
    );
  }

  if (telephoneNumberRaw) {
    params.telephone_number = normalizeNumericString(
      telephoneNumberRaw,
      "telephone_number",
    );
  }

  const env = String(params.env ?? "").trim().toUpperCase() || "NW";
  params.env = env;
  const accountNumberCandidate =
    getHeaderValue(req, "accountNumber") ||
    getHeaderValue(req, "accountnumber") ||
    params.accountNumber ||
    params.account_num;

  const accountNumber = accountNumberCandidate
    ? normalizeNumericString(accountNumberCandidate, "accountNumber")
    : undefined;

  if (accountNumber) {
    params.accountNumber = accountNumber;
    if (!params.account_num) {
      params.account_num = accountNumber;
    }
  }

  return {
    params,
    accountNumber,
    adjustmentType,
  };
};

const handleGetAccountAdjustmentByType = async (
  req: Request,
  res: Response,
  forcedAdjustmentType?: "CREDIT" | "DEBIT",
): Promise<void> => {
  const traceId = getTraceId();

  try {
    const request = buildGetAccountAdjustmentRequest(req, forcedAdjustmentType);

    const data = await getAccountAdjustmentService(request);
    res.status(200).json(data);
  } catch (error) {
    const knownError =
      error instanceof PaymentCoreServiceError
        ? error
        : new PaymentCoreServiceError("Failed to fetch account adjustment", 500);

    logger.error({
      trace_id: traceId,
      event: "getAccountAdjustment_FAILED",
      message: knownError.message,
      upstreamStatus: knownError.upstreamStatus,
      details: knownError.details,
    });

    sendServiceErrorResponse(res, knownError);
  }
};

export const getDebitAdjustment = async (
  req: Request,
  res: Response,
): Promise<void> => {
  return handleGetAccountAdjustmentByType(req, res, "DEBIT");
};

export const getCreditAdjustment = async (
  req: Request,
  res: Response,
): Promise<void> => {
  return handleGetAccountAdjustmentByType(req, res, "CREDIT");
};

export const getAdjustmentReason = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();

  try {
    const adjustmentType = normalizeAdjustmentTypeFilter(req.query);

    if (!adjustmentType) {
      throw new PaymentCoreServiceError("adj_type is required and must be either CREDIT or DEBIT", 400);
    }

    const request: GetAdjustmentReasonRequest = {
      adjustmentType,
    };

    const data = await getAdjustmentReasonService(request);
    res.status(200).json({
      adjustment_reason: data,
    });
  } catch (error) {
    const knownError =
      error instanceof PaymentCoreServiceError
        ? error
        : new PaymentCoreServiceError("Failed to fetch adjustment reason", 500);

    logger.error({
      trace_id: traceId,
      event: "getAdjustmentReason_FAILED",
      message: knownError.message,
      upstreamStatus: knownError.upstreamStatus,
      details: knownError.details,
    });

    sendServiceErrorResponse(res, knownError);
  }
};

export const reverseAccountAdjustment = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();

  try {
    const apiKeyOverride =
      getHeaderValue(req, "apikey") || getHeaderValue(req, "x-api-key");
    const authorizationOverride = getHeaderValue(req, "authorization");

    const request: ReverseAccountAdjustmentRequest = {
      payload: normalizeAccountAdjustmentPayload(
        (req.body as Record<string, unknown>) || {},
        "reverse",
      )
    };

    const data = await reverseAccountAdjustmentService(request);
    res.status(200).json(data);
  } catch (error) {
    const knownError =
      error instanceof PaymentCoreServiceError
        ? error
        : new PaymentCoreServiceError("Failed to reverse account adjustment", 500);

    logger.error({
      trace_id: traceId,
      event: "reverseAccountAdjustment_FAILED",
      message: knownError.message,
      upstreamStatus: knownError.upstreamStatus,
      details: knownError.details,
    });

    sendServiceErrorResponse(res, knownError);
  }
};

export const updateAdjustments = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();

  try {
    const request: UpdateAdjustmentsRequest = {
      payload: normalizeUpdateAdjustmentsPayload(req.body),
    };

    const data = await updateAdjustmentsService(request);
    res.status(200).json(data);
  } catch (error) {
    const knownError =
      error instanceof PaymentCoreServiceError
        ? error
        : new PaymentCoreServiceError("Failed to update adjustments", 500);

    logger.error({
      trace_id: traceId,
      event: "updateAdjustments_FAILED",
      message: knownError.message,
      upstreamStatus: knownError.upstreamStatus,
      details: knownError.details,
    });

    sendServiceErrorResponse(res, knownError);
  }
};
