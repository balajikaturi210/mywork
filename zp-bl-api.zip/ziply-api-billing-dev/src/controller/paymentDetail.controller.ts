import { Request, Response } from "express";
import { getPaymentDetailService } from "../service/paymentDetail.services";
import { PaymentDetailValidationError, parsePaymentId } from "../utils/paymentDetail";

/** GET /payments/:paymentId: one payment, its payment method and its status history, straight from the database. */
export const getPaymentDetail = async (req: Request, res: Response): Promise<void> => {
  let paymentId: string;
  try {
    paymentId = parsePaymentId(req.params.paymentId);
  } catch (error) {
    res.status(400).json({ message: error instanceof PaymentDetailValidationError ? error.message : "Invalid payment id" });
    return;
  }

  try {
    const payment = await getPaymentDetailService(paymentId);
    if (!payment) {
      res.status(404).json({ message: "Payment not found" });
      return;
    }
    res.status(200).json(payment);
  } catch {
    // The service has already logged the cause with the trace id.
    res.status(500).json({ message: "Failed to load payment" });
  }
};
