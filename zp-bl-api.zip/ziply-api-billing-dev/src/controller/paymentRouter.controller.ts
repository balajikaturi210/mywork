import { Request, Response } from "express";
import logger from "../logger/logger";
import { getPaymentTransactionHistoryService } from "../service/paymentRouter.service";
import { PaymentCoreServiceError } from "../types/paymentCore.types";
import { getTraceId } from "../utils/logger";

export const getPaymentTransactionHistory = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  const accountNumber = String(
    req.query.account_num ?? req.query.accountNumber ?? "",
  ).trim();

  if (!/^\d+$/.test(accountNumber)) {
    res.status(400).json({
      message: "account_num must contain only digits",
    });
    return;
  }

  try {
    const data = await getPaymentTransactionHistoryService(accountNumber);
    res.status(200).json(data);
  } catch (error) {
    const knownError =
      error instanceof PaymentCoreServiceError
        ? error
        : new PaymentCoreServiceError(
            "Failed to fetch payment transaction history",
            500,
          );

    logger.error({
      trace_id: traceId,
      event: "getPaymentTransactionHistory_FAILED",
      message: knownError.message,
      accountNumber,
      upstreamStatus: knownError.upstreamStatus,
    });

    res.status(knownError.statusCode).json({
      message: knownError.message,
      ...(knownError.upstreamStatus !== undefined && {
        code: knownError.upstreamStatus,
      }),
    });
  }
};
