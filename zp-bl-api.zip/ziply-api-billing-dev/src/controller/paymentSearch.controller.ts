import { Request, Response } from "express";
import { searchPaymentsService } from "../service/paymentSearch.services";
import { parsePaymentSearchQuery } from "../utils/paymentSearch";

/** Postgres error code for a statement stopped by statement_timeout. */
const QUERY_CANCELED = "57014";

/** GET /payment/getPaymentSearch: filtered, paged payments with totals for the whole filtered range. */
export const getPaymentSearch = async (req: Request, res: Response): Promise<void> => {
  let request;
  try {
    request = parsePaymentSearchQuery(req.query as Record<string, unknown>);
  } catch (error: any) {
    res.status(400).json({ message: error?.message ?? "Invalid payment search." });
    return;
  }

  try {
    res.status(200).json(await searchPaymentsService(request.criteria, request.page, request.perPage));
  } catch (error: any) {
    // The service has already logged the cause with the trace id; the caller only needs to know what to do next.
    if (error?.code === QUERY_CANCELED) {
      res.status(504).json({ message: "The search took too long. Try a shorter date range or add a filter." });
      return;
    }
    res.status(500).json({ message: "Failed to search payments" });
  }
};
