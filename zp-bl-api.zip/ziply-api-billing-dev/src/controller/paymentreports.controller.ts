import { Request, Response } from "express";
// import logger from "../utils/logger";
import { getAutopayLateDetailService, getAutopayLateReasonService, getAutopayNoPmService, getAutopayProcessingService, getPaymentFailureReasonService } from "../service/paymentreports.services";
import logger, {
  eventLog,
  inbound,
  categoryOpt,
  eventOpt,
  logReq,
  logRes,
} from "../logger/logger";
import { getTraceId } from "../utils/logger";
const eventData = eventLog();
eventData.module = "controller/paymentreports.controller";
const inboundLog = inbound();
const httpLogReq = logReq();
const httpLogRes = logRes();

export const getPaymentFailureReason = async (
 req: Request,
 res: Response
): Promise<void> => {
   const logEvent = JSON.parse(JSON.stringify(eventData));
    let traceId = getTraceId();
    logEvent.action = "getPaymentFailureReason";
    const days = Number(req.query.days) || 7;
    const src = String(req.query.src || "API");
 try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });

   const data = await getPaymentFailureReasonService(
     days,
     src,
     traceId
   );

      logger.info({
         message: `getPaymentFailureReason completed `,
         event: {
           ...logEvent,
           ...categoryOpt.web,
           ...(data ? eventOpt.successEnd : eventOpt.failureError),
         },
         ...inboundLog,
         http: {
           response: { body: { content: JSON.stringify({ data }) } },
         },
         ziply: { days, src },
       });
   res.status(200).json(data);
 } catch (error: any) {
     httpLogRes.http.response.body.content = JSON.stringify({ error }, [
         "error",
         ...Object.getOwnPropertyNames(error),
       ]);
       logger.error({
         message: `getPaymentFailureReason: Error for requestId: ${traceId} ${error.message}`,
         event: {
           ...logEvent,
           ...categoryOpt.web,
           ...eventOpt.failureError,
         },
         ...inboundLog,
         ziply: { days, src},
         error: {
           message: error?.message,
           code: error?.code,
           type: error?.constructor?.name,
         },
       });
   res.status(500).json({
     message: "Failed to fetch payment failure reasons"
   });
 }
};

export const getAutopayNoPm = async (
 req: Request,
 res: Response
): Promise<void> => {
   const logEvent = JSON.parse(JSON.stringify(eventData));
   logEvent.action = "getAutopayNoPm";
    let traceId = getTraceId();
    const days = Number(req.query.days) || 7;
   const src = String(req.query.src || "API");
 try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
   const data = await getAutopayNoPmService(
     days,
     src,
     traceId
   );
     logger.info({
         message: `getAutopayNoPm completed `,
         event: {
           ...logEvent,
           ...categoryOpt.web,
           ...(data ? eventOpt.successEnd : eventOpt.failureError),
         },
         ...inboundLog,
         http: {
           response: { body: { content: JSON.stringify({ data }) } },
         },
         ziply: { days, src },
       });
   res.status(200).json(data);
 } catch (error:any) {
     httpLogRes.http.response.body.content = JSON.stringify({ error }, [
         "error",
         ...Object.getOwnPropertyNames(error),
       ]);
       logger.error({
         message: `getAutopayNoPm: Error for requestId: ${traceId} ${error.message}`,
         event: {
           ...logEvent,
           ...categoryOpt.web,
           ...eventOpt.failureError,
         },
         ...inboundLog,
         ziply: { days, src},
         error: {
           message: error?.message,
           code: error?.code,
           type: error?.constructor?.name,
         },
       });
   res.status(500).json({
     message: "Failed to autopay details"
   });
 }
};

export const getAutopayProcessing = async (
 req: Request,
 res: Response
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getAutopayProcessing";
  let traceId = getTraceId();
  const months = Number(req.query.months) || 7;
 try {
  httpLogReq.http.request.method = "GET";
  httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
   const data = await getAutopayProcessingService(months,traceId);
     logger.info({
         message: `getAutopayProcessing completed `,
         event: {
           ...logEvent,
           ...categoryOpt.web,
           ...(data ? eventOpt.successEnd : eventOpt.failureError),
         },
         ...inboundLog,
         http: {
           response: { body: { content: JSON.stringify({ data }) } },
         },
         ziply: { months },
       });
   res.status(200).json(data);
 } catch (error:any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
         "error",
         ...Object.getOwnPropertyNames(error),
       ]);
       logger.error({
         message: `getAutopayProcessing: Error for requestId: ${traceId} ${error.message}`,
         event: {
           ...logEvent,
           ...categoryOpt.web,
           ...eventOpt.failureError,
         },
         ...inboundLog,
         ziply: { months},
         error: {
           message: error?.message,
           code: error?.code,
           type: error?.constructor?.name,
         },
       });
   res.status(500).json({
     message: "Failed to autopay processing details"
   });
 }
};

export const getAutopayLateDetails = async (
 req: Request,
 res: Response
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getAutopayLateDetails";
  let traceId = getTraceId();
  const months = Number(req.query.months) || 7;
 try {
  httpLogReq.http.request.method = "GET";
  httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
   const data = await getAutopayLateDetailService(months,traceId);
     logger.info({
         message: `getAutopayLateDetails completed `,
         event: {
           ...logEvent,
           ...categoryOpt.web,
           ...(data ? eventOpt.successEnd : eventOpt.failureError),
         },
         ...inboundLog,
         http: {
           response: { body: { content: JSON.stringify({ data }) } },
         },
         ziply: { months },
       });
   res.status(200).json(data);
 } catch (error:any) {
     httpLogRes.http.response.body.content = JSON.stringify({ error }, [
         "error",
         ...Object.getOwnPropertyNames(error),
       ]);
       logger.error({
         message: `getAutopayLateDetails: Error for requestId: ${traceId} ${error.message}`,
         event: {
           ...logEvent,
           ...categoryOpt.web,
           ...eventOpt.failureError,
         },
         ...inboundLog,
         ziply: { months},
         error: {
           message: error?.message,
           code: error?.code,
           type: error?.constructor?.name,
         },
       });
   res.status(500).json({
     message: "Failed to autopay late details"
   });
 }
};

export const getAutopayLateReason = async (
 req: Request,
 res: Response
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getAutopayLateReason";
  let traceId = getTraceId();
  const months = Number(req.query.months) || 7;
 try {
  httpLogReq.http.request.method = "GET";
  httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
   const data = await getAutopayLateReasonService(months,traceId);
    logger.info({
         message: `getAutopayLateReason completed `,
         event: {
           ...logEvent,
           ...categoryOpt.web,
           ...(data ? eventOpt.successEnd : eventOpt.failureError),
         },
         ...inboundLog,
         http: {
           response: { body: { content: JSON.stringify({ data }) } },
         },
         ziply: { months },
       });
   res.status(200).json(data);
 } catch (error:any) {
     httpLogRes.http.response.body.content = JSON.stringify({ error }, [
         "error",
         ...Object.getOwnPropertyNames(error),
       ]);
       logger.error({
         message: `getAutopayLateReason: Error for requestId: ${traceId} ${error.message}`,
         event: {
           ...logEvent,
           ...categoryOpt.web,
           ...eventOpt.failureError,
         },
         ...inboundLog,
         ziply: { months},
         error: {
           message: error?.message,
           code: error?.code,
           type: error?.constructor?.name,
         },
       });
   res.status(500).json({
     message: "Failed to autopay late reason"
   });
 }
};