import { Request, Response } from "express";
import { getTraceId } from "../utils/logger";
import {
  getAccountPaymentsService,
  getPaymentHistoryOnCustomRange as getPaymentHistoryOnCustomRangeService,
  getCustomerSearchService,
  getAccountWithAddressService,
  getAccountsByStatusService,
  getAccountsService,
  getAddressesService,
} from "../service/report.services";
import logger from "../logger/logger";
import pool from "../config/zbpDb";
import { CustomerSearchValidationError, parseCustomerSearchQuery } from "../utils/customerSearch";

const accountStatuses: Record<string, string> = {
  active: "BILLING_ACCOUNT_ACTIVE",
  closed: "BILLING_ACCOUNT_CLOSED",
  deactivated: "BILLING_ACCOUNT_DEACTIVATED",
  final_bill: "BILLING_ACCOUNT_FINAL_BILL",
  suspended: "BILLING_ACCOUNT_SUSPENDED",
};

const parsePositiveInteger = (
  value: unknown,
  defaultValue: number,
): number | undefined => {
  if (value === undefined) {
    return defaultValue;
  }

  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed > 0 ? parsed : undefined;
};

export const getAccountPayments = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  try {
    const accountNum = String(req.query.accountNum || "").trim();
    const days = Number(req.query.days || 30);

    if (!accountNum) {
      res.status(400).json({ message: "accountNum is required" });
      return;
    }

    const data = await getAccountPaymentsService(accountNum, days);
    res.status(200).json(data);
  } catch (error: any) {
    logger.error({ trace_id: traceId, event: "getAccountPayments_FAILED", message: error?.message });
    res.status(500).json({ message: "Failed to fetch account payments", error: error?.message });
  }
};

export const getPaymentHistoryOnCustomRange = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  try {
    const months = parsePositiveInteger(req.query.months, 1);
    const skip = req.query.skip === undefined ? 0 : Number(req.query.skip);
    const limit = parsePositiveInteger(req.query.limit, 200);

    if (months === undefined) {
      res.status(400).json({ message: "months must be a positive integer" });
      return;
    }

    if (!Number.isInteger(skip) || skip < 0) {
      res.status(400).json({ message: "skip must be a non-negative integer" });
      return;
    }

    if (limit === undefined) {
      res.status(400).json({ message: "limit must be a positive integer" });
      return;
    }

    const data = await getPaymentHistoryOnCustomRangeService(months, skip, limit);
    res.status(200).json(data);
  } catch (error: any) {
    logger.error({ trace_id: traceId, event: "getPaymentHistoryOnCustomRange_FAILED", message: error?.message });
    res.status(500).json({ message: "Failed to fetch payment history on custom range", error: error?.message });
  }
};

export const getAccountWithAddress = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  try {
    const accountNum = req.query.accountNum ? String(req.query.accountNum).trim() : undefined;
    const page = Math.max(1, Number(req.query.page || 1));
    // fixed page size per requirement
    const perPage = 10;

    const result = await getAccountWithAddressService(accountNum, page, perPage);
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({ trace_id: traceId, event: "getAccountWithAddress_FAILED", message: error?.message });
    res.status(500).json({ message: "Failed to fetch account with address", error: error?.message });
  }
};

export const getAccounts = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  try {
    const accountNum = req.query.accountNum ? String(req.query.accountNum).trim() : undefined;
    const page = Math.max(1, Number(req.query.page || 1));
    const perPage = 10;

    const result = await getAccountsService(accountNum, page, perPage);
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({ trace_id: traceId, event: "getAccounts_FAILED", message: error?.message });
    res.status(500).json({ message: "Failed to fetch accounts", error: error?.message });
  }
};

export const getAddresses = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  try {
    const accountNum = req.query.accountNum ? String(req.query.accountNum).trim() : undefined;
    const page = Math.max(1, Number(req.query.page || 1));
    const perPage = 10;

    const result = await getAddressesService(accountNum, page, perPage);
    res.status(200).json(result);
  } catch (error: any) {
    logger.error({ trace_id: traceId, event: "getAddresses_FAILED", message: error?.message });
    res.status(500).json({ message: "Failed to fetch addresses", error: error?.message });
  }
};

export const getAccountsAndAddresses = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  try {
    const accountNum = req.query.accountNum ? String(req.query.accountNum).trim() : undefined;
    const page = Math.max(1, Number(req.query.page || 1));
    const perPage = 10;

    const [accounts, addresses] = await Promise.all([
      getAccountsService(accountNum, page, perPage),
      getAddressesService(accountNum, page, perPage),
    ]);

    res.status(200).json({ accounts, addresses });
  } catch (error: any) {
    logger.error({ trace_id: traceId, event: "getAccountsAndAddresses_FAILED", message: error?.message });
    res.status(500).json({ message: "Failed to fetch accounts and addresses", error: error?.message });
  }
};

export const getAccountsByStatus = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  try {
    const requestedStatus = String(req.query.status || "").trim().toLowerCase();
    const status = accountStatuses[requestedStatus];
    const page = parsePositiveInteger(req.query.page, 1);
    const requestedPerPage = parsePositiveInteger(req.query.perPage, 10);

    if (!status) {
      res.status(400).json({
        message: "status must be one of: active, closed, deactivated, final_bill, suspended",
      });
      return;
    }

    if (page === undefined || requestedPerPage === undefined) {
      res.status(400).json({
        message: "page and perPage must be positive integers",
      });
      return;
    }

    const perPage = Math.min(requestedPerPage, 100);
    const result = await getAccountsByStatusService(status, page, perPage);
    res.status(200).json({
      status: requestedStatus,
      ...result,
    });
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getAccountsByStatus_FAILED",
      message: error?.message,
    });
    res.status(500).json({
      message: "Failed to fetch accounts by status",
      error: error?.message,
    });
  }
};

export const getCustomerSearch = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const traceId = getTraceId();
  try {
    const { criteria, page, perPage } = parseCustomerSearchQuery(req.query);
    const result = await getCustomerSearchService(criteria, page, perPage);

    res.status(200).json({
      message: result.total === 0 ? "Record doesn't exist" : "Customer records fetched successfully",
      searchField: Object.keys(criteria).length === 1 ? Object.keys(criteria)[0] : undefined,
      ...result,
      result: result.rows[0] ?? null,
    });
  } catch (error: any) {
    if (error instanceof CustomerSearchValidationError) {
      res.status(400).json({ message: error.message });
      return;
    }
    logger.error({
      trace_id: traceId,
      event: "getCustomerSearch_FAILED",
      message: error?.message,
    });
    res.status(500).json({
      message: "Failed to search customer record",
      error: error?.message,
    });
  }
};

export const dbDiagnostics = async (_req: Request, res: Response): Promise<void> => {
  try {
    const schemaRes = await pool.query(`SHOW search_path;`);
    const tablesRes = await pool.query(`
      SELECT table_schema, table_name
      FROM information_schema.tables
      WHERE table_name ILIKE '%billing%'
      ORDER BY table_schema, table_name
      LIMIT 100;
    `);

    res.status(200).json({
      search_path: schemaRes.rows,
      matching_tables: tablesRes.rows,
    });
  } catch (error: any) {
    res.status(500).json({ message: "Database diagnostics failed", error: error?.message });
  }
};
