import { Request, Response } from "express";
import {
  getSMBFeeService,
  getSMBFeeCoverageService,
  getSMBFeeExportService,
} from "../service/smbfee.services";
import logger, {
  eventLog,
  inbound,
  categoryOpt,
  eventOpt,
  logReq,
  logRes,
} from "../logger/logger";
import { getTraceId } from "../utils/logger";
const eventData = eventLog();
eventData.module = "controller/smbfee.controller";
const inboundLog = inbound();
const httpLogReq = logReq();
const httpLogRes = logRes();

export const getSMBFee = async (req: Request, res: Response): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getSMBFee";
  const days = Number(req.query.days);
  const from = String(req.query.from || "");
  const to = String(req.query.to || "");
  const src = String(req.query.src || "");
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const data = await getSMBFeeService(days, from, to, src, traceId);
    logger.info({
      message: `getSMBFee completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { days, from, to, src },
    });
    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getSMBFee: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { days, from, to, src },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch SMB Fee report",
    });
  }
};

export const getSMBFeeCoverage = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getSMBFeeCoverage";
  const days = Number(req.query.days);
  const start = String(req.query.from || "");
  const end = String(req.query.to || "");
  const src = String(req.query.src || "");
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const data = await getSMBFeeCoverageService(days, start, end, src, traceId);
    logger.info({
      message: `getSMBFeeCoverage completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { days, start, end, src },
    });
    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getSMBFeeCoverage: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { days, start, end, src },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch SMB Fee Coverage report",
    });
  }
};

export const getSMBFeeExport = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getSMBFeeExport";
  const days = Number(req.query.days);
  const start = String(req.query.from || "");
  const end = String(req.query.to || "");
  const src = String(req.query.src || "");
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const data = await getSMBFeeExportService(days, start, end, src, traceId);
    logger.info({
      message: `getSMBFeeExport completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { days, start, end, src },
    });
    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getSMBFeeExport: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { days, start, end, src },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch SMB Fee Export report",
    });
  }
};
