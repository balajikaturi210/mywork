import { Request, Response } from "express";
import {
  getSurchargeService,
  getSurchargePmTypesService,
  getSurchargeCardTypeMissingService,
  getSurchargeBankIdDrillService,
  compareBankIdService,
  surchargeExportService,
} from "../service/surcharge.services";
import { getDateRange } from "../utils/helper";
import { getTraceId } from "../utils/logger";
import logger, {
  eventLog,
  inbound,
  categoryOpt,
  eventOpt,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "controller/surcharge.controller";
const inboundLog = inbound();
const httpLogReq = logReq();
const httpLogRes = logRes();

export const getSurcharge = async (req: Request, res: Response) => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getSurcharge";
  let days = req.query.days ? Number(req.query.days) : 30;
  const { start, end } = getDateRange({
    from: req.query.from as string,
    to: req.query.to as string,
    days: req.query.days ? Number(req.query.days) : undefined,
    defaultDays: 30,
  });
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const data = await getSurchargeService(start, end, traceId);
    logger.info({
      message: `getSurcharge completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { start, end, days },
    });

    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getSurcharge: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { start, end, days },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch surcharge data",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const getSurchargePmTypes = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getSurchargePmTypes";
  try {
    httpLogReq.http.request.method = "GET";
    const data = await getSurchargePmTypesService(traceId);
    logger.info({
      message: `getSurchargePmTypes completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
    });
    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getSurchargePmTypes: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch surcharge PM types",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};
export const getSurchargeCardTypeMissing = async (
  req: Request,
  res: Response,
) => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getSurchargeCardTypeMissing";
  let days = req.query.days ? Number(req.query.days) : 30;
  const { start, end } = getDateRange({
    from: req.query.from as string,
    to: req.query.to as string,
    days: req.query.days ? Number(req.query.days) : undefined,
    defaultDays: 30,
  });
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });

    const data = await getSurchargeCardTypeMissingService(start, end, traceId);
    logger.info({
      message: `getSurchargeCardTypeMissing completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { start, end, days },
    });

    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getSurchargeCardTypeMissing: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { start, end, days },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch surcharge card type missing data",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const getSurchargeBankIdDrillController = async (
  req: Request,
  res: Response,
) => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getSurchargeBankIdDrillController";
  const bankId = (req.query.bank_id as string)?.trim()?.toUpperCase();
  const mode = ((req.query.mode as string) || "all").toLowerCase();
  const { start, end } = getDateRange({
    from: req.query.from as string,
    to: req.query.to as string,
    days: req.query.days ? Number(req.query.days) : undefined,
    defaultDays: 30,
  });
  const fromDate = start;
  const toDate = end;
  if (!bankId) {
    return res.status(400).json({ error: "bank_id is required" });
  }
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const result = await getSurchargeBankIdDrillService({
      bankId,
      mode,
      fromDate,
      toDate,
      traceId,
    });
    logger.info({
      message: `getSurchargeBankIdDrillController completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(result ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ result }) } },
      },
      ziply: { bankId, mode, fromDate, toDate },
    });

    return res.json(result);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getSurchargeBankIdDrillController: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { bankId, mode, fromDate, toDate },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });

    return res.status(500).json({
      message: "Failed to fetch Surcharge BankId Drill",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const compareBankIdController = async (req: Request, res: Response) => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "compareBankIdController";
  const bankId = req.query.bank_id?.toString().trim().toUpperCase();
  const paymentType = req.query.payment_type?.toString().trim().toUpperCase();
  if (!bankId || !paymentType) {
    return res.status(400).json({
      error: "bank_id and payment_type are required",
    });
  }
  const mode = req.query.mode?.toString().toLowerCase() || "all";
  const paymentCategoryId = req.query.payment_category_id
    ? Number(req.query.payment_category_id)
    : undefined;
  const { start, end } = getDateRange({
    from: req.query.from as string,
    to: req.query.to as string,
    days: req.query.days ? Number(req.query.days) : undefined,
    defaultDays: 30,
  });

  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const result = await compareBankIdService(
      bankId,
      paymentType,
      paymentCategoryId,
      start,
      end,
      mode,
      traceId
    );

    logger.info({
      message: `compareBankIdController completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(result ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ result }) } },
      },
      ziply: { bankId, paymentType, paymentCategoryId, start, end, mode },
    });

    res.json(result);
  } catch (error:any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `compareBankIdController: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { bankId, paymentType, paymentCategoryId, start, end, mode },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });

    return res.status(500).json({
      message: "Failed to Compare BankId",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const surchargeExportController = async (
  req: Request,
  res: Response,
) => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "surchargeExportController";
     const {
      has_surcharge,

      segment,

      card_class,
    } = req.query;

    if (!card_class) {
      return res.status(400).send("card_class is required");
    }
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const result = await surchargeExportService({
      hasSurcharge: String(has_surcharge || ""),

      segment: String(segment || ""),

      cardClass: String(card_class),
      traceId
    });

    res.setHeader("Content-Type", "text/csv");

    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${result.filename}"`,
    );
     logger.info({
      message: `surchargeExportController completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(result ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ result }) } },
      },
      ziply: { has_surcharge,

      segment,

      card_class},
    });

    return res.send(result.csv);
  } catch (error: any) {
       httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `surchargeExportController: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
        ziply: { has_surcharge,

      segment,

      card_class},
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });

    return res.status(500).json({
      message: error.message,
    });
  }
};
