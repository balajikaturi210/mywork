import { Request, Response } from "express";
import {
  getSuspensionAgingService,
  getDunningInvoiceAgingService,
  getPaidStillSuspendedService,
  getDunningInvoiceAccountsService,
} from "../service/suspensionAging.services";
import { getTraceId } from "../utils/logger";

import logger, {
  eventLog,
  inbound,
  categoryOpt,
  eventOpt,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "controller/suspensionAging.controller";
const inboundLog = inbound();
const httpLogReq = logReq();
const httpLogRes = logRes();

export const getSuspensionAging = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getSuspensionAging";
  const days =
    req.query.min_days !== undefined ? Number(req.query.min_days) : 7;
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });

    const data = await getSuspensionAgingService(days, traceId);
    logger.info({
      message: `getSuspensionAging completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { days },
    });
    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getSuspensionAging: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { days },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch Suspension Aging Details",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const getDunningInvoiceAging = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getDunningInvoiceAging";
  const acctStatus = String(req.query.acct_status ?? "SUSPENDED").toUpperCase();

  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const data = await getDunningInvoiceAgingService(acctStatus, traceId);
    logger.info({
      message: `getDunningInvoiceAging completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { acctStatus },
    });

    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getDunningInvoiceAging: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { acctStatus },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch dunning invoice aging",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const getPaidStillSuspended = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getPaidStillSuspended";
  try {
    httpLogReq.http.request.method = "GET";
    const data = await getPaidStillSuspendedService(traceId);
    logger.info({
      message: `getPaidStillSuspended completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
    });
    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getPaidStillSuspended: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    res.status(500).json({
      message: "Failed to fetch paid still suspended data",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const getDunningInvoiceAccounts = async (
  req: Request,
  res: Response,
) => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  let traceId = getTraceId();
  logEvent.action = "getDunningInvoiceAccounts";

  const dunningPlan = String(req.query.dunning_plan || "");

  const bucket = String(req.query.bucket || "total");

  const acctStatus = String(req.query.acct_status || "SUSPENDED").toUpperCase();
  try {
    if (!dunningPlan) {
      return res.status(400).json({
        error: "dunning_plan required",
      });
    }

    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const accounts = await getDunningInvoiceAccountsService(
      dunningPlan,
      bucket,
      acctStatus,
      traceId,
    );

    logger.info({
      message: `getDunningInvoiceAccounts completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(accounts ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ accounts }) } },
      },
      ziply: { dunningPlan, bucket, acctStatus },
    });
    return res.json(accounts);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getDunningInvoiceAccounts: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { dunningPlan, bucket, acctStatus },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    return res.status(500).json({
      error: error.message,
    });
  }
};
