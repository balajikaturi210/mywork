import { Request, Response } from "express";
import {
  getTechInstallService,
  getTechInstallTenureService,
  getTechInstallAccountsService,
  getTechInstallDiscountedAccountsService,
  getAutoPayLatenessTrendService,
  getPaperlessDiscountTrendService,
  getSurchargeTrendService,
} from "../service/trends.services";
import {  getTraceId } from "../utils/logger";
import { getDateRange } from "../utils/helper";
import logger, {
  eventLog,
  inbound,
  categoryOpt,
  eventOpt,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "controller/trends.controller";
const inboundLog = inbound();
const httpLogReq = logReq();
const httpLogRes = logRes();

export const getTechInstall = async (
  req: Request,
  res: Response,
): Promise<void> => {
    const logEvent = JSON.parse(JSON.stringify(eventData));
    let traceId = getTraceId();
    logEvent.action = "getTechInstall";
      const { start, end } = getDateRange({
      from: req.query.from as string,
      to: req.query.to as string,
      days: req.query.days ? Number(req.query.days) : undefined,
      defaultDays: 30,
    });
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const data = await getTechInstallService(start, end, traceId);
    logger.info({
      message: `getTechInstall completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      },
      ziply: { start, end },
    });
    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
        "error",
        ...Object.getOwnPropertyNames(error),
      ]);
      logger.error({
        message: `getTechInstall: Error for requestId: ${traceId} ${error.message}`,
        event: {
          ...logEvent,
          ...categoryOpt.web,
          ...eventOpt.failureError,
        },
        ...inboundLog,
        ziply: {  start, end },
        error: {
          message: error?.message,
          code: error?.code,
          type: error?.constructor?.name,
        },
      });

    res.status(500).json({
      message: "Failed to fetch Tech Install report",
      error: error instanceof Error ? error.message : "Unknown error",
    });
  }
};

export const getTechInstallTenure = async (
  req: Request,
  res: Response,
): Promise<void> => {
    const logEvent = JSON.parse(JSON.stringify(eventData));
    let traceId = getTraceId();
    logEvent.action = "getTechInstallTenure";
     const { start, end } = getDateRange({
      from: req.query.from as string,
      to: req.query.to as string,
      days: req.query.days ? Number(req.query.days) : undefined,
      defaultDays: 30,
    });
  try {
      httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const response = await getTechInstallTenureService(start, end,traceId);
      logger.info({
      message: `getTechInstallTenure completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(response ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ response }) } },
      },
      ziply: { start, end },
    });

    res.status(200).json(response);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
        "error",
        ...Object.getOwnPropertyNames(error),
      ]);
      logger.error({
        message: `getTechInstallTenure: Error for requestId: ${traceId} ${error.message}`,
        event: {
          ...logEvent,
          ...categoryOpt.web,
          ...eventOpt.failureError,
        },
        ...inboundLog,
        ziply: { start, end },
        error: {
          message: error?.message,
          code: error?.code,
          type: error?.constructor?.name,
        },
      });

    res.status(500).json({
      message: "Failed to fetch Tech Install tenure report",
      error: error.message,
    });
  }
};

export const getTechInstallAccounts = async (
  req: Request,
  res: Response,
): Promise<void> => {
    const logEvent = JSON.parse(JSON.stringify(eventData));
    let traceId = getTraceId();
    logEvent.action = "getTechInstallAccounts";
      const { start, end } = getDateRange({
      from: req.query.from as string,
      to: req.query.to as string,
      days: req.query.days ? Number(req.query.days) : undefined,
      defaultDays: 30,
    });
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const response = await getTechInstallAccountsService(start, end,traceId);
        logger.info({
      message: `getTechInstallAccounts completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(response ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ response }) } },
      },
      ziply: { start, end },
    });

    res.status(200).json(response);
  } catch (error: any) {
     httpLogRes.http.response.body.content = JSON.stringify({ error }, [
        "error",
        ...Object.getOwnPropertyNames(error),
      ]);
      logger.error({
        message: `getTechInstallAccounts: Error for requestId: ${traceId} ${error.message}`,
        event: {
          ...logEvent,
          ...categoryOpt.web,
          ...eventOpt.failureError,
        },
        ...inboundLog,
        ziply: { start, end },
        error: {
          message: error?.message,
          code: error?.code,
          type: error?.constructor?.name,
        },
      });

    res.status(500).json({
      message: "Failed to fetch Tech Install account report",
      error: error.message,
    });
  }
};

export const getTechInstallDiscountedAccounts = async (
  req: Request,
  res: Response,
): Promise<void> => {
   const logEvent = JSON.parse(JSON.stringify(eventData));
    let traceId = getTraceId();
    logEvent.action = "getTechInstallDiscountedAccounts";
     const { start, end } = getDateRange({
      from: req.query.from as string,
      to: req.query.to as string,
      days: req.query.days ? Number(req.query.days) : undefined,
      defaultDays: 30,
    });
  try {
    httpLogReq.http.request.method = "GET";
    httpLogReq.http.request.body.content = JSON.stringify({ query: req.query });
    const response = await getTechInstallDiscountedAccountsService(start, end,traceId);
      logger.info({
      message: `getTechInstallDiscountedAccounts completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(response ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ response }) } },
      },
      ziply: {start, end },
    });


    res.status(200).json(response);
  } catch (error: any) {
     httpLogRes.http.response.body.content = JSON.stringify({ error }, [
        "error",
        ...Object.getOwnPropertyNames(error),
      ]);
      logger.error({
        message: `getTechInstallDiscountedAccounts: Error for requestId: ${traceId} ${error.message}`,
        event: {
          ...logEvent,
          ...categoryOpt.web,
          ...eventOpt.failureError,
        },
        ...inboundLog,
        ziply: { start, end },
        error: {
          message: error?.message,
          code: error?.code,
          type: error?.constructor?.name,
        },
      });

    res.status(500).json({
      message: "Failed to fetch Tech Install discounted accounts",
      error: error.message,
    });
  }
};

/**
 * Retrieves the AutoPay lateness trend dashboard, including monthly trends,
 * current snapshot metrics, and category-wise overdue balance analysis.
 */
export const getAutoPayLatenessTrend = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const startTime = Date.now();
   const logEvent = JSON.parse(JSON.stringify(eventData));
    let traceId = getTraceId();
    logEvent.action = "getAutoPayLatenessTrend";
  try {
     httpLogReq.http.request.method = "GET";

    const response = await getAutoPayLatenessTrendService(traceId);

     logger.info({
      message: `getAutoPayLatenessTrend completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(response ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ response }) } },
      }
    });

    res.status(200).json(response);
  } catch (error: any) {
  httpLogRes.http.response.body.content = JSON.stringify({ error }, [
        "error",
        ...Object.getOwnPropertyNames(error),
      ]);
      logger.error({
        message: `getAutoPayLatenessTrend: Error for requestId: ${traceId} ${error.message}`,
        event: {
          ...logEvent,
          ...categoryOpt.web,
          ...eventOpt.failureError,
        },
        ...inboundLog,
        error: {
          message: error?.message,
          code: error?.code,
          type: error?.constructor?.name,
        },
      });
       res.status(500).json({
      message: "Failed to fetch AutoPay lateness trend report",
      error: error.message,
    });
  }
};

export const getPaperlessDiscountTrend = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
    let traceId = getTraceId();
    logEvent.action = "getPaperlessDiscountTrend";
  try {
    httpLogReq.http.request.method = "GET";
    const data = await getPaperlessDiscountTrendService(traceId);
     logger.info({
      message: `getPaperlessDiscountTrend completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      }
    });

    res.status(200).json(data);
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
        "error",
        ...Object.getOwnPropertyNames(error),
      ]);
      logger.error({
        message: `getPaperlessDiscountTrend: Error for requestId: ${traceId} ${error.message}`,
        event: {
          ...logEvent,
          ...categoryOpt.web,
          ...eventOpt.failureError,
        },
        ...inboundLog,
        error: {
          message: error?.message,
          code: error?.code,
          type: error?.constructor?.name,
        },
      });

    res.status(500).json({
      message: "Failed to fetch paperless discount trend",
      error: error.message,
    });
  }
};

export const getSurchargeTrend = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
    let traceId = getTraceId();
    logEvent.action = "getSurchargeTrend";
  try {
    httpLogReq.http.request.method = "GET";
    const data = await getSurchargeTrendService(traceId);
     logger.info({
      message: `getSurchargeTrend completed `,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...(data ? eventOpt.successEnd : eventOpt.failureError),
      },
      ...inboundLog,
      http: {
        response: { body: { content: JSON.stringify({ data }) } },
      }
    });
    res.status(200).json(data);
  } catch (error: any) {
     httpLogRes.http.response.body.content = JSON.stringify({ error }, [
        "error",
        ...Object.getOwnPropertyNames(error),
      ]);
      logger.error({
        message: `getSurchargeTrend: Error for requestId: ${traceId} ${error.message}`,
        event: {
          ...logEvent,
          ...categoryOpt.web,
          ...eventOpt.failureError,
        },
        ...inboundLog,
        error: {
          message: error?.message,
          code: error?.code,
          type: error?.constructor?.name,
        },
      });

    res.status(500).json({
      message: "Failed to fetch surcharge trend",
      error: error.message,
    });
  }
};
