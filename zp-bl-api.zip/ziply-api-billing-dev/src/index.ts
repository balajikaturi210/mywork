import "./config/env";
import express, { Request, Response } from "express";
import cors from "cors";
import routes from "./route";
import { initCabsSchema } from "./service/cabs/cabs.schema";
import pool from "./config/db"; // adjust path if different
import logger, {
  eventLog,
  categoryOpt,
  eventOpt
} from "./logger/logger";
const eventData = eventLog()
eventData.module = "server";


const logEvent = JSON.parse(JSON.stringify(eventData));
logEvent.action = "index";

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());
app.use(cors());

app.get("/", async (req: Request, res: Response) => {
  try {
    const dbTest = await pool.query("SELECT NOW()");

    res.json({
      status: "Application is online",
      db_time: dbTest.rows[0].now,
    });
  } catch (err: any) {
    console.error(err);
   logger.error({
      message: `Failed to start server: ${err instanceof Error ? err.message : String(err)}`,
      event: {
        ...event,
        ...eventOpt.failureError,
        ...categoryOpt.webProcess
      },
      error: {
        message: err instanceof Error ? err.message : String(err),
        code: (err as any)?.code,
        type: err?.constructor?.name
      },
    });
    res.status(500).send("Database connection failure.");
  }
});

app.use("/api/ziplybilling", routes);

// create the cabs schema if it is missing; never blocks or stops the service
void initCabsSchema();

app.listen(port, () => {
  console.log(`Server executing live on port ${port}`);
});
