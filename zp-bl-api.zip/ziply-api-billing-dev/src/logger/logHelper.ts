export const eventLog = (
    action = "",
    outcome = "unknown",
    type: string[] = ["start"],
    category: string | string[] = "web",
    module = ""
) => ({
    action,
    outcome,
    type,
    category: Array.isArray(category) ? category : [category],
    module
});

export const logReq = (content: unknown = {}, method = "GET") => ({
    http: {
        request: {
            method,
            body: { content: JSON.stringify(content) }
        }
    }
});

export const logRes = (content: unknown = {}) => ({
    http: {
        response: {
            body: { content: JSON.stringify(content) }
        }
    }
});

export const inbound = () => ({
    network: { direction: "inbound" }
});

export const outbound = () => ({
    network: { direction: "outbound" }
});

export const eventOpt = {
    successStart: { outcome: "success", type: ["start"] },
    successConnection: { outcome: "success", type: ["connection"] },
    successEnd: { outcome: "success", type: ["end"] },
    failureError: { outcome: "failure", type: ["error"] },
    unknownStart: { outcome: "unknown", type: ["start"] },
    unknownConnection: { outcome: "unknown", type: ["connection"] },
    unknownError: { outcome: "unknown", type: ["error"] },
    unknownEnd: { outcome: "unknown", type: ["end"] }
};

export const categoryOpt = {
    web: { category: ["web"] },
    process: { category: ["process"] },
    database: { category: ["database"] },
    authenticate: { category: ["authenticate"] },
    network: { category: ["network"] },
    webProcess: { category: ["web", "process"] },
    webNetwork: { category: ["web", "network"] },
    webDatabase: { category: ["web", "database"] },
    webAuthenticate: { category: ["web", "authenticate"] },
    webAuthentication: { category: ["web", "authentication"] },
    dbProcess: { category: ["database", "process"] },
    authProcess: { category: ["authenticate", "process"] },
    webDatabaseProcess: { category: ["web", "database", "process"] },
    webDatabaseAuthenticate: { category: ["web", "database", "authenticate"] },
};

export const logErr = (err: any) => ({
    error: {
        message: err?.message || String(err),
        code: err?.code || err?.cause?.code,
        type: err?.constructor?.name,
        ...(err?.statusCode && { statusCode: err.statusCode }),
        ...(err?.details !== undefined && { details: err.details }),
    }
});
