
import * as dotenv from 'dotenv';
dotenv.config();
import * as winston from 'winston';
import DailyRotateFile from 'winston-daily-rotate-file';
import { getTraceId, getClientIp, getSourceIp, getTransactionId, getDestinationDomain } from '../middlewares/requestContext.middleware';

const logger = winston.createLogger({
    defaultMeta: { name: `Ziply-Api-Billing-${process?.env?.NODE_ENV?.toUpperCase()}` },
    level: 'info',
    format: winston.format.combine(winston.format.timestamp(), winston.format.json()),
    transports: [
        new winston.transports.Console(),
        new DailyRotateFile({ filename: './logs/billingms.log', level: 'info' }),
        new DailyRotateFile({ filename: './logs/billingms_error.log', level: 'error' }),
      //new winston.transports.DailyRotateFile({ filename: ('./logs/billingms_debug.log'), level: 'debug' })
    ],
    exceptionHandlers: [
        new winston.transports.Console(),
      //new winston.transports.DailyRotateFile( { filename: ('./logs/billingms_exceptions.log') } )
    ]
});


const handler = {
  get(target: any, prop: string) {
    const orig = target[prop];
    if (typeof orig !== 'function') return orig;
    return function (obj: any, ...rest: any[]) {
      const traceId = getTraceId();
      const clientIp = getClientIp();
      const sourceIp = getSourceIp();
      const transactionId = getTransactionId();
      const destinationDomain = getDestinationDomain();
      if ((traceId || clientIp || sourceIp || transactionId || destinationDomain) && obj !== null && typeof obj === 'object' && !Array.isArray(obj)) {
        obj = {
          "trace": { id: traceId },
          "transaction": {
            "id": transactionId
          },
          "client": {
            "ip": clientIp
          },
          "source": {
            "ip": sourceIp
          },
          "destination": {
            "domain": destinationDomain
          },
          ...obj
        };
      }
      return orig.call(target, obj, ...rest);
    };
  }
};

export default new Proxy(logger, handler);

export { eventLog, logReq, logRes, inbound, outbound, eventOpt, logErr, categoryOpt } from "./logHelper";
