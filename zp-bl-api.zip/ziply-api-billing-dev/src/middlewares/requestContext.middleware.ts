import { AsyncLocalStorage } from 'async_hooks';
import { Request, Response, NextFunction } from 'express';
import logger, { eventLog, inbound } from '../logger/logger';
interface RequestContext {
    traceId: string | null;
    clientIp: string;
    sourceIp: string | undefined;
    destinationDomain: string | undefined;
    transactionId: string | null;
}

const asyncStorage = new AsyncLocalStorage<RequestContext>();

function requestContextMiddleware(req: Request, res: Response, next: NextFunction): void {
    logger.info({
        message: `Incoming ${req.method} ${req.originalUrl}`,
        ...eventLog('requestLogger', 'success', ['start'], 'web', 'middleware'),
        ...inbound(),
    });
    const traceId = (req.headers['x-request-id'] as string) || null;

    // Client IP: the original client address from proxy headers, falling back to direct connection
    const clientIp =
        (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() ||
        (req.headers['x-real-ip'] as string) ||
        req.ip ||
        '';

    // Source IP: the immediate TCP connection address
    const sourceIp = req?.socket?.remoteAddress || (req as any)?.connection?.remoteAddress;

    // Destination domain: the host the request was sent to
    const destinationDomain = req.hostname || (req.headers['host'] as string)?.split(':')[0];

    // Transaction ID: using sessionid from headers if available
    const transactionId = (req.headers['sessionid'] as string) || null;

    asyncStorage.run({ traceId, clientIp, sourceIp, destinationDomain, transactionId }, next);
}

function getTraceId(): string | null | undefined {
    return asyncStorage.getStore()?.traceId;
}

function getClientIp(): string | undefined {
    return asyncStorage.getStore()?.clientIp;
}

function getSourceIp(): string | undefined {
    return asyncStorage.getStore()?.sourceIp;
}

function getDestinationDomain(): string | undefined {
    return asyncStorage.getStore()?.destinationDomain;
}

function getTransactionId(): string | null | undefined {
    return asyncStorage.getStore()?.transactionId;
}

export {
    requestContextMiddleware,
    getTraceId,
    getClientIp,
    getSourceIp,
    getDestinationDomain,
    getTransactionId,
};
