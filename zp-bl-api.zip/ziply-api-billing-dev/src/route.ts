import { Router } from "express";
import {
  getSummary,
  getAutopay,
  getDailyPaymentFailureDetails,
  getStatusTrend,
  getQ1DeactivationBalance,
  getSuspendRestoreCohort,
  getCohortAccounts
} from "./controller/overview.controller";
import {
  getSuspensionAging,
  getDunningInvoiceAging,
  getPaidStillSuspended,
  getDunningInvoiceAccounts
} from "./controller/suspensionAging.controller";
import {
  getNpdWriteoffTrend,
  getNpdMissingWriteoffTrend,
  getNPDWriteoffAccounts,
  getWriteoffPayments,
  getNpdMissingWriteoffAccounts,
  getWriteoffDayAccounts
} from "./controller/npdWriteOff.controller";
import {
  getNpdWriteoffUecTrend,
  getNpdWriteoffBacklog,
  getNpdWriteoffPlanEntries,
} from "./controller/npdWriteOffUec.controller";
import { getPaymentFailureReason, getAutopayNoPm, getAutopayProcessing, getAutopayLateDetails, getAutopayLateReason} from "./controller/paymentreports.controller";
import {
  getSurcharge,
  getSurchargePmTypes,
  getSurchargeCardTypeMissing,
  getSurchargeBankIdDrillController,
  compareBankIdController,
  surchargeExportController
} from "./controller/surcharge.controller";
import { getARAging } from "./controller/arAging.controller";
import {
  getDDCurrent,
  getDDResolution,
  getCurrentDownload,
} from "./controller/dunningReports.controller";
import { getCustomerJourney } from "./controller/customerJourney.controller";
import {
  cabsUploadMiddleware, cabsUpload, cabsSnapshots, cabsSnapshot, cabsSummary, cabsDetails, cabsDetailsExport,
  cabsFilterOptions, cabsCircuitUsoc,
} from "./controller/cabs.controller";
import {
  getTechInstall,
  getTechInstallTenure,
  getTechInstallAccounts,
  getTechInstallDiscountedAccounts,
  getAutoPayLatenessTrend,
  getPaperlessDiscountTrend,
  getSurchargeTrend,
} from "./controller/trends.controller";
import{
  getSMBFee,
  getSMBFeeCoverage,
  getSMBFeeExport,
} from "./controller/smbfee.controller";
import {
  accountAdjustment,
  createCreditAdjustment,
  createDebitAdjustment,
  getCreditAdjustment,
  getDebitAdjustment,
  getAdjustmentReason,
  getAccountAdjustment,
  getInvoicePdf,
  getInvoices,
  getChargeBreakdown,
  getPaymentHistory,
  getPaymentTransactionHistory,
  reverseAccountAdjustment,
  updateAdjustments,
} from "./controller/paymentCore.controller";
import { getPaymentSearch } from "./controller/paymentSearch.controller";
import { getPaymentDetail } from "./controller/paymentDetail.controller";
import { getPaymentBankDetails } from "./controller/paymentBankDetails.controller";
import {
  getAccountPayments,
  getPaymentHistoryOnCustomRange,
  getCustomerSearch,
  getAccountWithAddress,
  getAccounts,
  getAccountsByStatus,
  getAddresses,
  getAccountsAndAddresses,
  dbDiagnostics,
} from "./controller/report.controller";
import {
  getAccount,
  getAccountHistory,
  getAccountReceivable,
  getGtvAccount,
  getPaymentMethods,
  getTreatment,
} from "./controller/billing.controller";
import {
  getAdjustmentTransactionsByAdjustmentId,
  getPaymentBatchCreatedUsers,
  getPaymentBatchDpiRecordsByFile,
  getPaymentBatchDpiAutopayRecords,
  getPaymentBatchPde0018RecordsByFile,
  getPaymentBatchErrorRecordsByFile,
  getPaymentBatchErrorRecords,
  getPaymentBatchFileDetails,
  getPaymentBatchFileNames,
  getPaymentBatchFiles,
  getPaymentBatchFifthThirdRecordsByFile,
  getPaymentBatchFiservRecordsByFile,
  getPaymentBatchSources,
  getPaymentBatchTrans,
  getPaymentBatchTransactionsByBatchRecordId,
  getPaymentTransactionsByPaymentId,
  getZbpAccountWhitelistByFile,
  searchPaymentBatchFiles,
} from "./controller/admin.controller";

const router = Router();

router.get("/summary", getSummary);
router.get("/autopay", getAutopay);
router.get("/payment-failure/daily", getDailyPaymentFailureDetails);
router.get("/status-trend", getStatusTrend);
router.get("/q1-deactivation-balance", getQ1DeactivationBalance);
router.get("/suspend-restore-cohort", getSuspendRestoreCohort);
router.get("/cohort-accounts", getCohortAccounts);
router.get("/suspension-aging", getSuspensionAging);
router.get("/dunning-invoice-aging", getDunningInvoiceAging);
router.get("/paid-still-suspended", getPaidStillSuspended);
router.get("/dunning-invoice-accounts", getDunningInvoiceAccounts);
router.get("/npd-writeoff-trend", getNpdWriteoffTrend);
router.get("/npd-missing-writeoff-trend", getNpdMissingWriteoffTrend);
router.get("/npd-writeoff-accounts", getNPDWriteoffAccounts);
router.get("/writeoff-payments", getWriteoffPayments);
router.get("/npd-missing-writeoff-accounts", getNpdMissingWriteoffAccounts);
router.get("/writeoff-day-accounts", getWriteoffDayAccounts);
router.get("/npd-writeoff-uec-trend", getNpdWriteoffUecTrend);
router.get("/npd-writeoff-backlog", getNpdWriteoffBacklog);
router.get("/npd-writeoff-plan-entries", getNpdWriteoffPlanEntries);
router.get("/payment-failure/reason", getPaymentFailureReason);
router.get("/autopay-no-pm", getAutopayNoPm);
router.get("/autopay-processing", getAutopayProcessing);
router.get("/autopay-late-detail", getAutopayLateDetails);
router.get("/autopay-late-reason", getAutopayLateReason);
router.get("/surcharge", getSurcharge);
router.get("/surcharge-pm-types", getSurchargePmTypes);
router.get("/surcharge-cardtype-missing", getSurchargeCardTypeMissing);
router.get("/surcharge-bankid-drill", getSurchargeBankIdDrillController);
router.get("/surcharge-bankid-compare", compareBankIdController);
router.get("/surcharge-export", surchargeExportController);
router.get("/ar-aging", getARAging);
router.get("/dd-current", getDDCurrent);
router.get("/dd-resolution", getDDResolution);
router.get("/dd-current-download", getCurrentDownload);
router.get("/customer-journey", getCustomerJourney);
router.get("/tech-install", getTechInstall);
router.get("/tech-install/tenure", getTechInstallTenure);
router.get("/tech-install/accounts", getTechInstallAccounts);
router.get(
  "/tech-install/discounted-accounts",
  getTechInstallDiscountedAccounts,
);
router.get("/autopay-lateness-trend", getAutoPayLatenessTrend);
router.get("/paperless-discount-trend", getPaperlessDiscountTrend);
router.get("/surcharge-trend", getSurchargeTrend);
router.get("/smb-surcharge", getSMBFee);
router.get("/smb-surcharge/coverage", getSMBFeeCoverage );
router.get("/smb-surcharge/export", getSMBFeeExport);
router.post("/billing/getAccount", getAccount);
router.get("/billing-accounts/:billingAccountId/payments", getPaymentHistory);
router.get("/v1/payment", getPaymentTransactionHistory);
router.get("/v1/billingaccount/:billingAccountId/payments", getPaymentHistory);
router.get("/v1/bill/invoices", getInvoices);
router.get("/v1/bill/chargeBreakdown", getChargeBreakdown);
router.get("/v1/bill/pdf", getInvoicePdf);
router.post("/v1/billing/accountAdjustment", accountAdjustment);
router.post("/v1/billing/creditadjustment", createCreditAdjustment);
router.post("/v1/billing/debitadjustments", createDebitAdjustment);
router.get("/v1/billing/getAccountAdjustment", getAccountAdjustment);
router.get("/v1/billing/debitAdjustment", getDebitAdjustment);
router.get("/v1/billing/creditAdjustment", getCreditAdjustment);
router.get("/v1/billing/debitadjustments", getDebitAdjustment);
router.get("/v1/billing/creditadjustment", getCreditAdjustment);
router.get("/v1/billing/adjustment-reason", getAdjustmentReason);
router.post("/v1/billing/reverseAccountAdjustment", reverseAccountAdjustment);
router.post("/v1/updateAdjustments", updateAdjustments);
router.get("/account-payments", getAccountPayments);
router.get("/payment/getPaymentHistoryOnCustomRange", getPaymentHistoryOnCustomRange);
router.get("/payment/getPaymentSearch", getPaymentSearch);
router.get("/account-with-address", getAccountWithAddress);
router.get("/accounts", getAccounts);
router.get("/addresses", getAddresses);
router.get("/accounts-with-addresses", getAccountsAndAddresses);
router.get("/accounts-by-status", getAccountsByStatus);
router.get("/customer-search", getCustomerSearch);
router.get("/payment-batch-files", getPaymentBatchFiles);
router.get("/payment-batch-error-records", getPaymentBatchErrorRecords);
router.get("/payment-batch-dpi-autopay-records", getPaymentBatchDpiAutopayRecords);
router.get("/payment-batch-trans", getPaymentBatchTrans);
router.post("/payment-batch/search", searchPaymentBatchFiles);
router.get("/payment-batch/file-names", getPaymentBatchFileNames);
router.get("/payment-batch/sources", getPaymentBatchSources);
router.get("/payment-batch/created-users", getPaymentBatchCreatedUsers);
router.get("/payment-batch/dpi/:fileId", getPaymentBatchDpiRecordsByFile);
router.get("/payment-batch/fiserv/:fileId", getPaymentBatchFiservRecordsByFile);
router.get("/payment-batch/fifth-third/:fileId", getPaymentBatchFifthThirdRecordsByFile);
router.get("/payment-batch/whitelist/:fileId", getZbpAccountWhitelistByFile);
router.get("/payment-batch/pde0018/:fileId", getPaymentBatchPde0018RecordsByFile);
router.get("/payment-batch/errors/:fileId", getPaymentBatchErrorRecordsByFile);
router.get("/payment-batch/transactions/:batchRecordId", getPaymentBatchTransactionsByBatchRecordId);
router.get("/payments/:paymentId/transactions", getPaymentTransactionsByPaymentId);
router.get("/payments/:paymentId", getPaymentDetail);
router.get("/payments/:paymentId/bank-details", getPaymentBankDetails);
router.get("/adjustments/:adjustmentId/transactions", getAdjustmentTransactionsByAdjustmentId);
router.get("/payment-batch/:fileId", getPaymentBatchFileDetails);
router.get("/db-diagnostics", dbDiagnostics);
router.post("/billing/getAccountReceivable", getAccountReceivable);
router.post("/billing/getTreatment", getTreatment);
router.get("/v1/billingaccount/:billing_account_id/recurringpayment", getPaymentMethods);
router.get("/v1/billing/getAccountHistory/:billing_account_id", getAccountHistory);
router.get("/billing/getGtvAccount/:accountNumber", getGtvAccount);

// CABS report: files are loaded in the background; the other endpoints read the finished snapshot.
router.post("/cabs/upload", cabsUploadMiddleware, cabsUpload);
router.get("/cabs/snapshots", cabsSnapshots);
router.get("/cabs/snapshots/:id", cabsSnapshot);
router.get("/cabs/summary", cabsSummary);
router.get("/cabs/details", cabsDetails);
router.get("/cabs/details/export", cabsDetailsExport);
router.get("/cabs/filter-options", cabsFilterOptions);
router.get("/cabs/circuit-usoc", cabsCircuitUsoc);
export default router;
