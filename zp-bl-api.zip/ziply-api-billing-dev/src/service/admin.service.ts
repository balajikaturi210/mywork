import pool from "../config/zbpDb";
import logger from "../logger/logger";
import {
  type PaginatedRowsResult,
  type PaymentBatchDpiAutopayRecordFilters,
  type PaymentBatchErrorRecordFilters,
  type PaymentBatchFileFilters,
  type PaymentBatchSearchFilters,
  type PaymentBatchTransFilters,
} from "../types/admin.types";
import { getTraceId } from "../utils/logger";

const getExistingColumnsForTable = async (tableName: string): Promise<Set<string>> => {
  const sql = `
    SELECT column_name
    FROM information_schema.columns
    WHERE table_schema = 'zbp' AND table_name = $1
  `;

  const rows = (await pool.query<{ column_name: string }>(sql, [tableName])).rows;
  return new Set(rows.map((row) => row.column_name));
};

const getFilterAndOrderColumns = (columns: Set<string>) => {
  const filterColumn = columns.has("file_id")
    ? "file_id"
    : columns.has("id")
      ? "id"
      : null;

  const orderColumn = columns.has("created_on")
    ? "created_on"
    : columns.has("created_at")
      ? "created_at"
      : columns.has("id")
        ? "id"
        : null;

  return { filterColumn, orderColumn };
};

const getPagedResult = async <T>(
  rowsSql: string,
  countSql: string,
  bindValues: Array<string | number>,
  page: number,
  perPage: number,
): Promise<PaginatedRowsResult<T>> => {
  const offset = (page - 1) * perPage;
  const rowsParams = [...bindValues, perPage, offset];

  const [rowsResult, countResult] = await Promise.all([
    pool.query(rowsSql, rowsParams),
    pool.query<{ total_count: number }>(countSql, bindValues),
  ]);

  const total = Number(countResult.rows[0]?.total_count ?? 0);
  return {
    rows: rowsResult.rows as T[],
    page,
    perPage,
    total,
    totalPages: Math.ceil(total / perPage),
  };
};

export const getPaymentBatchFilesService = async (
  filters: PaymentBatchFileFilters,
  page: number,
  perPage: number,
) => {
  const traceId = getTraceId();

  try {
    const whereClauses: string[] = [];
    const bindValues: Array<string | number> = [];

    if (filters.source) {
      bindValues.push(filters.source);
      whereClauses.push(`source = $${bindValues.length}`);
    }

    if (filters.fileStatus) {
      bindValues.push(filters.fileStatus);
      whereClauses.push(`file_status = $${bindValues.length}`);
    }

    const whereSql = whereClauses.length ? `WHERE ${whereClauses.join(" AND ")}` : "";
    const rowsSql = `
      SELECT
        id,
        file_name,
        source,
        source_file_path,
        file_status,
        record_count,
        start_time,
        end_time,
        created_by,
        created_on,
        updated_by,
        updated_on
      FROM zbp.payment_batch_file
      ${whereSql}
      ORDER BY created_on DESC, id DESC
      LIMIT $${bindValues.length + 1} OFFSET $${bindValues.length + 2}
    `;
    const countSql = `
      SELECT COUNT(*)::int AS total_count
      FROM zbp.payment_batch_file
      ${whereSql}
    `;

    return getPagedResult(rowsSql, countSql, bindValues, page, perPage);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchFilesService_FAILED",
      message: error?.message || String(error),
    });
    throw error;
  }
};

export const getPaymentBatchErrorRecordsService = async (
  filters: PaymentBatchErrorRecordFilters,
  page: number,
  perPage: number,
) => {
  const traceId = getTraceId();

  try {
    const whereClauses: string[] = [];
    const bindValues: Array<string | number> = [];

    if (typeof filters.fileId === "number") {
      bindValues.push(filters.fileId);
      whereClauses.push(`file_id = $${bindValues.length}`);
    }

    const whereSql = whereClauses.length ? `WHERE ${whereClauses.join(" AND ")}` : "";
    const rowsSql = `
      SELECT
        id,
        file_id,
        raw_data,
        created_by,
        created_on,
        updated_by,
        updated_on
      FROM zbp.payment_batch_error_record
      ${whereSql}
      ORDER BY created_on DESC, id DESC
      LIMIT $${bindValues.length + 1} OFFSET $${bindValues.length + 2}
    `;
    const countSql = `
      SELECT COUNT(*)::int AS total_count
      FROM zbp.payment_batch_error_record
      ${whereSql}
    `;

    return getPagedResult(rowsSql, countSql, bindValues, page, perPage);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchErrorRecordsService_FAILED",
      message: error?.message || String(error),
    });
    throw error;
  }
};

export const getPaymentBatchDpiAutopayRecordsService = async (
  filters: PaymentBatchDpiAutopayRecordFilters,
  page: number,
  perPage: number,
) => {
  const traceId = getTraceId();

  try {
    const whereClauses: string[] = [];
    const bindValues: Array<string | number> = [];

    if (filters.status) {
      bindValues.push(filters.status);
      whereClauses.push(`status = $${bindValues.length}`);
    }

    if (filters.accountNum) {
      bindValues.push(filters.accountNum);
      whereClauses.push(`account_num = $${bindValues.length}`);
    }

    if (typeof filters.fileId === "number") {
      bindValues.push(filters.fileId);
      whereClauses.push(`file_id = $${bindValues.length}`);
    }

    const whereSql = whereClauses.length ? `WHERE ${whereClauses.join(" AND ")}` : "";
    const rowsSql = `
      SELECT
        id,
        file_id,
        account_num,
        invoice_balance,
        current_balance,
        autopay_draft_date,
        regulated,
        status,
        created_by,
        created_on,
        updated_by,
        updated_on
      FROM zbp.payment_batch_dpi_autopay_record
      ${whereSql}
      ORDER BY created_on DESC, id DESC
      LIMIT $${bindValues.length + 1} OFFSET $${bindValues.length + 2}
    `;
    const countSql = `
      SELECT COUNT(*)::int AS total_count
      FROM zbp.payment_batch_dpi_autopay_record
      ${whereSql}
    `;

    return getPagedResult(rowsSql, countSql, bindValues, page, perPage);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchDpiAutopayRecordsService_FAILED",
      message: error?.message || String(error),
    });
    throw error;
  }
};

export const getPaymentBatchTransService = async (
  filters: PaymentBatchTransFilters,
  page: number,
  perPage: number,
) => {
  const traceId = getTraceId();

  try {
    const whereClauses: string[] = [];
    const bindValues: Array<string | number> = [];

    if (typeof filters.paymentId === "number") {
      bindValues.push(filters.paymentId);
      whereClauses.push(`payment_id = $${bindValues.length}`);
    }

    if (filters.destination) {
      bindValues.push(filters.destination);
      whereClauses.push(`destination = $${bindValues.length}`);
    }

    if (filters.status) {
      bindValues.push(filters.status);
      whereClauses.push(`status = $${bindValues.length}`);
    }

    const whereSql = whereClauses.length ? `WHERE ${whereClauses.join(" AND ")}` : "";
    const rowsSql = `
      SELECT
        id,
        batch_record_id,
        payment_id,
        destination,
        trans_json,
        status,
        error_msg,
        start_time,
        end_time,
        created_by,
        created_on,
        updated_by,
        updated_on
      FROM zbp.payment_batch_trans
      ${whereSql}
      ORDER BY created_on DESC, id DESC
      LIMIT $${bindValues.length + 1} OFFSET $${bindValues.length + 2}
    `;
    const countSql = `
      SELECT COUNT(*)::int AS total_count
      FROM zbp.payment_batch_trans
      ${whereSql}
    `;

    return getPagedResult(rowsSql, countSql, bindValues, page, perPage);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchTransService_FAILED",
      message: error?.message || String(error),
    });
    throw error;
  }
};

export const searchPaymentBatchFilesService = async (
  filters: PaymentBatchSearchFilters,
) => {
  const traceId = getTraceId();

  try {
    const whereClauses: string[] = [];
    const bindValues: Array<string | number> = [];

    if (filters.fileName) {
      bindValues.push(filters.fileName);
      whereClauses.push(`file_name = $${bindValues.length}`);
    }

    if (filters.source) {
      bindValues.push(filters.source);
      whereClauses.push(`source = $${bindValues.length}`);
    }

    if (filters.createdBy) {
      bindValues.push(filters.createdBy);
      whereClauses.push(`created_by = $${bindValues.length}`);
    }

    if (filters.dateFrom && filters.dateTo) {
      bindValues.push(filters.dateFrom);
      whereClauses.push(`created_on::date >= $${bindValues.length}::date`);
      bindValues.push(filters.dateTo);
      whereClauses.push(`created_on::date <= $${bindValues.length}::date`);
    }

    const whereSql = whereClauses.length ? `WHERE ${whereClauses.join(" AND ")}` : "";
    const sql = `
      SELECT
        id AS file_id,
        file_name,
        source,
        source_file_path,
        file_status,
        record_count,
        start_time,
        end_time,
        created_by,
        created_on,
        updated_by,
        updated_on
      FROM zbp.payment_batch_file
      ${whereSql}
      ORDER BY created_on DESC, id DESC
    `;

    return (await pool.query(sql, bindValues)).rows;
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "searchPaymentBatchFilesService_FAILED",
      message: error?.message || String(error),
    });
    throw error;
  }
};

export const getPaymentBatchFileNamesService = async () => {
  const traceId = getTraceId();

  try {
    const sql = `
      SELECT DISTINCT file_name
      FROM zbp.payment_batch_file
      WHERE file_name IS NOT NULL AND TRIM(file_name) <> ''
      ORDER BY file_name
    `;
    const rows = (await pool.query<{ file_name: string }>(sql)).rows;
    return rows.map((row) => row.file_name);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchFileNamesService_FAILED",
      message: error?.message || String(error),
    });
    throw error;
  }
};

export const getPaymentBatchSourcesService = async () => {
  const traceId = getTraceId();

  try {
    const requiredSources = ["CHASE", "FISERV", "DPI", "FIFTH_THIRD"];
    const sql = `
      SELECT DISTINCT source
      FROM zbp.payment_batch_file
      WHERE source IS NOT NULL AND TRIM(source) <> ''
      ORDER BY source
    `;
    const rows = (await pool.query<{ source: string }>(sql)).rows;
    const sourceSet = new Set(
      rows
        .map((row) => String(row.source || "").trim().toUpperCase())
        .filter((value) => value.length > 0),
    );

    for (const source of requiredSources) {
      sourceSet.add(source);
    }

    return Array.from(sourceSet).sort();
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchSourcesService_FAILED",
      message: error?.message || String(error),
    });
    throw error;
  }
};

export const getPaymentBatchCreatedUsersService = async () => {
  const traceId = getTraceId();

  try {
    const sql = `
      SELECT DISTINCT created_by
      FROM zbp.payment_batch_file
      WHERE created_by IS NOT NULL AND TRIM(created_by) <> ''
      ORDER BY created_by
    `;
    const rows = (await pool.query<{ created_by: string }>(sql)).rows;
    return rows.map((row) => row.created_by);
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchCreatedUsersService_FAILED",
      message: error?.message || String(error),
    });
    throw error;
  }
};

export const getPaymentBatchFileDetailsService = async (fileId: number) => {
  const traceId = getTraceId();

  try {
    const sql = `
      SELECT
        id AS file_id,
        file_name,
        source,
        file_status,
        record_count,
        start_time,
        end_time,
        created_by,
        created_on,
        updated_by,
        updated_on
      FROM zbp.payment_batch_file
      WHERE id = $1
      LIMIT 1
    `;

    return (await pool.query(sql, [fileId])).rows[0] ?? null;
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchFileDetailsService_FAILED",
      message: error?.message || String(error),
      fileId,
    });
    throw error;
  }
};

export const getPaymentBatchDpiRecordsByFileService = async (fileId: number) => {
  const traceId = getTraceId();

  try {
    const sql = `
      SELECT *
      FROM zbp.payment_batch_dpi_autopay_record
      WHERE file_id = $1
      ORDER BY created_on DESC, id DESC
    `;
    return (await pool.query(sql, [fileId])).rows;
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchDpiRecordsByFileService_FAILED",
      message: error?.message || String(error),
      fileId,
    });
    throw error;
  }
};

export const getPaymentBatchFiservRecordsByFileService = async (fileId: number) => {
  const traceId = getTraceId();

  try {
    const sql = `
      SELECT *
      FROM zbp.payment_batch_fiserv_record
      WHERE file_id = $1
      ORDER BY created_on DESC, id DESC
    `;
    return (await pool.query(sql, [fileId])).rows;
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchFiservRecordsByFileService_FAILED",
      message: error?.message || String(error),
      fileId,
    });
    throw error;
  }
};

export const getPaymentBatchFifthThirdRecordsByFileService = async (fileId: number) => {
  const traceId = getTraceId();

  try {
    const sql = `
      SELECT *
      FROM zbp.payment_batch_fifth_third_record
      WHERE file_id = $1
      ORDER BY created_on DESC, id DESC
    `;
    return (await pool.query(sql, [fileId])).rows;
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchFifthThirdRecordsByFileService_FAILED",
      message: error?.message || String(error),
      fileId,
    });
    throw error;
  }
};

export const getZbpAccountWhitelistByFileService = async (fileId: number) => {
  const traceId = getTraceId();

  try {
    const columns = await getExistingColumnsForTable("zbp_account_whitelist");
    const { filterColumn, orderColumn } = getFilterAndOrderColumns(columns);

    if (!filterColumn) {
      logger.warn({
        trace_id: traceId,
        event: "getZbpAccountWhitelistByFileService_SCHEMA_UNAVAILABLE",
        message:
          "zbp.zbp_account_whitelist has no supported filter column (expected file_id or id); returning empty result",
        fileId,
      });
      return [];
    }

    const orderSql = orderColumn ? `ORDER BY ${orderColumn} DESC, id DESC` : "";
    const sql = `
      SELECT *
      FROM zbp.zbp_account_whitelist
      WHERE ${filterColumn} = $1
      ${orderSql}
    `;
    return (await pool.query(sql, [fileId])).rows;
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getZbpAccountWhitelistByFileService_FAILED",
      message: error?.message || String(error),
      fileId,
    });
    throw error;
  }
};

export const getPaymentBatchPde0018RecordsByFileService = async (fileId: number) => {
  const traceId = getTraceId();

  try {
    const columns = await getExistingColumnsForTable("payment_batch_pde0018_record");
    const { filterColumn, orderColumn } = getFilterAndOrderColumns(columns);

    if (!filterColumn) {
      logger.warn({
        trace_id: traceId,
        event: "getPaymentBatchPde0018RecordsByFileService_SCHEMA_UNAVAILABLE",
        message:
          "zbp.payment_batch_pde0018_record is unavailable or has no supported filter column (expected file_id or id); returning empty result",
        fileId,
      });
      return [];
    }

    const orderSql = orderColumn ? `ORDER BY ${orderColumn} DESC, id DESC` : "";
    const sql = `
      SELECT *
      FROM zbp.payment_batch_pde0018_record
      WHERE ${filterColumn} = $1
      ${orderSql}
    `;
    return (await pool.query(sql, [fileId])).rows;
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchPde0018RecordsByFileService_FAILED",
      message: error?.message || String(error),
      fileId,
    });
    throw error;
  }
};

export const getPaymentBatchErrorRecordsByFileService = async (fileId: number) => {
  const traceId = getTraceId();

  try {
    const sql = `
      SELECT *
      FROM zbp.payment_batch_error_record
      WHERE file_id = $1
      ORDER BY created_on DESC, id DESC
    `;
    return (await pool.query(sql, [fileId])).rows;
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchErrorRecordsByFileService_FAILED",
      message: error?.message || String(error),
      fileId,
    });
    throw error;
  }
};

export const getPaymentBatchTransactionsByBatchRecordIdService = async (
  batchRecordId: number,
) => {
  const traceId = getTraceId();

  try {
    const sql = `
      SELECT *
      FROM zbp.payment_batch_trans
      WHERE batch_record_id = $1
      ORDER BY created_on DESC, id DESC
    `;
    return (await pool.query(sql, [batchRecordId])).rows;
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentBatchTransactionsByBatchRecordIdService_FAILED",
      message: error?.message || String(error),
      batchRecordId,
    });
    throw error;
  }
};

export const getPaymentTransactionsByPaymentIdService = async (paymentId: number) => {
  const traceId = getTraceId();

  try {
    const sql = `
      SELECT *
      FROM zbp.payment_trans
      WHERE payment_id = $1
      ORDER BY created_on DESC, id DESC
    `;
    return (await pool.query(sql, [paymentId])).rows;
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentTransactionsByPaymentIdService_FAILED",
      message: error?.message || String(error),
      paymentId,
    });
    throw error;
  }
};

export const getAdjustmentTransactionsByAdjustmentIdService = async (
  adjustmentId: string,
) => {
  const traceId = getTraceId();

  try {
    const digitsMatch = adjustmentId.match(/^(?:ADJ-)?(\d+)$/i);
    const candidates = digitsMatch
      ? [digitsMatch[1], `ADJ-${digitsMatch[1]}`]
      : [adjustmentId];

    const sql = `
      SELECT *
      FROM zbp.adjustment_trans
      WHERE adjustment_id::text = ANY($1::text[])
      ORDER BY created_on DESC, id DESC
    `;
    return (await pool.query(sql, [candidates])).rows;
  } catch (error: any) {
    logger.error({
      trace_id: traceId,
      event: "getAdjustmentTransactionsByAdjustmentIdService_FAILED",
      message: error?.message || String(error),
      adjustmentId,
    });
    throw error;
  }
};
