import { runQuery } from "../config/snowflake";
import { ARAgingParams, ARAging } from "../types/arAging.types";

import logger, {
  eventLog,
  categoryOpt,
  eventOpt,
  inbound,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "service/arAging.services";
const httpLogRes = logRes();
const inboundLog = inbound();

export const _AR_AUDIT_SQ = `
SELECT entity_id, MAX(ae.start_date) AS audit_change_date
FROM audit_billing_account_event ae
JOIN billing_account ba ON ba.id = entity_id
WHERE change_type = 'UPDATE'
  AND entity_type = 'BillingAccount'
  AND (
    description = CONCAT('''', ba.account_num, '''[Account Category: ''Legacy – R'' was updated to ''Residential'']')
    OR description LIKE CONCAT('''', ba.account_num, '''[Account Category: ''Legacy – B'' was updated to ''Business'']')
    OR description LIKE CONCAT('''', ba.account_num, '''[Account Category: ''Legacy – B'' was updated to ''Residential'']')
  )
GROUP BY entity_id
`;

/**
 * AR Aging Report API
 *
 * Returns unpaid and overdue customer balances as of a given date,
 * grouped into aging buckets (0–30, 31–60, … 181+ days).
 *
 * If no date is provided, it defaults to last day of previous month.
 *
 * Used for finance reporting and tracking overdue payments.
 */

export const getARAgingService = async (
  params: ARAgingParams,
): Promise<ARAging[]> => {
  let traceId =params.traceId;
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getARAgingService";
  try {
    const { as_of, segment, aging_by, incl_dbt } = params;

    const WRITE_OFF = "('RES-Dunning-Write-off', 'SMB-Dunning-Write-off')";

    const p1 = `DATEADD('day', 1, '${as_of}'::DATE)`;

    const inv_age =
      aging_by === "invoice-date"
        ? `DATEDIFF('day', i.approved_on::date, '${as_of}'::DATE)`
        : `DATEDIFF('day', i.due_date::date, '${as_of}'::DATE)`;

    const cat_f =
      segment === "SMB"
        ? "AND (ba.billing_account_category ILIKE 'Business%' OR ba.billing_account_category ILIKE 'Legacy-B%')"
        : segment === "RESI"
          ? "AND (ba.billing_account_category ILIKE 'Residential%' OR ba.billing_account_category ILIKE 'Legacy-R%')"
          : "";

    const seg_expr =
      "CASE WHEN ba.billing_account_category ILIKE 'Business%' OR ba.billing_account_category ILIKE 'Legacy-B%' THEN 'SMB' ELSE 'RESI' END";

    const bucket_sql = `
    SUM(CASE WHEN age_days <= 0 THEN net_balance ELSE 0 END) AS "curr",
    SUM(CASE WHEN age_days BETWEEN 1 AND 30 THEN net_balance ELSE 0 END) AS "b1_30",
    SUM(CASE WHEN age_days BETWEEN 31 AND 60 THEN net_balance ELSE 0 END) AS "b31_60",
    SUM(CASE WHEN age_days BETWEEN 61 AND 90 THEN net_balance ELSE 0 END) AS "b61_90",
    SUM(CASE WHEN age_days BETWEEN 91 AND 120 THEN net_balance ELSE 0 END) AS "b91_120",
    SUM(CASE WHEN age_days BETWEEN 121 AND 150 THEN net_balance ELSE 0 END) AS "b121_150",
    SUM(CASE WHEN age_days BETWEEN 151 AND 180 THEN net_balance ELSE 0 END) AS "b151_180",
    SUM(CASE WHEN age_days >= 181 THEN net_balance ELSE 0 END) AS "b181p"
  `;

    const dbt_cte =
      incl_dbt === "1"
        ? `,
dbt_base AS (
    SELECT ${seg_expr} AS segment,
           DATEDIFF('day', aa.created_on::date, '${as_of}'::DATE) AS age_days,
           COALESCE(aa.amount, 0) AS net_balance
    FROM account_adjustment aa
    JOIN billing_account ba ON ba.id = aa.billing_account_id
    LEFT JOIN billing_account_dunning bad ON bad.billing_account_id = ba.id
    LEFT JOIN invoice i_dbt ON i_dbt.id = aa.billed_invoice_id
    LEFT JOIN audit_changes abae ON abae.entity_id = aa.billing_account_id
    WHERE aa.credit = FALSE
      AND aa.status = 'ACCOUNT_ADJUSTMENT_POSTED'
      AND aa.created_on::date < ${p1}
      AND (aa.billed_invoice_id IS NULL OR i_dbt.approved_on::date > '${as_of}'::DATE)
      AND (abae.entity_id IS NULL OR aa.created_on::datetime > abae.audit_change_date)
      AND bad.dunning_plan_code NOT IN ${WRITE_OFF}
      ${cat_f}
      AND COALESCE(aa.amount, 0) <> 0
)`
        : "";

    const dbt_union =
      incl_dbt === "1"
        ? `
UNION ALL
SELECT segment, 'Debit Adj' AS doc_type, age_days, net_balance
FROM dbt_base WHERE net_balance <> 0`
        : "";

    const sql = `
WITH
audit_changes AS (${_AR_AUDIT_SQ}),
pa_by_inv AS (
  SELECT invoice_id, SUM(COALESCE(amount, 0)) AS total
  FROM payment_application
  WHERE type IN ('I','R') AND created_on < ${p1}
  GROUP BY invoice_id
),
adj_by_inv AS (
  SELECT invoice_id, SUM(COALESCE(amount, 0)) AS total
  FROM adjustment_application
  WHERE created_on < ${p1}
  GROUP BY invoice_id
),
pa_by_pmt AS (
  SELECT payment_id, SUM(COALESCE(amount, 0)) AS total
  FROM payment_application
  WHERE type IN ('I','R') AND created_on < ${p1}
  GROUP BY payment_id
),
pc_by_pmt AS (
  SELECT original_payment_id, SUM(COALESCE(change_amount, 0)) AS total
  FROM payment_change
  WHERE change_type IN ('CANCEL','PARTIAL_CANCEL')
    AND changed_on < ${p1}
  GROUP BY original_payment_id
),
aap_by_adj AS (
  SELECT account_adjustment_id, SUM(COALESCE(amount, 0)) AS total
  FROM adjustment_application
  WHERE created_on < ${p1}
  GROUP BY account_adjustment_id
),

inv_base AS (
  SELECT ${seg_expr} AS segment,
         ${inv_age} AS age_days,
         COALESCE(i.amount,0)
         - COALESCE(pa_inv.total,0)
         - COALESCE(adj_inv.total,0) AS net_balance
  FROM invoice i
  JOIN billing_account ba ON ba.id = i.billing_account_id
  LEFT JOIN billing_account_dunning bad ON bad.billing_account_id = ba.id
  LEFT JOIN audit_changes abae ON abae.entity_id = i.billing_account_id
  LEFT JOIN pa_by_inv pa_inv ON pa_inv.invoice_id = i.id
  LEFT JOIN adj_by_inv adj_inv ON adj_inv.invoice_id = i.id
  WHERE i.status <> 'INVOICE_PROCESSING'
    AND i.approved_on::date < ${p1}
    AND (abae.entity_id IS NULL OR i.approved_on::datetime > abae.audit_change_date)
    AND bad.dunning_plan_code NOT IN ${WRITE_OFF}
    ${cat_f}
),

pmt_base AS (
  SELECT ${seg_expr} AS segment,
         DATEDIFF('day', p.created_on::date, '${as_of}'::DATE) AS age_days,
         -(COALESCE(p.amount,0)
         - COALESCE(pa_pmt.total,0)
         - COALESCE(pc_pmt.total,0)) AS net_balance
  FROM payment p
  JOIN billing_account ba ON ba.id = p.billing_account_id
  LEFT JOIN billing_account_dunning bad ON bad.billing_account_id = ba.id
  LEFT JOIN audit_changes abae ON abae.entity_id = p.billing_account_id
  LEFT JOIN pa_by_pmt pa_pmt ON pa_pmt.payment_id = p.id
  LEFT JOIN pc_by_pmt pc_pmt ON pc_pmt.original_payment_id = p.id
  WHERE p.status IN ('COMPLETED','CANCELLED')
    AND p.created_on::date < ${p1}
    AND (abae.entity_id IS NULL OR p.created_on::datetime > abae.audit_change_date)
    AND bad.dunning_plan_code NOT IN ${WRITE_OFF}
    ${cat_f}
),

crd_base AS (
  SELECT ${seg_expr} AS segment,
         DATEDIFF('day', aa.created_on::date, '${as_of}'::DATE) AS age_days,
         IFF(aa.billed_invoice_id IS NULL,
             -(ABS(COALESCE(aa.amount,0)) - COALESCE(aap_crd.total,0)),
             -ABS(COALESCE(aa.amount,0))) AS net_balance
  FROM account_adjustment aa
  JOIN billing_account ba ON ba.id = aa.billing_account_id
  LEFT JOIN billing_account_dunning bad ON bad.billing_account_id = ba.id
  LEFT JOIN audit_changes abae ON abae.entity_id = aa.billing_account_id
  LEFT JOIN aap_by_adj aap_crd ON aap_crd.account_adjustment_id = aa.id
  LEFT JOIN invoice inv_crd ON inv_crd.id = aa.billed_invoice_id
  WHERE aa.credit = TRUE
    AND aa.status = 'ACCOUNT_ADJUSTMENT_POSTED'
    AND aa.created_on::date < ${p1}
    AND (abae.entity_id IS NULL OR aa.created_on::datetime > abae.audit_change_date)
    AND bad.dunning_plan_code NOT IN ${WRITE_OFF}
    ${cat_f}
    AND (
      (aa.billed_invoice_id IS NULL AND ABS(COALESCE(aa.amount,0))-COALESCE(aap_crd.total,0) <> 0)
      OR (aa.billed_invoice_id IS NOT NULL AND inv_crd.approved_on > ${p1})
    )
)
${dbt_cte}

SELECT segment AS "segment", doc_type  AS "doc_type",
       ${bucket_sql}
FROM (
  SELECT segment, 'Invoice' AS doc_type, age_days, net_balance FROM inv_base WHERE net_balance <> 0
  UNION ALL
  SELECT segment, 'Payment' AS doc_type, age_days, net_balance FROM pmt_base WHERE net_balance <> 0
  UNION ALL
  SELECT segment, 'Credit Adj' AS doc_type, age_days, net_balance FROM crd_base WHERE net_balance <> 0
  ${dbt_union}
) a
GROUP BY "segment", "doc_type"
ORDER BY "segment", "doc_type"
`;

    const row = await runQuery<ARAging>(sql);
    return row;
  } catch (error:any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
        "error",
        ...Object.getOwnPropertyNames(error),
      ]);
      logger.error({
        message: `Error in getARAgingService to fetch ARAging Service Details: ${traceId} - ${error.message}`,
        event: {
          ...logEvent,
          ...categoryOpt.webProcess,
          ...eventOpt.failureError,
        },
        error: {
          message: error?.message,
          code: error?.code,
          type: error?.constructor?.name,
        },
        ...httpLogRes,
        ...inboundLog,
      });
    throw error;
  }
};
