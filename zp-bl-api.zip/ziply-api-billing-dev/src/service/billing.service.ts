import "dotenv/config";
import axios, { AxiosError } from "axios";
import { XMLParser } from "fast-xml-parser";
import { logger, getTraceId } from "../utils/logger";
import { getPaymentCoreConfig, getUpstreamErrorMessage } from "../utils/paymentCore.util";
import {
  AccountHistoryResponse,
  GetAccountHistoryRequest,
  BillingServiceError,
  BillingReceivableServiceRequest,
  BillingServiceRequest,
  BillingTreatmentServiceRequest,
  GetAccountResponse,
  GetAccountReceivableResponse,
  GetPaymentMethodsRequest,
  GetPaymentsRequest,
  GetTreatmentResponse,
  PaymentMethodsResponse,
  PaymentsResponse,
} from "../types/billing.types";
import { getBillingAccountIdDetails } from "./helperUtil";
import pool from "../config/zbpDb";

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "@_",
  parseTagValue: true,
  trimValues: true,
});

const stripNs = (key: string): string => key.split(":").pop() || key;

const escapeXml = (value: string): string =>
  value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&apos;");

const asArray = <T>(value: T | T[] | null | undefined): T[] => {
  if (value === null || value === undefined) return [];
  return Array.isArray(value) ? value : [value];
};

const asRecord = (value: unknown): Record<string, unknown> =>
  value && typeof value === "object" && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : {};

const asReturnCode = (value: unknown): string | number | null => {
  if (value === null || value === undefined) return null;
  if (typeof value === "string" || typeof value === "number") return value;
  if (typeof value === "boolean") return value ? "true" : "false";
  return String(value);
};

const getChildByLocalName = (
  obj: unknown,
  localName: string,
): unknown | undefined => {
  if (!obj || typeof obj !== "object") return undefined;

  const entries = Object.entries(obj as Record<string, unknown>);
  const exact = entries.find(([key]) => stripNs(key) === localName);

  return exact?.[1];
};

const findFirstByLocalName = (
  obj: unknown,
  localName: string,
): unknown | undefined => {
  if (!obj || typeof obj !== "object") return undefined;

  if (Array.isArray(obj)) {
    for (const item of obj) {
      const found = findFirstByLocalName(item, localName);
      if (found !== undefined) return found;
    }
    return undefined;
  }

  const record = obj as Record<string, unknown>;

  for (const [key, value] of Object.entries(record)) {
    if (stripNs(key) === localName) return value;
  }

  for (const value of Object.values(record)) {
    const found = findFirstByLocalName(value, localName);
    if (found !== undefined) return found;
  }

  return undefined;
};

const findSoapBody = (parsedXml: unknown): Record<string, unknown> => {
  const envelope = findFirstByLocalName(parsedXml, "Envelope");
  const body = getChildByLocalName(envelope, "Body");

  return asRecord(body);
};

const getResponsePayload = (soapBody: Record<string, unknown>): Record<string, unknown> => {
  const responseContainer = Object.values(soapBody).find(
    (value) => value && typeof value === "object",
  );

  if (!responseContainer) return {};

  const responseRecord = asRecord(responseContainer);
  const resultKey = Object.keys(responseRecord).find((key) => {
    const name = stripNs(key).toLowerCase();
    return name.includes("result") || name === "return";
  });

  if (resultKey) return asRecord(responseRecord[resultKey]);

  return responseRecord;
};

const getNode = (source: Record<string, unknown>, nodeName: string): unknown =>
  findFirstByLocalName(source, nodeName);

const GET_ACCOUNT_RECEIVABLE_METHOD = "getAccountReceivable";
const GET_TREATMENT_METHOD = "getTreatment";
const GET_ACCOUNT_METHOD = "getAccount";
const BILLING_SOAP_TOKEN_REFRESH_SKEW_MS = 30000;
const BILLING_SOAP_TOKEN_MAX_AGE_SECONDS = 45 * 60;

let billingSoapTokenCache:
  | { token: string; expiresAt: number }
  | undefined;

const buildGetAccountXml = (request: BillingServiceRequest): string => {
  const namespace = (process.env.BILLING_SOAP_NAMESPACE || "").trim();
  const envelopeNamespace = namespace ? ` xmlns:ses="${escapeXml(namespace)}"` : "";
  const operationTag = namespace ? `ses:${GET_ACCOUNT_METHOD}` : GET_ACCOUNT_METHOD;
  const universalServiceNumberTag =
    request.universalServiceNumber === undefined
      ? ""
      : `<universalServiceNumber>${request.universalServiceNumber}</universalServiceNumber>`;

  return `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"${envelopeNamespace}>
  <soapenv:Header/>
  <soapenv:Body>
    <${operationTag}>
      <getAccountRequest>
        <crisId>${request.crisId}</crisId>
        <environment>${escapeXml(request.environment)}</environment>
        ${universalServiceNumberTag}
        <userId>${escapeXml(request.userId)}</userId>
        <applicationId>${escapeXml(request.applicationId)}</applicationId>
        <sequenceNumber>${request.sequenceNumber}</sequenceNumber>
        <telephoneNumber>${escapeXml(request.telephoneNumber)}</telephoneNumber>
        <trackingId>${escapeXml(request.trackingId)}</trackingId>
      </getAccountRequest>
    </${operationTag}>
  </soapenv:Body>
</soapenv:Envelope>`;
};

const buildGetAccountReceivableXml = (request: BillingReceivableServiceRequest): string => {
  const namespace = (process.env.BILLING_SOAP_NAMESPACE || "").trim();
  const operationTag = namespace
    ? `ses:${GET_ACCOUNT_RECEIVABLE_METHOD}`
    : GET_ACCOUNT_RECEIVABLE_METHOD;
  const operationNamespace = namespace ? ` xmlns:ses="${escapeXml(namespace)}"` : "";

  return `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
  <soapenv:Header/>
  <soapenv:Body>
    <${operationTag}${operationNamespace}>
      <getAccountReceivableRequest>
        <crisId>${request.crisId}</crisId>
        <environment>${escapeXml(request.environment)}</environment>
        <userId>${escapeXml(request.userId)}</userId>
        <workingTelephoneNumber>${escapeXml(request.workingTelephoneNumber)}</workingTelephoneNumber>
        <sequenceNumber>${request.sequenceNumber}</sequenceNumber>
        <includeAcctRcvDetail>${request.includeAcctRcvDetail}</includeAcctRcvDetail>
        <includeAcctRcvSummary>${request.includeAcctRcvSummary}</includeAcctRcvSummary>
        <includeCurrentBalance>${request.includeCurrentBalance}</includeCurrentBalance>
        <includePaymentHistory>${request.includePaymentHistory}</includePaymentHistory>
        <includeAdjustmentHistory>${request.includeAdjustmentHistory}</includeAdjustmentHistory>
        <maximumAdjustmentHistoryQty>${request.maximumAdjustmentHistoryQty}</maximumAdjustmentHistoryQty>
        <summaryNumberFlag_C_F01SUMF>${request.summaryNumberFlag_C_F01SUMF}</summaryNumberFlag_C_F01SUMF>
      </getAccountReceivableRequest>
    </${operationTag}>
  </soapenv:Body>
</soapenv:Envelope>`;
};

const buildGetTreatmentXml = (request: BillingTreatmentServiceRequest): string => {
  const namespace = (process.env.BILLING_SOAP_NAMESPACE || "").trim();
  const operationTag = namespace ? `ses:${GET_TREATMENT_METHOD}` : GET_TREATMENT_METHOD;
  const operationNamespace = namespace ? ` xmlns:ses="${escapeXml(namespace)}"` : "";

  const debugDelayTag =
    request.debugDelay === undefined ? "" : `<debugDelay>${request.debugDelay}</debugDelay>`;
  const universalServiceNumberTag =
    request.universalServiceNumber === undefined
      ? ""
      : `<universalServiceNumber>${request.universalServiceNumber}</universalServiceNumber>`;
  const workingTelephoneNumberTag =
    request.workingTelephoneNumber === undefined
      ? ""
      : `<workingTelephoneNumber>${escapeXml(request.workingTelephoneNumber)}</workingTelephoneNumber>`;

  return `<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
  <soapenv:Header/>
  <soapenv:Body>
    <${operationTag}${operationNamespace}>
      <getTreatmentRequest>
        <crisId>${request.crisId}</crisId>
        ${debugDelayTag}
        <environment>${escapeXml(request.environment)}</environment>
        ${universalServiceNumberTag}
        <userId>${escapeXml(request.userId)}</userId>
        ${workingTelephoneNumberTag}
        <sequenceNumber>${request.sequenceNumber}</sequenceNumber>
      </getTreatmentRequest>
    </${operationTag}>
  </soapenv:Body>
</soapenv:Envelope>`;
};

const getSoapConfig = () => {
  const endpoint = (process.env.BILLING_SOAP_ENDPOINT || "").trim();
  const timeout = Number(process.env.BILLING_SOAP_TIMEOUT_MS || 15000);
  const authorization = (process.env.BILLING_SOAP_AUTHORIZATION || "").trim();
  const oauthTokenUrl = (process.env.BILLING_SOAP_OAUTH_TOKEN_URL || "").trim();
  const oauthClientId = (process.env.BILLING_SOAP_OAUTH_CLIENT_ID || "").trim();
  const oauthClientSecret = (process.env.BILLING_SOAP_OAUTH_CLIENT_SECRET || "").trim();
  const oauthScope = (process.env.BILLING_SOAP_OAUTH_SCOPE || "").trim();

  if (!endpoint) {
    throw new BillingServiceError(
      "Billing service is currently unavailable. Please try again later",
      500,
    );
  }

  return {
    endpoint,
    timeout,
    authorization,
    oauthTokenUrl,
    oauthClientId,
    oauthClientSecret,
    oauthScope,
  };
};

const getBillingSoapAuthorization = async (
  traceId: string,
  config: ReturnType<typeof getSoapConfig>,
): Promise<string | undefined> => {
  if (config.authorization) {
    return config.authorization;
  }

  if (!config.oauthTokenUrl || !config.oauthClientId || !config.oauthClientSecret) {
    return undefined;
  }

  const now = Date.now();
  if (billingSoapTokenCache && now < billingSoapTokenCache.expiresAt - BILLING_SOAP_TOKEN_REFRESH_SKEW_MS) {
    return billingSoapTokenCache.token;
  }

  try {
    const tokenUrl = new URL(config.oauthTokenUrl);
    tokenUrl.searchParams.set("grant_type", "client_credentials");
    if (config.oauthScope) {
      tokenUrl.searchParams.set("scope", config.oauthScope);
    }

    const basicAuth = Buffer.from(`${config.oauthClientId}:${config.oauthClientSecret}`).toString("base64");
    const tokenResponse = await axios.post(tokenUrl.toString(), "", {
      headers: {
        Authorization: `Basic ${basicAuth}`,
        Accept: "application/json",
        "Content-Type": "application/json",
        "Content-Length": "0",
      },
      timeout: config.timeout,
      validateStatus: () => true,
    });

    if (tokenResponse.status >= 400) {
      throw new BillingServiceError("Internal server error", 500, {
        upstreamStatus: tokenResponse.status,
        upstreamBody: tokenResponse.data,
      });
    }

    const payload =
      tokenResponse.data && typeof tokenResponse.data === "object"
        ? (tokenResponse.data as Record<string, unknown>)
        : {};
    const accessToken = String(payload.access_token ?? "").trim();
    const tokenType = String(payload.token_type ?? "Bearer").trim() || "Bearer";
    const expiresIn = Number(payload.expires_in ?? 3600);
    const tokenTtlSeconds =
      Number.isFinite(expiresIn) && expiresIn > 0
        ? Math.min(expiresIn, BILLING_SOAP_TOKEN_MAX_AGE_SECONDS)
        : BILLING_SOAP_TOKEN_MAX_AGE_SECONDS;

    if (!accessToken) {
      throw new BillingServiceError("Internal server error", 500, {
        upstreamBody: payload,
      });
    }

    const authorizationValue = `${tokenType} ${accessToken}`;
    billingSoapTokenCache = {
      token: authorizationValue,
      expiresAt: now + tokenTtlSeconds * 1000,
    };

    return authorizationValue;
  } catch (error) {
    if (error instanceof BillingServiceError) {
      throw error;
    }

    const axiosError = error as AxiosError;
    logger.error({
      traceId,
      event: "BILLING_OAUTH_TOKEN_FAILED",
      message: axiosError.message,
      code: axiosError.code,
      status: axiosError.response?.status,
      data: axiosError.response?.data,
    });

    throw new BillingServiceError("Internal server error", 500, {
      message: axiosError.message,
      code: axiosError.code,
      status: axiosError.response?.status,
      data: axiosError.response?.data,
    });
  }
};

const buildBillingSoapHeaders = async (
  traceId: string,
  config: ReturnType<typeof getSoapConfig>,
): Promise<Record<string, string>> => {
  const headers: Record<string, string> = {
    "Content-Type": "application/soap+xml",
  };


  const authorization = await getBillingSoapAuthorization(traceId, config);
  if (authorization) {
    headers["Authorization"] = authorization;
  }


  return headers;
};

const mapGetAccountResponse = (payload: Record<string, unknown>): GetAccountResponse => {
  const rpgJobInformation = asRecord(getNode(payload, "rpgJobInformation"));
  const billingAccount = asRecord(getNode(payload, "billingAccount_BLACC"));
  const control = asArray(getNode(payload, "control_CONTROL")).map(asRecord);
  const control0 = control[0] || {};
  const subscriberProfile = asRecord(getNode(payload, "subscriberProfile_SUBINF"));
  const physicalAddress = asRecord(getNode(payload, "physicalAddress_PSAMAS"));
  const dslProfile = asRecord(getNode(payload, "servicemanDSLProfile_SUBDSLSVM"));
  const taxExemption = asRecord(getNode(payload, "taxExemption_BLTEC"));
  const equalAccess = asArray(getNode(payload, "equalAccess_BLEQAC"));
  const cycleTariffHistory = asRecord(getNode(payload, "cycleTariffHistory_BLCTH"));
  const billItems = asArray(getNode(payload, "billItem_SEREQP"));
  const contracts = asArray(getNode(payload, "currentContract"));
  const promotions = asArray(getNode(payload, "subscriberPromotion_SUBPRM"));
  const payHistory = asArray(getNode(payload, "onLineBillPayHistory_BLEBPPRH"));

  const billedMembers = control
    .map((item) => {
      const exchange = String(item.memberExchange_COMEX || "").trim();
      const line = String(item.memberLineNumber_COMNLN || "").trim();
      const phone = exchange || line ? `${exchange}${line}` : null;
      return { ...item, phone };
    })
    .filter((item) => item.phone);

  return {
    meta: {
      return_code: asReturnCode(rpgJobInformation.returnCode),
    },
    billing_account: {
      ...control0,
      monthly_recurring: control0.monthlyRecurringCharge ?? null,
      statement_due: cycleTariffHistory.statementDueDate_CTHDUE ?? null,
    },
    payment: {
      auto_pay: billingAccount.ebppAutoPay_ACCEAP ?? null,
      print_bills: billingAccount.ebppPrintBills_ACCEPB ?? null,
      ...billingAccount,
      ...control0,
    },
    customer: {
      ...subscriberProfile,
      billing_address: subscriberProfile.nineDigitZipCode_SUBZCD ?? null,
    },
    network: {
      service_address: physicalAddress,
      prov: dslProfile,
    },
    tax_exemption: Object.keys(taxExemption).length ? taxExemption : null,
    carriers: equalAccess,
    billed_members: billedMembers,
    services: billItems,
    contracts,
    promotions,
    pay_history: payHistory,
    raw: payload,
  };
};

const mapGetAccountReceivableResponse = (
  payload: Record<string, unknown>,
): GetAccountReceivableResponse => {
  const rpgJobInformation = asRecord(getNode(payload, "rpgJobInformation"));

  return {
    meta: {
      return_code: asReturnCode(rpgJobInformation.returnCode),
    },
    receivable_summary: asArray(getNode(payload, "accountReceivableSummary")),
    receivable_detail: asArray(getNode(payload, "accountReceivableDetail")),
    current_balance: asRecord(getNode(payload, "currentBalance")) || null,
    payment_history: asArray(getNode(payload, "paymentHistory")),
    adjustment_history: asArray(getNode(payload, "adjustmentHistory")),
    raw: payload,
  };
};

const mapGetTreatmentResponse = (payload: Record<string, unknown>): GetTreatmentResponse => {
  const rpgJobInformation = asRecord(getNode(payload, "rpgJobInformation"));
  const treatment =
    asRecord(getNode(payload, "treatment")) ||
    asRecord(getNode(payload, "accountTreatment")) ||
    payload;

  return {
    meta: {
      return_code: asReturnCode(rpgJobInformation.returnCode),
    },
    treatment,
    raw: payload,
  };
};

export const getAccountService = async (
  request: BillingServiceRequest,
): Promise<GetAccountResponse> => {
  const traceId = getTraceId();
  const soapConfig = getSoapConfig();
  const { endpoint, timeout } = soapConfig;
  const soapRequest = buildGetAccountXml(request);
  const headers = await buildBillingSoapHeaders(traceId, soapConfig);

  logger.info({
    traceId,
    event: "BILLING_GET_ACCOUNT_SOAP_REQUEST",
    endpoint,
    environment: request.environment,
    telephoneNumber: request.telephoneNumber,
  });

  try {
    const response = await axios.post(endpoint, soapRequest, {
      headers,
      timeout,
      responseType: "text",
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      throw new BillingServiceError("Billing SOAP endpoint returned HTTP error", 502, {
        upstreamStatus: response.status,
        upstreamBody: response.data,
      });
    }

    const parsedXml = parser.parse(String(response.data || ""));
    const soapBody = findSoapBody(parsedXml);
    const soapFault = getChildByLocalName(soapBody, "Fault");

    if (soapFault) {
      throw new BillingServiceError("SOAP Fault returned by billing service", 502, soapFault);
    }

    const payload = getResponsePayload(soapBody);
    const mapped = mapGetAccountResponse(payload);

    logger.info({
      traceId,
      event: "BILLING_GET_ACCOUNT_SOAP_SUCCESS",
      hasReturnCode: mapped.meta.return_code !== null,
      carrierCount: mapped.carriers.length,
      servicesCount: mapped.services.length,
    });

    return mapped;
  } catch (error) {
    if (error instanceof BillingServiceError) {
      logger.error({
        traceId,
        event: "BILLING_GET_ACCOUNT_SOAP_FAILED",
        message: error.message,
        details: error.details,
      });
      throw error;
    }

    const axiosError = error as AxiosError;
    const details = {
      message: axiosError.message,
      code: axiosError.code,
      status: axiosError.response?.status,
      data: axiosError.response?.data,
    };

    logger.error({
      traceId,
      event: "BILLING_GET_ACCOUNT_SOAP_FAILED",
      message: "Unexpected SOAP request failure",
      details,
    });

    throw new BillingServiceError("Failed to call billing SOAP endpoint", 502, details);
  }
};

export const getAccountReceivableService = async (
  request: BillingReceivableServiceRequest,
): Promise<GetAccountReceivableResponse> => {
  const traceId = getTraceId();
  const soapConfig = getSoapConfig();
  const { endpoint, timeout } = soapConfig;
  const soapRequest = buildGetAccountReceivableXml(request);
  const headers = await buildBillingSoapHeaders(traceId, soapConfig);

  logger.info({
    traceId,
    event: "BILLING_GET_ACCOUNT_RECEIVABLE_SOAP_REQUEST",
    endpoint,
    environment: request.environment,
    workingTelephoneNumber: request.workingTelephoneNumber,
  });

  try {
    const response = await axios.post(endpoint, soapRequest, {
      headers,
      timeout,
      responseType: "text",
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      throw new BillingServiceError("Billing SOAP endpoint returned HTTP error", 502, {
        upstreamStatus: response.status,
        upstreamBody: response.data,
      });
    }

    const parsedXml = parser.parse(String(response.data || ""));
    const soapBody = findSoapBody(parsedXml);
    const soapFault = getChildByLocalName(soapBody, "Fault");

    if (soapFault) {
      throw new BillingServiceError("SOAP Fault returned by billing service", 502, soapFault);
    }

    const payload = getResponsePayload(soapBody);
    const mapped = mapGetAccountReceivableResponse(payload);

    logger.info({
      traceId,
      event: "BILLING_GET_ACCOUNT_RECEIVABLE_SOAP_SUCCESS",
      hasReturnCode: mapped.meta.return_code !== null,
      summaryCount: mapped.receivable_summary.length,
      detailCount: mapped.receivable_detail.length,
    });

    return mapped;
  } catch (error) {
    if (error instanceof BillingServiceError) {
      logger.error({
        traceId,
        event: "BILLING_GET_ACCOUNT_RECEIVABLE_SOAP_FAILED",
        message: error.message,
        details: error.details,
      });
      throw error;
    }

    const axiosError = error as AxiosError;
    const details = {
      message: axiosError.message,
      code: axiosError.code,
      status: axiosError.response?.status,
      data: axiosError.response?.data,
    };

    logger.error({
      traceId,
      event: "BILLING_GET_ACCOUNT_RECEIVABLE_SOAP_FAILED",
      message: "Unexpected SOAP request failure",
      details,
    });

    throw new BillingServiceError("Failed to call billing SOAP endpoint", 502, details);
  }
};

export const getTreatmentService = async (
  request: BillingTreatmentServiceRequest,
): Promise<GetTreatmentResponse> => {
  const traceId = getTraceId();
  const soapConfig = getSoapConfig();
  const { endpoint, timeout } = soapConfig;
  const soapRequest = buildGetTreatmentXml(request);
  const headers = await buildBillingSoapHeaders(traceId, soapConfig);

  logger.info({
    traceId,
    event: "BILLING_GET_TREATMENT_SOAP_REQUEST",
    endpoint,
    environment: request.environment,
    crisId: request.crisId,
    workingTelephoneNumber: request.workingTelephoneNumber,
  });

  try {
    const response = await axios.post(endpoint, soapRequest, {
      headers,
      timeout,
      responseType: "text",
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      throw new BillingServiceError("Billing SOAP endpoint returned HTTP error", 502, {
        upstreamStatus: response.status,
        upstreamBody: response.data,
      });
    }

    const parsedXml = parser.parse(String(response.data || ""));
    const soapBody = findSoapBody(parsedXml);
    const soapFault = getChildByLocalName(soapBody, "Fault");

    if (soapFault) {
      throw new BillingServiceError("SOAP Fault returned by billing service", 502, soapFault);
    }

    const payload = getResponsePayload(soapBody);
    const mapped = mapGetTreatmentResponse(payload);

    logger.info({
      traceId,
      event: "BILLING_GET_TREATMENT_SOAP_SUCCESS",
      hasReturnCode: mapped.meta.return_code !== null,
    });

    return mapped;
  } catch (error) {
    if (error instanceof BillingServiceError) {
      logger.error({
        traceId,
        event: "BILLING_GET_TREATMENT_SOAP_FAILED",
        message: error.message,
        details: error.details,
      });
      throw error;
    }

    const axiosError = error as AxiosError;
    const details = {
      message: axiosError.message,
      code: axiosError.code,
      status: axiosError.response?.status,
      data: axiosError.response?.data,
    };

    logger.error({
      traceId,
      event: "BILLING_GET_TREATMENT_SOAP_FAILED",
      message: "Unexpected SOAP request failure",
      details,
    });

    throw new BillingServiceError("Failed to call billing SOAP endpoint", 502, details);
  }
};

export const getPaymentMethodsService = async (
  request: GetPaymentMethodsRequest,
): Promise<PaymentMethodsResponse> => {
  const traceId = getTraceId();
  const { baseUrl, timeout, headers, httpsAgent, tlsRejectUnauthorized, useProxy } =
    getPaymentCoreConfig();
  const endpoint = `${baseUrl}/v1/billingaccount/${encodeURIComponent(request.billingAccountId)}/recurringpayment`;

  logger.info({
    traceId,
    event: "PAYMENT_CORE_GET_PAYMENT_METHODS_REQUEST",
    endpoint,
    billingAccountId: request.billingAccountId,
    sort: request.sort,
    tlsRejectUnauthorized,
    useProxy,
  });

  try {
    const response = await axios.get(endpoint, {
      params: request.sort ? { sort: request.sort } : undefined,
      headers,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      const statusCode = response.status >= 500 ? 502 : response.status;
      const upstreamMessage = getUpstreamErrorMessage(response.data);
      const message = upstreamMessage
        ? `Payment Core responded with HTTP ${response.status}: ${upstreamMessage}`
        : `Payment Core responded with HTTP ${response.status}`;
      throw new BillingServiceError(
        message,
        statusCode,
        {
        errorType: "UPSTREAM_HTTP_ERROR",
        upstreamReached: true,
        upstreamStatus: response.status,
        upstreamBody: response.data,
        },
      );
    }

    logger.info({
      traceId,
      event: "PAYMENT_CORE_GET_PAYMENT_METHODS_SUCCESS",
      upstreamStatus: response.status,
    });

    return response.data as PaymentMethodsResponse;
  } catch (error) {
    if (error instanceof BillingServiceError) {
      logger.error({
        traceId,
        event: "PAYMENT_CORE_GET_PAYMENT_METHODS_FAILED",
        message: error.message,
        details: error.details,
      });
      throw error;
    }

    const axiosError = error as AxiosError;
    const isTimeout = axiosError.code === "ECONNABORTED";
    const upstreamReached = Boolean(axiosError.response);
    const message = isTimeout
      ? "Payment Core request timed out before receiving a response"
      : upstreamReached
        ? "Received an error response while connecting to Payment Core"
        : "Unable to connect to Payment Core API";
    const details = {
      errorType: isTimeout ? "UPSTREAM_TIMEOUT" : "UPSTREAM_CONNECTION_ERROR",
      upstreamReached,
      message: axiosError.message,
      code: axiosError.code,
      status: axiosError.response?.status,
      data: axiosError.response?.data,
    };

    logger.error({
      traceId,
      event: "PAYMENT_CORE_GET_PAYMENT_METHODS_FAILED",
      message,
      details,
    });

    throw new BillingServiceError(message, isTimeout ? 504 : 502, details);
  }
};

export const getPaymentsService = async (
  request: GetPaymentsRequest,
): Promise<PaymentsResponse> => {
  const traceId = getTraceId();
  const { baseUrl, timeout, headers, httpsAgent, tlsRejectUnauthorized, useProxy } =
    getPaymentCoreConfig();
      const billingAccountIdResponse = (await getBillingAccountIdDetails(request.billingAccountId)) ?? request.billingAccountId;

  const endpoint = `${baseUrl}/v1/billingaccount/${encodeURIComponent(billingAccountIdResponse)}/payments`;

  logger.info({
    traceId,
    event: "PAYMENT_CORE_GET_PAYMENTS_REQUEST",
    endpoint,
    billingAccountId: request.billingAccountId,
    tlsRejectUnauthorized,
    useProxy,
  });

  try {
    const response = await axios.get(endpoint, {
      headers,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      const statusCode = response.status >= 500 ? 502 : response.status;
      const upstreamMessage = getUpstreamErrorMessage(response.data);
      const message = upstreamMessage
        ? `Payment Core responded with HTTP ${response.status}: ${upstreamMessage}`
        : `Payment Core responded with HTTP ${response.status}`;
      throw new BillingServiceError(
        message,
        statusCode,
        {
        errorType: "UPSTREAM_HTTP_ERROR",
        upstreamReached: true,
        upstreamStatus: response.status,
        upstreamBody: response.data,
        },
      );
    }

    logger.info({
      traceId,
      event: "PAYMENT_CORE_GET_PAYMENTS_SUCCESS",
      upstreamStatus: response.status,
    });

    return response.data as PaymentsResponse;
  } catch (error) {
    if (error instanceof BillingServiceError) {
      logger.error({
        traceId,
        event: "PAYMENT_CORE_GET_PAYMENTS_FAILED",
        message: error.message,
        details: error.details,
      });
      throw error;
    }

    const axiosError = error as AxiosError;
    const isTimeout = axiosError.code === "ECONNABORTED";
    const upstreamReached = Boolean(axiosError.response);
    const message = isTimeout
      ? "Payment Core request timed out before receiving a response"
      : upstreamReached
        ? "Received an error response while connecting to Payment Core"
        : "Unable to connect to Payment Core API";
    const details = {
      errorType: isTimeout ? "UPSTREAM_TIMEOUT" : "UPSTREAM_CONNECTION_ERROR",
      upstreamReached,
      message: axiosError.message,
      code: axiosError.code,
      status: axiosError.response?.status,
      data: axiosError.response?.data,
    };

    logger.error({
      traceId,
      event: "PAYMENT_CORE_GET_PAYMENTS_FAILED",
      message,
      details,
    });

    throw new BillingServiceError(message, isTimeout ? 504 : 502, details);
  }
};




export const getGtvBillingAccountDetails = async (
  billingAccountId: string,
): Promise<unknown> => {
  try {

  
  const billingAccountIdResponse =
    (await getBillingAccountIdDetails(billingAccountId)) ?? billingAccountId;


  const billingAccountSql = `
    SELECT *
    FROM zbp.billing_account
    WHERE id = ${billingAccountIdResponse}
  `;

  const billingAccountResult = await pool.query(billingAccountSql);
  const account = billingAccountResult.rows[0];
  let accountNum;
  if(account && account.account_num){
      accountNum = account.account_num;
  }
  


  const billingAddressSql = `
    SELECT
      *,
      CONCAT_WS(', ',
        billing_address_street_1,
        billing_address_street_2,
        billing_address_city,
        billing_address_region_or_state,
        billing_address_postal_code,
        billing_address_country
      ) AS billing_address,
      CONCAT_WS(', ',
        service_address_street_1,
        service_address_street_2,
        service_address_city,
        service_address_region_or_state,
        service_address_postal_code,
        service_address_country
      ) AS service_address
    FROM zbp.billing_account_address
    WHERE billing_account_id = ${billingAccountIdResponse}
  `;

  const billingAddressResult = await pool.query(billingAddressSql);

  const billingCategorySql = `
    SELECT *
    FROM zbp.billing_account_category
    WHERE id = ${account.category_id}
  `;

  const billingCategoryResult = await pool.query(billingCategorySql);


const { baseUrl, timeout, headers, httpsAgent, tlsRejectUnauthorized, useProxy } =
    getPaymentCoreConfig();

    const endpoint = `${baseUrl}/v1/billingaccount/${billingAccountIdResponse}/recurringpayment`;


      const recurringPaymentResponse = await axios.get(endpoint, {
      headers,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      validateStatus: () => true,
    });

const paymentMethods = (recurringPaymentResponse.data ?? []).map(
  (item: any) => {
    const paymentMethod = item.payment_method ?? {};

    const cardTypeField = paymentMethod.custom_field_values?.find(
      (cf: any) => cf.custom_field?.name === "Card Type",
    );

    return {
      id: paymentMethod.id,
      billing_account_id: item.billing_account?.id,

      bank_account_number_last_four:
        paymentMethod.account_number ?? null,

      card_holder_firstname:
        paymentMethod.first_name ?? null,

      card_holder_lastname:
        paymentMethod.last_name ?? null,

     

      card_holder_name:
        paymentMethod.account_holder_name ?? null,

      card_identifier_last_four:paymentMethod.last_four ?? null,

      card_expiration: paymentMethod.expiration_date ?? null,

      card_type: cardTypeField?.value ?? null,


      nickname: paymentMethod.nickname ?? null,

      identifier_number: paymentMethod.identifier_number ?? null,
      payment_type:
        paymentMethod.payment_method_type ?? null,

      autopay_enabled: item.auto_payment,

      default_payment: item.auto_payment,

      valid_from: item.valid_from ?? null,

      valid_to: item.valid_to ?? null,

      created_by: item.created_by ?? null,

      created_on: item.created_on ?? null,

      token: paymentMethod.token ?? null,

    };
  },
);


  const cardTypeDetailsSql = `SELECT
    PMCF.value
FROM zbp.payment_method_custom_field_value PMCF
JOIN zbp.billing_account_payment_method BAPM
    ON PMCF.payment_method_id = BAPM.payment_method_id
WHERE PMCF.name = 'Card Type'
  AND BAPM.AUTOPAY_ENABLED = 'TRUE'
  AND BAPM.billing_account_id = '${billingAccountIdResponse}'
ORDER BY 1`;
const cardTypeDetailsResult = await pool.query(cardTypeDetailsSql);


const amountDetailsSql = `SELECT amount
FROM zbp.payment p
WHERE p.billing_account_id = ${billingAccountIdResponse}
  AND p.status = 'COMPLETED'
ORDER BY p.created_on DESC
LIMIT 1;`

const amountDetailsResult = await pool.query(amountDetailsSql);

const autopayEnabledSql = `SELECT CAST(MAX(al.created_on) AS DATE) AS auto_pay_enabled_date
FROM zbp.audit_log al
JOIN zbp.billing_account ba
    ON ba.account_num = al.account_num
WHERE al.description LIKE '%Auto%Payment%Autho%true%'
  AND al.entity_type = 'Autopayment'
  AND al.account_num = '${accountNum}'
  AND ba.auto_pay_enabled = TRUE;`
const autopayEnabledResult = await pool.query(autopayEnabledSql);

const autopayDisabledSql = `SELECT CAST(MAX(al.created_on) AS DATE) AS auto_pay_disabled_date
FROM zbp.audit_log al
JOIN zbp.billing_account ba
    ON ba.account_num = al.account_num
WHERE al.description LIKE '%Auto%Payment%Autho%false%'
  AND al.entity_type = 'Autopayment'
  AND al.account_num = '${accountNum}'
  AND ba.auto_pay_enabled = FALSE;`
const autopayDisabledResult = await pool.query(autopayDisabledSql);

  return {
    billingAccountDetails: {
      ...account,
      billingAddress: billingAddressResult.rows[0]?.billing_address ?? null,
      serviceAddress: billingAddressResult.rows[0]?.service_address ?? null,
    },
    billingCategory: {
      categoryType: billingCategoryResult.rows[0].type,
    },
    paymentMethods: paymentMethods,
    payments :{
      cardType: cardTypeDetailsResult.rows[0]?.value ?? null,
      lastPaymentAmount: amountDetailsResult.rows[0]?.amount ?? null,
      autoPayEnabledDate: autopayEnabledResult.rows[0]?.auto_pay_enabled_date ?? null,
      autoPayDisabledDate: autopayDisabledResult.rows[0]?.auto_pay_disabled_date ?? null
    }
  };
  } catch (error) {
    logger.error({
      event: "GET_GTV_BILLING_ACCOUNT_DETAILS_FAILED",
      message: (error as Error).message,
      details: error,
    });
    throw error;
  }
};

export const getAccountHistoryService = async (
  request: GetAccountHistoryRequest,
): Promise<AccountHistoryResponse> => {
  const traceId = getTraceId();
  const { baseUrl, timeout, headers, httpsAgent, tlsRejectUnauthorized, useProxy } =
    getPaymentCoreConfig();
  const endpoint = `${baseUrl}/v1/auditlogs/${encodeURIComponent(request.billingAccountId)}`;

  logger.info({
    traceId,
    event: "PAYMENT_CORE_GET_ACCOUNT_HISTORY_REQUEST",
    endpoint,
    billingAccountId: request.billingAccountId,
    tlsRejectUnauthorized,
    useProxy,
  });

  try {
    const response = await axios.get(endpoint, {
      headers,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      const statusCode = response.status >= 500 ? 502 : response.status;
      const upstreamMessage = getUpstreamErrorMessage(response.data);
      const message = upstreamMessage
        ? `Payment Core responded with HTTP ${response.status}: ${upstreamMessage}`
        : `Payment Core responded with HTTP ${response.status}`;
      throw new BillingServiceError(
        message,
        statusCode,
        {
          errorType: "UPSTREAM_HTTP_ERROR",
          upstreamReached: true,
          upstreamStatus: response.status,
          upstreamBody: response.data,
        },
      );
    }

    logger.info({
      traceId,
      event: "PAYMENT_CORE_GET_ACCOUNT_HISTORY_SUCCESS",
      upstreamStatus: response.status,
    });

    return response.data as AccountHistoryResponse;
  } catch (error) {
    if (error instanceof BillingServiceError) {
      logger.error({
        traceId,
        event: "PAYMENT_CORE_GET_ACCOUNT_HISTORY_FAILED",
        message: error.message,
        details: error.details,
      });
      throw error;
    }

    const axiosError = error as AxiosError;
    const isTimeout = axiosError.code === "ECONNABORTED";
    const upstreamReached = Boolean(axiosError.response);
    const message = isTimeout
      ? "Payment Core request timed out before receiving a response"
      : upstreamReached
        ? "Received an error response while connecting to Payment Core"
        : "Unable to connect to Payment Core API";
    const details = {
      errorType: isTimeout ? "UPSTREAM_TIMEOUT" : "UPSTREAM_CONNECTION_ERROR",
      upstreamReached,
      message: axiosError.message,
      code: axiosError.code,
      status: axiosError.response?.status,
      data: axiosError.response?.data,
    };

    logger.error({
      traceId,
      event: "PAYMENT_CORE_GET_ACCOUNT_HISTORY_FAILED",
      message,
      details,
    });

    throw new BillingServiceError(message, isTimeout ? 504 : 502, details);
  }
};