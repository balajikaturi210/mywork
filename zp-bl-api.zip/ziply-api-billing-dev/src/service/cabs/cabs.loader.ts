import fs from "fs";
import type { PoolClient } from "pg";
import zbpPool from "../../config/zbpDb";
import logger from "../../logger/logger";
import { AgingRow, BdtRow, BillingRow, CabsFileError, parseAging, parseBdtConfig, parseBdtConfigSmall, parseBillingDetail } from "./cabs.parsers";
import { SheetNotFoundError } from "./xlsxStream";

/** A load that has shown no activity for this long is treated as dead (for example the pod restarted mid-load). */
const STALE_MINUTES = 10;

export interface UploadedFile {
  path: string;
  originalname: string;
}
export interface CabsUploadFiles {
  billing: UploadedFile;
  aging: UploadedFile;
  bdt: UploadedFile;
  bdtSmall: UploadedFile;
}

const errText = (e: unknown): string => (e instanceof Error ? e.message : String(e));

export const failStaleSnapshots = async (): Promise<void> => {
  await zbpPool.query(
    `UPDATE cabs.snapshots
        SET status = 'FAILED', finished_at = now(), stage = NULL,
            error_message = 'Interrupted: the load stopped responding (the service may have restarted). Upload the files again.'
      WHERE status = 'PROCESSING' AND last_activity_at < now() - make_interval(mins => $1)`,
    [STALE_MINUTES],
  );
};

export class LoadInProgressError extends Error {
  constructor(public snapshotId: number) {
    super(`Another CABS load (snapshot ${snapshotId}) is still running. Wait for it to finish.`);
    this.name = "LoadInProgressError";
  }
}

const touch = (snapshotId: number, stage?: string) =>
  zbpPool.query(
    `UPDATE cabs.snapshots SET last_activity_at = now(), stage = COALESCE($2, stage) WHERE id = $1`,
    [snapshotId, stage ?? null],
  );

const insertRows = async (client: PoolClient, snapshotId: number, table: string, columns: string[], rows: unknown[][], suffix = "") => {
  if (!rows.length) return;
  const width = columns.length + 1;
  const params: unknown[] = [];
  const tuples = rows.map((row, i) => {
    params.push(snapshotId, ...row);
    return `(${Array.from({ length: width }, (_, k) => `$${i * width + k + 1}`).join(",")})`;
  });
  await client.query(`INSERT INTO ${table} (snapshot_id, ${columns.join(",")}) VALUES ${tuples.join(",")} ${suffix}`, params);
};

const BILLING_COLS = ["co_number", "ixc", "ixc_name", "ban", "bill_date", "ec_circuit", "bdw", "eo_info", "pop_key", "cust",
  "z_clli_address", "z_clli_st", "z_clli_city", "z_clli_zip", "pop", "nc", "cos", "usoc", "amount"];
const AGING_COLS = ["carrier_group", "carrier", "co_number", "ixc", "fg", "ban", "invoice", "inv_date", "current_amt", "days_30",
  "days_60", "days_90", "days_120", "days_150", "days_180", "days_270", "years_1_2", "over_2_years", "total_amt", "past_due"];
const BDT_COLS = ["ban", "co_number", "cycle", "ixc", "balfg", "bdt_sw_1", "csr_sw_1", "bdt_sw_2", "csr_sw_2", "aadr_key", "cardname",
  "paper_comment", "bdt_comment", "is_critical", "amount"];
const SMALL_COLS = ["co_number", "cycle", "ixc", "balfg", "bill_print", "comment"];

/**
 * Registers the snapshot and returns at once; the files are loaded in the background. The UI follows the snapshot's
 * status (PROCESSING, READY or FAILED). The uploaded temp files are removed when the load ends.
 */
export const startSnapshot = async (label: string | null, files: CabsUploadFiles, uploadedBy: string | null): Promise<number> => {
  await failStaleSnapshots();
  const running = await zbpPool.query(`SELECT id FROM cabs.snapshots WHERE status = 'PROCESSING' ORDER BY id DESC LIMIT 1`);
  if (running.rowCount) throw new LoadInProgressError(running.rows[0].id);

  const created = await zbpPool.query(
    `INSERT INTO cabs.snapshots (label, billing_file_name, aging_file_name, bdt_file_name, bdt_small_file_name, status, stage, uploaded_by)
     VALUES ($1, $2, $3, $4, $5, 'PROCESSING', 'queued', $6) RETURNING id`,
    [label, files.billing.originalname, files.aging.originalname, files.bdt.originalname, files.bdtSmall.originalname, uploadedBy],
  );
  const snapshotId: number = created.rows[0].id;
  setImmediate(() => {
    processSnapshot(snapshotId, files).catch((e) => logger.error({ message: `CABS snapshot ${snapshotId} crashed: ${errText(e)}` }));
  });
  return snapshotId;
};

const cleanFiles = (files: CabsUploadFiles) => {
  for (const f of [files.billing, files.aging, files.bdt, files.bdtSmall]) fs.promises.unlink(f.path).catch(() => undefined);
};

export const processSnapshot = async (snapshotId: number, files: CabsUploadFiles): Promise<void> => {
  const started = Date.now();
  const client = await zbpPool.connect();
  try {
    await client.query("BEGIN");
    let batches = 0;
    const tick = async () => {
      if (++batches % 10 === 0) await touch(snapshotId);
    };

    await touch(snapshotId, "loading billing detail");
    const billing = await parseBillingDetail(files.billing.path, async (rows: BillingRow[]) => {
      await insertRows(client, snapshotId, "cabs.billing_detail", BILLING_COLS, rows);
      await tick();
    });

    await touch(snapshotId, "loading aging");
    const aging = await parseAging(files.aging.path, async (rows: AgingRow[]) => {
      await insertRows(client, snapshotId, "cabs.aging", AGING_COLS, rows, "ON CONFLICT (snapshot_id, co_number, ban, invoice) DO NOTHING");
      await tick();
    });

    await touch(snapshotId, "loading BDT config");
    const bdt = await parseBdtConfig(files.bdt.path, async (rows: BdtRow[]) => {
      await insertRows(client, snapshotId, "cabs.bdt_config", BDT_COLS, rows, "ON CONFLICT (snapshot_id, ban) DO NOTHING");
      await tick();
    });
    const small = await parseBdtConfigSmall(files.bdtSmall.path, async (rows) => {
      await insertRows(client, snapshotId, "cabs.bdt_config_small_co", SMALL_COLS, rows);
    });

    await client.query(`UPDATE cabs.snapshots SET billing_truncated_month = $2, row_counts = $3 WHERE id = $1`, [
      snapshotId,
      billing.truncatedMonth,
      JSON.stringify({ billing_detail: billing.rowCount, aging: aging.rowCount, bdt_config: bdt.rowCount, bdt_config_small_co: small.rowCount }),
    ]);
    await client.query("COMMIT");

    await touch(snapshotId, "building circuit report");
    const circuits = await buildCircuitReport(snapshotId);

    await zbpPool.query(
      `UPDATE cabs.snapshots SET status = 'READY', stage = NULL, error_message = NULL, finished_at = now(), last_activity_at = now() WHERE id = $1`,
      [snapshotId],
    );
    logger.info({ message: `CABS snapshot ${snapshotId} ready: ${circuits} circuits in ${Math.round((Date.now() - started) / 1000)}s` });
  } catch (e) {
    await client.query("ROLLBACK").catch(() => undefined);
    const known = e instanceof CabsFileError || e instanceof SheetNotFoundError;
    logger.error({ message: `CABS snapshot ${snapshotId} failed: ${errText(e)}` });
    await removeSnapshotData(snapshotId).catch(() => undefined);
    await zbpPool.query(
      `UPDATE cabs.snapshots SET status = 'FAILED', stage = NULL, finished_at = now(), error_message = $2 WHERE id = $1`,
      [snapshotId, known ? errText(e) : `Load failed: ${errText(e)}`],
    );
  } finally {
    client.release();
    cleanFiles(files);
  }
};

const removeSnapshotData = async (snapshotId: number) => {
  for (const t of ["circuit_report", "billing_detail", "aging", "bdt_config", "bdt_config_small_co"]) {
    await zbpPool.query(`DELETE FROM cabs.${t} WHERE snapshot_id = $1`, [snapshotId]);
  }
};

const toNum = (v: unknown): number | null => (v === null || v === undefined ? null : Number(v));

/**
 * One row per circuit (co_number + ec_circuit): billed amount per month, first and last month billed, whether the
 * circuit is still billed in the latest complete month (Active), started later (New) or stopped (Dropped), joined to
 * the BAN's BDT delivery status and aging. A month the export stopped part-way through (billing_truncated_month) is
 * not used to decide that a circuit dropped.
 */
export const buildCircuitReport = async (snapshotId: number): Promise<number> => {
  const client = await zbpPool.connect();
  try {
    await client.query("BEGIN");
    const snap = await client.query(`SELECT billing_truncated_month FROM cabs.snapshots WHERE id = $1`, [snapshotId]);
    const truncated: string | null = snap.rows[0]?.billing_truncated_month ?? null;

    const monthly = await client.query(
      `SELECT co_number, ec_circuit, to_char(bill_date, 'YYYY-MM') AS m, SUM(amount) AS amt
         FROM cabs.billing_detail
        WHERE snapshot_id = $1 AND co_number IS NOT NULL AND ec_circuit IS NOT NULL AND bill_date IS NOT NULL
        GROUP BY co_number, ec_circuit, to_char(bill_date, 'YYYY-MM')`,
      [snapshotId],
    );
    const meta = await client.query(
      `SELECT co_number, ec_circuit,
              (array_agg(ixc_name ORDER BY bill_date DESC NULLS FIRST, id ASC) FILTER (WHERE ixc_name IS NOT NULL))[1] AS ixc_name,
              (array_agg(cust ORDER BY bill_date DESC NULLS FIRST, id ASC) FILTER (WHERE cust IS NOT NULL))[1] AS cust,
              (array_agg(ban ORDER BY bill_date DESC NULLS FIRST, id ASC) FILTER (WHERE ban IS NOT NULL))[1] AS ban
         FROM cabs.billing_detail
        WHERE snapshot_id = $1 AND co_number IS NOT NULL AND ec_circuit IS NOT NULL
        GROUP BY co_number, ec_circuit`,
      [snapshotId],
    );
    const bdt = await client.query(
      `SELECT ban, cardname, bdt_comment, paper_comment, is_critical FROM cabs.bdt_config WHERE snapshot_id = $1`,
      [snapshotId],
    );
    const aging = await client.query(
      `SELECT ban,
              ROUND(SUM(current_amt)) AS aging_current, ROUND(SUM(days_30)) AS aging_30, ROUND(SUM(days_60)) AS aging_60,
              ROUND(SUM(days_90)) AS aging_90, ROUND(SUM(days_120)) AS aging_120, ROUND(SUM(days_150)) AS aging_150,
              ROUND(SUM(days_180)) AS aging_180, ROUND(SUM(days_270)) AS aging_270, ROUND(SUM(years_1_2)) AS aging_1_2yr,
              ROUND(SUM(over_2_years)) AS aging_over_2yr, ROUND(SUM(total_amt)) AS aging_total,
              ROUND(SUM(past_due)) AS aging_past_due, COUNT(*) AS num_invoices
         FROM cabs.aging WHERE snapshot_id = $1 GROUP BY ban`,
      [snapshotId],
    );

    await client.query(`DELETE FROM cabs.circuit_report WHERE snapshot_id = $1`, [snapshotId]);
    if (!meta.rowCount) {
      await client.query("COMMIT");
      return 0;
    }

    const allMonths = [...new Set<string>(monthly.rows.map((r) => r.m as string))].sort();
    const completeMonths = truncated ? allMonths.filter((m) => m !== truncated) : allMonths;
    const amounts = new Map<string, Record<string, number | null>>();
    for (const r of monthly.rows) {
      const key = `${r.co_number}\u0000${r.ec_circuit}`;
      let rec = amounts.get(key);
      if (!rec) amounts.set(key, (rec = {}));
      rec[r.m] = toNum(r.amt);
    }
    const bdtByBan = new Map(bdt.rows.map((r) => [r.ban as string, r]));
    const agingByBan = new Map(aging.rows.map((r) => [r.ban as string, r]));
    const lastComplete = completeMonths.length ? completeMonths[completeMonths.length - 1] : null;

    const COLS = ["co_number", "ec_circuit", "ixc_name", "cust", "ban", "monthly_amounts", "first_month", "last_month",
      "latest_month_amount", "status", "cardname", "bdt_comment", "paper_comment", "is_critical", "aging_current", "aging_30",
      "aging_60", "aging_90", "aging_120", "aging_150", "aging_180", "aging_270", "aging_1_2yr", "aging_over_2yr", "aging_total",
      "aging_past_due", "num_invoices"];

    const rows: unknown[][] = meta.rows.map((m) => {
      const byMonth = amounts.get(`${m.co_number}\u0000${m.ec_circuit}`) ?? {};
      const present = completeMonths.filter((mo) => byMonth[mo] !== null && byMonth[mo] !== undefined);
      let status = "no data";
      let first: string | null = null;
      let last: string | null = null;
      if (present.length) {
        first = present[0];
        last = present[present.length - 1];
        if (last === lastComplete) status = first === completeMonths[0] ? "Active (present all months)" : `New in ${first}`;
        else status = `Dropped after ${last}`;
      }
      const monthly: Record<string, number | null> = {};
      for (const mo of allMonths) monthly[mo] = byMonth[mo] ?? null;
      const b = m.ban ? bdtByBan.get(m.ban) : undefined;
      const a = m.ban ? agingByBan.get(m.ban) : undefined;
      return [m.co_number, m.ec_circuit, m.ixc_name, m.cust, m.ban, JSON.stringify(monthly), first, last,
        lastComplete ? (byMonth[lastComplete] ?? null) : null, status,
        b?.cardname ?? null, b?.bdt_comment ?? null, b?.paper_comment ?? null, b?.is_critical ?? false,
        toNum(a?.aging_current), toNum(a?.aging_30), toNum(a?.aging_60), toNum(a?.aging_90), toNum(a?.aging_120), toNum(a?.aging_150),
        toNum(a?.aging_180), toNum(a?.aging_270), toNum(a?.aging_1_2yr), toNum(a?.aging_over_2yr), toNum(a?.aging_total),
        toNum(a?.aging_past_due), a ? Number(a.num_invoices) : null];
    });

    const CHUNK = 500;
    for (let i = 0; i < rows.length; i += CHUNK) {
      await insertRows(client, snapshotId, "cabs.circuit_report", COLS, rows.slice(i, i + CHUNK));
    }
    await client.query("COMMIT");
    return rows.length;
  } catch (e) {
    await client.query("ROLLBACK").catch(() => undefined);
    throw e;
  } finally {
    client.release();
  }
};
