import fs from "fs";
import { parse } from "csv-parse";
import { readSheetRows, CellValue, excelSerialToIso } from "./xlsxStream";

/**
 * Readers for the four CABS source files. Each reads its file as a stream and hands rows to `onBatch`, so memory
 * stays flat however many rows the export holds. The rules follow the original Python loader.
 */

export const BILLING_BATCH = 2000;

// Values pandas treats as "missing" when it reads a file; kept so the same cells become NULL as before.
const NA_VALUES = new Set(["", "#N/A", "#N/A N/A", "#NA", "-1.#IND", "-1.#QNAN", "-NaN", "-nan", "1.#IND", "1.#QNAN",
  "<NA>", "N/A", "NA", "NULL", "NaN", "None", "n/a", "nan", "null"]);

// Mainframe exports pad some fields with NUL bytes (e.g. "6102\0\0AF01\0"); Postgres text cannot hold them, and they
// stand for padding, so they become spaces.
const noNul = (s: string): string => (s.includes("\u0000") ? s.replace(/\u0000/g, " ") : s);

const text = (v: CellValue | undefined): string | null => {
  if (v === null || v === undefined) return null;
  const s = noNul(typeof v === "string" ? v : String(v));
  return NA_VALUES.has(s) ? null : s;
};

const pad4 = (v: CellValue | undefined): string | null => {
  const s = text(v);
  return s === null ? null : s.trim().padStart(4, "0");
};

const num = (v: CellValue | undefined): number | null => {
  if (typeof v === "number") return Number.isFinite(v) ? v : null;
  if (typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v))) return Number(v);
  return null;
};

const isoDate = (v: CellValue | undefined): string | null => {
  if (v === null || v === undefined) return null;
  if (typeof v === "number") return excelSerialToIso(v);
  const s = String(v).trim();
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
  const us = /^(\d{1,2})\/(\d{1,2})\/(\d{4})/.exec(s);
  if (us) return `${us[3]}-${us[1].padStart(2, "0")}-${us[2].padStart(2, "0")}`;
  return null;
};

export class CabsFileError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CabsFileError";
  }
}

// ---------------------------------------------------------------- billing detail

export const BILLING_COLUMNS = ["co_number", "ixc", "ixc_name", "ban", "bill_date", "ec_circuit", "bdw", "eo_info", "pop_key",
  "cust", "z_clli_address", "z_clli_st", "z_clli_city", "z_clli_zip", "pop", "nc", "cos", "usoc", "amount"] as const;
export type BillingRow = (string | number | null)[];

const FOOTER = /No filters applied|exceeded the allowed volume/i;

/**
 * Sheet "Export". The export tool appends a blank row and warning lines ("No filters applied", "exceeded the allowed
 * volume") at the very end; only the last 10 rows are checked for them, as before. When a footer is found the latest
 * bill month is reported as truncated (the export stopped part-way through it).
 */
export const parseBillingDetail = async (
  file: string,
  onBatch: (rows: BillingRow[]) => Promise<void>,
): Promise<{ rowCount: number; truncatedMonth: string | null }> => {
  const TAIL = 10;
  const pending: CellValue[][] = [];
  let batch: BillingRow[] = [];
  let rowCount = 0;
  let maxDate: string | null = null;
  let header = true;

  const toRow = (raw: CellValue[]): BillingRow => {
    const get = (i: number) => raw[i];
    const date = isoDate(get(4));
    if (date && (maxDate === null || date > maxDate)) maxDate = date;
    return [pad4(get(0)), text(get(1)), text(get(2)), text(get(3)), date, text(get(5)), text(get(6)), text(get(7)),
      text(get(8)), text(get(9)), text(get(10)), text(get(11)), text(get(12)), text(get(13)), text(get(14)),
      text(get(15)), text(get(16)), text(get(17)), num(get(18))];
  };
  const accept = async (raw: CellValue[]) => {
    batch.push(toRow(raw));
    rowCount++;
    if (batch.length >= BILLING_BATCH) {
      const full = batch;
      batch = [];
      await onBatch(full);
    }
  };

  for await (const raw of readSheetRows(file, "Export")) {
    if (header) {
      header = false;
      if (raw.filter((c) => c !== null).length < BILLING_COLUMNS.length) {
        throw new CabsFileError(`The billing detail file needs ${BILLING_COLUMNS.length} columns on the "Export" sheet; it has ${raw.filter((c) => c !== null).length}`);
      }
      continue;
    }
    pending.push(raw);
    if (pending.length > TAIL) await accept(pending.shift()!);
  }
  const footerAt = pending.findIndex((r) => text(r[0]) === null || FOOTER.test(String(r[0])));
  const kept = footerAt >= 0 ? pending.slice(0, footerAt) : pending;
  for (const raw of kept) await accept(raw);
  if (batch.length) await onBatch(batch);
  const truncatedMonth = footerAt >= 0 && maxDate ? (maxDate as string).slice(0, 7) : null;
  return { rowCount, truncatedMonth };
};

// ---------------------------------------------------------------- aging

const AGING_COLUMNS = ["CARRIER GROUP", "CARRIER", "CO", "IXC", "FG", "BAN", "INVOICE", "INV DATE", "CURRENT", "30 DAYS",
  "60 DAYS", "90 DAYS", "120 DAYS", "150 DAYS", "180 DAYS", "270 DAYS", "1-2 YEARS", "OVER 2 YEARS", "TOTAL", "PAST DUE"];
export type AgingRow = (string | number | null)[];

/** INV DATE arrives as a number like 20260901 (or, in other exports, as a date). */
const invDate = (v: CellValue | undefined): string | null => {
  if (typeof v === "number") {
    if (Number.isInteger(v) && v >= 19000101 && v <= 21001231) {
      const s = String(v);
      return `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}`;
    }
    return excelSerialToIso(v);
  }
  if (typeof v === "string" && /^\d{8}$/.test(v.trim())) {
    const s = v.trim();
    return `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}`;
  }
  return isoDate(v);
};

/** Sheet "Report": one row per invoice, columns found by their header names. */
export const parseAging = async (file: string, onBatch: (rows: AgingRow[]) => Promise<void>): Promise<{ rowCount: number }> => {
  let index: Map<string, number> | null = null;
  let batch: AgingRow[] = [];
  let rowCount = 0;
  let line = 0;
  for await (const raw of readSheetRows(file, "Report")) {
    line++;
    if (!index) {
      index = new Map();
      raw.forEach((h, i) => {
        const name = typeof h === "string" ? h.trim() : null;
        if (name && !index!.has(name)) index!.set(name, i);
      });
      const missing = AGING_COLUMNS.filter((c) => !index!.has(c));
      if (missing.length) throw new CabsFileError(`The aging file's "Report" sheet is missing column(s): ${missing.join(", ")}`);
      continue;
    }
    if (raw.every((c) => c === null || c === "")) continue;
    const at = (name: string) => raw[index!.get(name)!];
    const invoice = num(at("INVOICE"));
    if (invoice === null) throw new CabsFileError(`Aging file, row ${line}: INVOICE is missing`);
    batch.push([text(at("CARRIER GROUP")), text(at("CARRIER")), pad4(at("CO")), text(at("IXC")), text(at("FG")), text(at("BAN")),
      Math.trunc(invoice), invDate(at("INV DATE")), num(at("CURRENT")), num(at("30 DAYS")), num(at("60 DAYS")), num(at("90 DAYS")),
      num(at("120 DAYS")), num(at("150 DAYS")), num(at("180 DAYS")), num(at("270 DAYS")), num(at("1-2 YEARS")),
      num(at("OVER 2 YEARS")), num(at("TOTAL")), num(at("PAST DUE"))]);
    rowCount++;
    if (batch.length >= BILLING_BATCH) {
      const full = batch;
      batch = [];
      await onBatch(full);
    }
  }
  if (!index) throw new CabsFileError(`The aging file's "Report" sheet is empty`);
  if (batch.length) await onBatch(batch);
  return { rowCount };
};

// ---------------------------------------------------------------- BDT config (CSV)

async function* csvRecords(file: string): AsyncGenerator<string[]> {
  const parser = fs.createReadStream(file).pipe(parse({ bom: true, relax_column_count: true, relax_quotes: true, skip_empty_lines: true }));
  for await (const record of parser) yield record as string[];
}

const csvText = (v: string | undefined): string | null => {
  if (v === undefined) return null;
  const raw = noNul(v);
  if (NA_VALUES.has(raw)) return null; // a truly empty field
  const s = raw.trim(); // a field of only spaces stays an empty string, as before
  return s === "nan" ? null : s;
};

export type BdtRow = (string | boolean | null)[];

/**
 * ARPCRPT.CSV: one row per BAN. The header spans two lines (the second is sub-captions and is skipped);
 * columns are read by position.
 */
export const parseBdtConfig = async (file: string, onBatch: (rows: BdtRow[]) => Promise<void>): Promise<{ rowCount: number }> => {
  let batch: BdtRow[] = [];
  let rowCount = 0;
  let line = 0;
  for await (const rec of csvRecords(file)) {
    line++;
    if (line === 1) {
      if (rec.length < 15) throw new CabsFileError(`The BDT config file needs 15 columns; this one has ${rec.length}`);
      continue;
    }
    if (line === 2) continue;
    const co = csvText(rec[1]);
    batch.push([csvText(rec[0]), co === null ? null : co.padStart(4, "0"), csvText(rec[2]), csvText(rec[3]), csvText(rec[4]),
      csvText(rec[5]), csvText(rec[6]), csvText(rec[7]), csvText(rec[8]), csvText(rec[9]), csvText(rec[10]), csvText(rec[11]),
      csvText(rec[12]), csvText(rec[13]) === "CRITICAL", csvText(rec[14])]);
    rowCount++;
    if (batch.length >= BILLING_BATCH) {
      const full = batch;
      batch = [];
      await onBatch(full);
    }
  }
  if (line === 0) throw new CabsFileError("The BDT config file is empty");
  if (batch.length) await onBatch(batch);
  return { rowCount };
};

/** ARPCRPT-1.CSV (small companies): CO, CYCLE, IXC, BALFG, BILL PRINT, COMMENT. */
export const parseBdtConfigSmall = async (file: string, onBatch: (rows: (string | null)[][]) => Promise<void>): Promise<{ rowCount: number }> => {
  let batch: (string | null)[][] = [];
  let rowCount = 0;
  let line = 0;
  for await (const rec of csvRecords(file)) {
    line++;
    if (line === 1) {
      if (rec.length < 6) throw new CabsFileError(`The small-company BDT file needs at least 6 columns; this one has ${rec.length}`);
      continue;
    }
    const co = csvText(rec[0]);
    batch.push([co === null ? null : co.padStart(4, "0"), csvText(rec[1]), csvText(rec[2]), csvText(rec[3]), csvText(rec[4]), csvText(rec[5])]);
    rowCount++;
  }
  if (line === 0) throw new CabsFileError("The small-company BDT file is empty");
  if (batch.length) await onBatch(batch);
  return { rowCount };
};
