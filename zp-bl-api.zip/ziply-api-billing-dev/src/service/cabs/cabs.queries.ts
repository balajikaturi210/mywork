import zbpPool from "../../config/zbpDb";
import { CabsFilters } from "../../types/cabs.types";

export const BDT_STATUSES = ["BDTCARD found", "BDTCARD not found", "BDTCARD not foune"];

const SORTS: Record<string, string> = {
  past_due: "aging_past_due",
  outstanding: "aging_total",
  latest_amount: "latest_month_amount",
  circuit: "ec_circuit",
  ban: "ban",
};

const BUCKETS: Record<string, string> = {
  "90": "aging_90",
  "180": "aging_180",
  "270": "aging_270",
  "1_2yr": "aging_1_2yr",
  over_2yr: "aging_over_2yr",
};

const SNAPSHOT_COLUMNS = `id, label, to_char(uploaded_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS uploaded_at, billing_file_name,
  aging_file_name, bdt_file_name, bdt_small_file_name, billing_truncated_month, row_counts, status, stage, error_message,
  to_char(finished_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS finished_at`;

export const listSnapshots = async () =>
  (await zbpPool.query(`SELECT ${SNAPSHOT_COLUMNS} FROM cabs.snapshots ORDER BY uploaded_at DESC`)).rows;

export const getSnapshot = async (id: number) =>
  (await zbpPool.query(`SELECT ${SNAPSHOT_COLUMNS} FROM cabs.snapshots WHERE id = $1`, [id])).rows[0] ?? null;

/** The snapshot a request means: the one asked for, else the latest one that finished loading. */
export const resolveSnapshotId = async (requested?: number): Promise<number | null> => {
  if (requested) return requested;
  const r = await zbpPool.query(`SELECT id FROM cabs.snapshots WHERE status = 'READY' ORDER BY uploaded_at DESC LIMIT 1`);
  return r.rows[0]?.id ?? null;
};

class Where {
  clauses: string[] = [];
  params: unknown[] = [];
  constructor(snapshotId: number) {
    this.params.push(snapshotId);
    this.clauses.push("snapshot_id = $1");
  }
  add(sql: string, ...values: unknown[]) {
    let text = sql;
    for (const v of values) {
      this.params.push(v);
      text = text.replace("?", `$${this.params.length}`);
    }
    this.clauses.push(text);
  }
  get sql() {
    return this.clauses.join(" AND ");
  }
  get filtered() {
    return this.clauses.length > 1;
  }
}

const bdtClause = (w: Where, bdtStatus?: string) => {
  if (bdtStatus === "none") w.add("bdt_comment IS NULL");
  else if (bdtStatus && BDT_STATUSES.includes(bdtStatus)) w.add("bdt_comment = ?", bdtStatus);
};

const applyFilters = (w: Where, f: CabsFilters) => {
  if (f.co) w.add("co_number = ?", f.co);
  if (f.ixc) w.add("ixc_name = ?", f.ixc);
  if (f.ban) w.add("ban ILIKE ?", `%${f.ban}%`);
  if (f.status === "active") w.add("status = 'Active (present all months)'");
  else if (f.status === "dropped") w.add("status LIKE 'Dropped%'");
  else if (f.status === "new") w.add("status LIKE 'New%'");
  if (f.critical === "true") w.add("is_critical = true");
  else if (f.critical === "false") w.add("is_critical = false");
  bdtClause(w, f.bdt_status);
  if (f.min_past_due !== undefined && Number.isFinite(f.min_past_due)) w.add("aging_past_due >= ?", f.min_past_due);
  const bucket = f.aging_bucket ? BUCKETS[f.aging_bucket] : undefined;
  if (bucket) w.add(`${bucket} > 0`);
  if (f.search) {
    const like = `%${f.search}%`;
    w.add("(ec_circuit ILIKE ? OR ban ILIKE ? OR cust ILIKE ?)", like, like, like);
  }
};

const numify = (row: Record<string, unknown>, skip: string[] = []) => {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(row)) {
    out[k] = typeof v === "string" && !skip.includes(k) && /^-?\d+(\.\d+)?$/.test(v) && NUMERIC_KEYS.has(k) ? Number(v) : v;
  }
  return out;
};

const NUMERIC_KEYS = new Set(["latest_month_amount", "aging_current", "aging_30", "aging_60", "aging_90", "aging_120", "aging_150",
  "aging_180", "aging_270", "aging_1_2yr", "aging_over_2yr", "aging_total", "aging_past_due", "amount"]);

const allNum = (row: Record<string, unknown>) =>
  Object.fromEntries(Object.entries(row).map(([k, v]) => [k, v === null || v === undefined ? 0 : Number(v)]));

export const getSummary = async (snapshotId: number, filters: CabsFilters) => {
  const w = new Where(snapshotId);
  applyFilters(w, filters);

  const circuit = (await zbpPool.query(
    `SELECT COUNT(*) AS total_circuits,
            SUM(CASE WHEN status = 'Active (present all months)' THEN 1 ELSE 0 END) AS active_circuits,
            SUM(CASE WHEN status LIKE 'Dropped%' THEN 1 ELSE 0 END) AS dropped_circuits,
            SUM(CASE WHEN status LIKE 'New%' THEN 1 ELSE 0 END) AS new_circuits,
            SUM(CASE WHEN is_critical THEN 1 ELSE 0 END) AS critical_circuits,
            SUM(latest_month_amount) AS latest_month_billed
       FROM cabs.circuit_report WHERE ${w.sql}`,
    w.params,
  )).rows[0];

  // Aging and BDT dollars belong to the BAN, and every circuit of a BAN carries them, so count each BAN once.
  const aging = (await zbpPool.query(
    `SELECT COUNT(*) AS distinct_bans, SUM(aging_total) AS total_outstanding, SUM(aging_past_due) AS total_past_due,
            SUM(aging_current) AS total_current, SUM(aging_30) AS total_30, SUM(aging_60) AS total_60, SUM(aging_90) AS total_90,
            SUM(aging_120) AS total_120, SUM(aging_150) AS total_150, SUM(aging_180) AS total_180, SUM(aging_270) AS total_270,
            SUM(aging_1_2yr) AS total_1_2yr, SUM(aging_over_2yr) AS total_over_2yr
       FROM (SELECT DISTINCT ON (ban) ban, aging_total, aging_past_due, aging_current, aging_30, aging_60, aging_90, aging_120,
                    aging_150, aging_180, aging_270, aging_1_2yr, aging_over_2yr
               FROM cabs.circuit_report WHERE ${w.sql} AND ban IS NOT NULL) d`,
    w.params,
  )).rows[0];

  const bdtBreakdown = (await zbpPool.query(
    `SELECT bdt_comment, COUNT(*)::int AS bans
       FROM (SELECT DISTINCT ON (ban) ban, bdt_comment FROM cabs.circuit_report WHERE ${w.sql} AND ban IS NOT NULL) d
      GROUP BY bdt_comment`,
    w.params,
  )).rows;

  // CABS ages receivables per BAN, so "invoices unpaid a long time" means the invoices of BANs with a matching circuit.
  const bans = (await zbpPool.query(`SELECT DISTINCT ban FROM cabs.circuit_report WHERE ${w.sql} AND ban IS NOT NULL`, w.params)).rows.map((r) => r.ban);
  const invoiceKeys = ["total_invoices", "invoices_over_2yr", "invoices_1_2yr", "invoices_270d", "invoices_180d", "invoices_past_due",
    "dollars_over_2yr", "dollars_1_2yr"];
  const invoices = bans.length
    ? (await zbpPool.query(
        `SELECT COUNT(*) AS total_invoices,
                SUM(CASE WHEN over_2_years > 0 THEN 1 ELSE 0 END) AS invoices_over_2yr,
                SUM(CASE WHEN years_1_2 > 0 THEN 1 ELSE 0 END) AS invoices_1_2yr,
                SUM(CASE WHEN days_270 > 0 THEN 1 ELSE 0 END) AS invoices_270d,
                SUM(CASE WHEN days_180 > 0 THEN 1 ELSE 0 END) AS invoices_180d,
                SUM(CASE WHEN past_due > 0 THEN 1 ELSE 0 END) AS invoices_past_due,
                SUM(over_2_years) AS dollars_over_2yr, SUM(years_1_2) AS dollars_1_2yr
           FROM cabs.aging WHERE snapshot_id = $1 AND ban = ANY($2)`,
        [snapshotId, bans],
      )).rows[0]
    : Object.fromEntries(invoiceKeys.map((k) => [k, 0]));

  return {
    snapshot: await getSnapshot(snapshotId),
    filtered: w.filtered,
    circuit_summary: allNum(circuit),
    aging_summary: allNum(aging),
    bdt_breakdown: bdtBreakdown,
    invoice_summary: allNum(invoices),
  };
};

const DETAIL_COLUMNS = `co_number, ec_circuit, ixc_name, cust, ban, status, cardname, bdt_comment, paper_comment, is_critical,
  latest_month_amount, aging_current, aging_30, aging_60, aging_90, aging_120, aging_150, aging_180, aging_270, aging_1_2yr,
  aging_over_2yr, aging_total, aging_past_due, num_invoices`;

export const getDetails = async (snapshotId: number, filters: CabsFilters, page: number, pageSize: number, sort?: string, dir?: string) => {
  const w = new Where(snapshotId);
  applyFilters(w, filters);
  const safePage = Math.max(page || 1, 1);
  const safeSize = Math.min(Math.max(pageSize || 100, 1), 1000);
  const sortKey = (sort && SORTS[sort]) || "aging_past_due";
  const direction = dir === "asc" ? "ASC" : "DESC";

  const total = Number((await zbpPool.query(`SELECT COUNT(*) AS n FROM cabs.circuit_report WHERE ${w.sql}`, w.params)).rows[0].n);
  const limitParams = [...w.params, safeSize, (safePage - 1) * safeSize];
  const rows = (await zbpPool.query(
    `SELECT ${DETAIL_COLUMNS}, monthly_amounts FROM cabs.circuit_report WHERE ${w.sql}
      ORDER BY ${sortKey} ${direction} NULLS LAST, co_number, ec_circuit LIMIT $${w.params.length + 1} OFFSET $${w.params.length + 2}`,
    limitParams,
  )).rows.map((r) => numify(r));
  return { total, page: safePage, page_size: safeSize, rows };
};

const CSV_FIELDS = DETAIL_COLUMNS.split(",").map((s) => s.trim());

const csvCell = (v: unknown): string => {
  if (v === null || v === undefined) return "";
  if (typeof v === "boolean") return v ? "True" : "False"; // the same text the original report exported
  const s = String(v);
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

export const exportDetailsCsv = async (snapshotId: number, filters: CabsFilters): Promise<string> => {
  const w = new Where(snapshotId);
  applyFilters(w, filters);
  const rows = (await zbpPool.query(
    `SELECT ${DETAIL_COLUMNS} FROM cabs.circuit_report WHERE ${w.sql} ORDER BY aging_past_due DESC NULLS LAST, co_number, ec_circuit`,
    w.params,
  )).rows;
  const lines = [CSV_FIELDS.join(",")];
  for (const r of rows) lines.push(CSV_FIELDS.map((f) => csvCell(r[f])).join(","));
  return lines.join("\r\n") + "\r\n";
};

/** Each dimension's list is scoped by the other filters but never by its own current value, so it can still be changed. */
export const getFilterOptions = async (snapshotId: number, f: Pick<CabsFilters, "co" | "ixc" | "bdt_status" | "ban">) => {
  const q = async (w: Where, sql: string) => (await zbpPool.query(sql.replace("{where}", w.sql), w.params)).rows;

  let w = new Where(snapshotId);
  if (f.ixc) w.add("ixc_name = ?", f.ixc);
  bdtClause(w, f.bdt_status);
  if (f.ban) w.add("ban ILIKE ?", `%${f.ban}%`);
  const co = (await q(w, `SELECT DISTINCT co_number FROM cabs.circuit_report WHERE {where} ORDER BY co_number`)).map((r) => r.co_number);

  w = new Where(snapshotId);
  if (f.co) w.add("co_number = ?", f.co);
  bdtClause(w, f.bdt_status);
  if (f.ban) w.add("ban ILIKE ?", `%${f.ban}%`);
  const ixc = (await q(w, `SELECT ixc_name, COUNT(*) AS n FROM cabs.circuit_report WHERE {where} GROUP BY ixc_name ORDER BY n DESC, ixc_name LIMIT 50`)).map((r) => r.ixc_name);

  w = new Where(snapshotId);
  if (f.co) w.add("co_number = ?", f.co);
  if (f.ixc) w.add("ixc_name = ?", f.ixc);
  if (f.ban) w.add("ban ILIKE ?", `%${f.ban}%`);
  const bdt = (await q(w, `SELECT bdt_comment, COUNT(*)::int AS n FROM cabs.circuit_report WHERE {where} GROUP BY bdt_comment ORDER BY n DESC, bdt_comment`))
    .map((r) => ({ value: r.bdt_comment ?? "none", count: r.n }));

  w = new Where(snapshotId);
  w.add("ban IS NOT NULL");
  if (f.co) w.add("co_number = ?", f.co);
  if (f.ixc) w.add("ixc_name = ?", f.ixc);
  bdtClause(w, f.bdt_status);
  const ban = (await q(w, `SELECT DISTINCT ban FROM cabs.circuit_report WHERE {where} ORDER BY ban LIMIT 500`)).map((r) => r.ban);

  return { co, ixc, bdt_status: bdt, ban };
};

/** Service-level (USOC) lines of one circuit, which the circuit report collapses into a single monthly total. */
export const getCircuitUsoc = async (snapshotId: number, co: string, circuit: string) => {
  const rows = (await zbpPool.query(
    `SELECT usoc, nc, cos, bdw, eo_info, pop_key, to_char(bill_date, 'YYYY-MM') AS m, amount
       FROM cabs.billing_detail WHERE snapshot_id = $1 AND co_number = $2 AND ec_circuit = $3 ORDER BY usoc, bill_date`,
    [snapshotId, co, circuit],
  )).rows;
  const months = [...new Set<string>(rows.filter((r) => r.m).map((r) => r.m as string))].sort();
  const lines = new Map<string, { usoc: string | null; nc: string | null; cos: string | null; bdw: string | null; eo_info: string | null;
    pop_key: string | null; amounts: Record<string, number | null>; total: number }>();
  for (const r of rows) {
    const key = JSON.stringify([r.usoc, r.nc, r.cos, r.bdw, r.eo_info, r.pop_key]);
    let line = lines.get(key);
    if (!line) {
      line = { usoc: r.usoc, nc: r.nc, cos: r.cos, bdw: r.bdw, eo_info: r.eo_info, pop_key: r.pop_key,
        amounts: Object.fromEntries(months.map((m) => [m, null])), total: 0 };
      lines.set(key, line);
    }
    const amount = r.amount === null ? 0 : Number(r.amount);
    if (r.m) line.amounts[r.m] = amount;
    line.total += amount;
  }
  return { co, circuit, months, usoc_lines: [...lines.values()].sort((a, b) => (a.usoc ?? "").localeCompare(b.usoc ?? "")) };
};
