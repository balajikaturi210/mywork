import zbpPool from "../../config/zbpDb";
import logger from "../../logger/logger";

/**
 * Schema `cabs` in the payments database: the four raw CABS files of a snapshot plus the derived circuit report.
 * Idempotent, runs at start-up. Deleting a snapshot removes its rows from every table (ON DELETE CASCADE).
 */
const DDL = [
  `CREATE SCHEMA IF NOT EXISTS cabs`,
  `CREATE TABLE IF NOT EXISTS cabs.snapshots (
      id SERIAL PRIMARY KEY,
      label TEXT,
      uploaded_at TIMESTAMPTZ DEFAULT now(),
      billing_file_name TEXT,
      aging_file_name TEXT,
      bdt_file_name TEXT,
      bdt_small_file_name TEXT,
      billing_truncated_month TEXT,
      row_counts JSONB,
      status TEXT NOT NULL DEFAULT 'PROCESSING',
      stage TEXT,
      error_message TEXT,
      finished_at TIMESTAMPTZ,
      last_activity_at TIMESTAMPTZ DEFAULT now(),
      uploaded_by TEXT
  )`,
  `ALTER TABLE cabs.snapshots ADD COLUMN IF NOT EXISTS last_activity_at TIMESTAMPTZ DEFAULT now()`,
  `CREATE TABLE IF NOT EXISTS cabs.billing_detail (
      id SERIAL PRIMARY KEY,
      snapshot_id INTEGER NOT NULL REFERENCES cabs.snapshots(id) ON DELETE CASCADE,
      co_number TEXT, ixc TEXT, ixc_name TEXT, ban TEXT, bill_date DATE, ec_circuit TEXT, bdw TEXT, eo_info TEXT,
      pop_key TEXT, cust TEXT, z_clli_address TEXT, z_clli_st TEXT, z_clli_city TEXT, z_clli_zip TEXT, pop TEXT,
      nc TEXT, cos TEXT, usoc TEXT, amount NUMERIC(14,2)
  )`,
  `CREATE TABLE IF NOT EXISTS cabs.aging (
      id SERIAL PRIMARY KEY,
      snapshot_id INTEGER NOT NULL REFERENCES cabs.snapshots(id) ON DELETE CASCADE,
      carrier_group TEXT, carrier TEXT, co_number TEXT, ixc TEXT, fg TEXT, ban TEXT, invoice BIGINT, inv_date DATE,
      current_amt NUMERIC(14,2), days_30 NUMERIC(14,2), days_60 NUMERIC(14,2), days_90 NUMERIC(14,2),
      days_120 NUMERIC(14,2), days_150 NUMERIC(14,2), days_180 NUMERIC(14,2), days_270 NUMERIC(14,2),
      years_1_2 NUMERIC(14,2), over_2_years NUMERIC(14,2), total_amt NUMERIC(14,2), past_due NUMERIC(14,2),
      UNIQUE (snapshot_id, co_number, ban, invoice)
  )`,
  `CREATE TABLE IF NOT EXISTS cabs.bdt_config (
      id SERIAL PRIMARY KEY,
      snapshot_id INTEGER NOT NULL REFERENCES cabs.snapshots(id) ON DELETE CASCADE,
      ban TEXT, co_number TEXT, cycle TEXT, ixc TEXT, balfg TEXT, bdt_sw_1 TEXT, csr_sw_1 TEXT, bdt_sw_2 TEXT,
      csr_sw_2 TEXT, aadr_key TEXT, cardname TEXT, paper_comment TEXT, bdt_comment TEXT, is_critical BOOLEAN, amount TEXT,
      UNIQUE (snapshot_id, ban)
  )`,
  `CREATE TABLE IF NOT EXISTS cabs.bdt_config_small_co (
      id SERIAL PRIMARY KEY,
      snapshot_id INTEGER NOT NULL REFERENCES cabs.snapshots(id) ON DELETE CASCADE,
      co_number TEXT, cycle TEXT, ixc TEXT, balfg TEXT, bill_print TEXT, comment TEXT
  )`,
  `CREATE TABLE IF NOT EXISTS cabs.circuit_report (
      id SERIAL PRIMARY KEY,
      snapshot_id INTEGER NOT NULL REFERENCES cabs.snapshots(id) ON DELETE CASCADE,
      co_number TEXT, ec_circuit TEXT, ixc_name TEXT, cust TEXT, ban TEXT, monthly_amounts JSONB, first_month TEXT,
      last_month TEXT, latest_month_amount NUMERIC(14,2), status TEXT, cardname TEXT, bdt_comment TEXT,
      paper_comment TEXT, is_critical BOOLEAN, aging_current NUMERIC(14,2), aging_30 NUMERIC(14,2),
      aging_60 NUMERIC(14,2), aging_90 NUMERIC(14,2), aging_120 NUMERIC(14,2), aging_150 NUMERIC(14,2),
      aging_180 NUMERIC(14,2), aging_270 NUMERIC(14,2), aging_1_2yr NUMERIC(14,2), aging_over_2yr NUMERIC(14,2),
      aging_total NUMERIC(14,2), aging_past_due NUMERIC(14,2), num_invoices INTEGER
  )`,
  `CREATE INDEX IF NOT EXISTS idx_cabs_bd_snap ON cabs.billing_detail (snapshot_id)`,
  `CREATE INDEX IF NOT EXISTS idx_cabs_bd_circuit ON cabs.billing_detail (snapshot_id, co_number, ec_circuit)`,
  `CREATE INDEX IF NOT EXISTS idx_cabs_bd_co_ban ON cabs.billing_detail (snapshot_id, co_number, ban)`,
  `CREATE INDEX IF NOT EXISTS idx_cabs_ag_snap ON cabs.aging (snapshot_id)`,
  `CREATE INDEX IF NOT EXISTS idx_cabs_ag_ban ON cabs.aging (snapshot_id, ban)`,
  `CREATE INDEX IF NOT EXISTS idx_cabs_bc_snap ON cabs.bdt_config (snapshot_id)`,
  `CREATE INDEX IF NOT EXISTS idx_cabs_cr_snap ON cabs.circuit_report (snapshot_id)`,
  `CREATE INDEX IF NOT EXISTS idx_cabs_cr_co ON cabs.circuit_report (snapshot_id, co_number)`,
  `CREATE INDEX IF NOT EXISTS idx_cabs_cr_ixc ON cabs.circuit_report (snapshot_id, ixc_name)`,
  `CREATE INDEX IF NOT EXISTS idx_cabs_cr_status ON cabs.circuit_report (snapshot_id, status)`,
  `CREATE INDEX IF NOT EXISTS idx_cabs_cr_critical ON cabs.circuit_report (snapshot_id, is_critical)`,
  `CREATE INDEX IF NOT EXISTS idx_cabs_cr_pastdue ON cabs.circuit_report (snapshot_id, aging_past_due)`,
];

export const initCabsSchema = async (): Promise<void> => {
  if (String(process.env.CABS_SCHEMA_INIT ?? "true").toLowerCase() === "false") {
    logger.info({ message: "CABS schema initialisation disabled (CABS_SCHEMA_INIT=false)" });
    return;
  }
  try {
    for (const statement of DDL) await zbpPool.query(statement);
    logger.info({ message: "CABS schema ready" });
  } catch (err) {
    // The rest of the API must keep working; the CABS endpoints fail visibly instead.
    logger.error({ message: `CABS schema initialisation failed: ${err instanceof Error ? err.message : String(err)}` });
  }
};
