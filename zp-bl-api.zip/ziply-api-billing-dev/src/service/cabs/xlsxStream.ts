import yauzl from "yauzl";
import sax from "sax";
import { StringDecoder } from "string_decoder";
import type { Readable } from "stream";

/**
 * Minimal streaming .xlsx reader. The CABS exports can hold 150,000+ rows (136 MB of XML), which a workbook loader
 * would hold in memory; this reads one sheet row by row. It copes with files that use prefixed XML tags (x:row),
 * inline strings, cells without references and empty rows, as well as ordinary Excel files with shared strings.
 */
export type CellValue = string | number | boolean | null;

const localName = (name: string): string => {
  const i = name.indexOf(":");
  return i >= 0 ? name.slice(i + 1) : name;
};

const attr = (tag: string, name: string): string | undefined => {
  const m = new RegExp(`(?:^|\\s)(?:\\w+:)?${name}="([^"]*)"`).exec(tag);
  return m ? decodeXml(m[1]) : undefined;
};

const decodeXml = (s: string): string =>
  s.replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&");

type ZipEntries = { zip: yauzl.ZipFile; entries: Map<string, yauzl.Entry> };

const openZip = (file: string): Promise<ZipEntries> =>
  new Promise((resolve, reject) => {
    yauzl.open(file, { lazyEntries: true, autoClose: false }, (err, zip) => {
      if (err || !zip) {
        reject(err ?? new Error("Could not open file"));
        return;
      }
      const entries = new Map<string, yauzl.Entry>();
      zip.on("entry", (entry: yauzl.Entry) => {
        entries.set(entry.fileName, entry);
        zip.readEntry();
      });
      zip.on("end", () => resolve({ zip, entries }));
      zip.on("error", reject);
      zip.readEntry();
    });
  });

const openEntry = (z: ZipEntries, name: string): Promise<Readable> =>
  new Promise((resolve, reject) => {
    const entry = z.entries.get(name);
    if (!entry) {
      reject(new Error(`Entry ${name} not found in the xlsx file`));
      return;
    }
    z.zip.openReadStream(entry, (err, stream) => (err || !stream ? reject(err ?? new Error("Cannot read entry")) : resolve(stream)));
  });

const readEntryText = async (z: ZipEntries, name: string): Promise<string | null> => {
  if (!z.entries.has(name)) return null;
  const stream = await openEntry(z, name);
  const chunks: Buffer[] = [];
  for await (const chunk of stream) chunks.push(chunk as Buffer);
  return Buffer.concat(chunks).toString("utf8").replace(/^﻿/, "");
};

const resolveTarget = (target: string): string => {
  if (target.startsWith("/")) return target.slice(1);
  const parts = ("xl/" + target).split("/");
  const out: string[] = [];
  for (const p of parts) {
    if (p === "..") out.pop();
    else if (p !== ".") out.push(p);
  }
  return out.join("/");
};

/** Path of the named sheet inside the zip, and the sheet names that exist (for the error message). */
const findSheetPath = async (z: ZipEntries, sheetName: string): Promise<{ path: string | null; names: string[] }> => {
  const workbook = await readEntryText(z, "xl/workbook.xml");
  const rels = await readEntryText(z, "xl/_rels/workbook.xml.rels");
  if (!workbook || !rels) throw new Error("This does not look like an .xlsx workbook");
  const relTargets = new Map<string, string>();
  for (const m of rels.matchAll(/<Relationship\b[^>]*>/g)) {
    const id = attr(m[0], "Id");
    const target = attr(m[0], "Target");
    if (id && target) relTargets.set(id, target);
  }
  const names: string[] = [];
  let found: string | null = null;
  for (const m of workbook.matchAll(/<(?:\w+:)?sheet\b[^>]*>/g)) {
    const name = attr(m[0], "name");
    const rid = attr(m[0], "id");
    if (!name) continue;
    names.push(name);
    if (name === sheetName && rid && relTargets.has(rid)) found = resolveTarget(relTargets.get(rid)!);
  }
  return { path: found, names };
};

const parseSharedStrings = async (z: ZipEntries): Promise<string[]> => {
  const xml = await readEntryText(z, "xl/sharedStrings.xml");
  if (!xml) return [];
  const out: string[] = [];
  const parser = sax.parser(true);
  let inSi = false;
  let inT = false;
  let skip = 0;
  let cur = "";
  parser.onopentag = (node) => {
    const n = localName(node.name);
    if (n === "si") {
      inSi = true;
      cur = "";
    } else if (n === "rPh") skip++;
    else if (n === "t" && inSi && skip === 0) inT = true;
  };
  parser.ontext = (text) => {
    if (inT) cur += text;
  };
  parser.onclosetag = (name) => {
    const n = localName(name);
    if (n === "t") inT = false;
    else if (n === "rPh") skip--;
    else if (n === "si") {
      inSi = false;
      out.push(cur);
    }
  };
  parser.write(xml).close();
  return out;
};

const BUILTIN_DATE_FORMATS = new Set([14, 15, 16, 17, 18, 19, 20, 21, 22, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 45, 46, 47, 50, 51, 52, 53, 54, 55, 56, 57, 58]);

/** Style (cellXfs) indexes that carry a date format, so numeric cells in them can be turned into dates. */
const parseDateStyles = async (z: ZipEntries): Promise<Set<number>> => {
  const xml = await readEntryText(z, "xl/styles.xml");
  const dateStyles = new Set<number>();
  if (!xml) return dateStyles;
  const custom = new Map<number, string>();
  for (const m of xml.matchAll(/<(?:\w+:)?numFmt\b[^>]*>/g)) {
    const id = Number(attr(m[0], "numFmtId"));
    const code = attr(m[0], "formatCode");
    if (Number.isFinite(id) && code) custom.set(id, code);
  }
  const cellXfs = /<(?:\w+:)?cellXfs\b[^>]*>([\s\S]*?)<\/(?:\w+:)?cellXfs>/.exec(xml);
  if (!cellXfs) return dateStyles;
  let index = 0;
  for (const m of cellXfs[1].matchAll(/<(?:\w+:)?xf\b[^>]*?(\/?)>/g)) {
    const id = Number(attr(m[0], "numFmtId") ?? 0);
    let isDate = BUILTIN_DATE_FORMATS.has(id);
    const code = custom.get(id);
    if (code) {
      const stripped = code.replace(/"[^"]*"/g, "").replace(/\[[^\]]*\]/g, "").replace(/\\./g, "");
      isDate = /[dmyhs]/i.test(stripped) && !/^general$/i.test(stripped);
    }
    if (isDate) dateStyles.add(index);
    index++;
  }
  return dateStyles;
};

const columnIndex = (ref: string): number => {
  let n = 0;
  for (const ch of ref) {
    const c = ch.charCodeAt(0);
    if (c < 65 || c > 90) break;
    n = n * 26 + (c - 64);
  }
  return n - 1;
};

/** Excel serial date (1900 system) to YYYY-MM-DD. */
export const excelSerialToIso = (serial: number): string => {
  const ms = Math.round((serial - 25569) * 86400000);
  return new Date(ms).toISOString().slice(0, 10);
};

export class SheetNotFoundError extends Error {
  constructor(sheetName: string, names: string[]) {
    super(`Sheet "${sheetName}" was not found. This file has: ${names.length ? names.join(", ") : "no sheets"}`);
    this.name = "SheetNotFoundError";
  }
}

/** Streams the rows of one sheet. Empty cells come back as null; a row without cells is an empty array. */
export async function* readSheetRows(file: string, sheetName: string): AsyncGenerator<CellValue[]> {
  const z = await openZip(file);
  try {
    const { path, names } = await findSheetPath(z, sheetName);
    if (!path) throw new SheetNotFoundError(sheetName, names);
    const shared = await parseSharedStrings(z);
    const dateStyles = await parseDateStyles(z);
    const stream = await openEntry(z, path);

    const queue: CellValue[][] = [];
    let failure: Error | null = null;
    const parser = sax.parser(true);

    let row: CellValue[] = [];
    let nextCol = 0;
    let cellCol = 0;
    let cellType = "";
    let cellStyle = -1;
    let vText = "";
    let inlineText = "";
    let inV = false;
    let inIs = false;
    let inT = false;
    let skip = 0;

    parser.onerror = (e) => {
      failure = e;
    };
    parser.onopentag = (node) => {
      const n = localName(node.name);
      if (n === "row") {
        row = [];
        nextCol = 0;
      } else if (n === "c") {
        const ref = node.attributes["r"] as string | undefined;
        cellCol = ref ? columnIndex(ref) : nextCol;
        nextCol = cellCol + 1;
        cellType = String(node.attributes["t"] ?? "");
        cellStyle = node.attributes["s"] !== undefined ? Number(node.attributes["s"]) : -1;
        vText = "";
        inlineText = "";
      } else if (n === "v") inV = true;
      else if (n === "is") inIs = true;
      else if (n === "rPh") skip++;
      else if (n === "t" && inIs && skip === 0) inT = true;
    };
    parser.ontext = (text) => {
      if (inV) vText += text;
      else if (inT) inlineText += text;
    };
    const finishCell = () => {
      let value: CellValue = null;
      switch (cellType) {
        case "inlineStr":
          value = inlineText;
          break;
        case "s":
          value = shared[Number(vText)] ?? null;
          break;
        case "str":
          value = vText;
          break;
        case "b":
          value = vText === "1";
          break;
        case "e":
          value = null;
          break;
        case "d":
          value = vText || null;
          break;
        default: {
          if (vText === "") value = null;
          else {
            const num = Number(vText);
            value = Number.isFinite(num) ? (dateStyles.has(cellStyle) ? excelSerialToIso(num) : num) : vText;
          }
        }
      }
      while (row.length < cellCol) row.push(null);
      row[cellCol] = value;
    };
    parser.onclosetag = (name) => {
      const n = localName(name);
      if (n === "v") inV = false;
      else if (n === "t") inT = false;
      else if (n === "is") inIs = false;
      else if (n === "rPh") skip--;
      else if (n === "c") finishCell();
      else if (n === "row") queue.push(row);
    };

    const decoder = new StringDecoder("utf8");
    let first = true;
    for await (const chunk of stream) {
      let text = decoder.write(chunk as Buffer);
      if (first) {
        text = text.replace(/^﻿/, "");
        first = false;
      }
      parser.write(text);
      if (failure) throw failure;
      while (queue.length) yield queue.shift()!;
    }
    parser.close();
    if (failure) throw failure;
    while (queue.length) yield queue.shift()!;
  } finally {
    z.zip.close();
  }
}
