
import { runQuery } from "../config/snowflake";
import { CustomerJourney } from "../types/customerJourney.types";
import logger, {
  eventLog,
  categoryOpt,
  eventOpt,
  inbound,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "service/customerJourney.services";
const httpLogRes = logRes();
const inboundLog = inbound();


/**
 * Retrieves the customer journey timeline for a billing account.
 *
 * Aggregates payment transactions, payment failures, account status changes,
 * and invoice events into a single chronological timeline. The endpoint
 * validates the account number, queries Snowflake for all customer lifecycle
 * events, and returns up to 500 recent events for display in the Customer
 * Journey dashboard.
 */

export const getCustomerJourneyService = async (
  account_num: string,
  traceId?:string
): Promise<CustomerJourney[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getCustomerJourneyService";
  try {
    const sql = `
WITH acct_payments AS (
    SELECT
        p.id AS payment_id,
        p.billing_account_id,
        p.created_on,
        p.status,
        p.amount,
        p.payment_source_type,
        p.payment_method_id
    FROM payment p
    JOIN billing_account ba
      ON ba.id = p.billing_account_id
    WHERE ba.account_num = '${account_num}'
),

latest_reason AS (
    SELECT
        psh.payment_id,
        COALESCE(NULLIF(TRIM(psh.reason), ''), '') AS reason
    FROM payment_status_history psh
    JOIN acct_payments ap
      ON ap.payment_id = psh.payment_id
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY psh.payment_id
        ORDER BY psh.created_on DESC
    ) = 1
),

payments AS (
    SELECT
        ap.created_on AS "event_ts",
        CASE
            WHEN ap.status = 'PROCESSING_ERROR' THEN 'failure'
            ELSE 'payment'
        END AS "event_type",
        CASE
            WHEN ap.status = 'PROCESSING_ERROR' THEN 'Payment Failed'
            WHEN ap.status = 'COMPLETED' THEN 'Payment Completed'
            ELSE ap.status
        END AS "event_label",
        TO_CHAR(ap.amount, '$999,999.99') AS "amount",
        ap.status AS "detail1",
        COALESCE(ap.payment_source_type, '') AS "detail2",
        ap.payment_id::VARCHAR AS "ref_id",
        NULL AS "description",
        COALESCE(pm.nickname, '') AS "pay_method",
        COALESCE(pm.payment_type, '') AS "pay_method_type",
        COALESCE(lr.reason, '') AS "failure_reason"
    FROM acct_payments ap
    LEFT JOIN payment_method pm
      ON pm.id = ap.payment_method_id
    LEFT JOIN latest_reason lr
      ON lr.payment_id = ap.payment_id
),

status_changes AS (
    SELECT
        csh.created_on AS event_ts,
        'status' AS event_type,
        csh.ba_status_id AS event_label,
        NULL AS amount,
        csh.ba_status_id AS detail1,
        '' AS detail2,
        csh.id::VARCHAR AS ref_id,
        '' AS description,
        '' AS pay_method,
        '' AS pay_method_type,
        '' AS failure_reason
    FROM change_status_history csh
    JOIN billing_account ba
      ON ba.id = csh.billing_account_id
    WHERE ba.account_num = '${account_num}'
    AND csh.id_type = 'BA'
),

invoices AS (
    SELECT
        i.approved_on AS event_ts,
        'invoice' AS event_type,
        'Invoice #' || i.id::VARCHAR AS event_label,
        TO_CHAR(i.amount, '$999,999.99') AS amount,
        i.status AS detail1,
        i.type AS detail2,
        i.id::VARCHAR AS ref_id,
        '' AS description,
        '' AS pay_method,
        '' AS pay_method_type,
        '' AS failure_reason
    FROM invoice i
    WHERE i.billing_account_id = (
        SELECT id
        FROM billing_account
        WHERE account_num = '${account_num}'
        LIMIT 1
    )
)

SELECT * FROM payments
UNION ALL
SELECT * FROM status_changes
UNION ALL
SELECT * FROM invoices
ORDER BY "event_ts" DESC
LIMIT 500;
`;

    const result = await runQuery<CustomerJourney>(sql);

    return result as CustomerJourney[];
  } catch (error:any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
           "error",
           ...Object.getOwnPropertyNames(error),
         ]);
         logger.error({
           message: `Error in getCustomerJourneyService to fetch Customer Details: ${traceId} - ${error.message}`,
           event: {
             ...logEvent,
             ...categoryOpt.webProcess,
             ...eventOpt.failureError,
           },
           error: {
             message: error?.message,
             code: error?.code,
             type: error?.constructor?.name,
           },
           ...httpLogRes,
           ...inboundLog,
         });
    throw error;
  }
};
