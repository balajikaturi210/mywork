
import { runQuery } from "../config/snowflake";
import {
  DDCurrentRequest,
  DDCurrent,
  DDResolutionRow,
  DDResolutionResponse,
  DDResolutionSummaryItem,
  DdCurrentDownloadQuery,
  DdCurrentDownload,
} from "../types/dunningReports.types";
import logger, {
  eventLog,
  categoryOpt,
  eventOpt,
  inbound,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "service/dunningReports.services";
const httpLogRes = logRes();
const inboundLog = inbound();

// DD Current API
// Fetches unpaid AutoPay invoices for DD+4 and DD+12 buckets,
// grouped by SMB/RESI segment with account count and balance summary.
// Applies minimum balance filter and excludes recently paid invoices.

export const getDDCurrentService = async (params: DDCurrentRequest) => {
  let traceId = params.traceId
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getDDCurrentService";
  try {
    const { min_bal } = params;

    const sql = `
    WITH open_invoices AS (
      SELECT
        i.id AS invoice_id,
        i.billing_account_id,
        COALESCE(i.auto_pay_date, i.due_date)::DATE AS due_date,
        DATEDIFF(
          'day',
          COALESCE(i.auto_pay_date, i.due_date)::DATE,
          CURRENT_DATE()
        ) AS days_past_due
      FROM invoice i
      WHERE COALESCE(i.auto_pay_date, i.due_date)::DATE IN (
        DATEADD('day', -4, CURRENT_DATE()),
        DATEADD('day', -12, CURRENT_DATE())
      )
    ),
    paid AS (
      SELECT DISTINCT pa.invoice_id
      FROM payment p
      JOIN payment_application pa
        ON pa.payment_id = p.id
      WHERE p.payment_source_type = 'BATCH'
        AND p.status = 'COMPLETED'
        AND p.created_on >= DATEADD('day', -30, CURRENT_DATE())
    ),
    unpaid AS (
      SELECT
        oi.invoice_id,
        oi.billing_account_id,
        oi.due_date,
        oi.days_past_due
      FROM open_invoices oi
      LEFT JOIN paid pd
        ON pd.invoice_id = oi.invoice_id
      WHERE pd.invoice_id IS NULL
    ),
    with_acct AS (
      SELECT
        u.invoice_id,
        u.due_date,
        u.days_past_due,
        bad.account_num,
        bad.first_name,
        bad.last_name,
        bad.billing_account_category AS category,
        ROUND(bad.balance, 2) AS balance,
        CASE
          WHEN ba.billing_account_category ILIKE 'Business%'
            OR ba.billing_account_category ILIKE 'Legacy-B%'
          THEN 'SMB'
          ELSE 'RESI'
        END AS "segment"
      FROM unpaid u
      JOIN billing_account_detailed bad
        ON bad.id = u.billing_account_id
      JOIN billing_account ba
        ON ba.account_num = bad.account_num
       AND ba.automatic_payment = TRUE
       AND ba.status = 'BILLING_ACCOUNT_ACTIVE'
      WHERE ROUND(bad.balance, 2) > ${min_bal}
    )
    SELECT
      CASE
        WHEN days_past_due = 4 THEN 'DD+4'
        ELSE 'DD+12'
      END AS "bucket",
      "segment",
      COUNT(DISTINCT account_num) AS "accounts",
      ROUND(SUM(balance), 2) AS "total_balance"
    FROM with_acct
    GROUP BY "bucket", "segment"
    ORDER BY "bucket", "segment"
  `;

    const rows = (await runQuery(sql)) as DDCurrent[];

    const summary: Record<string, { accounts: number; balance: number }> = {
      "DD+4": {
        accounts: 0,
        balance: 0,
      },
      "DD+12": {
        accounts: 0,
        balance: 0,
      },
    };

    rows.forEach((r: any) => {
      const bucket = r.BUCKET || r.bucket;

      summary[bucket].accounts += Number(r.ACCOUNTS || r.accounts || 0);

      summary[bucket].balance += Number(
        r.TOTAL_BALANCE || r.total_balance || 0,
      );
    });

    return {
      by_segment: rows,
      summary,
      min_bal,
    };
  } catch (error:any) {
       httpLogRes.http.response.body.content = JSON.stringify({ error }, [
              "error",
              ...Object.getOwnPropertyNames(error),
            ]);
            logger.error({
              message: `Error in getDDCurrentService to fetch DD Current Details: ${traceId} - ${error.message}`,
              event: {
                ...logEvent,
                ...categoryOpt.webProcess,
                ...eventOpt.failureError,
              },
              error: {
                message: error?.message,
                code: error?.code,
                type: error?.constructor?.name,
              },
              ...httpLogRes,
              ...inboundLog,
            });
    throw error;
  }
};

// DD Resolution API
// Builds AutoPay invoice payment resolution report for last N months (max 12).
// Classifies invoices into ON TIME, DD+1-4, DD+5-12, DD+13+, and UNPAID based on first batch payment date.
// Groups data by due month and customer segment (SMB / RESI / ALL).
// Calculates resolution percentages (within 4 days and 12 days) for collections performance.

export const getDDResolutionService = async (
  monthsInput: number = 6,
  traceId?:string
): Promise<DDResolutionResponse> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getDDResolutionService";
  try {
    const months = Math.min(monthsInput, 12);
    const pay_buf = months + 4;

    const sql = `
    WITH invoices AS (
      SELECT i.id AS invoice_id, i.billing_account_id,
        COALESCE(i.auto_pay_date, i.due_date)::DATE AS due_date,
        DATE_TRUNC('month',
          COALESCE(i.auto_pay_date, i.due_date)::DATE
        )::DATE AS due_month
      FROM invoice i
      WHERE COALESCE(i.auto_pay_date, i.due_date)
            >= DATEADD('month', -${months}, CURRENT_DATE())
        AND COALESCE(i.auto_pay_date, i.due_date) < CURRENT_DATE()
    ),

    autopay_bridge AS (
      SELECT bad.id AS bad_id,
        CASE
          WHEN ba.billing_account_category ILIKE 'Business%'
            OR ba.billing_account_category ILIKE 'Legacy-B%'
          THEN 'SMB' ELSE 'RESI'
        END AS segment
      FROM billing_account_detailed bad
      JOIN billing_account ba
        ON ba.account_num = bad.account_num
       AND ba.automatic_payment = TRUE
       AND ba.status = 'BILLING_ACCOUNT_ACTIVE'
    ),

    inv_autopay AS (
      SELECT inv.invoice_id, inv.billing_account_id,
        inv.due_date, inv.due_month, ab.segment
      FROM invoices inv
      JOIN autopay_bridge ab
        ON ab.bad_id = inv.billing_account_id
    ),

    first_batch AS (
      SELECT pa.invoice_id,
        MIN(p.created_on)::DATE AS first_paid_on
      FROM payment p
      JOIN payment_application pa
        ON pa.payment_id = p.id
      WHERE p.payment_source_type = 'BATCH'
        AND p.status = 'COMPLETED'
        AND p.created_on >= DATEADD('month', -${pay_buf}, CURRENT_DATE())
      GROUP BY pa.invoice_id
    )

    SELECT
      TO_CHAR(ia.due_month, 'YYYY-MM') AS "due_month",
      ia.segment AS "segment",
      CASE
        WHEN fb.first_paid_on IS NULL THEN 'UNPAID'
        WHEN fb.first_paid_on <= ia.due_date THEN 'ON TIME'
        WHEN DATEDIFF('day', ia.due_date, fb.first_paid_on) <= 4 THEN 'DD+1-4'
        WHEN DATEDIFF('day', ia.due_date, fb.first_paid_on) <= 12 THEN 'DD+5-12'
        ELSE 'DD+13+'
      END AS "resolution",
      COUNT(DISTINCT ia.invoice_id) AS "invoice_count"
    FROM inv_autopay ia
    LEFT JOIN first_batch fb
      ON fb.invoice_id = ia.invoice_id
    GROUP BY ia.due_month, ia.segment, "resolution"
    ORDER BY ia.due_month, ia.segment, "resolution"
  `;

    const rows: DDResolutionRow[] = (await runQuery(sql)) as DDResolutionRow[];

    const bySeg: Record<string, Record<string, number>> = {};

    for (const r of rows) {
      const seg = r.segment;
      const res = r.resolution;
      const cnt = Number(r.invoice_count || 0);

      if (!bySeg[seg]) bySeg[seg] = {};
      if (!bySeg["ALL"]) bySeg["ALL"] = {};

      bySeg[seg][res] = (bySeg[seg][res] || 0) + cnt;
      bySeg["ALL"][res] = (bySeg["ALL"][res] || 0) + cnt;
    }

    const summary: DDResolutionSummaryItem[] = [];

    for (const seg of ["SMB", "RESI", "ALL"] as const) {
      const d = bySeg[seg] || {};

      const total = Object.values(d).reduce((a, b) => a + b, 0);

      const cum4 = (d["ON TIME"] || 0) + (d["DD+1-4"] || 0);
      const cum12 = cum4 + (d["DD+5-12"] || 0);

      summary.push({
        segment: seg,
        on_time: d["ON TIME"] || 0,
        dd1_4: d["DD+1-4"] || 0,
        dd5_12: d["DD+5-12"] || 0,
        dd13p: d["DD+13+"] || 0,
        unpaid: d["UNPAID"] || 0,
        total,
        pct_dd4: total ? Number(((cum4 / total) * 100).toFixed(1)) : 0,
        pct_dd12: total ? Number(((cum12 / total) * 100).toFixed(1)) : 0,
      });
    }

    return {
      by_month: rows,
      summary,
      months_range: months,
    };
  } catch (error:any) {
     httpLogRes.http.response.body.content = JSON.stringify({ error }, [
              "error",
              ...Object.getOwnPropertyNames(error),
            ]);
            logger.error({
              message: `Error in getDDResolutionService to fetch DD Resolution Details: ${traceId} - ${error.message}`,
              event: {
                ...logEvent,
                ...categoryOpt.webProcess,
                ...eventOpt.failureError,
              },
              error: {
                message: error?.message,
                code: error?.code,
                type: error?.constructor?.name,
              },
              ...httpLogRes,
              ...inboundLog,
            });
    throw error;
  }
};

export const getDdCurrentDownloadService = async (
  query: DdCurrentDownloadQuery,
): Promise<DdCurrentDownload[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getDdCurrentDownloadService";
  let traceId = query.traceId;
  try {
    const bucket = query.bucket || "";
    const minBal = Number(query.min_bal ?? 100);

    let dayFilter = "";

    if (bucket === "DD+4") {
      dayFilter = "AND oi.days_past_due = 4";
    } else if (bucket === "DD+12") {
      dayFilter = "AND oi.days_past_due = 12";
    }

    logger.info({
      message: "DD Current Service started",
      bucket,
      minBal,
    });

    const sql = `
    WITH open_invoices AS (
        SELECT i.id AS invoice_id, i.billing_account_id,
            COALESCE(i.auto_pay_date, i.due_date)::DATE AS due_date,
            DATEDIFF('day', COALESCE(i.auto_pay_date, i.due_date)::DATE,
                     CURRENT_DATE()) AS days_past_due
        FROM invoice i
       WHERE i.status = 'INVOICE_OPEN' and COALESCE(i.auto_pay_date, i.due_date)::DATE
            IN (DATEADD('day', -4, CURRENT_DATE()), DATEADD('day', -12, CURRENT_DATE()))
    ),
    paid AS (
        SELECT DISTINCT pa.invoice_id
        FROM payment p
        JOIN payment_application pa ON pa.payment_id = p.id
        WHERE p.payment_source_type='BATCH'
          AND p.status='COMPLETED'
          AND p.created_on >= DATEADD('day',-30,CURRENT_DATE())
    ),
    unpaid AS (
        SELECT oi.invoice_id, oi.billing_account_id, oi.due_date, oi.days_past_due
        FROM open_invoices oi
        LEFT JOIN paid pd ON pd.invoice_id = oi.invoice_id
        WHERE pd.invoice_id IS NULL ${dayFilter}
    )
    SELECT bad.account_num, bad.first_name, bad.last_name,
        CASE WHEN ba.billing_account_category ILIKE 'Business%'
              OR ba.billing_account_category ILIKE 'Legacy-B%'
             THEN 'SMB' ELSE 'RESI' END AS segment,
        bad.billing_account_category AS category,
        ROUND(bad.balance, 2) AS balance,
        TO_CHAR(u.due_date,'YYYY-MM-DD') AS due_date,
        u.days_past_due,
        CASE WHEN u.days_past_due=4 THEN 'DD+4' ELSE 'DD+12' END AS bucket,
        COALESCE(d.dunning_plan_name,'—') AS dunning_plan,
        bad.bill_cycle_name AS bill_cycle
    FROM unpaid u
    JOIN billing_account_detailed bad ON bad.id = u.billing_account_id
    JOIN billing_account ba ON ba.account_num = bad.account_num
       AND ba.automatic_payment = TRUE
       AND ba.status = 'BILLING_ACCOUNT_ACTIVE'
    LEFT JOIN billing_account_dunning d ON d.billing_account_id = ba.id
    WHERE ROUND(bad.balance, 2) > ${minBal}
    ORDER BY u.days_past_due DESC, bad.balance DESC
  `;

  

    const rows = await runQuery<DdCurrentDownload>(sql);

 

    return rows;
  } catch (error:any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
              "error",
              ...Object.getOwnPropertyNames(error),
            ]);
            logger.error({
              message: `Error in getDdCurrentDownloadService to download Report: ${traceId} - ${error.message}`,
              event: {
                ...logEvent,
                ...categoryOpt.webProcess,
                ...eventOpt.failureError,
              },
              error: {
                message: error?.message,
                code: error?.code,
                type: error?.constructor?.name,
              },
              ...httpLogRes,
              ...inboundLog,
            });
    throw error;
  }
};
