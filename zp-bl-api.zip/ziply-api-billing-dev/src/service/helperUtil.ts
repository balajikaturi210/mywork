
import pool from "../config/zbpDb";



export const getBillingAccountIdDetails = async (
  id: string
): Promise<string | null> => {
  try {
   const sql = `
  SELECT id
  FROM zbp.billing_account
  WHERE (account_num = $1
         OR id::text = $1)
    AND account_num <> id::text
`;
    
const row = (await pool.query(sql, [id])).rows[0];

    return row?.id ?? null;
  } catch (error) {
    console.error('Error fetching billing account details:', error);
    return null;
  }
};
