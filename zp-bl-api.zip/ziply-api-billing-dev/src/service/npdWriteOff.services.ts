import {
  NpdWriteoffTrend,
  NpdMissingWriteoffTrend,
  NPDWriteoffAccount,
  WriteoffPayment,
  NpdMissingWriteoffAccount,
  WriteoffDayAccount,
} from "../types/npdWriteOff.types";
import { runQuery } from "../config/snowflake";

import logger, {
  eventLog,
  categoryOpt,
  eventOpt,
  inbound,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "service/dunningReports.services";
const httpLogRes = logRes();
const inboundLog = inbound();

// src/constants/npdMissingCtes.ts

const NPD_MISSING_CTES = `
WITH deact_events AS (
    SELECT billing_account_id, MAX(created_on) AS deact_on
    FROM change_status_history
    WHERE ba_status_id = 'BILLING_ACCOUNT_DEACTIVATED'
    GROUP BY billing_account_id
),

non_pay AS (
    SELECT DISTINCT de.billing_account_id
    FROM deact_events de
    JOIN change_status_history csh
        ON csh.billing_account_id = de.billing_account_id
        AND csh.ba_status_id = 'BILLING_ACCOUNT_SUSPENDED'
        AND csh.created_on < de.deact_on
),

open_bal AS (
    SELECT billing_account_id,
           COUNT(*) AS open_inv_count,
           SUM(balance) AS open_balance
    FROM invoice
    WHERE status = 'INVOICE_OPEN'
      AND balance > 0
    GROUP BY billing_account_id
),

written_off AS (
    SELECT DISTINCT billing_account_id
    FROM statement
    WHERE credit_adjustments_write_off_amount > 0
)
`;
export const getNpdWriteoffTrendService = async (
  traceId?: string,
): Promise<NpdWriteoffTrend[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getNpdWriteoffTrendService";
  try {
    const sql = `
    SELECT
      TO_CHAR(
        DATE_TRUNC('month', s.created_on),
        'YYYY-MM'
      ) AS "writeoff_month",

      COUNT(DISTINCT s.billing_account_id) AS "accounts",

      ROUND(
        SUM(s.credit_adjustments_write_off_amount),
        2
      ) AS "total_balance",

      ROUND(
        SUM(
          CASE
            WHEN ba.billing_account_category ILIKE 'Business%'
              OR ba.billing_account_category ILIKE 'Legacy-B%'
            THEN s.credit_adjustments_write_off_amount
          END
        ),
        2
      ) AS "smb_balance",

      ROUND(
        SUM(
          CASE
            WHEN ba.billing_account_category NOT ILIKE 'Business%'
              AND ba.billing_account_category NOT ILIKE 'Legacy-B%'
            THEN s.credit_adjustments_write_off_amount
          END
        ),
        2
      ) AS "resi_balance"

    FROM statement s
    JOIN billing_account ba
      ON ba.id = s.billing_account_id

    WHERE s.credit_adjustments_write_off_amount > 0

    GROUP BY "writeoff_month"

    ORDER BY "writeoff_month" DESC
  `;

    const rows = await runQuery<NpdWriteoffTrend>(sql);

    return rows;
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in getNpdWriteoffTrendService to fetch NpdWriteOff Trend Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });
    throw error;
  }
};

export const getNpdMissingWriteoffTrendService = async (
  traceId?: string,
): Promise<NpdMissingWriteoffTrend[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getNpdMissingWriteoffTrendService";
  try {
    const sql = `
      ${NPD_MISSING_CTES}

      SELECT
        TO_CHAR(
          DATE_TRUNC('month', de.deact_on),
          'YYYY-MM'
        ) AS "disconnect_month",

        COUNT(DISTINCT de.billing_account_id) AS "missing_count",

        ROUND(
          SUM(ob.open_balance),
          2
        ) AS "total_open_balance",

        ROUND(
          SUM(
            CASE
              WHEN ba.billing_account_category ILIKE 'Business%'
                OR ba.billing_account_category ILIKE 'Legacy-B%'
              THEN ob.open_balance
            END
          ),
          2
        ) AS "smb_balance",

        ROUND(
          SUM(
            CASE
              WHEN ba.billing_account_category NOT ILIKE 'Business%'
                AND ba.billing_account_category NOT ILIKE 'Legacy-B%'
              THEN ob.open_balance
            END
          ),
          2
        ) AS "resi_balance"

      FROM deact_events de

      JOIN non_pay np
        ON np.billing_account_id = de.billing_account_id

      JOIN billing_account ba
        ON ba.id = de.billing_account_id

      JOIN open_bal ob
        ON ob.billing_account_id = de.billing_account_id

      LEFT JOIN written_off wo
        ON wo.billing_account_id = de.billing_account_id

      WHERE ba.status = 'BILLING_ACCOUNT_DEACTIVATED'
        AND wo.billing_account_id IS NULL

      GROUP BY "disconnect_month"

      ORDER BY "disconnect_month" DESC
    `;

    const row = await runQuery<NpdMissingWriteoffTrend>(sql);
    return row;
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in getNpdMissingWriteoffTrendService to fetch Missing NpdWriteOff Trend Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });
    throw error;
  }
};

export const getNPDWriteoffAccountsService = async (
  month: string,
  traceId?: string,
): Promise<NPDWriteoffAccount[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getNPDWriteoffAccountsService";
  try {
    const sql = `
    SELECT
        ba.account_num as "account_num",
        ba.status as "status",
        ba.billing_account_category AS "category",
        ba.automatic_payment::VARCHAR AS "autopay",
        ROUND(s.credit_adjustments_write_off_amount, 2) AS "writeoff_amount",
        TO_CHAR(s.created_on, 'YYYY-MM-DD HH24:MI') AS "writeoff_posted_on",
        CASE
            WHEN EXISTS (
                SELECT 1
                FROM change_status_history csh
                WHERE csh.billing_account_id = s.billing_account_id
                  AND csh.ba_status_id = 'BILLING_ACCOUNT_SUSPENDED'
            )
            THEN TRUE
            ELSE FALSE
        END AS "was_suspended"
    FROM statement s
    JOIN billing_account ba
        ON ba.id = s.billing_account_id
    WHERE s.credit_adjustments_write_off_amount > 0
      AND TO_CHAR(DATE_TRUNC('month', s.created_on), 'YYYY-MM') = '${month}'
    ORDER BY s.credit_adjustments_write_off_amount DESC
    LIMIT 1000
`;

    const rows = await runQuery<NPDWriteoffAccount>(sql);

    return rows;
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in getNPDWriteoffAccountsService to fetch  NpdWriteOff Account Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });

    throw error;
  }
};

export const getWriteoffPaymentsService = async (
  days: number,
  traceId?: string,
): Promise<WriteoffPayment[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getWriteoffPaymentsService";
  try {
    const sql = `
    SELECT
        TO_CHAR(DATE_TRUNC('day', p.created_on), 'YYYY-MM-DD') AS "day",
        p.payment_source_type AS "src",
        CASE
            WHEN ba.billing_account_category ILIKE 'Business%'
              OR ba.billing_account_category ILIKE 'Legacy-B%'
            THEN 'SMB'
            ELSE 'RESI'
        END AS "segment",
        COUNT(*) AS "pay_count",
        COUNT(DISTINCT p.billing_account_id) AS "unique_accts",
        COALESCE(SUM(p.amount), 0) AS "total_amount"
    FROM payment p
    JOIN billing_account ba
        ON ba.id = p.billing_account_id
    WHERE ba.status = 'BILLING_ACCOUNT_CLOSED'
      AND p.status = 'COMPLETED'
      AND p.created_on >= DATEADD('day', -${days}, CURRENT_DATE())
      AND p.created_on < CURRENT_DATE()
    GROUP BY "day", p.payment_source_type, "segment"
    ORDER BY "day", p.payment_source_type, "segment"
  `;

    const rows = await runQuery<WriteoffPayment>(sql);

    return rows;
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in getWriteoffPaymentsService to fetch  NpdWriteOff Payments Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });

    throw error;
  }
};

export const getNpdMissingWriteoffAccountsService = async (
  month: string,
  traceId?: string,
): Promise<NpdMissingWriteoffAccount[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getNpdMissingWriteoffAccountsService";
  try {
    const sql = `
WITH deact_events AS (
    SELECT billing_account_id, MAX(created_on) AS deact_on
    FROM change_status_history
    WHERE ba_status_id = 'BILLING_ACCOUNT_DEACTIVATED'
    GROUP BY billing_account_id
),
non_pay AS (
    SELECT DISTINCT de.billing_account_id
    FROM deact_events de
    JOIN change_status_history csh
        ON  csh.billing_account_id = de.billing_account_id
        AND csh.ba_status_id = 'BILLING_ACCOUNT_SUSPENDED'
        AND csh.created_on < de.deact_on
),
open_bal AS (
    SELECT billing_account_id,
           COUNT(*) AS open_inv_count,
           SUM(balance) AS open_balance
    FROM invoice
    WHERE status = 'INVOICE_OPEN' AND balance > 0
    GROUP BY billing_account_id
),
written_off AS (
    SELECT DISTINCT billing_account_id
    FROM statement
    WHERE credit_adjustments_write_off_amount > 0
)

SELECT
    ba.account_num AS "account_num",
    ba.billing_account_category AS "category",
    ba.automatic_payment::VARCHAR AS "autopay",
    ROUND(ob.open_balance, 2) AS "open_balance",
    ob.open_inv_count AS "open_inv_count",
    TO_CHAR(de.deact_on::DATE, 'YYYY-MM-DD') AS "deactivated_on",
    DATEDIFF('day', de.deact_on::DATE, CURRENT_DATE()) AS "days_disconnected"
FROM deact_events de
JOIN non_pay np
    ON np.billing_account_id = de.billing_account_id
JOIN billing_account ba
    ON ba.id = de.billing_account_id
JOIN open_bal ob
    ON ob.billing_account_id = de.billing_account_id
LEFT JOIN written_off wo
    ON wo.billing_account_id = de.billing_account_id
WHERE ba.status = 'BILLING_ACCOUNT_DEACTIVATED'
  AND wo.billing_account_id IS NULL
  AND de.deact_on >= DATE_TRUNC('month', TO_DATE('${month}-01'))
  AND de.deact_on < DATEADD('month', 1, DATE_TRUNC('month', TO_DATE('${month}-01')))
ORDER BY ob.open_balance DESC
LIMIT 1000
`;

    const rows = await runQuery<NpdMissingWriteoffAccount>(sql);

    return rows;
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in getNpdMissingWriteoffAccountsService to fetch  Missing NpdWriteOff Account Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });

    throw error;
  }
};

export const getWriteoffDayAccountsService = async (
  day: string,
  traceId?: string,
): Promise<WriteoffDayAccount[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getWriteoffDayAccountsService";
  try {
    if (!day) {
      throw new Error("day parameter required");
    }

    const sql = `
    SELECT
        ba.account_num AS "account_num",
        ba.billing_account_category AS "category",
        ROUND(ba.balance, 2) AS "balance",
        p.payment_source_type AS "src",
        ROUND(p.amount, 2) AS "amount",
        TO_CHAR(p.created_on, 'YYYY-MM-DD HH24:MI') AS "created_on",
        p.payment_method_id AS "payment_method_id"
    FROM payment p
    JOIN billing_account ba
        ON ba.id = p.billing_account_id
    WHERE ba.status = 'BILLING_ACCOUNT_CLOSED'
      AND p.status = 'COMPLETED'
      AND DATE_TRUNC('day', p.created_on)::DATE = TO_DATE('${day}')
    ORDER BY p.amount DESC
    LIMIT 500
  `;

    const rows = await runQuery<WriteoffDayAccount>(sql);

    return rows;
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in getWriteoffDayAccountsService to fetch  NpdWriteOff Day Account Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });

    throw error;
  }
};
