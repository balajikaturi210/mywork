import { runQuery } from "../config/snowflake";
import {
  NpdWriteoffBacklog,
  NpdWriteoffPlanEntry,
  NpdWriteoffUecTrend,
} from "../types/npdWriteOffUec.types";
import { buildPlanEntries } from "../utils/npdWriteOffUec";
import logger, { eventLog, categoryOpt, eventOpt } from "../logger/logger";

const eventData = eventLog();
eventData.module = "service/npdWriteOffUec.services";

/**
 * Definitions (Snowflake, PDA_12)
 *   Write-off account   billing_account_detailed row whose current billing_account_dunning plan is
 *                       'RES Dunning Write off' or 'SMB Dunning Write off', with balance > 0.
 *   Write-off month     the month the account was closed (billing_account_detailed.end_date), not the month the
 *                       write-off plan was assigned. Closure always comes first, so the newest months are
 *                       under-counted until the dunning job catches up (see the backlog and plan-entry views).
 *   UEC                 sum of adjustment_item.amount with reason 'Equipment Return - Debit' on the same accounts.
 *                       Equipment-return debits only start in March/April 2026, so earlier months show 0.
 */
const WRITEOFF_PLANS = `('RES Dunning Write off', 'SMB Dunning Write off')`;
const RES_PLAN = `'RES Dunning Write off'`;
const SMB_PLAN = `'SMB Dunning Write off'`;

const num = (v: unknown): number => {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
};

const logFailure = (action: string, error: any, traceId?: string) =>
  logger.error({
    message: `${action}: ${traceId ?? ""} - ${error?.message}`,
    event: {
      ...JSON.parse(JSON.stringify(eventData)),
      action,
      ...categoryOpt.webProcess,
      ...eventOpt.failureError,
    },
    error: { message: error?.message, code: error?.code, type: error?.constructor?.name },
  });

/** Write-off and UEC by the month the account closed, oldest month first. `months` is validated by the caller. */
export const getNpdWriteoffUecTrendService = async (
  months: number,
  traceId?: string,
): Promise<NpdWriteoffUecTrend[]> => {
  try {
    const rows = await runQuery<any>(`
      WITH equipment_charges AS (
          SELECT aa.billing_account_id, SUM(ai.amount) AS equipment_charge_amt
          FROM account_adjustment aa
          JOIN adjustment_item ai ON ai.account_adjustment_id = aa.id
          WHERE ai.adjustment_reason = 'Equipment Return - Debit'
          GROUP BY aa.billing_account_id
      ),
      writeoff_accounts AS (
          SELECT ba.id, ba.balance, bad.dunning_plan_name AS plan,
                 DATE_TRUNC('month', ba.end_date) AS writeoff_month,
                 COALESCE(ec.equipment_charge_amt, 0) AS equipment_charge_amt
          FROM billing_account_detailed ba
          JOIN billing_account_dunning bad ON ba.id = bad.billing_account_id
          LEFT JOIN equipment_charges ec ON ec.billing_account_id = ba.id
          WHERE bad.dunning_plan_name IN ${WRITEOFF_PLANS}
            AND ba.balance > 0
            AND ba.end_date >= DATEADD('month', -${months}, DATE_TRUNC('month', CURRENT_DATE()))
      )
      SELECT
          TO_CHAR(writeoff_month, 'YYYY-MM')                                        AS "month",
          COUNT(DISTINCT id)                                                        AS "accounts",
          SUM(balance)                                                              AS "total_writeoff",
          SUM(IFF(plan = ${RES_PLAN}, balance, 0))                                  AS "resi_amount",
          SUM(IFF(plan = ${SMB_PLAN}, balance, 0))                                  AS "smb_amount",
          SUM(equipment_charge_amt)                                                 AS "uec_amount",
          ROUND(100.0 * SUM(equipment_charge_amt) / NULLIF(SUM(balance), 0), 1)     AS "uec_pct"
      FROM writeoff_accounts
      GROUP BY writeoff_month
      ORDER BY writeoff_month`);
    return rows.map((r) => ({
      month: String(r.month),
      accounts: num(r.accounts),
      total_writeoff: num(r.total_writeoff),
      resi_amount: num(r.resi_amount),
      smb_amount: num(r.smb_amount),
      uec_amount: num(r.uec_amount),
      uec_pct: r.uec_pct === null || r.uec_pct === undefined ? null : num(r.uec_pct),
    }));
  } catch (error: any) {
    logFailure("getNpdWriteoffUecTrendService", error, traceId);
    throw error;
  }
};

/**
 * Closed accounts that still owe a balance, by closure month: how much is already flagged into a write-off plan and
 * how much is still waiting for the dunning job, with the unreturned equipment charge (UEC) on the pending accounts.
 * The "pending" part is what the trend above is missing.
 */
export const getNpdWriteoffBacklogService = async (
  months: number,
  traceId?: string,
): Promise<NpdWriteoffBacklog[]> => {
  try {
    const rows = await runQuery<any>(`
      WITH equipment_charges AS (
          SELECT aa.billing_account_id, SUM(ai.amount) AS equipment_charge_amt
          FROM account_adjustment aa
          JOIN adjustment_item ai ON ai.account_adjustment_id = aa.id
          WHERE ai.adjustment_reason = 'Equipment Return - Debit'
          GROUP BY aa.billing_account_id
      )
      SELECT
          TO_CHAR(DATE_TRUNC('month', ba.end_date), 'YYYY-MM')                      AS "month",
          COUNT(DISTINCT ba.id)                                                     AS "accounts",
          SUM(ba.balance)                                                           AS "total_balance",
          SUM(IFF(bad.dunning_plan_name IN ${WRITEOFF_PLANS}, ba.balance, 0))       AS "already_flagged",
          SUM(IFF(bad.dunning_plan_name IN ${WRITEOFF_PLANS}, 0, ba.balance))       AS "pending",
          COUNT(DISTINCT IFF(bad.dunning_plan_name IN ${WRITEOFF_PLANS}, NULL, ba.id)) AS "pending_accounts",
          SUM(IFF(bad.dunning_plan_name IN ${WRITEOFF_PLANS}, 0, COALESCE(ec.equipment_charge_amt, 0))) AS "pending_uec"
      FROM billing_account_detailed ba
      LEFT JOIN billing_account_dunning bad ON ba.id = bad.billing_account_id
      LEFT JOIN equipment_charges ec ON ec.billing_account_id = ba.id
      WHERE ba.balance > 0
        AND ba.end_date >= DATEADD('month', -${months}, DATE_TRUNC('month', CURRENT_DATE()))
      GROUP BY DATE_TRUNC('month', ba.end_date)
      ORDER BY DATE_TRUNC('month', ba.end_date)`);
    return rows.map((r) => ({
      month: String(r.month),
      accounts: num(r.accounts),
      total_balance: num(r.total_balance),
      already_flagged: num(r.already_flagged),
      pending: num(r.pending),
      pending_accounts: num(r.pending_accounts),
      pending_uec: num(r.pending_uec),
    }));
  } catch (error: any) {
    logFailure("getNpdWriteoffBacklogService", error, traceId);
    throw error;
  }
};

/**
 * Audit-log check: accounts that actually entered a write-off dunning plan, by the month it happened. A month with
 * almost no entries, when other months have thousands, means the write-off dunning job stalled that month.
 * Every month of the window is returned (zero when quiet) with `stalled` / `partial_month` flags.
 */
export const getNpdWriteoffPlanEntriesService = async (
  months: number,
  traceId?: string,
): Promise<NpdWriteoffPlanEntry[]> => {
  try {
    const rows = await runQuery<any>(`
      SELECT
          TO_CHAR(DATE_TRUNC('month', ae.start_date), 'YYYY-MM')                    AS "month",
          COUNT(DISTINCT ae.root_entity_id)                                         AS "accounts_entered",
          SUM(ba.balance)                                                           AS "current_balance"
      FROM audit_billing_account_event ae
      JOIN billing_account_detailed ba ON ba.id = ae.root_entity_id
      WHERE ae.entity_type = 'BillingAccountDunning'
        AND ae.change_type = 'UPDATE'
        AND (ae.description LIKE '%Plan Name:%was updated to ''RES Dunning Write off''%'
             OR ae.description LIKE '%Plan Name:%was updated to ''SMB Dunning Write off''%')
        AND ae.start_date >= DATEADD('month', -${months}, DATE_TRUNC('month', CURRENT_DATE()))
      GROUP BY DATE_TRUNC('month', ae.start_date)
      ORDER BY DATE_TRUNC('month', ae.start_date)`);
    return buildPlanEntries(
      rows.map((r) => ({
        month: String(r.month),
        accounts_entered: num(r.accounts_entered),
        current_balance: num(r.current_balance),
      })),
      months,
    );
  } catch (error: any) {
    logFailure("getNpdWriteoffPlanEntriesService", error, traceId);
    throw error;
  }
};
