import { getTraceId } from "../utils/logger";
import { runQuery } from "../config/snowflake";
import {
  Summary,
  AutoPay,
  PaymentFailureDaily,
  StatusTrend,
  Q1DeactivationBalance,
  SuspendRestoreCohort,
  CohortAccount,
} from "../types/overview.types";
import logger, {
  eventLog,
  categoryOpt,
  eventOpt,
  inbound,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "service/overview.services";
const httpLogRes = logRes();
const inboundLog = inbound();

export const getSummaryService = async (traceId: string): Promise<Summary> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getSummaryService";
  try {
    // const summarySql = `
    //   WITH bc AS (
    //     SELECT account_num,
    //            MAX(
    //              CASE
    //                WHEN bill_cycle_name != 'NO_BILL_PULL'
    //                THEN bill_cycle_name
    //              END
    //            ) AS bill_cycle_name
    //     FROM billing_account_detailed
    //     GROUP BY account_num
    //   )
    //   SELECT
    //     COUNT(*) AS "active_accounts",
    //     SUM(CASE WHEN ba.automatic_payment = TRUE THEN 1 ELSE 0 END) AS "autopay_on",
    //     SUM(
    //       CASE
    //         WHEN COALESCE(bc.bill_cycle_name, 'NO_BILL_PULL') != 'NO_BILL_PULL'
    //         THEN 1 ELSE 0
    //       END
    //     ) AS "main_billing",
    //     SUM(
    //       CASE
    //         WHEN COALESCE(bc.bill_cycle_name, 'NO_BILL_PULL') = 'NO_BILL_PULL'
    //         THEN 1 ELSE 0
    //       END
    //     ) AS "no_bill_pull"
    //   FROM billing_account ba
    //   LEFT JOIN bc
    //     ON bc.account_num = ba.account_num
    //   WHERE ba.status = 'BILLING_ACCOUNT_ACTIVE'
    // `;
     const summarySql = `select 

SUM(CASE WHEN ba.status = 'BILLING_ACCOUNT_ACTIVE' THEN 1 ELSE 0 END) AS "active_accounts",

SUM(CASE WHEN ba.automatic_payment = TRUE THEN 1 ELSE 0 END) AS "autopay_on",

SUM(

    CASE

        WHEN COALESCE(ba.bill_cycle_name, 'NO_BILL_PULL') != 'NO_BILL_PULL'

            THEN 1 ELSE 0

          END

        ) AS "main_billing"

        FROM billing_account_detailed ba where ba.status in ('BILLING_ACCOUNT_ACTIVE')
        AND COALESCE(ba.bill_cycle_name, 'NO_BILL_PULL') != 'NO_BILL_PULL'
 `;

    // Independent Snowflake queries run concurrently instead of one after another.
    const [main, counts, wo, fail] = await Promise.all([
      runQuery<Summary>(summarySql),
      runQuery<any>(`
        SELECT
          COUNT_IF(status = 'BILLING_ACCOUNT_SUSPENDED') AS "suspended",
          COUNT_IF(status = 'BILLING_ACCOUNT_DEACTIVATED') AS "disconnected",
          COUNT_IF(status = 'BILLING_ACCOUNT_FINAL_BILL') AS "final_bill",
          COUNT_IF(status = 'BILLING_ACCOUNT_CLOSED') AS "closed",
          COUNT_IF(status = 'BILLING_ACCOUNT_ACTIVE' AND bill_type = 'PAPER') AS "paper_bill"
        FROM billing_account
      `),
      runQuery<any>(`
        SELECT
          COUNT(*) AS "pay_count",
          COALESCE(SUM(p.amount), 0) AS "pay_total",
          COUNT(DISTINCT p.billing_account_id) AS "unique_accts"
        FROM payment p
        JOIN billing_account ba
          ON ba.id = p.billing_account_id
        WHERE ba.status='BILLING_ACCOUNT_CLOSED'
          AND p.status='COMPLETED'
          AND p.created_on >= DATEADD('day', -30, CURRENT_DATE())
      `),
      runQuery<any>(`
        SELECT
          payment_source_type AS "src",
          COUNT(CASE WHEN status='COMPLETED' THEN 1 END) AS "completed",
          COUNT(CASE WHEN status='PROCESSING_ERROR' THEN 1 END) AS "failed"
        FROM payment
        WHERE created_on >= DATEADD('day', -7, CURRENT_DATE())
          AND created_on < CURRENT_DATE()
          AND payment_source_type IN ('API', 'BATCH')
          AND status IN ('COMPLETED', 'PROCESSING_ERROR')
        GROUP BY payment_source_type
      `),
    ]);

    const s: any = main?.[0] ?? {};
    const c: any = counts?.[0] ?? {};
    s.suspended = c.suspended ?? 0;
    s.disconnected = c.disconnected ?? 0;
    s.final_bill = c.final_bill ?? 0;
    s.closed = c.closed ?? 0;
    s.paper_bill = c.paper_bill ?? 0;

    s.wo_pay_count = wo?.[0]?.pay_count ?? 0;
    s.wo_pay_total = Number(wo?.[0]?.pay_total ?? 0);
    s.wo_pay_accts = wo?.[0]?.unique_accts ?? 0;

    for (const r of fail ?? []) {
      const total = (r.completed ?? 0) + (r.failed ?? 0);
      const pct = total ? Number(((r.failed / total) * 100).toFixed(1)) : 0;

      if (r.src === "API") s.api_fail_pct = pct;
      if (r.src === "BATCH") s.batch_fail_pct = pct;
    }

    s.api_fail_pct ??= 0;
    s.batch_fail_pct ??= 0;
    return s;
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in getSummaryService to  fetch Summary Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });
    throw error;
  }
};

export const getAutoPayService = async (
  traceId: string,
): Promise<AutoPay[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getAutoPayService";
  try {
    const sql = `
    SELECT
      CASE WHEN automatic_payment = TRUE THEN 'AutoPay ON'
           ELSE 'AutoPay OFF' END AS "autopay",
      billing_account_category AS "category",
      COUNT(*) AS "accounts"
    FROM billing_account
    WHERE status = 'BILLING_ACCOUNT_ACTIVE'
    GROUP BY
      CASE WHEN automatic_payment = TRUE THEN 'AutoPay ON'
           ELSE 'AutoPay OFF' END,
      billing_account_category
    ORDER BY "autopay", "accounts" DESC
  `;

    const rows = await runQuery<AutoPay>(sql);
    return rows;
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in getAutoPayService to fetch Auto Pay Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });
    throw error;
  }
};

export const getPaymentFailureDaily = async (
  days: number = 7,
  traceId: string,
): Promise<PaymentFailureDaily[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getPaymentFailureDaily";
  try {
    const sql = `
    SELECT
      TO_CHAR(DATE_TRUNC('day', created_on), 'YYYY-MM-DD') AS "day",
      payment_source_type AS "src",
      COUNT(CASE WHEN status = 'COMPLETED' THEN 1 END) AS "completed",
      COUNT(CASE WHEN status = 'PROCESSING_ERROR' THEN 1 END) AS "failed",
      COUNT(CASE WHEN status = 'VOID' THEN 1 END) AS "voided"
    FROM payment
    WHERE created_on >= DATEADD('day', -${days}, CURRENT_DATE())
      AND created_on < CURRENT_DATE()
      AND payment_source_type IN ('API', 'BATCH')
      AND status IN ('COMPLETED', 'PROCESSING_ERROR', 'VOID')
    GROUP BY "day", payment_source_type
    ORDER BY "day", payment_source_type
  `;

    const rows = await runQuery<PaymentFailureDaily>(sql);
    return rows;
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getDailyPaymentFailureDetails: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { days },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    throw error;
  }
};

export const getStatusTrendService = async (
  days: number = 56,
  traceId: string,
): Promise<StatusTrend[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getStatusTrendService";
  try {
    const sql = `
      WITH history AS (
        SELECT
          billing_account_id,
          ba_status_id,
          created_on,
          LAG(ba_status_id) OVER (
            PARTITION BY billing_account_id ORDER BY created_on
          ) AS prev_status
        FROM change_status_history
        WHERE created_on >= DATEADD('day', -${days}, CURRENT_DATE())
          AND created_on < CURRENT_DATE()
      )
      SELECT
        TO_CHAR(DATE_TRUNC('day', created_on), 'YYYY-MM-DD') AS "day",
        CASE
          WHEN ba_status_id = 'BILLING_ACCOUNT_SUSPENDED' THEN 'SUSPENDED'
          WHEN ba_status_id = 'BILLING_ACCOUNT_DEACTIVATED' THEN 'DEACTIVATED'
          ELSE 'RESTORED'
        END AS "status",
        COUNT(*) AS "cnt"
      FROM history
      WHERE
        ba_status_id = 'BILLING_ACCOUNT_SUSPENDED'
        OR ba_status_id = 'BILLING_ACCOUNT_DEACTIVATED'
        OR (
          ba_status_id = 'BILLING_ACCOUNT_ACTIVE'
          AND prev_status IN (
            'BILLING_ACCOUNT_SUSPENDED',
            'BILLING_ACCOUNT_DEACTIVATED'
          )
        )
      GROUP BY "day", "status"
      ORDER BY "day", "status"
    `;

    const rows = await runQuery<StatusTrend>(sql);

    return rows;
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getStatusTrend: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { days },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });

    throw error;
  }
};

export const getQ1DeactivationBalanceService = async (
  traceId: string,
): Promise<Q1DeactivationBalance> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getQ1DeactivationBalanceService";
  try {
    const sql = `
      WITH deactivated AS (
        SELECT
          billing_account_id,
          MIN(created_on)::DATE AS deactivated_on
        FROM change_status_history
        WHERE ba_status_id = 'BILLING_ACCOUNT_DEACTIVATED'
          AND created_on >= '2026-01-01'::DATE
          AND created_on < '2026-04-01'::DATE
        GROUP BY billing_account_id
      ),

      open_invoices AS (
        SELECT
          billing_account_id,
          COUNT(*) AS open_inv_count,
          SUM(balance) AS open_inv_balance
        FROM invoice
        WHERE status = 'INVOICE_OPEN'
        GROUP BY billing_account_id
      )

      SELECT
        COUNT(DISTINCT d.billing_account_id) AS "total_disconnects",

        COUNT(DISTINCT CASE 
          WHEN COALESCE(oi.open_inv_balance, 0) > 0 
          THEN d.billing_account_id 
        END) AS "with_balance",

        ROUND(COALESCE(SUM(oi.open_inv_balance), 0), 2) AS "total_open_balance",

        ROUND(COALESCE(SUM(
          CASE 
            WHEN ba.billing_account_category ILIKE 'Business%' 
              OR ba.billing_account_category ILIKE 'Legacy-B%'
            THEN oi.open_inv_balance 
          END
        ), 0), 2) AS "smb_balance",

        ROUND(COALESCE(SUM(
          CASE 
            WHEN ba.billing_account_category NOT ILIKE 'Business%' 
             AND ba.billing_account_category NOT ILIKE 'Legacy-B%'
            THEN oi.open_inv_balance 
          END
        ), 0), 2) AS "resi_balance"

      FROM deactivated d
      JOIN billing_account ba 
        ON ba.id = d.billing_account_id
      LEFT JOIN open_invoices oi 
        ON oi.billing_account_id = d.billing_account_id
    `;

    const rows = await runQuery<Q1DeactivationBalance>(sql);

    return (
      rows[0] || {
        total_disconnects: 0,
        with_balance: 0,
        total_open_balance: 0,
        smb_balance: 0,
        resi_balance: 0,
      }
    );
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getQ1DeactivationBalanceService: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });

    throw error;
  }
};

// Cohort numbers change slowly and the query is heavy, so cache per `days`.
const COHORT_CACHE_TTL_MS = 5 * 60 * 1000;
const cohortCache = new Map<
  number,
  { expires: number; rows: Promise<SuspendRestoreCohort[]> }
>();

export const getSuspendRestoreCohortService = async (
  days: number,
  traceId: string,
): Promise<SuspendRestoreCohort[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getSuspendRestoreCohortService";
  try {
    const cached = cohortCache.get(days);
    if (cached && cached.expires > Date.now()) {
      return await cached.rows;
    }
    const sql = `
      WITH suspensions AS (
        SELECT
          billing_account_id,
          created_on AS suspend_on,
          DATE_TRUNC('day', created_on)::DATE AS suspend_date
        FROM change_status_history
        WHERE ba_status_id = 'BILLING_ACCOUNT_SUSPENDED'
          AND created_on >= DATEADD('day', -${days}, CURRENT_DATE())
          AND created_on < CURRENT_DATE()
      ),

      ranked_next AS (
        SELECT
          s.billing_account_id,
          s.suspend_on,
          s.suspend_date,
          csh.ba_status_id AS next_status,
          DATEDIFF(
            'day',
            s.suspend_date,
            DATE_TRUNC('day', csh.created_on)::DATE
          ) AS days_elapsed,

          ROW_NUMBER() OVER (
            PARTITION BY s.billing_account_id, s.suspend_on
            ORDER BY csh.created_on
          ) AS rn
        FROM suspensions s
        JOIN change_status_history csh
          ON csh.billing_account_id = s.billing_account_id
         AND csh.created_on > s.suspend_on
      ),

      first_next AS (
        SELECT
          billing_account_id,
          suspend_on,
          suspend_date,
          next_status,
          days_elapsed
        FROM ranked_next
        WHERE rn = 1
      ),

      chargeback_accts AS (
        SELECT ba2.id AS billing_account_id
        FROM billing_account ba2
        WHERE ba2.account_num IN (
          SELECT ba.account_num
          FROM suspensions s
          JOIN billing_account ba ON ba.id = s.billing_account_id
        )
        AND ba2.account_num IN (
          SELECT ba.account_num
          FROM payment p
          JOIN billing_account ba ON ba.id = p.billing_account_id
          WHERE UPPER(COALESCE(p.description, '')) LIKE '%CHRGBK%'

          UNION

          SELECT ba.account_num
          FROM payment_status_history psh
          JOIN payment p ON p.id = psh.payment_id
          JOIN billing_account ba ON ba.id = p.billing_account_id
          WHERE UPPER(COALESCE(psh.reason, '')) LIKE '%CHRGBK%'

          UNION

          SELECT ba.account_num
          FROM invoice_item ii
          JOIN invoice i ON i.id = ii.invoice_id
          JOIN billing_account ba ON ba.id = i.billing_account_id
          WHERE UPPER(COALESCE(ii.description, '')) LIKE '%CHRGBK%'
        )
      ),

      cohort AS (
        SELECT
          s.billing_account_id,
          s.suspend_on,
          s.suspend_date,
          fn.next_status,
          fn.days_elapsed,
          ba.status AS current_status,
          CASE
            WHEN cb.billing_account_id IS NOT NULL THEN 1
            ELSE 0
          END AS is_chargeback
        FROM suspensions s
        LEFT JOIN first_next fn
          ON fn.billing_account_id = s.billing_account_id
         AND fn.suspend_on = s.suspend_on
        JOIN billing_account ba
          ON ba.id = s.billing_account_id
        LEFT JOIN chargeback_accts cb
          ON cb.billing_account_id = s.billing_account_id
      )

      SELECT
        TO_CHAR(suspend_date, 'YYYY-MM-DD') AS "suspend_date",

        COUNT(*) AS "suspended",
        COUNT(CASE WHEN is_chargeback = 1 THEN 1 END) AS "chargebacks",

        COUNT(CASE
          WHEN next_status = 'BILLING_ACCOUNT_ACTIVE'
           AND current_status = 'BILLING_ACCOUNT_ACTIVE'
          THEN 1 END) AS "restored",

        COUNT(CASE
          WHEN next_status = 'BILLING_ACCOUNT_ACTIVE'
           AND current_status = 'BILLING_ACCOUNT_ACTIVE'
           AND days_elapsed = 0
          THEN 1 END) AS "r_d0",

        COUNT(CASE
          WHEN next_status = 'BILLING_ACCOUNT_ACTIVE'
           AND current_status = 'BILLING_ACCOUNT_ACTIVE'
           AND days_elapsed BETWEEN 1 AND 7
          THEN 1 END) AS "r_d1_7",

        COUNT(CASE
          WHEN next_status = 'BILLING_ACCOUNT_ACTIVE'
           AND current_status = 'BILLING_ACCOUNT_ACTIVE'
           AND days_elapsed BETWEEN 8 AND 14
          THEN 1 END) AS "r_d8_14",

        COUNT(CASE
          WHEN next_status = 'BILLING_ACCOUNT_ACTIVE'
           AND current_status = 'BILLING_ACCOUNT_ACTIVE'
           AND days_elapsed BETWEEN 15 AND 30
          THEN 1 END) AS "r_d15_30",

        COUNT(CASE
          WHEN next_status = 'BILLING_ACCOUNT_ACTIVE'
           AND current_status = 'BILLING_ACCOUNT_ACTIVE'
           AND days_elapsed > 30
          THEN 1 END) AS "r_d31p",

        COUNT(CASE
          WHEN next_status = 'BILLING_ACCOUNT_ACTIVE'
           AND current_status != 'BILLING_ACCOUNT_ACTIVE'
          THEN 1 END) AS "temp_restored",

        COUNT(CASE WHEN current_status = 'BILLING_ACCOUNT_DEACTIVATED' THEN 1 END) AS "to_deact",
        COUNT(CASE WHEN current_status = 'BILLING_ACCOUNT_FINAL_BILL' THEN 1 END) AS "to_final_bill",
        COUNT(CASE WHEN current_status = 'BILLING_ACCOUNT_CLOSED' THEN 1 END) AS "to_closed",
        COUNT(CASE WHEN current_status = 'BILLING_ACCOUNT_SUSPENDED' THEN 1 END) AS "still_suspended"

      FROM cohort
      GROUP BY "suspend_date"
      ORDER BY "suspend_date"
    `;

    // Cache the in-flight promise so concurrent requests share one query;
    // drop it on failure so errors are not cached.
    if (cohortCache.size >= 20) cohortCache.clear(); // `days` is caller-controlled
    const pending = runQuery<SuspendRestoreCohort>(sql);
    cohortCache.set(days, {
      expires: Date.now() + COHORT_CACHE_TTL_MS,
      rows: pending,
    });
    pending.catch(() => cohortCache.delete(days));

    return await pending;
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getSuspendRestoreCohortService: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { days },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });
    throw error;
  }
};

export const COHORT_BUCKET_FILTER: Record<string, string> = {
  suspended: "",
  restored:
    "AND fn.next_status='BILLING_ACCOUNT_ACTIVE' AND ba.status='BILLING_ACCOUNT_ACTIVE'",
  r_d0: "AND fn.next_status='BILLING_ACCOUNT_ACTIVE' AND ba.status='BILLING_ACCOUNT_ACTIVE' AND fn.days_elapsed=0",
  r_d1_7:
    "AND fn.next_status='BILLING_ACCOUNT_ACTIVE' AND ba.status='BILLING_ACCOUNT_ACTIVE' AND fn.days_elapsed BETWEEN 1 AND 7",
  r_d8_14:
    "AND fn.next_status='BILLING_ACCOUNT_ACTIVE' AND ba.status='BILLING_ACCOUNT_ACTIVE' AND fn.days_elapsed BETWEEN 8 AND 14",
  r_d15_30:
    "AND fn.next_status='BILLING_ACCOUNT_ACTIVE' AND ba.status='BILLING_ACCOUNT_ACTIVE' AND fn.days_elapsed BETWEEN 15 AND 30",
  r_d31p:
    "AND fn.next_status='BILLING_ACCOUNT_ACTIVE' AND ba.status='BILLING_ACCOUNT_ACTIVE' AND fn.days_elapsed > 30",
  temp_restored:
    "AND fn.next_status='BILLING_ACCOUNT_ACTIVE' AND ba.status!='BILLING_ACCOUNT_ACTIVE'",
  to_deact: "AND ba.status='BILLING_ACCOUNT_DEACTIVATED'",
  to_final_bill: "AND ba.status='BILLING_ACCOUNT_FINAL_BILL'",
  to_closed: "AND ba.status='BILLING_ACCOUNT_CLOSED'",
  still_suspended: "AND ba.status='BILLING_ACCOUNT_SUSPENDED'",
};

export const getCohortAccountsService = async (
  suspend_date: string,
  bucket: string = "suspended",
  traceId: string,
): Promise<CohortAccount[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getCohortAccountsService";
  try {
    if (!suspend_date) {
      throw new Error("suspend_date required");
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(suspend_date)) {
      throw new Error("suspend_date must be YYYY-MM-DD");
    }

    const bucketFilter = COHORT_BUCKET_FILTER[bucket] || "";

    const cacheKey = `cohort_drill_v5_${suspend_date}_${bucket}`;

    const sql = `
    WITH suspensions AS (
        SELECT billing_account_id,
               created_on AS suspend_on,
               DATE_TRUNC('day', created_on)::DATE AS suspend_date
        FROM change_status_history
        WHERE ba_status_id='BILLING_ACCOUNT_SUSPENDED'
          AND DATE_TRUNC('day', created_on)::DATE = TO_DATE('${suspend_date}')
    ),
    ranked_next AS (
        SELECT s.billing_account_id,
               s.suspend_on,
               csh.ba_status_id AS next_status,
               DATEDIFF(
                   'day',
                   s.suspend_date,
                   DATE_TRUNC('day', csh.created_on)::DATE
               ) AS days_elapsed,
               ROW_NUMBER() OVER (
                   PARTITION BY s.billing_account_id, s.suspend_on
                   ORDER BY csh.created_on
               ) AS rn
        FROM suspensions s
        JOIN change_status_history csh
            ON csh.billing_account_id = s.billing_account_id
           AND csh.created_on > s.suspend_on
    ),
    fn AS (
        SELECT billing_account_id, suspend_on, next_status, days_elapsed
        FROM ranked_next
        WHERE rn = 1
    ),
    susp_accts AS (
        SELECT DISTINCT ba.account_num
        FROM suspensions s
        JOIN billing_account ba ON ba.id = s.billing_account_id
    ),
    chargeback_notes AS (
        SELECT ba2.id AS billing_account_id, cb.note
        FROM (
            SELECT ba.account_num, p.description AS note
            FROM payment p
            JOIN billing_account ba ON ba.id = p.billing_account_id
            WHERE ba.account_num IN (SELECT account_num FROM susp_accts)
              AND UPPER(COALESCE(p.description, '')) LIKE '%CHRGBK%'

            UNION

            SELECT ba.account_num, psh.reason AS note
            FROM payment_status_history psh
            JOIN payment p ON p.id = psh.payment_id
            JOIN billing_account ba ON ba.id = p.billing_account_id
            WHERE ba.account_num IN (SELECT account_num FROM susp_accts)
              AND UPPER(COALESCE(psh.reason, '')) LIKE '%CHRGBK%'

            UNION

            SELECT ba.account_num, ii.description AS note
            FROM invoice_item ii
            JOIN invoice i ON i.id = ii.invoice_id
            JOIN billing_account ba ON ba.id = i.billing_account_id
            WHERE ba.account_num IN (SELECT account_num FROM susp_accts)
              AND UPPER(COALESCE(ii.description, '')) LIKE '%CHRGBK%'
        ) cb
        JOIN billing_account ba2 ON ba2.account_num = cb.account_num
    ),
    chargeback_accts AS (
        SELECT billing_account_id, MAX(note) AS chargeback_note
        FROM chargeback_notes
        GROUP BY billing_account_id
    )

    SELECT
        ba.account_num AS "account_num",
        ba.billing_account_category AS "category",
        ba.status AS "current_status",
        COALESCE(fn.next_status, '(none yet)') AS "next_status",
        fn.days_elapsed AS "days_elapsed",
        ROUND(ba.balance, 2) AS "balance",
        ba.automatic_payment::VARCHAR AS "autopay",
        COALESCE(d.dunning_plan_name, '—') AS "dunning_plan",
        CASE WHEN cb.billing_account_id IS NOT NULL THEN 'Yes' ELSE 'No' END AS "chargeback",
        cb.chargeback_note AS "chargeback_note"
    FROM suspensions s
    LEFT JOIN fn
        ON fn.billing_account_id = s.billing_account_id
       AND fn.suspend_on = s.suspend_on
    JOIN billing_account ba
        ON ba.id = s.billing_account_id
    LEFT JOIN billing_account_dunning d
        ON d.billing_account_id = ba.id
    LEFT JOIN chargeback_accts cb
        ON cb.billing_account_id = s.billing_account_id
    WHERE 1=1
    ${bucketFilter}
    ORDER BY ba.account_num
  `;

    const rows = await runQuery<CohortAccount>(sql);

    return rows;
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `getCohortAccountsService: Error for requestId: ${traceId} ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.web,
        ...eventOpt.failureError,
      },
      ...inboundLog,
      ziply: { suspend_date, bucket },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
    });

    throw error;
  }
};
