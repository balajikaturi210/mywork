import axios, { AxiosError } from "axios";
import logger from "../logger/logger";
import { PaymentCoreServiceError } from "../types/paymentCore.types";
import { getTraceId } from "../utils/logger";
import { getPaymentCoreConfig } from "../utils/paymentCore.util";

export type PaymentBankDetails = { bank_name: string | null; routing_number: string | null };

/** This runs after the payment screen is already on show, so it gives up sooner than the 15 s used for page-blocking calls. */
const BANK_DETAILS_TIMEOUT_MS = 8000;

const text = (value: unknown): string | null => {
  if (typeof value !== "string" && typeof value !== "number") return null;
  const result = String(value).trim();
  return result === "" ? null : result;
};

/**
 * The bank name and routing number of one payment. The database does not hold them; Payment Core does, and it can
 * return a single payment by id (about 1 KB) instead of the account's whole payment history.
 * Only those two fields are passed on: the account number, token and the rest of the record stay behind.
 * Returns null when Payment Core has no such payment.
 */
export const getPaymentBankDetailsService = async (paymentId: string): Promise<PaymentBankDetails | null> => {
  const traceId = getTraceId();
  const { baseUrl, timeout, headers, httpsAgent, useProxy } = getPaymentCoreConfig();

  try {
    const response = await axios.get(`${baseUrl}/v1/payment`, {
      params: { id: paymentId },
      headers,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout: Math.min(timeout, BANK_DETAILS_TIMEOUT_MS),
      validateStatus: () => true,
    });

    if (response.status === 404) {
      return null;
    }
    if (response.status >= 400) {
      throw new PaymentCoreServiceError("Payment Core could not return the bank details", 502, response.status);
    }

    const payment = Array.isArray(response.data) ? response.data[0] : response.data;
    const method = payment && typeof payment === "object" ? (payment as { payment_method?: Record<string, unknown> }).payment_method : undefined;
    return method ? { bank_name: text(method.bank_name), routing_number: text(method.routing_number) } : null;
  } catch (error) {
    if (error instanceof PaymentCoreServiceError) {
      logger.error({ trace_id: traceId, event: "getPaymentBankDetailsService_FAILED", message: error.message, paymentId, upstreamStatus: error.upstreamStatus });
      throw error;
    }

    const axiosError = error as AxiosError;
    const isTimeout = axiosError.code === "ECONNABORTED";
    logger.error({ trace_id: traceId, event: "getPaymentBankDetailsService_FAILED", message: axiosError.message, paymentId, code: axiosError.code });
    throw new PaymentCoreServiceError(
      isTimeout ? "Payment Core took too long to return the bank details" : "Unable to reach Payment Core",
      isTimeout ? 504 : 502,
    );
  }
};
