import axios, { AxiosError } from "axios";
import pool from "../config/zbpDb";
import { getTraceId } from "../utils/logger";
import logger from "../logger/logger";
import {
  AccountAdjustmentRequest,
  GetAdjustmentReasonRequest,
  GetInvoicePdfRequest,
  GetAccountAdjustmentRequest,
  GetInvoicesRequest,
  GetChargeBreakdownRequest,
  InvoicePdfResponse,
  PaymentCoreServiceError,
  ReverseAccountAdjustmentRequest,
  UpdateAdjustmentsRequest,
} from "../types/paymentCore.types";
import {
  getPaymentCoreConfig,
  getUpstreamErrorMessage,
} from "../utils/paymentCore.util";
import { getVpmConfig, getVpmUpstreamErrorMessage } from "../utils/vpm.util";
import {
  AccountAdjustmentOperation,
  AccountAdjustmentType,
  getAccountAdjustmentConfig,
} from "../utils/accountAdjustment.util";
import {getBillingAccountIdDetails } from "../service/helperUtil";

const buildUpstreamHttpError = (
  status: number,
  payload: unknown,
  operation: "invoices" | "invoicePdf" | "chargeBreakdown",
): PaymentCoreServiceError => {
  const detailMessage = getVpmUpstreamErrorMessage(payload);
  const fallbackMessage = {
    invoices: "Unable to fetch invoices",
    invoicePdf: "Unable to fetch invoice PDF",
    chargeBreakdown: "Unable to fetch charge breakdown",
  }[operation];
  const message = detailMessage || fallbackMessage;
  const statusCode = status >= 500 ? 502 : status;

  return new PaymentCoreServiceError(
    message,
    statusCode,
    status,
    {
      errorType: "UPSTREAM_HTTP_ERROR",
      upstreamReached: true,
      upstreamStatus: status,
      upstreamBody: payload,
    },
  );
};

const buildConnectionError = (error: AxiosError, context: string): PaymentCoreServiceError => {
  const isTimeout = error.code === "ECONNABORTED";
  const upstreamReached = Boolean(error.response);
  const message = isTimeout
    ? `${context} timed out before receiving a response`
    : upstreamReached
      ? `Received an error response while connecting to ${context}`
      : `Unable to connect to ${context}`;

  return new PaymentCoreServiceError(
    message,
    isTimeout ? 504 : 502,
    error.response?.status,
    {
      errorType: isTimeout ? "UPSTREAM_TIMEOUT" : "UPSTREAM_CONNECTION_ERROR",
      upstreamReached,
      message: error.message,
      code: error.code,
      status: error.response?.status,
      data: error.response?.data,
    },
  );
};

const buildAccountAdjustmentUpstreamHttpError = (
  status: number,
  payload: unknown,
  operation: AccountAdjustmentOperation,
): PaymentCoreServiceError => {
  const detailMessage = getVpmUpstreamErrorMessage(payload);
  const fallbackMessage =
    operation === "get"
      ? "Unable to fetch account adjustments"
      : operation === "create"
        ? "Unable to create account adjustment"
        : "Unable to reverse account adjustment";
  const message = detailMessage || fallbackMessage;
  const statusCode = status >= 500 ? 502 : status;

  return new PaymentCoreServiceError(message, statusCode, status, {
    errorType: "UPSTREAM_HTTP_ERROR",
    upstreamReached: true,
    upstreamStatus: status,
    upstreamBody: payload,
  });
};

const buildAccountAdjustmentConnectionError = (
  error: AxiosError,
  operation: AccountAdjustmentOperation,
): PaymentCoreServiceError => {
  const context =
    operation === "create"
      ? "accountAdjustment endpoint"
      : operation === "get"
        ? "getAccountAdjustment endpoint"
        : "reverseAccountAdjustment endpoint";

  const isTimeout = error.code === "ECONNABORTED";
  const upstreamReached = Boolean(error.response);
  const message = isTimeout
    ? `${context} timed out before receiving a response`
    : upstreamReached
      ? `Received an error response while connecting to ${context}`
      : `Unable to connect to ${context}`;

  return new PaymentCoreServiceError(message, isTimeout ? 504 : 502, error.response?.status, {
    errorType: isTimeout ? "UPSTREAM_TIMEOUT" : "UPSTREAM_CONNECTION_ERROR",
    upstreamReached,
    message: error.message,
    code: error.code,
    status: error.response?.status,
    data: error.response?.data,
  });
};

const withAccountNumberAliases = (params: Record<string, string>): Record<string, string> => {
  const normalized = { ...params };
  const accountNumber =
    String(normalized.accountNumber ?? normalized.account_num ?? normalized.billingAccountId ?? "").trim() ||
    undefined;

  if (!accountNumber) {
    return normalized;
  }

  if (!normalized.accountNumber) {
    normalized.accountNumber = accountNumber;
  }

  if (!normalized.account_num) {
    normalized.account_num = accountNumber;
  }

  return normalized;
};

type AdjustmentReasonType = "CREDIT" | "DEBIT";

type AdjustmentReasonRow = {
  id: number;
  charge_code: string;
  adjustment_type: string;
  short_description: string | null;
  long_description: string | null;
};

const getAdjustmentReasonList = async (
  adjustmentType?: AdjustmentReasonType,
): Promise<AdjustmentReasonRow[]> => {
  const bindValues: string[] = [];
  const conditions: string[] = ["gtv_charge_code = FALSE"];

  if (adjustmentType) {
    bindValues.push(adjustmentType);
    conditions.push(`UPPER(adjustment_type) = $${bindValues.length}`);
  }

  const whereClause = `WHERE ${conditions.join(" AND ")}`;

  const sql = `
    SELECT
      id,
      charge_code,
      adjustment_type,
      short_description,
      long_description
    FROM zbp.zbp_adjustment_reason
    ${whereClause}
    ORDER BY id ASC
  `;

  return (await pool.query<AdjustmentReasonRow>(sql, bindValues)).rows;
};

export const getAdjustmentReasonService = async (
  request: GetAdjustmentReasonRequest,
): Promise<AdjustmentReasonRow[]> => {
  return getAdjustmentReasonList(request.adjustmentType);
};

export const getPaymentHistoryService = async (
  accountNum: string,
  expand: string = "current_status_entry",
): Promise<unknown> => {
  const traceId = getTraceId();
  const { baseUrl, timeout, headers, httpsAgent, useProxy } = getPaymentCoreConfig();
  const endpoint = `${baseUrl}/v1/payment`;

  try {
    const response = await axios.get(endpoint, {
      params: {
        account_num: accountNum,
        expand,
      },
      headers,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      const statusCode =
        response.status >= 400 && response.status < 500 ? response.status : 502;
      const upstreamMessage = getUpstreamErrorMessage(response.data);
      const message = upstreamMessage
        ? `Payment Core responded with HTTP ${response.status}: ${upstreamMessage}`
        : `Payment Core responded with HTTP ${response.status}`;
      throw new PaymentCoreServiceError(
        message,
        statusCode,
        response.status,
      );
    }

    logger.info({
      trace_id: traceId,
      event: "getPaymentHistoryService_SUCCESS",
      accountNum,
      expand,
      upstreamStatus: response.status,
    });

    return response.data;
  } catch (error) {
    if (error instanceof PaymentCoreServiceError) {
      logger.error({
        trace_id: traceId,
        event: "getPaymentHistoryService_FAILED",
        message: error.message,
        accountNum,
        expand,
        upstreamStatus: error.upstreamStatus,
      });
      throw error;
    }

    if (error instanceof Error && error.name === "BillingServiceError") {
      throw new PaymentCoreServiceError(error.message, 500);
    }

    const axiosError = error as AxiosError;
    const isTimeout = axiosError.code === "ECONNABORTED";
    const upstreamReached = Boolean(axiosError.response);
    const message = isTimeout
      ? "Payment Core request timed out before receiving a response"
      : upstreamReached
        ? "Received an error response while connecting to Payment Core"
        : "Unable to connect to Payment Core API";
    logger.error({
      trace_id: traceId,
      event: "getPaymentHistoryService_FAILED",
      message,
      accountNum,
      expand,
      code: axiosError.code,
      upstreamStatus: axiosError.response?.status,
      upstreamReached,
    });

    throw new PaymentCoreServiceError(
      message,
      isTimeout ? 504 : 502,
      axiosError.response?.status,
    );
  }
};

export const getBillingAccountPaymentsService = async (
  billingAccountId: string,
): Promise<unknown> => {
  const traceId = getTraceId();
  const { baseUrl, timeout, headers, httpsAgent, useProxy } = getPaymentCoreConfig();
  const billingAccountIdResponse = (await getBillingAccountIdDetails(billingAccountId)) ?? billingAccountId;
  const endpoint = `${baseUrl}/v1/billingaccount/${encodeURIComponent(billingAccountIdResponse)}/payments`;

  try {
    const response = await axios.get(endpoint, {
      headers,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      const statusCode =
        response.status >= 400 && response.status < 500 ? response.status : 502;
      const upstreamMessage = getUpstreamErrorMessage(response.data);
      const message = upstreamMessage
        ? `Payment Core responded with HTTP ${response.status}: ${upstreamMessage}`
        : `Payment Core responded with HTTP ${response.status}`;
      throw new PaymentCoreServiceError(message, statusCode, response.status);
    }

    logger.info({
      trace_id: traceId,
      event: "getBillingAccountPaymentsService_SUCCESS",
      billingAccountId,
      upstreamStatus: response.status,
    });

    return response.data;
  } catch (error) {
    if (error instanceof PaymentCoreServiceError) {
      logger.error({
        trace_id: traceId,
        event: "getBillingAccountPaymentsService_FAILED",
        message: error.message,
        billingAccountId,
        upstreamStatus: error.upstreamStatus,
      });
      throw error;
    }

    if (error instanceof Error && error.name === "BillingServiceError") {
      throw new PaymentCoreServiceError(error.message, 500);
    }

    const axiosError = error as AxiosError;
    const isTimeout = axiosError.code === "ECONNABORTED";
    const upstreamReached = Boolean(axiosError.response);
    const message = isTimeout
      ? "Payment Core request timed out before receiving a response"
      : upstreamReached
        ? "Received an error response while connecting to Payment Core"
        : "Unable to connect to Payment Core API";

    logger.error({
      trace_id: traceId,
      event: "getBillingAccountPaymentsService_FAILED",
      message,
      billingAccountId,
      code: axiosError.code,
      upstreamStatus: axiosError.response?.status,
      upstreamReached,
    });

    throw new PaymentCoreServiceError(
      message,
      isTimeout ? 504 : 502,
      axiosError.response?.status,
    );
  }
};

export const getInvoicesService = async (
  request: GetInvoicesRequest,
): Promise<unknown> => {
  const traceId = getTraceId();
  const { baseUrl, timeout, source, headers, auth, httpsAgent, useProxy } = getVpmConfig({
    apiKey: request.apiKeyOverride,
    authorization: request.authorizationOverride,
  });
  const endpoint = `${baseUrl}/invoices`;
  const invoiceSource = request.source ?? source;

  logger.info({
    trace_id: traceId,
    event: "getInvoicesService_REQUEST",
    endpoint,
    accountNum: request.accountNum,
    source: invoiceSource,
  });

  try {
    const response = await axios.get(endpoint, {
      params: {
        account_num: request.accountNum,
        source: invoiceSource,
      },
      headers,
      auth,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      throw buildUpstreamHttpError(
        response.status,
        response.data,
        "invoices",
      );
    }

    logger.info({
      trace_id: traceId,
      event: "getInvoicesService_SUCCESS",
      accountNum: request.accountNum,
      upstreamStatus: response.status,
    });

    return response.data;
  } catch (error) {
    if (error instanceof PaymentCoreServiceError) {
      logger.error({
        trace_id: traceId,
        event: "getInvoicesService_FAILED",
        message: error.message,
        accountNum: request.accountNum,
        upstreamStatus: error.upstreamStatus,
        details: error.details,
      });
      throw error;
    }

    const axiosError = error as AxiosError;
    const connectionError = buildConnectionError(axiosError, "VPM invoices endpoint");
    logger.error({
      trace_id: traceId,
      event: "getInvoicesService_FAILED",
      message: connectionError.message,
      accountNum: request.accountNum,
      upstreamStatus: connectionError.upstreamStatus,
      details: connectionError.details,
    });

    throw connectionError;
  }
};

export const getChargeBreakdownService = async (
  request: GetChargeBreakdownRequest,
): Promise<unknown> => {
  const traceId = getTraceId();
  const { baseUrl, timeout, source, headers, auth, httpsAgent, useProxy } = getVpmConfig();
  const endpoint = `${baseUrl}/chargeBreakdown`;
  const invoiceSource = request.source ?? source;

  logger.info({
    trace_id: traceId,
    event: "getChargeBreakdownService_REQUEST",
    endpoint,
    invoiceId: request.invoiceId,
    source: invoiceSource,
  });

  try {
    const response = await axios.get(endpoint, {
      params: {
        invoice_id: request.invoiceId,
        source: invoiceSource,
      },
      headers,
      auth,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      throw buildUpstreamHttpError(response.status, response.data, "chargeBreakdown");
    }

    logger.info({
      trace_id: traceId,
      event: "getChargeBreakdownService_SUCCESS",
      invoiceId: request.invoiceId,
      upstreamStatus: response.status,
    });

    return response.data;
  } catch (error) {
    const knownError = error instanceof PaymentCoreServiceError
      ? error
      : buildConnectionError(error as AxiosError, "VPM charge breakdown endpoint");

    logger.error({
      trace_id: traceId,
      event: "getChargeBreakdownService_FAILED",
      message: knownError.message,
      invoiceId: request.invoiceId,
      upstreamStatus: knownError.upstreamStatus,
      details: knownError.details,
    });

    throw knownError;
  }
};

export const getInvoicePdfService = async (
  request: GetInvoicePdfRequest,
): Promise<InvoicePdfResponse> => {
  const traceId = getTraceId();
  const { baseUrl, timeout, headers, auth, httpsAgent, useProxy } = getVpmConfig({
    apiKey: request.apiKeyOverride,
    authorization: request.authorizationOverride,
  });
  const endpoint = `${baseUrl}/pdf`;

  logger.info({
    trace_id: traceId,
    event: "getInvoicePdfService_REQUEST",
    endpoint,
    accountNum: request.accountNum,
    invoiceId: request.invoiceId,
  });

  try {
    const response = await axios.get<ArrayBuffer>(endpoint, {
      params: {
        ...(request.accountNum ? { account_num: request.accountNum } : {}),
        invoice_id: request.invoiceId,
      },
      headers: {
        ...headers,
        Accept: "application/pdf",
      },
      auth,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      responseType: "arraybuffer",
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      let payload: unknown = response.data;
      try {
        const text = Buffer.from(response.data).toString("utf-8");
        payload = text ? JSON.parse(text) : text;
      } catch {
        payload = Buffer.from(response.data).toString("utf-8");
      }

      throw buildUpstreamHttpError(
        response.status,
        payload,
        "invoicePdf",
      );
    }

    logger.info({
      trace_id: traceId,
      event: "getInvoicePdfService_SUCCESS",
      accountNum: request.accountNum,
      invoiceId: request.invoiceId,
      upstreamStatus: response.status,
    });

    return {
      data: Buffer.from(response.data),
      contentType: String(response.headers["content-type"] || "application/pdf"),
      contentDisposition: response.headers["content-disposition"]
        ? String(response.headers["content-disposition"])
        : undefined,
    };
  } catch (error) {
    if (error instanceof PaymentCoreServiceError) {
      logger.error({
        trace_id: traceId,
        event: "getInvoicePdfService_FAILED",
        message: error.message,
        accountNum: request.accountNum,
        invoiceId: request.invoiceId,
        upstreamStatus: error.upstreamStatus,
        details: error.details,
      });
      throw error;
    }

    const axiosError = error as AxiosError;
    const connectionError = buildConnectionError(axiosError, "VPM invoice PDF endpoint");
    logger.error({
      trace_id: traceId,
      event: "getInvoicePdfService_FAILED",
      message: connectionError.message,
      accountNum: request.accountNum,
      invoiceId: request.invoiceId,
      upstreamStatus: connectionError.upstreamStatus,
      details: connectionError.details,
    });

    throw connectionError;
  }
};

export const accountAdjustmentService = async (
  request: AccountAdjustmentRequest,
): Promise<unknown> => {
  const traceId = getTraceId();
  const operation: AccountAdjustmentOperation = "create";
  const { endpoint, timeout, headers, httpsAgent, useProxy } =
    getAccountAdjustmentConfig(operation);

  logger.info({
    trace_id: traceId,
    event: "accountAdjustmentService_REQUEST",
    endpoint,
  });

  try {
    const response = await axios.post(endpoint, request.payload, {
      headers,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      throw buildAccountAdjustmentUpstreamHttpError(response.status, response.data, operation);
    }

    logger.info({
      trace_id: traceId,
      event: "accountAdjustmentService_SUCCESS",
      upstreamStatus: response.status,
    });

    return response.data;
  } catch (error) {
    if (error instanceof PaymentCoreServiceError) {
      logger.error({
        trace_id: traceId,
        event: "accountAdjustmentService_FAILED",
        message: error.message,
        upstreamStatus: error.upstreamStatus,
        details: error.details,
      });
      throw error;
    }

    const axiosError = error as AxiosError;
    const connectionError = buildAccountAdjustmentConnectionError(axiosError, operation);
    logger.error({
      trace_id: traceId,
      event: "accountAdjustmentService_FAILED",
      message: connectionError.message,
      upstreamStatus: connectionError.upstreamStatus,
      details: connectionError.details,
    });

    throw connectionError;
  }
};

export const createCreditAdjustmentService = async (
  request: AccountAdjustmentRequest,
): Promise<unknown> => {
  const traceId = getTraceId();
  const operation: AccountAdjustmentOperation = "create";
  const adjustmentType: AccountAdjustmentType = "CREDIT";
  const { endpoint, timeout, headers, httpsAgent, useProxy } =
    getAccountAdjustmentConfig(operation, adjustmentType);

  logger.info({
    trace_id: traceId,
    event: "createCreditAdjustmentService_REQUEST",
    endpoint,
  });

  try {
    const response = await axios.post(endpoint, request.payload, {
      headers,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      throw buildAccountAdjustmentUpstreamHttpError(response.status, response.data, operation);
    }

    logger.info({
      trace_id: traceId,
      event: "createCreditAdjustmentService_SUCCESS",
      upstreamStatus: response.status,
    });

    return response.data;
  } catch (error) {
    if (error instanceof PaymentCoreServiceError) {
      logger.error({
        trace_id: traceId,
        event: "createCreditAdjustmentService_FAILED",
        message: error.message,
        upstreamStatus: error.upstreamStatus,
        details: error.details,
      });
      throw error;
    }

    const axiosError = error as AxiosError;
    const connectionError = buildAccountAdjustmentConnectionError(axiosError, operation);
    logger.error({
      trace_id: traceId,
      event: "createCreditAdjustmentService_FAILED",
      message: connectionError.message,
      upstreamStatus: connectionError.upstreamStatus,
      details: connectionError.details,
    });

    throw connectionError;
  }
};

export const createDebitAdjustmentService = async (
  request: AccountAdjustmentRequest,
): Promise<unknown> => {
  const traceId = getTraceId();
  const operation: AccountAdjustmentOperation = "create";
  const adjustmentType: AccountAdjustmentType = "DEBIT";
  const { endpoint, timeout, headers, httpsAgent, useProxy } =
    getAccountAdjustmentConfig(operation, adjustmentType);

  logger.info({
    trace_id: traceId,
    event: "createDebitAdjustmentService_REQUEST",
    endpoint,
  });

  try {
    const response = await axios.post(endpoint, request.payload, {
      headers,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      throw buildAccountAdjustmentUpstreamHttpError(response.status, response.data, operation);
    }

    logger.info({
      trace_id: traceId,
      event: "createDebitAdjustmentService_SUCCESS",
      upstreamStatus: response.status,
    });

    return response.data;
  } catch (error) {
    if (error instanceof PaymentCoreServiceError) {
      logger.error({
        trace_id: traceId,
        event: "createDebitAdjustmentService_FAILED",
        message: error.message,
        upstreamStatus: error.upstreamStatus,
        details: error.details,
      });
      throw error;
    }

    const axiosError = error as AxiosError;
    const connectionError = buildAccountAdjustmentConnectionError(axiosError, operation);
    logger.error({
      trace_id: traceId,
      event: "createDebitAdjustmentService_FAILED",
      message: connectionError.message,
      upstreamStatus: connectionError.upstreamStatus,
      details: connectionError.details,
    });

    throw connectionError;
  }
};

export const getAccountAdjustmentService = async (
  request: GetAccountAdjustmentRequest,
): Promise<unknown> => {
  const traceId = getTraceId();
  const operation: AccountAdjustmentOperation = "get";
  const { endpoint, timeout, headers,  httpsAgent, useProxy } =
    getAccountAdjustmentConfig(operation, request.adjustmentType);
  const requestParams = withAccountNumberAliases(request.params || {});
  if (request.accountNumber) {
    requestParams.accountNumber = request.accountNumber;
    if (!requestParams.account_num) {
      requestParams.account_num = request.accountNumber;
    }
  }
  const requestHeaders = request.accountNumber
    ? { ...headers, accountNumber: request.accountNumber }
    : headers;

  logger.info({
    trace_id: traceId,
    event: "getAccountAdjustmentService_REQUEST",
    endpoint,
    adjustmentType: request.adjustmentType,
    hasAccountNumber: Boolean(request.accountNumber),
  });

  try {
    const response = await axios.get(endpoint, {
      params: requestParams,
      headers: requestHeaders,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      throw buildAccountAdjustmentUpstreamHttpError(response.status, response.data, operation);
    }

    logger.info({
      trace_id: traceId,
      event: "getAccountAdjustmentService_SUCCESS",
      upstreamStatus: response.status,
    });
    return response.data;
  } catch (error) {
    if (error instanceof PaymentCoreServiceError) {
      logger.error({
        trace_id: traceId,
        event: "getAccountAdjustmentService_FAILED",
        message: error.message,
        upstreamStatus: error.upstreamStatus,
        details: error.details,
      });
      throw error;
    }

    const axiosError = error as AxiosError;
    const connectionError = buildAccountAdjustmentConnectionError(axiosError, operation);
    logger.error({
      trace_id: traceId,
      event: "getAccountAdjustmentService_FAILED",
      message: connectionError.message,
      upstreamStatus: connectionError.upstreamStatus,
      details: connectionError.details,
    });

    throw connectionError;
  }
};

export const reverseAccountAdjustmentService = async (
  request: ReverseAccountAdjustmentRequest,
): Promise<unknown> => {
  const traceId = getTraceId();
  const operation: AccountAdjustmentOperation = "reverse";
  const { endpoint, timeout, headers,  httpsAgent, useProxy } =
    getAccountAdjustmentConfig(operation);

  logger.info({
    trace_id: traceId,
    event: "reverseAccountAdjustmentService_REQUEST",
    endpoint,
  });

  try {
    const response = await axios.post(endpoint, request.payload, {
      headers,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      throw buildAccountAdjustmentUpstreamHttpError(response.status, response.data, operation);
    }

    logger.info({
      trace_id: traceId,
      event: "reverseAccountAdjustmentService_SUCCESS",
      upstreamStatus: response.status,
    });

    return response.data;
  } catch (error) {
    if (error instanceof PaymentCoreServiceError) {
      logger.error({
        trace_id: traceId,
        event: "reverseAccountAdjustmentService_FAILED",
        message: error.message,
        upstreamStatus: error.upstreamStatus,
        details: error.details,
      });
      throw error;
    }

    const axiosError = error as AxiosError;
    const connectionError = buildAccountAdjustmentConnectionError(axiosError, operation);
    logger.error({
      trace_id: traceId,
      event: "reverseAccountAdjustmentService_FAILED",
      message: connectionError.message,
      upstreamStatus: connectionError.upstreamStatus,
      details: connectionError.details,
    });

    throw connectionError;
  }
};

export const updateAdjustmentsService = async (
  request: UpdateAdjustmentsRequest,
): Promise<unknown> => {
  const traceId = getTraceId();
  const { baseUrl, timeout, headers, httpsAgent, useProxy } = getPaymentCoreConfig();
  const endpoint = `${baseUrl}/v1/updateAdjustments`;

  logger.info({
    trace_id: traceId,
    event: "updateAdjustmentsService_REQUEST",
    endpoint,
  });

  try {
    const response = await axios.post(endpoint, request.payload, {
      headers,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      const statusCode =
        response.status >= 400 && response.status < 500 ? response.status : 502;
      const upstreamMessage = getUpstreamErrorMessage(response.data);
      const message = upstreamMessage
        ? `Payment Core responded with HTTP ${response.status}: ${upstreamMessage}`
        : `Payment Core responded with HTTP ${response.status}`;
      throw new PaymentCoreServiceError(message, statusCode, response.status, response.data);
    }

    logger.info({
      trace_id: traceId,
      event: "updateAdjustmentsService_SUCCESS",
      upstreamStatus: response.status,
    });

    return response.data;
  } catch (error) {
    if (error instanceof PaymentCoreServiceError) {
      logger.error({
        trace_id: traceId,
        event: "updateAdjustmentsService_FAILED",
        message: error.message,
        upstreamStatus: error.upstreamStatus,
        details: error.details,
      });
      throw error;
    }

    const axiosError = error as AxiosError;
    const isTimeout = axiosError.code === "ECONNABORTED";
    const upstreamReached = Boolean(axiosError.response);
    const message = isTimeout
      ? "Payment Core updateAdjustments request timed out before receiving a response"
      : upstreamReached
        ? "Received an error response while connecting to Payment Core updateAdjustments endpoint"
        : "Unable to connect to Payment Core updateAdjustments endpoint";

    logger.error({
      trace_id: traceId,
      event: "updateAdjustmentsService_FAILED",
      message,
      code: axiosError.code,
      upstreamStatus: axiosError.response?.status,
      upstreamReached,
    });

    throw new PaymentCoreServiceError(
      message,
      isTimeout ? 504 : 502,
      axiosError.response?.status,
    );
  }
};
