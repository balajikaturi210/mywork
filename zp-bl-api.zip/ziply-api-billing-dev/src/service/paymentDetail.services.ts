import pool from "../config/zbpDb";
import logger from "../logger/logger";
import { getTraceId } from "../utils/logger";
import { toPaymentCoreShape } from "../utils/paymentDetail";

/**
 * One payment with everything its detail screen shows, from the database in three indexed lookups run together:
 * the payment with its account and payment method, the method's custom fields, and the payment's status history.
 * Returns null when there is no such payment.
 */
export const getPaymentDetailService = async (paymentId: string) => {
  const traceId = getTraceId();
  try {
    const [paymentResult, fieldsResult, historyResult] = await Promise.all([
      pool.query(
        `SELECT
           p.id, p.billing_account_id, p.payment_method_id, p.payment_method_type, p.description, p.status, p.occurred_on,
           p.amount, p.currency, p.unapplied_amount, p.cancel_amount, p.refund_amount, p.surcharge_amount,
           p.payment_source_type, p.reference, p.auth_code, p.transaction_number, p.mark_for_settlement,
           ba.account_num, ba.first_name AS account_first_name, ba.last_name AS account_last_name,
           pm.nickname, pm.payment_type AS method_payment_type, ct.description AS method_category,
           pm.card_holder_firstname, pm.card_holder_lastname, pm.card_holder_name, pm.card_type, pm.card_identifier_last_four,
           pm.card_expiration, pm.bank_account_number_last_four, pm.bank_account_type
         FROM zbp.payment p
         LEFT JOIN zbp.billing_account ba ON ba.id = p.billing_account_id
         LEFT JOIN zbp.payment_method pm ON pm.id = p.payment_method_id
         LEFT JOIN zbp.payment_category_type ct ON ct.id = pm.payment_category_id
         WHERE p.id = $1`,
        [paymentId],
      ),
      pool.query(
        `SELECT v.id, v.custom_field_id, v.name, v.value, v.custom_field_enabled
         FROM zbp.payment_method_custom_field_value v
         WHERE v.payment_method_id = (SELECT payment_method_id FROM zbp.payment WHERE id = $1)
         ORDER BY v.name, v.id`,
        [paymentId],
      ),
      pool.query(
        `SELECT h.id, h.status_id, h.reason, h.reason_code, h.status_date, h.created_by
         FROM zbp.payment_status_history h
         WHERE h.payment_id = $1
         ORDER BY h.status_date, h.id`,
        [paymentId],
      ),
    ]);

    const row = paymentResult.rows[0];
    return row ? toPaymentCoreShape(row, fieldsResult.rows, historyResult.rows) : null;
  } catch (err: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentDetailService_FAILED",
      message: err?.message || String(err),
      paymentId,
    });
    throw err;
  }
};
