import axios, { AxiosError } from "axios";
import logger from "../logger/logger";
import { getTraceId } from "../utils/logger";
import { getPaymentRouterConfig } from "../utils/paymentRouter.util";
import { PaymentCoreServiceError } from "../types/paymentCore.types";
import { getUpstreamErrorMessage } from "../utils/paymentCore.util";

export const getPaymentTransactionHistoryService = async (
  accountNumber: string,
): Promise<unknown> => {
  const traceId = getTraceId();
  const { baseUrl, timeout, headers, httpsAgent, useProxy } =
    getPaymentRouterConfig();
  const endpoint = `${baseUrl}/v1/payment`;

  try {
    const response = await axios.get(endpoint, {
      params: {
        account_num: accountNumber,
        expand: "current_status_entry",
      },
      headers,
      httpsAgent,
      proxy: useProxy ? undefined : false,
      timeout,
      validateStatus: () => true,
    });

    if (response.status >= 400) {
      const statusCode =
        response.status >= 400 && response.status < 500 ? response.status : 502;
      const upstreamMessage = getUpstreamErrorMessage(response.data);
      const message = upstreamMessage
        ? `Payment Router responded with HTTP ${response.status}: ${upstreamMessage}`
        : `Payment Router responded with HTTP ${response.status}`;
      throw new PaymentCoreServiceError(
        message,
        statusCode,
        response.status,
        response.data,
      );
    }

    logger.info({
      trace_id: traceId,
      event: "getPaymentTransactionHistoryService_SUCCESS",
      accountNumber,
      upstreamStatus: response.status,
    });

    return response.data;
  } catch (error) {
    if (error instanceof PaymentCoreServiceError) {
      logger.error({
        trace_id: traceId,
        event: "getPaymentTransactionHistoryService_FAILED",
        message: error.message,
        accountNumber,
        upstreamStatus: error.upstreamStatus,
      });
      throw error;
    }

    const axiosError = error as AxiosError;
    const isTimeout = axiosError.code === "ECONNABORTED";
    const upstreamReached = Boolean(axiosError.response);
    const message = isTimeout
      ? "Payment Router request timed out before receiving a response"
      : upstreamReached
        ? "Received an error response while connecting to Payment Router"
        : "Unable to connect to Payment Router API";

    logger.error({
      trace_id: traceId,
      event: "getPaymentTransactionHistoryService_FAILED",
      message,
      accountNumber,
      code: axiosError.code,
      upstreamStatus: axiosError.response?.status,
      upstreamReached,
    });

    throw new PaymentCoreServiceError(
      message,
      isTimeout ? 504 : 502,
      axiosError.response?.status,
    );
  }
};
