import { zbpSearchPool as pool } from "../config/zbpDb";
import logger from "../logger/logger";
import { getTraceId } from "../utils/logger";
import { PAYMENT_TYPE_SQL, type PaymentSearchCriteria } from "../utils/paymentSearch";

/** What the customer's Payments tab shows about the account whatever the filters are. */
export type AccountPaymentHighlights = {
  last_payment_amount: number | null;
  last_payment_on: string | null;
  failed_last_90_days: number;
};

export type PaymentSearchSummary = {
  total: number;
  success: number;
  failure: number;
  /** cancelled, void and any other status */
  other: number;
  amount_processed: number;
  amount_failed: number;
};

const num = (value: unknown): number => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
};

const escapeLike = (text: string): string => text.replace(/[\\%_]/g, (character) => `\\${character}`);

/** Start of the first day of the range, in UTC. */
export const rangeStart = (days: number, now: Date = new Date()): Date =>
  new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() - (days - 1)));

/**
 * WITH clause and WHERE clause shared by the page of rows and the summary so both always describe the same payments.
 * Validation attempts (the $1 card checks) are left out unless the payment type asks for them.
 * An account number or name is resolved to its accounts first (MATERIALIZED stops the planner from walking every
 * payment newest-first and testing each one's account), then only those accounts' payments are read.
 */
export const buildPaymentWhere = (criteria: PaymentSearchCriteria, now: Date = new Date()) => {
  const binds: Array<string | number | Date> = [];
  const conditions: string[] = [];
  if (criteria.days !== undefined) {
    binds.push(rangeStart(criteria.days, now));
    conditions.push("p.created_on >= $1");
  }
  const accountConditions: string[] = [];
  const bind = (value: string | number): string => {
    binds.push(value);
    return `$${binds.length}`;
  };

  if (criteria.status === "success") conditions.push("p.status = 'COMPLETED'");
  if (criteria.status === "failure") conditions.push("p.status IN ('PROCESSING_ERROR', 'FAILED')");
  if (criteria.status === "other") conditions.push("(p.status IS NULL OR p.status NOT IN ('COMPLETED', 'PROCESSING_ERROR', 'FAILED'))");

  if (criteria.paymentType === "validation") conditions.push(`${PAYMENT_TYPE_SQL} = 'Validation'`);
  else if (criteria.paymentType === "recurring") conditions.push(`${PAYMENT_TYPE_SQL} = 'Recurring'`);
  else if (criteria.paymentType === "one-time") conditions.push(`${PAYMENT_TYPE_SQL} = 'One Time'`);
  else conditions.push(`${PAYMENT_TYPE_SQL} IS DISTINCT FROM 'Validation'`);

  if (criteria.accountNumber) accountConditions.push(`ba.account_num LIKE ${bind(`${escapeLike(criteria.accountNumber)}%`)}`);
  if (criteria.accountName) {
    accountConditions.push(`CONCAT_WS(' ', ba.first_name, ba.last_name) ILIKE ${bind(`%${escapeLike(criteria.accountName)}%`)}`);
  }
  if (accountConditions.length > 0) conditions.push("p.billing_account_id IN (SELECT id FROM matched_accounts)");
  // One account by its id: a plain indexed equality on the payment itself, no lookup of accounts needed.
  if (criteria.billingAccountId) conditions.push(`p.billing_account_id = ${bind(criteria.billingAccountId)}`);
  if (criteria.minAmount !== undefined) conditions.push(`p.amount >= ${bind(criteria.minAmount)}`);

  return {
    with: accountConditions.length > 0
      ? `WITH matched_accounts AS MATERIALIZED (SELECT ba.id FROM zbp.billing_account ba WHERE ${accountConditions.join(" AND ")})`
      : "",
    where: conditions.join("\n        AND "),
    binds,
  };
};

/**
 * The last payment and the recent failures of one account, whatever the filters are. Validation attempts (the $1 card
 * checks) count as neither a payment nor a failure here, the same as in the list.
 */
export const accountHighlightsSql = `
      SELECT last_payment.amount      AS last_payment_amount,
             last_payment.occurred_on AS last_payment_on,
             failures.failed          AS failed_last_90_days
      FROM (
        SELECT COUNT(*) AS failed
        FROM zbp.payment p
        WHERE p.billing_account_id = $1
          AND p.created_on >= $2
          AND p.status IN ('PROCESSING_ERROR', 'FAILED')
          AND ${PAYMENT_TYPE_SQL} IS DISTINCT FROM 'Validation'
      ) failures
      LEFT JOIN LATERAL (
        SELECT p.amount, p.occurred_on
        FROM zbp.payment p
        WHERE p.billing_account_id = $1
          AND p.status = 'COMPLETED'
          AND ${PAYMENT_TYPE_SQL} IS DISTINCT FROM 'Validation'
        ORDER BY p.occurred_on DESC, p.id DESC
        LIMIT 1
      ) last_payment ON TRUE`;

/** One page of payments plus totals for everything that matches, newest first. */
export const searchPaymentsService = async (criteria: PaymentSearchCriteria, page: number, perPage: number) => {
  const traceId = getTraceId();
  try {
    const { with: withClause, where, binds } = buildPaymentWhere(criteria);

    const rowsSql = `
      ${withClause}
      SELECT
        p.id,
        p.billing_account_id,
        ba.account_num,
        CONCAT_WS(' ', ba.first_name, ba.last_name) AS account_name,
        ba.billing_ind,
        ba.status AS account_status,
        p.occurred_on,
        p.status,
        p.payment_method_id,
        p.payment_method_type,
        p.payment_method_type_description,
        ${PAYMENT_TYPE_SQL} AS payment_type,
        p.amount,
        p.unapplied_amount,
        p.cancel_amount,
        p.refund_amount,
        p.surcharge_amount
      FROM zbp.payment p
      LEFT JOIN zbp.billing_account ba ON ba.id = p.billing_account_id
      WHERE ${where}
      ORDER BY p.created_on DESC, p.id DESC
      LIMIT $${binds.length + 1} OFFSET $${binds.length + 2}`;

    const summarySql = `
      ${withClause}
      SELECT
        COUNT(*)                                                               AS total,
        COUNT(*) FILTER (WHERE p.status = 'COMPLETED')                         AS success,
        COUNT(*) FILTER (WHERE p.status IN ('PROCESSING_ERROR', 'FAILED'))     AS failure,
        COALESCE(SUM(p.amount) FILTER (WHERE p.status = 'COMPLETED'), 0)       AS amount_processed,
        COALESCE(SUM(p.amount) FILTER (WHERE p.status IN ('PROCESSING_ERROR', 'FAILED')), 0)    AS amount_failed
      FROM zbp.payment p
      WHERE ${where}`;

    const [rowsResult, summaryResult, highlightsResult] = await Promise.all([
      pool.query(rowsSql, [...binds, perPage, (page - 1) * perPage]),
      pool.query(summarySql, binds),
      criteria.billingAccountId
        ? pool.query(accountHighlightsSql, [criteria.billingAccountId, rangeStart(90)])
        : Promise.resolve(null),
    ]);

    const raw = summaryResult.rows[0] ?? {};
    const total = num(raw.total);
    const success = num(raw.success);
    const failure = num(raw.failure);
    const summary: PaymentSearchSummary = {
      total,
      success,
      failure,
      other: Math.max(total - success - failure, 0),
      amount_processed: num(raw.amount_processed),
      amount_failed: num(raw.amount_failed),
    };

    const highlights = highlightsResult?.rows[0];
    const account: AccountPaymentHighlights | undefined = highlights
      ? {
        last_payment_amount: highlights.last_payment_amount === null ? null : num(highlights.last_payment_amount),
        last_payment_on: highlights.last_payment_on ?? null,
        failed_last_90_days: num(highlights.failed_last_90_days),
      }
      : undefined;

    return { rows: rowsResult.rows, total, page, perPage, summary, ...(account ? { account } : {}) };
  } catch (err: any) {
    logger.error({
      trace_id: traceId,
      event: "searchPaymentsService_FAILED",
      message: err?.message || String(err),
    });
    throw err;
  }
};
