import { getTraceId } from "../utils/logger";
import { runQuery } from "../config/snowflake";
import logger, {
  eventLog,
  categoryOpt,
  eventOpt,
  inbound,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "service/paymentreports.services";
const httpLogRes = logRes();
const inboundLog = inbound();

/**
* Payment Failure Reason Report API
*
* Returns payment failure reasons for failed payments
* grouped by day and reason.
*
* Used to analyze payment failures and identify
* the most common failure reasons.
*/
export const getPaymentFailureReasonService = async (
 days: number,
 src: string,
 traceId:string
) => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getPaymentFailureReasonService";
 try {
   const sql = `WITH failed_pmts AS (
                SELECT p.id,
                    TO_CHAR(DATE_TRUNC('day',p.created_on),'YYYY-MM-DD') AS day
                FROM payment p
                WHERE p.created_on >= DATEADD('day',-${days},CURRENT_DATE())
                  AND p.created_on  < CURRENT_DATE()
                  AND p.payment_source_type = '${src}'
                  AND p.status = 'PROCESSING_ERROR'
            ),
            latest_reason AS (
                SELECT psh.payment_id,
                    COALESCE(NULLIF(TRIM(psh.reason),''),'— no reason —') AS reason
                FROM payment_status_history psh
                JOIN failed_pmts fp ON fp.id=psh.payment_id
                QUALIFY ROW_NUMBER() OVER (PARTITION BY psh.payment_id ORDER BY psh.created_on DESC)=1
            )
            SELECT fp.day, COALESCE(lr.reason,'— no reason —') AS "reason", COUNT(*) AS "cnt"
            FROM failed_pmts fp
            LEFT JOIN latest_reason lr ON lr.payment_id=fp.id
            GROUP BY fp.day, lr.reason ORDER BY fp.day, "cnt" DESC`;
   const rows = await runQuery(sql);
   return rows;
 } catch (error:any) {
  httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in getPaymentFailureReasonService to  fetch Payment Failure Reason Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });
   throw error;
 }
};

/*** 
 * Autopay No PM API 
*/

export const getAutopayNoPmService = async (
 days: number,
 src: string,
 traceId:string
) => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getAutopayNoPmService";
 try {
logger.info({
       traceId: getTraceId(),
       timestamp: new Date().toISOString(),
       level: "info",
       message: "Fetching autopay details",
       context: {
           api: "/autopay-no-pm",
           days,
           src,
       },
   });

   const sql = `SELECT
                ba.billing_account_category  AS category,
                COUNT(*)                     AS accounts
            FROM billing_account ba
            LEFT JOIN billing_account_payment_method bapm
                ON  bapm.billing_account_id = ba.id
                AND bapm.is_default = TRUE
                AND (bapm.valid_to IS NULL OR bapm.valid_to >= CURRENT_DATE())
            WHERE ba.status               = 'BILLING_ACCOUNT_ACTIVE'
              AND ba.automatic_payment = TRUE
              AND bapm.billing_account_id IS NULL
            GROUP BY ba.billing_account_category
            ORDER BY accounts DESC`;
    const rows = await runQuery(sql);
   return rows;
 } catch (error:any) {
  httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in getAutopayNoPmService to fetch Autopay PM service: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });
   throw error;
 }
};

/*** 
 * Autopay Processing API 
*/

export const getAutopayProcessingService = async (
 months?: number,
 traceId?:string
) => {
 const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getAutopayProcessingService";
 try {
   const sql = `WITH pmt_base AS (
   SELECT p.id AS payment_id, p.billing_account_id,
                    DATE_TRUNC('month', p.created_on)::DATE AS pay_month,
                    p.created_on AS pay_date, p.status
                FROM payment p
                WHERE p.payment_source_type = 'BATCH'
                  AND p.created_on >= DATEADD('month', -${months}, CURRENT_DATE())
                  AND p.status IN ('COMPLETED', 'FAILED', 'PROCESSING_ERROR')
            ),
            with_inv AS (
                SELECT pb.payment_id, pb.billing_account_id,
                    pb.pay_month, pb.pay_date, pb.status,
                    MIN(COALESCE(i.auto_pay_date, i.due_date))::DATE AS earliest_ap_date
                FROM pmt_base pb
                LEFT JOIN payment_application pa ON pa.payment_id = pb.payment_id
                LEFT JOIN invoice i              ON i.id = pa.invoice_id
                GROUP BY pb.payment_id, pb.billing_account_id,
                         pb.pay_month, pb.pay_date, pb.status
            ),
            classified AS (
                SELECT billing_account_id, pay_month, pay_date, earliest_ap_date,
                    CASE
                        WHEN status = 'COMPLETED'
                         AND DATE_TRUNC('month', earliest_ap_date) = pay_month
                            THEN 'On Time'
                        WHEN status = 'COMPLETED'
                            THEN 'Late'
                        ELSE 'Failed'
                    END AS outcome
                FROM with_inv
            )
            SELECT TO_CHAR(pay_month, 'YYYY-MM') AS month,
                   outcome, COUNT(*) AS count
            FROM classified c
            WHERE c.outcome != 'Late'
               OR EXISTS (
                   SELECT 1 FROM invoice i_next
                   WHERE i_next.billing_account_id = c.billing_account_id
                     AND COALESCE(i_next.auto_pay_date, i_next.due_date)
                             > LAST_DAY(DATE_TRUNC('month', c.earliest_ap_date)::DATE)
                     AND COALESCE(i_next.auto_pay_date, i_next.due_date) <= c.pay_date
               )
            GROUP BY pay_month, outcome ORDER BY month, outcome`;
    const rows = await runQuery(sql);
   return rows;
 } catch (error:any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
 logger.error({
      message: `Error in getAutopayProcessingService to  fetch AutoPay Prcocessing Service Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });
   throw error;
 }
};

export const getAutopayLateDetailService = async (
 months?: number,
 traceId?:string
) => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getAutopayLateDetailService";
 try {
   const sql = ` WITH pmt_base AS (
                SELECT p.id AS payment_id, p.billing_account_id,
                    DATE_TRUNC('month', p.created_on)::DATE AS pay_month,
                    p.created_on::DATE AS pay_date
                FROM payment p
                WHERE p.payment_source_type = 'BATCH'
                  AND p.status              = 'COMPLETED'
                  AND p.created_on >= DATEADD('month', -${months}, CURRENT_DATE())
            ),
            with_inv AS (
                SELECT pb.payment_id, pb.billing_account_id,
                    pb.pay_month, pb.pay_date,
                    MIN(COALESCE(i.auto_pay_date, i.due_date))::DATE AS earliest_ap_date
                FROM pmt_base pb
                LEFT JOIN payment_application pa ON pa.payment_id = pb.payment_id
                LEFT JOIN invoice i              ON i.id = pa.invoice_id
                GROUP BY pb.payment_id, pb.billing_account_id, pb.pay_month, pb.pay_date
            ),
            late_only AS (
                SELECT wi.billing_account_id, wi.pay_month, wi.pay_date,
                    wi.earliest_ap_date,
                    DATEDIFF('day', wi.earliest_ap_date, wi.pay_date) AS days_late,
                    CASE
                        WHEN DATEDIFF('day', wi.earliest_ap_date, wi.pay_date) <= 0  THEN 'Early / Same-day'
                        WHEN DATEDIFF('day', wi.earliest_ap_date, wi.pay_date) <=  7 THEN '1–7 days'
                        WHEN DATEDIFF('day', wi.earliest_ap_date, wi.pay_date) <= 14 THEN '8–14 days'
                        WHEN DATEDIFF('day', wi.earliest_ap_date, wi.pay_date) <= 30 THEN '15–30 days'
                        WHEN DATEDIFF('day', wi.earliest_ap_date, wi.pay_date) <= 60 THEN '31–60 days'
                        ELSE '60+ days'
                    END AS late_bucket
                FROM with_inv wi
                WHERE DATE_TRUNC('month', wi.earliest_ap_date) != wi.pay_month
                  AND wi.earliest_ap_date IS NOT NULL
                  AND EXISTS (
                      SELECT 1 FROM invoice i_next
                      WHERE i_next.billing_account_id = wi.billing_account_id
                        AND COALESCE(i_next.auto_pay_date, i_next.due_date)
                                > LAST_DAY(DATE_TRUNC('month', wi.earliest_ap_date)::DATE)
                        AND COALESCE(i_next.auto_pay_date, i_next.due_date) <= wi.pay_date
                  )
            )
            SELECT TO_CHAR(pay_month, 'YYYY-MM') AS month, late_bucket,
                COUNT(*) AS count,
                ROUND(AVG(days_late), 1) AS avg_days_late,
                MIN(days_late) AS min_days_late,
                MAX(days_late) AS max_days_late
            FROM late_only
            GROUP BY pay_month, late_bucket
            ORDER BY month,
                CASE late_bucket
                    WHEN 'Early / Same-day' THEN 0
                    WHEN '1–7 days'         THEN 1
                    WHEN '8–14 days'        THEN 2
                    WHEN '15–30 days'       THEN 3
                    WHEN '31–60 days'       THEN 4
                    ELSE                         5
                END`;
    const rows = await runQuery(sql);
   return rows;
 } catch (error:any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
 logger.error({
      message: `Error in getAutopayLateDetailService to  fetch AutoPay Late Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });
throw error;
 }
};

export const getAutopayLateReasonService = async (
 months:  number,
 traceId:string
) => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getAutopayLateReasonService";
 try {
    const pay_buf = months + 4;


   const sql = `WITH late_batch AS (
                SELECT p.id AS payment_id, p.billing_account_id,
                    DATE_TRUNC('month', p.created_on)::DATE AS pay_month,
                    DATE_TRUNC('month',
                        MIN(COALESCE(i.auto_pay_date, i.due_date))::DATE)::DATE AS due_month,
                    MAX(p.created_on) AS pay_date
                FROM payment p
                LEFT JOIN payment_application pa ON pa.payment_id = p.id
                LEFT JOIN invoice i              ON i.id = pa.invoice_id
                WHERE p.payment_source_type = 'BATCH'
                  AND p.status              = 'COMPLETED'
                  AND p.created_on >= DATEADD('month', -${pay_buf}, CURRENT_DATE())
                GROUP BY p.id, p.billing_account_id,
                         DATE_TRUNC('month', p.created_on)::DATE
                HAVING MIN(COALESCE(i.auto_pay_date, i.due_date)) IS NOT NULL
                   AND DATE_TRUNC('month',
                           MIN(COALESCE(i.auto_pay_date, i.due_date))::DATE)
                       != DATE_TRUNC('month', p.created_on)::DATE
                   AND DATE_TRUNC('month',
                           MIN(COALESCE(i.auto_pay_date, i.due_date))::DATE)
                       >= DATEADD('month', -${months}, CURRENT_DATE())
            ),
            batch_failures AS (
                SELECT DISTINCT billing_account_id,
                       DATE_TRUNC('month', created_on)::DATE AS fail_month
                FROM payment
                WHERE payment_source_type = 'BATCH'
                  AND status IN ('PROCESSING_ERROR', 'FAILED')
                  AND created_on >= DATEADD('month', -${pay_buf}, CURRENT_DATE())
            ),
            otp_payments AS (
                SELECT DISTINCT billing_account_id,
                       DATE_TRUNC('month', created_on)::DATE AS otp_month
                FROM payment
                WHERE payment_source_type = 'API'
                  AND status              = 'COMPLETED'
                  AND created_on >= DATEADD('month', -${pay_buf}, CURRENT_DATE())
            ),
            autopay_enrollment AS (
                SELECT billing_account_id, MIN(created_on) AS first_void_on
                FROM payment
                WHERE status='VOID' AND payment_source_type='BATCH'
                GROUP BY billing_account_id
            )
            SELECT TO_CHAR(lb.due_month, 'YYYY-MM') AS month,
                CASE
                    WHEN bf.billing_account_id IS NOT NULL
                     AND otp.billing_account_id IS NOT NULL THEN 'AutoPay Failed + OTP in Due Month'
                    WHEN bf.billing_account_id IS NOT NULL  THEN 'Delayed — AutoPay Retry After Failure'
                    WHEN otp.billing_account_id IS NOT NULL THEN 'OTP Made in Due Month (No Prior Failure)'
                    ELSE                                         'No Attempt or OTP in Due Month'
                END AS reason,
                COUNT(*) AS count
            FROM late_batch lb
            LEFT JOIN batch_failures bf
                ON  bf.billing_account_id = lb.billing_account_id
                AND bf.fail_month         = lb.due_month
            LEFT JOIN otp_payments otp
                ON  otp.billing_account_id = lb.billing_account_id
                AND otp.otp_month          = lb.due_month
            LEFT JOIN autopay_enrollment ae
                ON  ae.billing_account_id = lb.billing_account_id
            WHERE NOT (
                bf.billing_account_id  IS NULL
                AND otp.billing_account_id IS NULL
                AND ae.first_void_on   IS NOT NULL
                AND ae.first_void_on    > LAST_DAY(lb.due_month)
            )
            AND EXISTS (
                SELECT 1 FROM invoice i_next
                WHERE i_next.billing_account_id = lb.billing_account_id
                  AND COALESCE(i_next.auto_pay_date, i_next.due_date) > LAST_DAY(lb.due_month)
                  AND COALESCE(i_next.auto_pay_date, i_next.due_date) <= lb.pay_date
            )
            GROUP BY lb.due_month, reason ORDER BY lb.due_month, count DESC`;
    const rows = await runQuery(sql);
   return rows;
 } catch (error:any) {
   httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
 logger.error({
      message: `Error in getAutopayLateReasonService to  fetch AutoPay Late Reason Service Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });
throw error;
 }
};