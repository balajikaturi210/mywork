import { getTraceId } from "../utils/logger";
import pool from "../config/zbpDb";
import logger from "../logger/logger";
import type { CustomerSearchCriteria } from "../utils/customerSearch";
import { PAYMENT_TYPE_SQL } from "../utils/paymentSearch";

const toDpiAccountNum = (value: unknown): string => {
  const accountNum = String(value ?? "").trim();
  if (!accountNum) {
    return "";
  }

  if (/^\d+$/.test(accountNum) && accountNum.length > 10) {
    return accountNum.slice(-10);
  }

  return accountNum;
};

const mapLegacyTypeLabel = (value: unknown): string | undefined => {
  const raw = String(value ?? "").trim().toLowerCase();
  if (!raw) {
    return undefined;
  }

  const normalized = raw.replace(/[^a-z0-9]/g, "");

  if (normalized === "legacyr") {
    return "Residential";
  }

  if (normalized === "legacyb") {
    return "Business";
  }

  return undefined;
};

export const getAccountPaymentsService = async (
  accountNum: string,
  days: number = 30,
) => {
  const traceId = getTraceId();
  try {
    const sql = `
      SELECT
        ba.account_num AS "account_num",
        ba.status AS "account_status",
        p.id AS "payment_id",
        p.amount AS "payment_amount",
        p.status AS "payment_status",
        p.created_on AS "payment_created_on"
      FROM zbp.billing_account ba
      LEFT JOIN zbp.payment p
        ON p.billing_account_id = ba.id
      WHERE ba.account_num = $1
        AND p.created_on >= CURRENT_DATE - ($2 || ' days')::interval
      ORDER BY p.created_on DESC
    `;

    const rows = (await pool.query<any>(sql, [accountNum, String(days)])).rows;
    return rows;
  } catch (err: any) {
    logger.error({
      trace_id: traceId,
      event: "getAccountPaymentsService_FAILED",
      message: err?.message || String(err),
    });
    throw err;
  }
};

export const getPaymentHistoryOnCustomRange = async (
  months: number = 1,
  skip: number = 0,
  limit: number = 200,
) => {
  const traceId = getTraceId();
  try {
    const cutoffDate = new Date();
    cutoffDate.setMonth(cutoffDate.getMonth() - months);

    const sql = `
      SELECT
        p.id,
        p.billing_account_id,
        ba.account_num,
        CONCAT_WS(' ', ba.first_name, ba.last_name) AS account_name,
        p.occurred_on,
        p.status,
        p.payment_method_id,
        p.payment_method_type,
        p.payment_method_type_description,
        ${PAYMENT_TYPE_SQL} AS payment_type,
        p.amount,
        p.unapplied_amount,
        p.cancel_amount,
        p.refund_amount,
        p.surcharge_amount
      FROM zbp.payment p
      JOIN zbp.billing_account ba
        ON ba.id = p.billing_account_id
      WHERE p.created_on >= $1
      ORDER BY p.created_on DESC, p.id DESC
      LIMIT $2 OFFSET $3
    `;

    const rows = (await pool.query(sql, [cutoffDate, limit, skip])).rows;
    return rows;
  } catch (err: any) {
    logger.error({
      trace_id: traceId,
      event: "getPaymentHistoryOnCustomRange_FAILED",
      message: err?.message || String(err),
    });
    throw err;
  }
};

export const getAccountWithAddressService = async (
  accountNum?: string,
  page: number = 1,
  perPage: number = 10,
) => {
  const traceId = getTraceId();
  try {
    const offset = (Math.max(1, page) - 1) * perPage;

    const pgSql = `
      SELECT
        ba.account_num,
        ba.first_name,
        ba.last_name,
        ba."type",
        ba.billing_account_category AS customer_type,
        ba.primary_email,
        ba.telephone_number,
        CONCAT_WS(', ', a.street_1 , a.street_2, a.city, a.region_or_state, a.country) AS billing_address
      FROM zbp.billing_account ba
      LEFT JOIN LATERAL (
        SELECT billing_address_street_1 as street_1, billing_address_street_2 as street_2, billing_address_city as city, billing_address_region_or_state as region_or_state, billing_address_country as country
        FROM zbp.billing_account_address baa2
        WHERE baa2.billing_account_id = ba.id
        ORDER BY baa2.billing_account_id
        LIMIT 1
      ) a ON true
      WHERE ($1::text IS NULL OR ba.account_num = $1::text)
      ORDER BY ba.account_num
      LIMIT $2 OFFSET $3
    `;

    const binds: any[] = [accountNum ?? null, perPage, offset];
    const pgRes = await pool.query(pgSql, binds);
    const rows = pgRes.rows;

    const countSql = `
      SELECT COUNT(*)::int AS total_count
      FROM zbp.billing_account ba
      WHERE ($1::text IS NULL OR ba.account_num = $1::text)
    `;
    const countRes = await pool.query(countSql, [accountNum ?? null]);
    const total = Number(countRes.rows?.[0]?.total_count ?? 0);

    return { rows, page: Math.max(1, page), perPage, total };
  } catch (err: any) {
    logger.error({
      trace_id: traceId,
      event: "getAccountWithAddressService_FAILED",
      message: err?.message || String(err),
    });
    throw err;
  }
};

export const getAccountsService = async (
  accountNum?: string,
  page: number = 1,
  perPage: number = 10,
) => {
  const traceId = getTraceId();
  try {
    const offset = (Math.max(1, page) - 1) * perPage;

    const sql = `
      SELECT
        account_num,
        first_name,
        last_name,
        "type",
        billing_account_category AS customer_type,
        primary_email,
        telephone_number
      FROM zbp.billing_account
      WHERE ($1::text IS NULL OR account_num = $1::text)
      ORDER BY account_num
      LIMIT $2 OFFSET $3
    `;

    const binds: any[] = [accountNum ?? null, perPage, offset];
    const res = await pool.query(sql, binds);
    const rows = res.rows;

    const countSql = `
      SELECT COUNT(*)::int AS total_count
      FROM zbp.billing_account
      WHERE ($1::text IS NULL OR account_num = $1::text)
    `;
    const countRes = await pool.query(countSql, [accountNum ?? null]);
    const total = Number(countRes.rows?.[0]?.total_count ?? 0);

    return { rows, page: Math.max(1, page), perPage, total };
  } catch (err: any) {
    logger.error({ trace_id: traceId, event: "getAccountsService_FAILED", message: err?.message || String(err) });
    throw err;
  }
};

export const getAddressesService = async (
  accountNum?: string,
  page: number = 1,
  perPage: number = 10,
) => {
  const traceId = getTraceId();
  try {
    const offset = (Math.max(1, page) - 1) * perPage;

    const sql = `
      SELECT
        baa.billing_account_id,
        ba.account_num,
        baa.billing_address_street_1 as street_1,
        baa.billing_address_street_2 as street_2,
        baa.billing_address_city as city,
        baa.billing_address_region_or_state as region_or_state,
        baa.billing_address_country as country
      FROM zbp.billing_account_address baa
      JOIN zbp.billing_account ba
        ON ba.id = baa.billing_account_id
      WHERE ($1::text IS NULL OR ba.account_num = $1::text)
      ORDER BY baa.billing_account_id
      LIMIT $2 OFFSET $3
    `;

    const binds: any[] = [accountNum ?? null, perPage, offset];
    const res = await pool.query(sql, binds);
    const rows = res.rows;

    const countSql = `
      SELECT COUNT(*)::int AS total_count
      FROM zbp.billing_account_address baa
      JOIN zbp.billing_account ba
        ON ba.id = baa.billing_account_id
      WHERE ($1::text IS NULL OR ba.account_num = $1::text)
    `;
    const countRes = await pool.query(countSql, [accountNum ?? null]);
    const total = Number(countRes.rows?.[0]?.total_count ?? 0);

    return { rows, page: Math.max(1, page), perPage, total };
  } catch (err: any) {
    logger.error({ trace_id: traceId, event: "getAddressesService_FAILED", message: err?.message || String(err) });
    throw err;
  }
};

export const getAccountsByStatusService = async (
  status: string,
  page: number = 1,
  perPage: number = 100,
) => {
  const traceId = getTraceId();
  try {
    const normalizedPage = Math.max(1, page);
    const offset = (normalizedPage - 1) * perPage;

    const sql = `
     SELECT
        ba.id AS billing_account_id,
        ba.customer_id AS customer_number,
        ba.account_num,
        ba.first_name,
        ba.last_name,
        ba."type",
        ba.status,
        bac."type" AS customer_type,
        ba.primary_email,
        ba.telephone_number,
        baa.billing_address_street_1 as street_1,
        baa.billing_address_street_2 as street_2,
        baa.billing_address_city as city,
        baa.billing_address_region_or_state as region_or_state,
        baa.billing_address_postal_code as postal_code,
        baa.billing_address_country as country
      FROM zbp.billing_account ba
      LEFT JOIN zbp.billing_account_address baa
        ON baa.billing_account_id = ba.id
      LEFT JOIN zbp.billing_account_category bac
        ON bac.id = ba.category_id
      WHERE ba.status = $1
      ORDER BY ba.account_num DESC
      LIMIT $2 OFFSET $3
    `;

    const countSql = `
      SELECT COUNT(*)::int AS total_count
      FROM zbp.billing_account ba
      WHERE ba.status = $1
    `;

    const [dataResult, countResult] = await Promise.all([
      pool.query(sql, [status, perPage, offset]),
      pool.query<{ total_count: number }>(countSql, [status]),
    ]);
    const total = countResult.rows[0]?.total_count ?? 0;
    const rows = dataResult.rows.map((row) => ({
      ...row,
      dpi_account_num: toDpiAccountNum(row.account_num),
    }));

    return {
      rows,
      page: normalizedPage,
      perPage,
      total,
      totalPages: Math.ceil(total / perPage),
    };
  } catch (err: any) {
    logger.error({
      trace_id: traceId,
      event: "getAccountsByStatusService_FAILED",
      message: err?.message || String(err),
    });
    throw err;
  }
};

export const getCustomerSearchService = async (
  criteria: CustomerSearchCriteria,
  page: number = 1,
  perPage: number = 10,
) => {
  const traceId = getTraceId();
  try {
    const conditions: string[] = [];
    const bindValues: Array<string | number> = [];
    const addCondition = (value: string | number | undefined, build: (parameter: string) => string) => {
      if (value) {
        bindValues.push(value);
        conditions.push(build(`$${bindValues.length}`));
      }
    };
    addCondition(criteria.accountNumber ? `${criteria.accountNumber}%` : undefined, (parameter) => `ba.account_num LIKE ${parameter}`);
    addCondition(criteria.summaryAccountNumber ? `${criteria.summaryAccountNumber}%` : undefined, (parameter) => `ba.account_num LIKE ${parameter}`);
    addCondition(criteria.primaryEmailAddress ? `%${criteria.primaryEmailAddress}%` : undefined, (parameter) => `COALESCE(ba.primary_email, '') ILIKE ${parameter}`);
    addCondition(criteria.customerName ? `%${criteria.customerName}%` : undefined, (parameter) => `(
      CONCAT_WS(' ', ba.first_name, ba.last_name) ILIKE ${parameter}
      OR ba.first_name ILIKE ${parameter}
      OR ba.last_name ILIKE ${parameter}
    )`);
    addCondition(criteria.firstName ? `%${criteria.firstName}%` : undefined, (parameter) => `ba.first_name ILIKE ${parameter}`);
    addCondition(criteria.lastName ? `%${criteria.lastName}%` : undefined, (parameter) => `ba.last_name ILIKE ${parameter}`);
    addCondition(criteria.telephoneNumber, (parameter) => `LEFT(COALESCE(ba.account_num, ''), 10) = ${parameter}`);
    addCondition(criteria.dateFrom, (parameter) => `ba.created_on >= (${parameter}::date::timestamp AT TIME ZONE 'UTC')`);
    addCondition(criteria.dateTo, (parameter) => `ba.created_on < ((${parameter}::date + 1)::timestamp AT TIME ZONE 'UTC')`);
    addCondition(criteria.days, (parameter) => `ba.created_on >= NOW() - (${parameter} || ' days')::interval`);
    if (conditions.length === 0) {
      throw new Error("Customer search requires at least one criterion.");
    }
    const whereClause = conditions.join(" AND ");

    const sql = `
      SELECT
        ba.id AS billing_account_id,
        ba.customer_id AS customer_number,
        ba.account_num,
        ba.start_date,
        ba.end_date,
        ba.created_on,
        ba.suspended_date,
        ba.balance,
        ba.auto_pay_enabled,
        ba.paper_bill_flag,
        ba.bill_cycle_name,
        ba.dunning_tier_name,
        ba.first_name,
        ba.last_name,
        ba."type",
        ba.status,
        ba.billing_ind,
        bac."type" AS customer_type,
        ba.primary_email,
        ba.telephone_number,
        baa.billing_address_street_1 as street_1,
        baa.billing_address_street_2 as street_2,
        baa.billing_address_city as city,
        baa.billing_address_region_or_state as region_or_state,
        baa.billing_address_postal_code as postal_code,
        baa.billing_address_country as country
      FROM zbp.billing_account ba
      LEFT JOIN zbp.billing_account_address baa
        ON baa.billing_account_id = ba.id
      LEFT JOIN zbp.billing_account_category bac
        ON bac.id = ba.category_id
      WHERE ${whereClause}
      ORDER BY ba.account_num DESC
      LIMIT $${bindValues.length + 1} OFFSET $${bindValues.length + 2}
    `;

    const result = await pool.query(sql, [...bindValues, perPage, (page - 1) * perPage]);
    const count = await pool.query(
      `SELECT COUNT(*)::int AS total FROM zbp.billing_account ba WHERE ${whereClause}`,
      bindValues,
    );

    return {
      rows: result.rows.map((row) => ({
        ...row,
        customer_type: mapLegacyTypeLabel(row.customer_type) ?? row.customer_type,
        dpi_account_num: toDpiAccountNum(row.account_num),
      })),
      total: Number(count.rows[0].total),
      page,
      perPage,
    };
  } catch (err: any) {
    logger.error({
      trace_id: traceId,
      event: "getCustomerSearchService_FAILED",
      message: err?.message || String(err),
    });
    throw err;
  }
};
