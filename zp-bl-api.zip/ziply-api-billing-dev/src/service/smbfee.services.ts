import { runQuery } from "../config/snowflake";
import logger, {
  eventLog,
  categoryOpt,
  eventOpt,
  inbound,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "service/smbfee.services";
const httpLogRes = logRes();
const inboundLog = inbound();

// ==============================
// SMB Fee Service
// ==============================
// Parse request parameters
// Calculate start and end dates
// Build SMB Fee SQL Query
// Execute Snowflake Query
// Process Query Result
// Calculate Invoice Statistics
// Prepare API Response
// Return Summary Response
// Error Handling

export const getSMBFeeService = async (
 days?: number,
 from?: string,
 to?: string,
 src?: string,
 traceId?:string
) => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getSMBFeeService";
 try {
  let dateCondition = "";
if (from && to) {
   dateCondition = `
       inv.created_on >= '${from}'::DATE
       AND inv.created_on < DATEADD('day', 1, '${to}'::DATE)
   `;
} else {
   dateCondition = `
       inv.created_on >= DATEADD('day', -${days}, CURRENT_DATE())
       AND inv.created_on < CURRENT_DATE()
   `;
}


   const sql = `WITH smb_fees AS (
                SELECT bad.account_num, ii.description, ii.total_amount
                FROM billing_account_detailed bad
                JOIN invoice inv             ON bad.id = inv.billing_account_id
                JOIN invoice_item ii         ON inv.id = ii.invoice_id
                JOIN invoice_item_charge iic ON ii.id  = iic.invoice_item_id
                JOIN billing_account_custom_field_value spe
                                             ON spe.billing_account_id = bad.id
                WHERE ${dateCondition}
                  AND spe.value = 'SMB'
                  AND (ii.description LIKE '%Paper Statement Fee%'
                    OR ii.description LIKE '%Business Payment Fee%')
                  AND NOT EXISTS (
                      SELECT 1 FROM invoice_item ex
                      WHERE ex.invoice_id = inv.id
                        AND ex.description LIKE '%Payment Surcharge%'
                  )
            ),
            smb_all_invoices AS (
                SELECT COUNT(DISTINCT inv.id) AS total_invoices
                FROM billing_account_detailed bad
                JOIN invoice inv ON bad.id = inv.billing_account_id
                JOIN billing_account_custom_field_value spe ON spe.billing_account_id = bad.id
                WHERE ${dateCondition}
                  AND spe.value = 'SMB'
                  AND NOT EXISTS (
                      SELECT 1 FROM invoice_item ex
                      WHERE ex.invoice_id = inv.id
                        AND ex.description LIKE '%Payment Surcharge%'
                  )
            ),
            smb_fee_invoices AS (
                SELECT COUNT(DISTINCT inv.id) AS invoices_with_fee
                FROM billing_account_detailed bad
                JOIN invoice inv             ON bad.id = inv.billing_account_id
                JOIN invoice_item ii         ON inv.id = ii.invoice_id
                JOIN invoice_item_charge iic ON ii.id  = iic.invoice_item_id
                JOIN billing_account_custom_field_value spe ON spe.billing_account_id = bad.id
                WHERE ${dateCondition}
                  AND spe.value = 'SMB'
                  AND (ii.description LIKE '%Paper Statement Fee%'
                    OR ii.description LIKE '%Business Payment Fee%')
                  AND NOT EXISTS (
                      SELECT 1 FROM invoice_item ex
                      WHERE ex.invoice_id = inv.id
                        AND ex.description LIKE '%Payment Surcharge%'
                  )
            )
            SELECT
                COUNT(DISTINCT account_num) AS total_accts,
                COUNT(DISTINCT CASE WHEN description LIKE '%Paper Statement Fee%'  THEN account_num END) AS paper_stmt_accts,
                COUNT(DISTINCT CASE WHEN description LIKE '%Business Payment Fee%' THEN account_num END) AS biz_pay_accts,
                ROUND(SUM(total_amount), 2) AS total_amount,
                ROUND(SUM(CASE WHEN description LIKE '%Paper Statement Fee%'  THEN total_amount ELSE 0 END), 2) AS paper_stmt_amount,
                ROUND(SUM(CASE WHEN description LIKE '%Business Payment Fee%' THEN total_amount ELSE 0 END), 2) AS biz_pay_amount,
                (SELECT total_invoices    FROM smb_all_invoices) AS total_invoices,
                (SELECT invoices_with_fee FROM smb_fee_invoices) AS invoices_with_fee
            FROM smb_fees`;
 const rows = await runQuery(sql);
   return rows;
 } catch (error:any) {

  httpLogRes.http.response.body.content = JSON.stringify({ error }, [
       "error",
       ...Object.getOwnPropertyNames(error),
     ]);
     logger.error({
       message: `Error in getSMBFeeService to  fetch SMB Fee Service Details: ${traceId} - ${error.message}`,
       event: {
         ...logEvent,
         ...categoryOpt.webProcess,
         ...eventOpt.failureError,
       },
       error: {
         message: error?.message,
         code: error?.code,
         type: error?.constructor?.name,
       },
       ...httpLogRes,
       ...inboundLog,
     });
   throw error;
 }
};

// ==============================
// SMB Fee Coverage Service
// ==============================
export const getSMBFeeCoverageService = async (
 days?: number,
 from?: string,
 to?: string,
 src?: string,
 traceId?:string
) => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getSMBFeeCoverageService";
 try {
  let dateCondition = "";
if (from && to) {
   dateCondition = `
       inv.created_on >= '${from}'::DATE
       AND inv.created_on < DATEADD('day', 1, '${to}'::DATE)
   `;
} else {
   dateCondition = `
       inv.created_on >= DATEADD('day', -${days}, CURRENT_DATE())
       AND inv.created_on < CURRENT_DATE()
   `;
}

   
   const sql = `WITH profile_pm AS (
                SELECT customer_account_id, id AS pm_id,
                       payment_category_id, payment_type AS pm_payment_type
                FROM payment_method
                QUALIFY ROW_NUMBER() OVER (PARTITION BY customer_account_id ORDER BY id DESC) = 1
            ),
            card_type_pm AS (
                SELECT DISTINCT pmcf.payment_method_id, pmcf.value AS card_type
                FROM payment_method_custom_field_value pmcf
                WHERE pmcf.custom_field_id = 270 AND pmcf.name = 'Card Type'
                  AND TRIM(COALESCE(pmcf.value, '')) != ''
            ),
            bank_id_pm AS (
                SELECT DISTINCT pmcf.payment_method_id, pmcf.value AS bank_id
                FROM payment_method_custom_field_value pmcf
                WHERE pmcf.custom_field_id = 188 AND pmcf.name = 'Bank-ID'
                  AND TRIM(COALESCE(pmcf.value, '')) != ''
            ),
            channel_pm AS (
                SELECT payment_method_id, channel FROM (
                    SELECT pmcf.payment_method_id, pmcf.value AS channel,
                        ROW_NUMBER() OVER (PARTITION BY pmcf.payment_method_id ORDER BY pmcf.created_on DESC) AS rn
                    FROM payment_method_custom_field_value pmcf
                    WHERE pmcf.custom_field_id = 187 AND pmcf.name = 'Payment Channel'
                      AND TRIM(COALESCE(pmcf.value, '')) != ''
                      AND pmcf.value != 'AUTOPAY'
                ) t WHERE rn = 1
            )
            SELECT
                bad.account_num, bad.status,
                bad.billing_account_category AS category,
                bad.bill_cycle_name,
                TO_CHAR(inv.created_on, 'YYYY-MM-DD') AS invoice_date,
                inv.id::VARCHAR AS invoice_id,
                CASE WHEN bad.bill_type = 'PAPER' THEN 'Paper' ELSE 'Paperless' END AS paperless_flag,
                CASE WHEN bad.automatic_payment = TRUE THEN 'AutoPay ON' ELSE 'AutoPay OFF' END AS autopay_flag,
                CASE
                    WHEN MAX(ct.card_type) IS NOT NULL THEN MAX(ct.card_type)
                    WHEN MAX(bi.bank_id)   IS NOT NULL THEN MAX(bi.bank_id)
                    WHEN MAX(pc.channel)   IS NOT NULL THEN MAX(pc.channel)
                    WHEN MAX(pm.payment_category_id::VARCHAR) IS NOT NULL OR MAX(pm.pm_payment_type) IS NOT NULL
                         THEN TRIM(COALESCE(MAX(pm.payment_category_id::VARCHAR), '') || ' · ' || COALESCE(MAX(pm.pm_payment_type), ''))
                    ELSE '—'
                END AS profile_pay_method,
                COALESCE(MAX(CASE WHEN ii.description LIKE '%Paper Statement Fee%'  THEN ii.total_amount END), 0) AS paper_fee,
                COALESCE(MAX(CASE WHEN ii.description LIKE '%Business Payment Fee%' THEN ii.total_amount END), 0) AS biz_fee,
                CASE
                    WHEN MAX(CASE WHEN ii.description LIKE '%Paper Statement Fee%'  THEN 1 ELSE 0 END) = 1 THEN 'Paper Statement Fee'
                    WHEN MAX(CASE WHEN ii.description LIKE '%Business Payment Fee%' THEN 1 ELSE 0 END) = 1 THEN 'Business Payment Fee'
                    ELSE 'No Fee Applied'
                END AS fee_status
            FROM billing_account_detailed bad
            JOIN invoice inv ON bad.id = inv.billing_account_id
            JOIN billing_account_custom_field_value spe ON spe.billing_account_id = bad.id
            LEFT JOIN invoice_item ii ON inv.id = ii.invoice_id
               AND (ii.description LIKE '%Paper Statement Fee%' OR ii.description LIKE '%Business Payment Fee%')
            LEFT JOIN profile_pm pm ON pm.customer_account_id = bad.id
            LEFT JOIN card_type_pm ct ON ct.payment_method_id = pm.pm_id
            LEFT JOIN bank_id_pm   bi ON bi.payment_method_id = pm.pm_id
            LEFT JOIN channel_pm   pc ON pc.payment_method_id = pm.pm_id
            WHERE ${dateCondition}
              AND spe.value = 'SMB'
              AND NOT EXISTS (
                  SELECT 1 FROM invoice_item ex
                  WHERE ex.invoice_id = inv.id
                    AND ex.description LIKE '%Payment Surcharge%'
              )
            GROUP BY bad.account_num, bad.status, bad.billing_account_category, bad.bill_cycle_name,
                     inv.created_on, inv.id, bad.bill_type, bad.automatic_payment
            ORDER BY inv.created_on DESC, bad.account_num`;
  //  console.log("Executing Coverage SQL....");
  //  console.log(sql);
   const rows = await runQuery(sql);
   return rows;
 } catch (error:any) {
  httpLogRes.http.response.body.content = JSON.stringify({ error }, [
       "error",
       ...Object.getOwnPropertyNames(error),
     ]);
     logger.error({
       message: `Error in getSMBFeeCoverageService to fetch SMB Fee Coverage Service Details: ${traceId} - ${error.message}`,
       event: {
         ...logEvent,
         ...categoryOpt.webProcess,
         ...eventOpt.failureError,
       },
       error: {
         message: error?.message,
         code: error?.code,
         type: error?.constructor?.name,
       },
       ...httpLogRes,
       ...inboundLog,
     });
   throw error;
 }
};

// ==============================
// SMB Fee Export Service
// ==============================
export const getSMBFeeExportService = async (
 days?: number,
 from?: string,
 to?: string,
 src?: string,
 traceId?:string
) => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getSMBFeeExportService";
 try {
  let dateCondition = "";
if (from && to) {
   dateCondition = `
       inv.created_on >= '${from}'::DATE
       AND inv.created_on < DATEADD('day', 1, '${to}'::DATE)
   `;
} else {
   dateCondition = `
       inv.created_on >= DATEADD('day', -${days}, CURRENT_DATE())
       AND inv.created_on < CURRENT_DATE()
   `;
}

   
   const sql = `SELECT
                CONCAT(bad.account_num, '\t') AS account_num,
                bad.billing_account_category  AS category,
                bad.bill_cycle_name,
                TO_CHAR(inv.created_on, 'YYYY-MM-DD') AS invoice_date,
                CASE
                    WHEN ii.description LIKE '%Paper Statement Fee%'  THEN 'Paper Statement Fee'
                    WHEN ii.description LIKE '%Business Payment Fee%' THEN 'Business Payment Fee'
                    ELSE ii.description
                END AS fee_type,
                ii.total_amount,
                ii.invoice_id::VARCHAR AS invoice_id,
                ii.product_id::VARCHAR AS product_id
            FROM billing_account_detailed bad
            JOIN invoice inv             ON bad.id = inv.billing_account_id
            JOIN invoice_item ii         ON inv.id = ii.invoice_id
            JOIN invoice_item_charge iic ON ii.id  = iic.invoice_item_id
            JOIN billing_account_custom_field_value spe ON spe.billing_account_id = bad.id
            WHERE ${dateCondition}
              AND spe.value = 'SMB'
              AND (ii.description LIKE '%Paper Statement Fee%'
                OR ii.description LIKE '%Business Payment Fee%')
            ORDER BY inv.created_on DESC, bad.account_num`;
   const rows = await runQuery(sql);
   return rows;
 } catch (error:any) {
   httpLogRes.http.response.body.content = JSON.stringify({ error }, [
       "error",
       ...Object.getOwnPropertyNames(error),
     ]);
     logger.error({
       message: `Error in getSMBFeeExportService to Export SMB Fee: ${traceId} - ${error.message}`,
       event: {
         ...logEvent,
         ...categoryOpt.webProcess,
         ...eventOpt.failureError,
       },
       error: {
         message: error?.message,
         code: error?.code,
         type: error?.constructor?.name,
       },
       ...httpLogRes,
       ...inboundLog,
     });
   throw error;
 }
};