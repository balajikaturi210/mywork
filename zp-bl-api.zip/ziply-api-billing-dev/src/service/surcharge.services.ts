import { runQuery } from "../config/snowflake";
import {
  Surcharge,
  SurchargePmType,
  SurchargeCardTypeMissing,
  DrillParams,
  BreakdownRow,
  PmcfRow,
  CompareResponse,
  SurchargeExportRequest,
  SurchargeExportResponse,
} from "../types/surcharge.types";
import { createObjectCsvStringifier } from "csv-writer";
import logger, {
  eventLog,
  categoryOpt,
  eventOpt,
  inbound,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "service/surcharge.services";
const httpLogRes = logRes();
const inboundLog = inbound();

/**
 * Surcharge Report API
 *
 * Returns last 30 days payment transactions with surcharge details,
 * grouped by day, segment (SMB/RESI), and payment method type.
 *
 * Used to analyze surcharge revenue and payment method usage.
 */

export const getSurchargeService = async (
  start: string,
  end: string,
  traceId?: string,
): Promise<Surcharge[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getSurchargeService";
  try {
    const sql = `
    WITH all_otp AS (
        SELECT DATE_TRUNC('day', p.created_on)::DATE AS day,
            p.id AS payment_id,
            p.payment_method_id
        FROM payment p
        WHERE p.payment_source_type = 'API'
          AND p.status = 'COMPLETED'
          AND p.created_on >= '${start}'::DATE
          AND p.created_on < DATEADD('day', 1, '${end}'::DATE)
          AND p.payment_method_id NOT IN (
              SELECT pmcf.payment_method_id
              FROM payment_method_custom_field_value pmcf
              WHERE pmcf.custom_field_id = 187
                AND pmcf.name = 'Payment Channel'
                AND pmcf.value = 'AUTOPAY'
          )
    ),

    surcharge_entries AS (
        SELECT DISTINCT pmcf.payment_method_id,
            TRY_CAST(pmcf.value AS FLOAT) AS surcharge_amount
        FROM payment_method_custom_field_value pmcf
        WHERE pmcf.name = 'Payment Surcharge Amount'
          AND TRIM(COALESCE(pmcf.value, '')) != ''
    ),

    card_type_direct AS (
        SELECT DISTINCT pmcf.payment_method_id,
            pmcf.value AS card_type
        FROM payment_method_custom_field_value pmcf
        WHERE pmcf.custom_field_id = 270
          AND pmcf.name = 'Card Type'
          AND TRIM(COALESCE(pmcf.value, '')) != ''
    ),

    bank_id_direct AS (
        SELECT DISTINCT pmcf.payment_method_id,
            pmcf.value AS bank_id
        FROM payment_method_custom_field_value pmcf
        WHERE pmcf.custom_field_id = 188
          AND pmcf.name = 'Bank-ID'
          AND TRIM(COALESCE(pmcf.value, '')) != ''
    ),

    payment_channel AS (
        SELECT payment_method_id, channel
        FROM (
            SELECT pmcf.payment_method_id,
                   pmcf.value AS channel,
                   ROW_NUMBER() OVER (
                       PARTITION BY pmcf.payment_method_id
                       ORDER BY pmcf.created_on DESC
                   ) AS rn
            FROM payment_method_custom_field_value pmcf
            WHERE pmcf.custom_field_id = 187
              AND pmcf.name = 'Payment Channel'
              AND TRIM(COALESCE(pmcf.value, '')) != ''
              AND pmcf.value != 'AUTOPAY'
        ) t
        WHERE rn = 1
    ),

    joined AS (
        SELECT
            otp.day ,
            pm.customer_account_id AS billing_account_id,

            CASE
                WHEN se.payment_method_id IS NOT NULL THEN 1 ELSE 0
            END AS has_surcharge,

            COALESCE(se.surcharge_amount, 0) AS surcharge_amount,

            cd.card_type AS card_type,

            CASE
                WHEN cd.card_type IS NOT NULL THEN cd.card_type
                WHEN bd.bank_id IS NOT NULL THEN bd.bank_id
                WHEN pc.channel IS NOT NULL THEN pc.channel || ' — card type missing'
                WHEN pm.payment_category_id IS NOT NULL
                  OR pm.payment_type IS NOT NULL
                THEN TRIM(
                    COALESCE(pm.payment_category_id::VARCHAR, '')
                    || ' · '
                    || COALESCE(pm.payment_type, '')
                )
                ELSE '— Unknown —'
            END AS card_class,

            CASE
                WHEN cd.card_type IS NOT NULL THEN 'Card Type'
                WHEN bd.bank_id IS NOT NULL THEN 'Bank-ID'
                WHEN pc.channel IS NOT NULL THEN 'Payment Channel'
                WHEN pm.payment_category_id IS NOT NULL
                  OR pm.payment_type IS NOT NULL THEN 'PM Type'
                ELSE '—'
            END AS card_class_source

        FROM all_otp otp
        JOIN payment_method pm
            ON pm.id = otp.payment_method_id

        LEFT JOIN surcharge_entries se
            ON se.payment_method_id = otp.payment_method_id

        LEFT JOIN card_type_direct cd
            ON cd.payment_method_id = otp.payment_method_id

        LEFT JOIN bank_id_direct bd
            ON bd.payment_method_id = otp.payment_method_id

        LEFT JOIN payment_channel pc
            ON pc.payment_method_id = otp.payment_method_id
    )

    SELECT
        TO_CHAR(j.day, 'YYYY-MM-DD') AS "day",

        CASE
            WHEN ba.billing_account_category ILIKE 'Business%'
              OR ba.billing_account_category ILIKE 'Legacy-B%'
            THEN 'SMB'
            ELSE 'RESI'
        END AS "segment",

        j.has_surcharge AS "hasSurcharge",
        j.card_class AS "cardClass",
        j.card_class_source AS "cardClassSource",
        j.card_type AS "cardType",

        COUNT(*) AS "txn_count",
        COALESCE(SUM(j.surcharge_amount), 0) AS "total_surcharge"

    FROM joined j
    JOIN billing_account ba
        ON ba.id = j.billing_account_id

    GROUP BY 1,2,3,4,5,6
    ORDER BY 1,2,3,4,5,6
  `;
    const row = await runQuery<Surcharge>(sql);
    return row;
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in getSurchargeService to fetch surcharge Service Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });
    throw error;
  }
};

/**
 * Payment Method Types API
 *
 * Returns summary of payment methods with card type,
 * bank ID, and payment channel details grouped by type.
 *
 * Used for payment analytics and configuration checks.
 */

export const getSurchargePmTypesService = async (
  traceId?: string,
): Promise<SurchargePmType[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getSurchargePmTypesService";
  try {
    const sql = `
    WITH pm_base AS (
      SELECT
        id AS pm_id,
        payment_type,
        payment_category_id::VARCHAR AS payment_category_id
      FROM payment_method
      WHERE payment_type IS NOT NULL
    ),

    enriched AS (
      SELECT
        pm.payment_type,
        pm.payment_category_id,
        pm.pm_id,

        MAX(CASE WHEN pmcf.custom_field_id = 270
                  AND TRIM(COALESCE(pmcf.value,''))!=''
             THEN pmcf.name END) AS cf_270_name,

        MAX(CASE WHEN pmcf.custom_field_id = 270
                  AND TRIM(COALESCE(pmcf.value,''))!=''
             THEN pmcf.value END) AS cf_270_value,

        MAX(CASE WHEN pmcf.custom_field_id = 188
                  AND TRIM(COALESCE(pmcf.value,''))!=''
             THEN pmcf.name END) AS cf_188_name,

        MAX(CASE WHEN pmcf.custom_field_id = 188
                  AND TRIM(COALESCE(pmcf.value,''))!=''
             THEN pmcf.value END) AS cf_188_value,

        MAX(CASE WHEN pmcf.custom_field_id = 187
                  AND TRIM(COALESCE(pmcf.value,''))!=''
             THEN pmcf.name END) AS cf_187_name,

        MAX(CASE WHEN pmcf.custom_field_id = 187
                  AND TRIM(COALESCE(pmcf.value,''))!=''
             THEN pmcf.value END) AS cf_187_value

      FROM pm_base pm
      LEFT JOIN payment_method_custom_field_value pmcf
        ON pmcf.payment_method_id = pm.pm_id

      GROUP BY pm.payment_type, pm.payment_category_id, pm.pm_id
    )

    SELECT
      payment_type AS "payment_type",
      payment_category_id AS "payment_category_id",
      COUNT(DISTINCT pm_id) AS "pm_count",

      MAX(cf_270_name) AS "field_270_name",
      LISTAGG(DISTINCT cf_270_value, ' | ')
        WITHIN GROUP (ORDER BY cf_270_value) AS "field_270_values",

      MAX(cf_188_name) AS "field_188_name",
      LISTAGG(DISTINCT cf_188_value, ' | ')
        WITHIN GROUP (ORDER BY cf_188_value) AS "field_188_values",

      MAX(cf_187_name) AS "field_187_name",
      LISTAGG(DISTINCT cf_187_value, ' | ')
        WITHIN GROUP (ORDER BY cf_187_value) AS "field_187_values"

    FROM enriched
    GROUP BY "payment_type", "payment_category_id"
    ORDER BY "pm_count" DESC
  `;

    const row = await runQuery<SurchargePmType>(sql);
    return row;
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in getSurchargePmTypesService to fetch surcharge Payment method Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });
    throw error;
  }
};

/**
 * Finds API payments with surcharge where Card Type / Bank ID is missing.
 * Used for data quality checks (last 30 days).
 */

export const getSurchargeCardTypeMissingService = async (
  start: string,
  end: string,
  traceId?: string,
): Promise<SurchargeCardTypeMissing[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getSurchargeCardTypeMissingService";
  try {
    const sql = `
    WITH autopay_pms AS (
      SELECT DISTINCT pmcf.payment_method_id
      FROM payment_method_custom_field_value pmcf
      WHERE pmcf.custom_field_id = 187
        AND pmcf.name = 'Payment Channel'
        AND pmcf.value = 'AUTOPAY'
    ),
    card_type_direct AS (
      SELECT DISTINCT pmcf.payment_method_id
      FROM payment_method_custom_field_value pmcf
      WHERE pmcf.custom_field_id = 270
        AND pmcf.name = 'Card Type'
        AND TRIM(COALESCE(pmcf.value,'')) != ''
    ),
    bank_id_direct AS (
      SELECT DISTINCT pmcf.payment_method_id
      FROM payment_method_custom_field_value pmcf
      WHERE pmcf.custom_field_id = 188
        AND pmcf.name = 'Bank-ID'
        AND TRIM(COALESCE(pmcf.value,'')) != ''
    ),
    payment_channel AS (
      SELECT payment_method_id, channel
      FROM (
        SELECT
          pmcf.payment_method_id,
          pmcf.value AS channel,
          ROW_NUMBER() OVER (
            PARTITION BY pmcf.payment_method_id
            ORDER BY pmcf.created_on DESC
          ) rn
        FROM payment_method_custom_field_value pmcf
        WHERE pmcf.custom_field_id = 187
          AND pmcf.name = 'Payment Channel'
          AND TRIM(COALESCE(pmcf.value,'')) != ''
          AND pmcf.value != 'AUTOPAY'
      ) t
      WHERE rn = 1
    ),
    surcharge_entries AS (
      SELECT DISTINCT
        pmcf.payment_method_id,
        TRY_CAST(pmcf.value AS FLOAT) AS surcharge_amount
      FROM payment_method_custom_field_value pmcf
      WHERE pmcf.name = 'Payment Surcharge Amount'
        AND TRIM(COALESCE(pmcf.value,'')) != ''
    )
    SELECT
      ba.account_num AS "account_num",
      ba.status AS "status",
      CASE
        WHEN ba.billing_account_category ILIKE 'Business%'
          OR ba.billing_account_category ILIKE 'Legacy-B%'
        THEN 'SMB'
        ELSE 'RESI'
      END AS "segment",
      ba.billing_account_category AS "category",
      TO_CHAR(p.created_on,'YYYY-MM-DD') AS "payment_date",
      p.amount AS "amount",
      pc.channel AS "channel",
      pm.id::VARCHAR AS "payment_method_id",
      pm.payment_category_id::VARCHAR AS "payment_category_id",
      pm.payment_type AS "payment_type",
      CASE WHEN se.payment_method_id IS NOT NULL THEN 1 ELSE 0 END AS "has_surcharge",
      COALESCE(se.surcharge_amount, 0) AS "surcharge_amount"
    FROM payment p
    JOIN payment_method pm
      ON pm.id = p.payment_method_id
    JOIN billing_account ba
      ON ba.id = pm.customer_account_id
    JOIN payment_channel pc
      ON pc.payment_method_id = p.payment_method_id
    LEFT JOIN surcharge_entries se
      ON se.payment_method_id = p.payment_method_id
    WHERE p.payment_source_type = 'API'
      AND p.status = 'COMPLETED'
      AND p.created_on >= '${start}'::DATE
      AND p.created_on < DATEADD('day', 1, '${end}'::DATE)
      AND pm.payment_type <> 'TB'
      AND p.payment_method_id NOT IN (
        SELECT payment_method_id FROM autopay_pms
      )
      AND p.payment_method_id NOT IN (
        SELECT payment_method_id FROM card_type_direct
      )
      AND p.payment_method_id NOT IN (
        SELECT payment_method_id FROM bank_id_direct
      )
    ORDER BY p.created_on DESC
  `;

    const row = await runQuery<SurchargeCardTypeMissing>(sql);
    return row;
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in getSurchargeCardTypeMissingService to fetch surcharge CardType Missing Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });
    throw error;
  }
};

export const getSurchargeBankIdDrillService = async ({
  bankId,
  mode,
  fromDate,
  toDate,
  traceId,
}: DrillParams) => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getSurchargeBankIdDrillService";
  try {
    const safeBankId = bankId.replace(/'/g, "''");

    let dateCte = "";
    let dateJoin = "";
    let binds: any[] = [];

    const useRange = mode === "range" && fromDate && toDate;

    if (useRange) {
      dateCte = `
      otp_pms AS (
        SELECT DISTINCT p.payment_method_id
        FROM payment p
        WHERE p.payment_source_type = 'API'
          AND p.status = 'COMPLETED'
          AND p.created_on >= TO_DATE(?)
          AND p.created_on < DATEADD('day', 1, TO_DATE(?))
      ),
    `;

      dateJoin = `JOIN otp_pms op ON op.payment_method_id = bp.payment_method_id`;

      binds.push(fromDate, toDate);
    }

    const summarySql = `
    WITH bank_pms AS (
      SELECT DISTINCT pmcf.payment_method_id
      FROM payment_method_custom_field_value pmcf
      WHERE pmcf.custom_field_id = 188
        AND pmcf.name = 'Bank-ID'
        AND pmcf.value = '${safeBankId}'
    ),
    ${dateCte}
    surcharge_pms AS (
      SELECT DISTINCT pmcf.payment_method_id
      FROM payment_method_custom_field_value pmcf
      WHERE pmcf.name = 'Payment Surcharge Amount'
        AND TRIM(COALESCE(pmcf.value,'')) <> ''
    )

    SELECT
      pm.payment_type AS "payment_type",
      pm.payment_category_id::VARCHAR AS "payment_category_id",
      COUNT(DISTINCT pm.id) AS "pm_count",
      COUNT(DISTINCT CASE WHEN sp.payment_method_id IS NOT NULL THEN pm.id END) AS "pm_with_surcharge",
      COUNT(DISTINCT CASE WHEN sp.payment_method_id IS NULL THEN pm.id END) AS "pm_no_surcharge"
    FROM bank_pms bp
    ${dateJoin}
    JOIN payment_method pm ON pm.id = bp.payment_method_id
    LEFT JOIN surcharge_pms sp ON sp.payment_method_id = pm.id
    GROUP BY pm.payment_type, pm.payment_category_id
    ORDER BY "pm_count" DESC
  `;

    const samplesSql = `
    WITH bank_pms AS (
      SELECT DISTINCT pmcf.payment_method_id
      FROM payment_method_custom_field_value pmcf
      WHERE pmcf.custom_field_id = 188
        AND pmcf.name = 'Bank-ID'
        AND pmcf.value = '${safeBankId}'
    ),
    ${dateCte}
    surcharge_pms AS (
      SELECT DISTINCT pmcf.payment_method_id
      FROM payment_method_custom_field_value pmcf
      WHERE pmcf.name = 'Payment Surcharge Amount'
        AND TRIM(COALESCE(pmcf.value,'')) <> ''
    ),
    card_type AS (
      SELECT DISTINCT pmcf.payment_method_id, pmcf.value AS card_type
      FROM payment_method_custom_field_value pmcf
      WHERE pmcf.custom_field_id = 270
        AND pmcf.name = 'Card Type'
        AND TRIM(COALESCE(pmcf.value,'')) <> ''
    )

    SELECT
      ba.account_num AS "account_num",
      ba.billing_account_category AS "category",
      ba.status AS "status",
      pm.id::VARCHAR AS "payment_method_id",
      pm.payment_type AS "payment_type",
      pm.payment_category_id::VARCHAR AS "payment_category_id",
      COALESCE(ct.card_type,'—') AS "card_type",
      CASE WHEN sp.payment_method_id IS NOT NULL THEN 'Yes' ELSE 'No' END AS "has_surcharge",
      CASE WHEN pm.valid_to IS NULL THEN 'Current' ELSE 'Expired' END AS "pm_status"
    FROM bank_pms bp
    ${dateJoin}
    JOIN payment_method pm ON pm.id = bp.payment_method_id
    JOIN billing_account ba ON ba.id = pm.customer_account_id
    LEFT JOIN surcharge_pms sp ON sp.payment_method_id = pm.id
    LEFT JOIN card_type ct ON ct.payment_method_id = pm.id
    ORDER BY ba.account_num, pm.id
    LIMIT 50
  `;


    const [summary, samples] = await Promise.all([
      runQuery(summarySql, binds),
      runQuery(samplesSql, binds),
    ]);

    return {
      summary,
      samples,
    };
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in getSurchargeBankIdDrillService to fetch surcharge BankId Details: ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });
    throw error;
  }
};

export const compareBankIdService = async (
  bankId: string,
  paymentType: string,
  paymentCategoryId?: number,
  start?: string,
  end?: string,
  mode: string = "all",
  traceId?: string,
): Promise<CompareResponse> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "compareBankIdService";
  try {
    const rangeMode = mode === "range";

    const categoryFilter =
      paymentCategoryId !== undefined
        ? `AND pm.payment_category_id = ${paymentCategoryId}`
        : "";

    const dateCTE = rangeMode
      ? `
otp_pms AS (
    SELECT DISTINCT p.payment_method_id
    FROM payment p
    WHERE p.payment_source_type='API'
      AND p.status='COMPLETED'
      AND p.created_on >= ?::DATE
      AND p.created_on < DATEADD(day,1,?::DATE)
),
`
      : "";

    const dateJoin = rangeMode
      ? `
JOIN otp_pms op
ON op.payment_method_id = bp.payment_method_id
`
      : "";

    const breakdownSql = `
WITH bank_pms AS (

    SELECT DISTINCT
        pmcf.payment_method_id

    FROM payment_method_custom_field_value pmcf

    WHERE pmcf.custom_field_id = 188
      AND pmcf.name = 'Bank-ID'
      AND pmcf.value = ?

),

${dateCTE}


target_pms AS (

    SELECT
        pm.id AS pm_id,
        pm.customer_account_id,
        pm.valid_to

    FROM bank_pms bp

    ${dateJoin}

    JOIN payment_method pm
        ON pm.id = bp.payment_method_id

    WHERE pm.payment_type = ?

    ${categoryFilter}

),


surcharge_pms AS (

    SELECT DISTINCT
        pmcf.payment_method_id

    FROM payment_method_custom_field_value pmcf

    WHERE pmcf.name='Payment Surcharge Amount'
      AND TRIM(COALESCE(pmcf.value,''))!=''

),


card_type_pms AS (

    SELECT DISTINCT
        pmcf.payment_method_id

    FROM payment_method_custom_field_value pmcf

    WHERE pmcf.custom_field_id=270
      AND pmcf.name='Card Type'
      AND TRIM(COALESCE(pmcf.value,''))!=''

),


channel_pms AS (

    SELECT
        pmcf.payment_method_id,
        pmcf.value AS channel

    FROM payment_method_custom_field_value pmcf

    WHERE pmcf.custom_field_id=187
      AND pmcf.name='Payment Channel'
      AND TRIM(COALESCE(pmcf.value,''))!=''

    QUALIFY ROW_NUMBER()
    OVER(
        PARTITION BY pmcf.payment_method_id
        ORDER BY pmcf.created_on DESC
    )=1

),


bankid_pms AS (

    SELECT
        pmcf.payment_method_id,
        pmcf.value AS bank_id_value

    FROM payment_method_custom_field_value pmcf

    WHERE pmcf.custom_field_id=188
      AND pmcf.name='Bank-ID'
      AND TRIM(COALESCE(pmcf.value,''))!=''

    QUALIFY ROW_NUMBER()
    OVER(
        PARTITION BY pmcf.payment_method_id
        ORDER BY pmcf.created_on DESC
    )=1

),


enriched AS (

SELECT

    tp.pm_id,

    CASE
        WHEN sp.payment_method_id IS NOT NULL
        THEN 'With Surcharge'
        ELSE 'No Surcharge'
    END AS surcharge_group,


    CASE
        WHEN ba.billing_account_category ILIKE 'Business%'
          OR ba.billing_account_category ILIKE 'Legacy-B%'
        THEN 'SMB'
        ELSE 'RESI'
    END AS segment,


    ba.billing_account_category AS category,


    CASE
        WHEN tp.valid_to IS NULL
        THEN 'Current'
        ELSE 'Expired'
    END AS pm_status,


    CASE
        WHEN ct.payment_method_id IS NOT NULL
        THEN 'Has Card Type (270)'
        ELSE 'No Card Type (270)'
    END AS card_type_flag,


    COALESCE(bi.bank_id_value,'— absent —') AS bank_id_188,


    COALESCE(ch.channel,'— none —') AS channel


FROM target_pms tp


JOIN billing_account ba
ON ba.id = tp.customer_account_id


LEFT JOIN surcharge_pms sp
ON sp.payment_method_id = tp.pm_id


LEFT JOIN card_type_pms ct
ON ct.payment_method_id = tp.pm_id


LEFT JOIN bankid_pms bi
ON bi.payment_method_id = tp.pm_id


LEFT JOIN channel_pms ch
ON ch.payment_method_id = tp.pm_id

)


SELECT

surcharge_group as "surcharge_group",
segment as "segment",
pm_status as "pm_status",
card_type_flag as "card_type_flag",
bank_id_188 as "bank_id_188",
channel as "channel",
COUNT(*) as "pm_count"

FROM enriched

GROUP BY
surcharge_group,
segment,
pm_status,
card_type_flag,
bank_id_188,
channel


ORDER BY
surcharge_group,
"pm_count"  DESC

`;

    const breakdownBinds = rangeMode
      ? [bankId, start, end, paymentType]
      : [bankId, paymentType];

   

    const breakdown = await runQuery<BreakdownRow>(
      breakdownSql,
      breakdownBinds,
    );

    const pmcfSql = `

WITH bank_pms AS (

    SELECT DISTINCT
        pmcf.payment_method_id

    FROM payment_method_custom_field_value pmcf

    WHERE pmcf.custom_field_id=188
      AND pmcf.name='Bank-ID'
      AND pmcf.value=?

),


${dateCTE}


target_pms AS (

SELECT
    pm.id AS pm_id

FROM bank_pms bp

${dateJoin}

JOIN payment_method pm
ON pm.id=bp.payment_method_id

WHERE pm.payment_type=?

${categoryFilter}

),


surcharge_pms AS (

SELECT DISTINCT
payment_method_id

FROM payment_method_custom_field_value

WHERE name='Payment Surcharge Amount'
AND TRIM(COALESCE(value,''))!=''

)


SELECT

CASE
WHEN sp.payment_method_id IS NOT NULL
THEN 'With Surcharge'
ELSE 'No Surcharge'
END AS "surcharge_group",


pmcf.name AS "cf_name",
pmcf.value AS "cf_value",


COUNT(DISTINCT tp.pm_id) AS "pm_count"


FROM target_pms tp


LEFT JOIN surcharge_pms sp
ON sp.payment_method_id=tp.pm_id


LEFT JOIN payment_method_custom_field_value pmcf
ON pmcf.payment_method_id=tp.pm_id


WHERE pmcf.name IS NOT NULL
AND TRIM(COALESCE(pmcf.value,''))!=''


GROUP BY
"surcharge_group",
pmcf.name,
pmcf.value


ORDER BY
"surcharge_group",
"pm_count" DESC

`;

    const pmcfBinds = rangeMode
      ? [bankId, start, end, paymentType]
      : [bankId, paymentType];

    const pmcf = await runQuery<PmcfRow>(pmcfSql, pmcfBinds);


    return {
      breakdown,
      pmcf,
    };
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in compareBankIdService to compare  BankId : ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });
    throw error;
  }
};

export const surchargeExportService = async (
  request: SurchargeExportRequest,
): Promise<SurchargeExportResponse> => {
   const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "surchargeExportService";
  let traceId = request.traceId;
  try {
    const start = Date.now();

    const filters: string[] = [];

    const binds: any[] = [];

    if (request.hasSurcharge === "0" || request.hasSurcharge === "1") {
      filters.push("AND seg.has_surcharge = ?");

      binds.push(request.hasSurcharge);
    }

    if (request.segment) {
      filters.push("AND seg.segment = ?");

      binds.push(request.segment);
    }

    filters.push("AND seg.card_class = ?");

    binds.push(request.cardClass);

    const where = filters.join("\n");

    const sql = `

WITH all_otp AS (

SELECT

DATE_TRUNC('day',p.created_on)::DATE day,

p.id payment_id,

p.payment_method_id,

p.created_on

FROM payment p

WHERE

p.payment_source_type='API'

AND p.status='COMPLETED'


),


surcharge_entries AS (

SELECT DISTINCT

pmcf.payment_method_id,

TRY_CAST(pmcf.value AS FLOAT)
surcharge_amount


FROM payment_method_custom_field_value pmcf


WHERE

pmcf.name='Payment Surcharge Amount'

),


card_type_direct AS (

SELECT DISTINCT

pmcf.payment_method_id,

pmcf.value card_type


FROM payment_method_custom_field_value pmcf


WHERE

pmcf.custom_field_id=270

),


bank_id_direct AS (

SELECT DISTINCT

pmcf.payment_method_id,

pmcf.value bank_id


FROM payment_method_custom_field_value pmcf


WHERE

pmcf.custom_field_id=188

),


joined AS (

SELECT

otp.created_on,

otp.payment_id,

otp.payment_method_id,


pm.customer_account_id billing_account_id,


CASE

WHEN se.payment_method_id IS NOT NULL

THEN 1

ELSE 0

END has_surcharge,


COALESCE(
se.surcharge_amount,
0
)
surcharge_amount,


cd.card_type,


CASE

WHEN cd.card_type IS NOT NULL

THEN cd.card_type


WHEN bd.bank_id IS NOT NULL

THEN bd.bank_id


ELSE '— Unknown —'


END card_class



FROM all_otp otp


JOIN payment_method pm

ON pm.id =
otp.payment_method_id


LEFT JOIN surcharge_entries se

ON se.payment_method_id =
otp.payment_method_id


LEFT JOIN card_type_direct cd

ON cd.payment_method_id =
otp.payment_method_id


LEFT JOIN bank_id_direct bd

ON bd.payment_method_id =
otp.payment_method_id


),


seg AS (

SELECT

j.*,

ba.account_num,


CASE

WHEN ba.billing_account_category ILIKE 'Business%'

OR ba.billing_account_category ILIKE 'Legacy-B%'

THEN 'SMB'

ELSE 'RESI'

END segment


FROM joined j


JOIN billing_account ba

ON ba.id=j.billing_account_id

)



SELECT

TO_CHAR(
seg.created_on,
'YYYY-MM-DD HH24:MI:SS'
)
"payment_date",


seg.payment_id::VARCHAR  AS "payment_id",

seg.account_num AS "account_num",

seg.segment AS "segment",

seg.payment_method_id::VARCHAR "payment_method_id",

seg.card_class AS "card_class",

seg.card_type "card_brand",


CASE seg.has_surcharge

WHEN 1 THEN 'Yes'

ELSE 'No'

END "has_surcharge",


seg.surcharge_amount "surcharge_amount"


FROM seg

WHERE 1=1

${where}

ORDER BY seg.created_on DESC

`;

 

    const rows = await runQuery(sql, binds);

  

    const csvWriter = createObjectCsvStringifier({
      header: [
        { id: "payment_date", title: "payment_date" },

        { id: "payment_id", title: "payment_id" },

        { id: "account_num", title: "account_num" },

        { id: "segment", title: "segment" },

        { id: "payment_method_id", title: "payment_method_id" },

        { id: "card_class", title: "card_class" },

        { id: "card_brand", title: "card_brand" },

        { id: "has_surcharge", title: "has_surcharge" },

        { id: "surcharge_amount", title: "surcharge_amount" },
      ],
    });

    const csv = csvWriter.getHeaderString() + csvWriter.stringifyRecords(rows);

    const safeClass = request.cardClass.replace(/[\\/:*?"<>|]/g, "_");

    return {
      csv,

      filename: `surcharge_${request.segment || "ALL"}_${safeClass}_${new Date()
        .toISOString()
        .slice(0, 10)}.csv`,
    };
  } catch (error:any) {
     httpLogRes.http.response.body.content = JSON.stringify({ error }, [
      "error",
      ...Object.getOwnPropertyNames(error),
    ]);
    logger.error({
      message: `Error in surchargeExportService to compare  BankId : ${traceId} - ${error.message}`,
      event: {
        ...logEvent,
        ...categoryOpt.webProcess,
        ...eventOpt.failureError,
      },
      error: {
        message: error?.message,
        code: error?.code,
        type: error?.constructor?.name,
      },
      ...httpLogRes,
      ...inboundLog,
    });
    throw error;
  }
};
