import { runQuery } from "../config/snowflake";
import {
  SuspensionAging,
  DunningInvoiceAging,
  PaidStillSuspended,
  DunningInvoiceAccount
} from "../types/suspensionAging.types";
import logger, {
  eventLog,
  categoryOpt,
  eventOpt,
  inbound,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "service/suspensionAging.services";
const httpLogRes = logRes();
const inboundLog = inbound();

/**
 * Returns billing accounts that are currently suspended and shows
 * how long they have been in suspension with balance and dunning info.
 */

export const getSuspensionAgingService = async (
  days: number = 7,
  traceId?:string
): Promise<SuspensionAging[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getSuspensionAgingService";
  try {
    const minDays = days;

    const sql = `
      WITH latest_suspension AS (
        SELECT
          billing_account_id,
          MAX(created_on) AS suspended_since
        FROM change_status_history
        WHERE ba_status_id = 'BILLING_ACCOUNT_SUSPENDED'
        GROUP BY billing_account_id
      )

      SELECT
        ba.account_num as "account_num",
        ba.billing_account_category AS "category",
        ba.automatic_payment::VARCHAR AS "autopay",
        ROUND(ba.balance, 2) AS "balance",
        TO_CHAR(ls.suspended_since, 'YYYY-MM-DD') AS "suspended_since",
        DATEDIFF('day', ls.suspended_since::DATE, CURRENT_DATE()) AS "days_suspended",
        COALESCE(d.dunning_plan_name, '—') AS "dunning_plan",
        COALESCE(d.dunning_tier_name, '—') AS "dunning_tier"
      FROM billing_account ba
      JOIN latest_suspension ls
        ON ls.billing_account_id = ba.id
      LEFT JOIN billing_account_dunning d
        ON d.billing_account_id = ba.id
      WHERE ba.status = 'BILLING_ACCOUNT_SUSPENDED'
        AND DATEDIFF('day', ls.suspended_since::DATE, CURRENT_DATE()) >= ${minDays}
      ORDER BY "days_suspended" DESC
    `;

    const rows = await runQuery<SuspensionAging>(sql);

    return rows;
  } catch (error: any) {
     httpLogRes.http.response.body.content = JSON.stringify({ error }, [
         "error",
         ...Object.getOwnPropertyNames(error),
       ]);
       logger.error({
         message: `Error in getSuspensionAgingService to fetch Suspension Aging Details: ${traceId} - ${error.message}`,
         event: {
           ...logEvent,
           ...categoryOpt.webProcess,
           ...eventOpt.failureError,
         },
         error: {
           message: error?.message,
           code: error?.code,
           type: error?.constructor?.name,
         },
         ...httpLogRes,
         ...inboundLog,
       });
    throw error;
  }
};

/**
 * Dunning Invoice Aging API
 *
 * Returns invoice aging summary grouped by dunning plan,
 * filtered by account status (ACTIVE / SUSPENDED / OTHERS).
 *
 * Shows overdue distribution, total balance, and average age
 * of oldest unpaid invoice per account.
 */
export const getDunningInvoiceAgingService = async (
  acctStatus: string,
  traceId:string

): Promise<DunningInvoiceAging[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getDunningInvoiceAgingService";
  try {
    let statusFilter = "";

    if (acctStatus === "SUSPENDED") {
      statusFilter = "AND ba.status = 'BILLING_ACCOUNT_SUSPENDED'";
    } else if (acctStatus === "ACTIVE") {
      statusFilter = "AND ba.status = 'BILLING_ACCOUNT_ACTIVE'";
    } else if (acctStatus === "OTHERS") {
      statusFilter =
        "AND ba.status NOT IN ('BILLING_ACCOUNT_SUSPENDED','BILLING_ACCOUNT_ACTIVE')";
    }

    const sql = `
    WITH per_account AS (
      SELECT
        ba.id AS ba_id,
        COALESCE(d.dunning_plan_name, '— No Plan —') AS dunning_plan,
        DATEDIFF('day', MIN(i.due_date), CURRENT_DATE()) AS oldest_age_days,
        SUM(i.balance) AS total_open_balance
      FROM billing_account ba
      LEFT JOIN billing_account_dunning d
        ON d.billing_account_id = ba.id
      JOIN invoice i
        ON i.billing_account_id = ba.id
      WHERE i.type = 'INVOICE'
        AND i.balance > 0
        AND i.due_date IS NOT NULL
        ${statusFilter}
      GROUP BY ba.id, d.dunning_plan_name
    )

    SELECT
      dunning_plan as "dunning_plan",
      COUNT(*) AS "total_accts",

      SUM(CASE WHEN oldest_age_days BETWEEN 0 AND 24 THEN 1 ELSE 0 END) AS "d0_24",
      SUM(CASE WHEN oldest_age_days BETWEEN 25 AND 45 THEN 1 ELSE 0 END) AS "d25_45",
      SUM(CASE WHEN oldest_age_days BETWEEN 46 AND 74 THEN 1 ELSE 0 END) AS "d46_74",
      SUM(CASE WHEN oldest_age_days > 74 THEN 1 ELSE 0 END) AS "d75p",

      ROUND(AVG(oldest_age_days), 0) AS "avg_oldest_days",
      ROUND(SUM(total_open_balance), 2) AS "total_balance"

    FROM per_account
    GROUP BY "dunning_plan"
    ORDER BY "total_accts" DESC
  `;

    const rows = await runQuery<DunningInvoiceAging>(sql);

    return rows;
  } catch (error: any) {
  httpLogRes.http.response.body.content = JSON.stringify({ error }, [
         "error",
         ...Object.getOwnPropertyNames(error),
       ]);
       logger.error({
         message: `Error in getDunningInvoiceAgingService to fetch Dunning Invoice Aging Details: ${traceId} - ${error.message}`,
         event: {
           ...logEvent,
           ...categoryOpt.webProcess,
           ...eventOpt.failureError,
         },
         error: {
           message: error?.message,
           code: error?.code,
           type: error?.constructor?.name,
         },
         ...httpLogRes,
         ...inboundLog,
       });
    throw error;
  }
};

/**
 * Returns suspended accounts that have made payments after suspension,
 * including payment count, total paid, and last payment details.
 */
export const getPaidStillSuspendedService = async (traceId?:string): Promise<
  PaidStillSuspended[]
> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getPaidStillSuspendedService";
  try {
    const sql = `
    WITH latest_suspension AS (
      SELECT
        billing_account_id,
        MAX(created_on) AS suspended_since
      FROM change_status_history
      WHERE ba_status_id = 'BILLING_ACCOUNT_SUSPENDED'
      GROUP BY billing_account_id
    )

    SELECT
      ba.id AS "billing_account_id",
      ba.account_num AS "account_num",
      ba.billing_account_category AS "category",
      ba.automatic_payment::VARCHAR AS "autopay",
      ROUND(ba.balance, 2) AS "balance",
      TO_CHAR(ls.suspended_since, 'YYYY-MM-DD HH24:MI') AS "suspended_since",
      DATEDIFF('day', ls.suspended_since::DATE, CURRENT_DATE()) AS "days_suspended",

      COUNT(p.id) AS "payment_count",
      ROUND(SUM(p.amount), 2) AS "total_paid",
      TO_CHAR(MAX(p.created_on), 'YYYY-MM-DD HH24:MI') AS "last_payment_on",
      DATEDIFF('day', MAX(p.created_on)::DATE, CURRENT_DATE()) AS "days_since_payment"

    FROM billing_account ba
    JOIN latest_suspension ls
      ON ls.billing_account_id = ba.id

    JOIN payment p
      ON p.billing_account_id = ba.id
      AND p.status = 'COMPLETED'
      AND p.created_on > ls.suspended_since
      AND not exists (select 1 from invoice i where i.billing_account_id = Ba.id 
      and i.due_date < sysdate() and i.balance > 0)

    WHERE ba.status = 'BILLING_ACCOUNT_SUSPENDED'

    GROUP BY
      ba.id,
      ba.account_num,
      ba.billing_account_category,
      ba.automatic_payment,
      ba.balance,
      ls.suspended_since

    ORDER BY "last_payment_on" DESC
  `;

    let row = await runQuery<PaidStillSuspended>(sql);
    return row;
  } catch (error: any) {
     httpLogRes.http.response.body.content = JSON.stringify({ error }, [
         "error",
         ...Object.getOwnPropertyNames(error),
       ]);
       logger.error({
         message: `Error in getPaidStillSuspendedService to fetch Paid Still Suspended Details: ${traceId} - ${error.message}`,
         event: {
           ...logEvent,
           ...categoryOpt.webProcess,
           ...eventOpt.failureError,
         },
         error: {
           message: error?.message,
           code: error?.code,
           type: error?.constructor?.name,
         },
         ...httpLogRes,
         ...inboundLog,
       });
    throw error;
  }
};



const BUCKET_SQL: Record<string, string> = {
  d0_24: "oldest_age_days BETWEEN 0 AND 24",
  d25_45: "oldest_age_days BETWEEN 25 AND 45",
  d46_74: "oldest_age_days BETWEEN 46 AND 74",
  d75p: "oldest_age_days > 74",
  total: "1=1",
};

export  const getDunningInvoiceAccountsService = async (
  dunningPlan: string,
  bucket: string = "total",
  acctStatus: string = "SUSPENDED",
  traceId?:string
): Promise<DunningInvoiceAccount[]> =>{
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getDunningInvoiceAccounts";
try{
  const bucketCondition =
    BUCKET_SQL[bucket] || BUCKET_SQL.total;

  let statusFilter = "";

  switch (acctStatus.toUpperCase()) {
    case "SUSPENDED":
      statusFilter =
        "AND ba.status = 'BILLING_ACCOUNT_SUSPENDED'";
      break;

    case "ACTIVE":
      statusFilter =
        "AND ba.status = 'BILLING_ACCOUNT_ACTIVE'";
      break;

    case "OTHERS":
      statusFilter = `
        AND ba.status NOT IN (
          'BILLING_ACCOUNT_SUSPENDED',
          'BILLING_ACCOUNT_ACTIVE'
        )
      `;
      break;
  }


  const sql = `
    WITH per_account AS (

      SELECT
        ba.account_num AS "account_num",
        ba.billing_account_category AS "category",
        ba.status AS "acct_status",
        ba.automatic_payment::VARCHAR AS "autopay",

        ROUND(ba.balance,2) AS "account_balance",

        MIN(i.due_date)::DATE AS "oldest_due_date",

        DATEDIFF(
          'day',
          MIN(i.due_date),
          CURRENT_DATE()
        ) AS "oldest_age_days",

        COUNT(i.id) AS "open_invoice_count",

        ROUND(
          SUM(i.balance),
          2
        ) AS "total_open_balance"

      FROM billing_account ba

      LEFT JOIN billing_account_dunning d
        ON d.billing_account_id = ba.id

      JOIN invoice i
        ON i.billing_account_id = ba.id

      WHERE i.type = 'INVOICE'
        AND i.balance > 0
        AND i.due_date IS NOT NULL

        ${statusFilter}

        AND COALESCE(
          d.dunning_plan_name,
          '— No Plan —'
        ) = ?

      GROUP BY
        ba.id,
        ba.account_num,
        ba.billing_account_category,
        ba.status,
        ba.automatic_payment,
        ba.balance
    )

    SELECT *
    FROM per_account

    WHERE ${bucketCondition}

    ORDER BY
      "oldest_age_days" DESC,
      "account_num"
  `;


  return await runQuery<DunningInvoiceAccount>(
    sql,
    [dunningPlan]
  );
}catch (error: any) {
   httpLogRes.http.response.body.content = JSON.stringify({ error }, [
         "error",
         ...Object.getOwnPropertyNames(error),
       ]);
       logger.error({
         message: `Error in getDunningInvoiceAccounts to fetch Dunning Invoice Accounts: ${traceId} - ${error.message}`,
         event: {
           ...logEvent,
           ...categoryOpt.webProcess,
           ...eventOpt.failureError,
         },
         error: {
           message: error?.message,
           code: error?.code,
           type: error?.constructor?.name,
         },
         ...httpLogRes,
         ...inboundLog,
       });
    throw error;
  }
}
