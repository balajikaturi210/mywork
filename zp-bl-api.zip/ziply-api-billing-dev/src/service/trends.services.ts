import { runQuery } from "../config/snowflake";
import {
  TechInstallResponse,
  TechInstallTenure,
  TechInstallAccount,
  TechInstallDiscountedAccount,
  AutoPayLatenessTrendResponse,
  PaperlessDiscountTrendResponse,
  SurchargeTrend,
} from "../types/trends.types";
import logger, {
  eventLog,
  categoryOpt,
  eventOpt,
  inbound,
  logReq,
  logRes,
} from "../logger/logger";
const eventData = eventLog();
eventData.module = "service/trends.services";
const httpLogRes = logRes();
const inboundLog = inbound();

/**
 * Generates the Technician Installation dashboard report.
 *
 * Aggregates technician installation metrics for the specified date range,
 * including installation charges, discounts, fee adjustments, refunds,
 * and current month new account statistics, then returns a consolidated
 * response for the dashboard.
 */

export const getTechInstallService = async (
  start: string,
  end: string,
  traceId:string
): Promise<TechInstallResponse> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getTechInstallService";
  try {
    const summarySql = `
WITH install_charges AS (
    SELECT
        ii.id AS item_id,
        ii.invoice_id,
        ii.billing_account_id,
        ii.created_on AS charge_date
    FROM invoice_item ii
    WHERE ii.created_on >= '${start}'::DATE
      AND ii.created_on < DATEADD('day',1,'${end}'::DATE)
      AND ii.description = 'Technician Installation'
      AND ii.total_amount = 90
),

discounts AS (
    SELECT DISTINCT invoice_id
    FROM invoice_item
    WHERE created_on >= '${start}'::DATE
      AND created_on < DATEADD('day',1,'${end}'::DATE)
      AND description = 'Technician Installation Fee Discount'
      AND total_amount = -90
),

fee_adj_accts AS (
    SELECT DISTINCT billing_account_id
    FROM invoice_item
    WHERE description = 'Technician Installation Fee Discount Adjustment'
      AND created_on >= '${start}'::DATE
      AND created_on < DATEADD('day',1,'${end}'::DATE)
)

SELECT
    COUNT(DISTINCT ic.billing_account_id) AS total_charged,

    COUNT(DISTINCT CASE
        WHEN d.invoice_id IS NULL
        THEN ic.billing_account_id
    END) AS net_paid,

    COUNT(DISTINCT CASE
        WHEN d.invoice_id IS NOT NULL
        THEN ic.billing_account_id
    END) AS discounted,

    COUNT(DISTINCT CASE
        WHEN d.invoice_id IS NULL
         AND fa.billing_account_id IS NOT NULL
        THEN ic.billing_account_id
    END) AS net_paid_with_fee_adj,

    COUNT(DISTINCT CASE
        WHEN rf_pos.invoice_id IS NOT NULL
        THEN ic.billing_account_id
    END) AS positive_refund,

    COUNT(DISTINCT CASE
        WHEN rf_neg.invoice_id IS NOT NULL
        THEN ic.billing_account_id
    END) AS negative_refund

FROM install_charges ic

LEFT JOIN discounts d
    ON d.invoice_id = ic.invoice_id

LEFT JOIN fee_adj_accts fa
    ON fa.billing_account_id = ic.billing_account_id

LEFT JOIN (
    SELECT DISTINCT invoice_id
    FROM invoice_item
    WHERE description='Refund for'
      AND total_amount > 0
      AND created_on >= '${start}'::DATE
      AND created_on < DATEADD('day',1,'${end}'::DATE)
) rf_pos
ON rf_pos.invoice_id=ic.invoice_id

LEFT JOIN (
    SELECT DISTINCT invoice_id
    FROM invoice_item
    WHERE description='Refund for'
      AND total_amount < 0
      AND created_on >= '${start}'::DATE
      AND created_on < DATEADD('day',1,'${end}'::DATE)
) rf_neg
ON rf_neg.invoice_id=ic.invoice_id;
`;

    const feeAdjustmentSql = `
SELECT
COUNT(DISTINCT billing_account_id) AS cnt
FROM invoice_item
WHERE created_on >= '${start}'::DATE
AND created_on < DATEADD('day',1,'${end}'::DATE)
AND description='Technician Installation Fee Discount Adjustment';
`;

    const newAccountsSql = `
SELECT
COUNT(*) AS new_accounts_mtd,

COUNT(
CASE
WHEN billing_account_category='Residential'
THEN 1
END
) AS residential,

COUNT(
CASE
WHEN billing_account_category='Business'
THEN 1
END
) AS business

FROM billing_account

WHERE DATE_TRUNC('month',created_on)
=
DATE_TRUNC('month',CURRENT_DATE());
`;

    const summaryRows = await runQuery(summarySql);
    const feeRows = await runQuery(feeAdjustmentSql);
    const accountRows = await runQuery(newAccountsSql);

    const r = summaryRows[0] || {};
    const fa = feeRows[0] || {};
    const na = accountRows[0] || {};

    logger.info({
      event: "TECH_INSTALL_REPORT_SUCCESS",
    });

    return {
      total_charged: Number(r.TOTAL_CHARGED || 0),
      net_paid: Number(r.NET_PAID || 0),
      net_paid_with_fee_adj: Number(r.NET_PAID_WITH_FEE_ADJ || 0),
      discounted: Number(r.DISCOUNTED || 0),
      fee_discount_adjustment: Number(fa.CNT || 0),
      positive_refund: Number(r.POSITIVE_REFUND || 0),
      negative_refund: Number(r.NEGATIVE_REFUND || 0),
      new_accounts_mtd: Number(na.NEW_ACCOUNTS_MTD || 0),
      new_accounts_resi: Number(na.RESIDENTIAL || 0),
      new_accounts_biz: Number(na.BUSINESS || 0),
    };
  } catch (error: any) {
   httpLogRes.http.response.body.content = JSON.stringify({ error }, [
           "error",
           ...Object.getOwnPropertyNames(error),
         ]);
         logger.error({
           message: `Error in getTechInstallService : ${traceId} - ${error.message}`,
           event: {
             ...logEvent,
             ...categoryOpt.webProcess,
             ...eventOpt.failureError,
           },
           error: {
             message: error?.message,
             code: error?.code,
             type: error?.constructor?.name,
           },
           ...httpLogRes,
           ...inboundLog,
         });
    throw error;
  }
};

/**
 * Aggregates technician installation tenure metrics by grouping
 * net-paid installation accounts into tenure buckets and calculating
 * the average account tenure and invoice count for each bucket.
 */
export const getTechInstallTenureService = async (
  start: string,
  end: string,
  traceId:string
): Promise<TechInstallTenure[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getTechInstallTenureService";
  try {
  

    const sql = `
      WITH install_charges AS (
          SELECT
              ii.billing_account_id,
              ii.invoice_id,
              ii.created_on AS charge_date
          FROM invoice_item ii
          WHERE ii.created_on >= '${start}'::DATE
            AND ii.created_on < DATEADD('day', 1, '${end}'::DATE)
            AND ii.description = 'Technician Installation'
            AND ii.total_amount = 90
      ),

      discounts AS (
          SELECT DISTINCT invoice_id
          FROM invoice_item
          WHERE created_on >= '${start}'::DATE
            AND created_on < DATEADD('day', 1, '${end}'::DATE)
            AND description = 'Technician Installation Fee Discount'
            AND total_amount = -90
      ),

      net_paid AS (
          SELECT
              ic.billing_account_id,
              ic.charge_date
          FROM install_charges ic
          LEFT JOIN discounts d
              ON d.invoice_id = ic.invoice_id
          WHERE d.invoice_id IS NULL
      ),

      invoice_counts AS (
          SELECT
              billing_account_id,
              COUNT(*) AS invoice_count
          FROM invoice
          GROUP BY billing_account_id
      )

      SELECT
          CASE
              WHEN DATEDIFF('day', ba.created_on, np.charge_date) <= 30 THEN '0-30 days'
              WHEN DATEDIFF('day', ba.created_on, np.charge_date) <= 90 THEN '31-90 days'
              WHEN DATEDIFF('day', ba.created_on, np.charge_date) <= 180 THEN '91-180 days'
              WHEN DATEDIFF('day', ba.created_on, np.charge_date) <= 365 THEN '181-365 days'
              ELSE '365+ days'
          END AS tenure_bucket,

          COUNT(*) AS accounts,

          ROUND(
              AVG(DATEDIFF('day', ba.created_on, np.charge_date)),
              0
          ) AS avg_tenure_days,

          ROUND(
              AVG(COALESCE(inv.invoice_count, 0)),
              1
          ) AS avg_invoice_count

      FROM net_paid np
      JOIN billing_account ba
          ON ba.id = np.billing_account_id

      LEFT JOIN invoice_counts inv
          ON inv.billing_account_id = np.billing_account_id

      GROUP BY tenure_bucket
      ORDER BY tenure_bucket;
    `;

    // Aggregate technician installation tenure metrics.
    const rows = await runQuery(sql);

 

    return rows.map((row: any) => ({
      tenure_bucket: row.TENURE_BUCKET,
      accounts: Number(row.ACCOUNTS),
      avg_tenure_days: Number(row.AVG_TENURE_DAYS),
      avg_invoice_count: Number(row.AVG_INVOICE_COUNT),
    }));
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
           "error",
           ...Object.getOwnPropertyNames(error),
         ]);
         logger.error({
           message: `Error in getTechInstallTenureService : ${traceId} - ${error.message}`,
           event: {
             ...logEvent,
             ...categoryOpt.webProcess,
             ...eventOpt.failureError,
           },
           error: {
             message: error?.message,
             code: error?.code,
             type: error?.constructor?.name,
           },
           ...httpLogRes,
           ...inboundLog,
         });

    throw error;
  }
};

/**
 * Aggregates technician installation account details by retrieving
 * net-paid installation charges, customer tenure, invoice history,
 * fee adjustments, and sales order information for dashboard reporting.
 */
export const getTechInstallAccountsService = async (
  start: string,
  end: string,
  traceId:string
): Promise<TechInstallAccount[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getTechInstallAccountsService";
  try {
   

    const sql = `
    WITH install_charges AS (
        SELECT
            ii.id AS item_id,
            ii.invoice_id,
            ii.billing_account_id,
            ii.created_on AS charge_date,
            ii.total_amount AS install_amount,
            ii.order_item_id
        FROM invoice_item ii
        WHERE ii.created_on >= '${start}'::DATE
          AND ii.created_on < DATEADD('day',1,'${end}'::DATE)
          AND ii.description='Technician Installation'
          AND ii.total_amount=90
    ),

    discounts AS (
        SELECT DISTINCT invoice_id
        FROM invoice_item
        WHERE created_on >= '${start}'::DATE
          AND created_on < DATEADD('day',1,'${end}'::DATE)
          AND description='Technician Installation Fee Discount'
          AND total_amount=-90
    ),

    invoice_counts AS (
        SELECT
            billing_account_id,
            COUNT(*) AS invoice_count
        FROM invoice
        GROUP BY billing_account_id
    )

    SELECT
        ba.account_num,
        ba.billing_account_category AS category,
        ba.status,
        TO_CHAR(ic.charge_date,'YYYY-MM-DD') AS charge_date,

        DATEDIFF('day',ba.created_on,ic.charge_date) AS tenure_days,

        COALESCE(inv.invoice_count,0) AS invoice_count,

        CASE
            WHEN COALESCE(inv.invoice_count,0)<=1 THEN 'New'
            WHEN COALESCE(inv.invoice_count,0)<=3 THEN 'Early'
            WHEN COALESCE(inv.invoice_count,0)<=12 THEN 'Established'
            ELSE 'Loyal'
        END AS customer_type,

        ic.install_amount,

        COALESCE(fa_sub.fee_adj_amount,0) AS fee_adj_amount,

        ic.install_amount-
        COALESCE(fa_sub.fee_adj_amount,0) AS net_amount,

        CASE
            WHEN fa_sub.fee_adj_amount IS NOT NULL
            THEN 'Yes'
            ELSE 'No'
        END AS has_fee_adj,

        COALESCE(oh.sales_order_type,'Unknown') AS sales_order_type,

        oh.order_number,

        CASE
            WHEN UPPER(COALESCE(oh.sales_order_type,'')) IN
            ('NEW','NEW_CONNECT')
            THEN 'New Install'

            WHEN UPPER(COALESCE(oh.sales_order_type,'')) IN
            ('CHANGE','MODIFY','UPGRADE','DOWNGRADE')
            THEN 'Change Order'

            WHEN DATEDIFF('day',ba.created_on,ic.charge_date)<=30
            THEN 'New Install'

            ELSE 'Change Order'
        END AS order_classification

    FROM install_charges ic

    JOIN billing_account ba
        ON ba.id=ic.billing_account_id

    LEFT JOIN discounts d
        ON d.invoice_id=ic.invoice_id

    LEFT JOIN (
        SELECT
            billing_account_id,
            SUM(total_amount) AS fee_adj_amount
        FROM invoice_item
        WHERE description='Technician Installation Fee Discount Adjustment'
          AND created_on>='${start}'::DATE
          AND created_on<DATEADD('day',1,'${end}'::DATE)
        GROUP BY billing_account_id
    ) fa_sub
        ON fa_sub.billing_account_id=ic.billing_account_id

    LEFT JOIN invoice_counts inv
        ON inv.billing_account_id=ic.billing_account_id

    LEFT JOIN order_item oi
        ON oi.id=ic.order_item_id

    LEFT JOIN order_header oh
        ON oh.id=oi.order_id

    WHERE d.invoice_id IS NULL

    ORDER BY ic.charge_date DESC;
    `;

    // Aggregate technician installation account metrics.
    const rows = await runQuery(sql);



    return rows.map((row: any) => ({
      account_num: row.ACCOUNT_NUM,
      category: row.CATEGORY,
      status: row.STATUS,
      charge_date: row.CHARGE_DATE,
      tenure_days: Number(row.TENURE_DAYS),
      invoice_count: Number(row.INVOICE_COUNT),
      customer_type: row.CUSTOMER_TYPE,
      install_amount: Number(row.INSTALL_AMOUNT),
      fee_adj_amount: Number(row.FEE_ADJ_AMOUNT),
      net_amount: Number(row.NET_AMOUNT),
      has_fee_adj: row.HAS_FEE_ADJ,
      sales_order_type: row.SALES_ORDER_TYPE,
      order_number: row.ORDER_NUMBER,
      order_classification: row.ORDER_CLASSIFICATION,
    }));
  } catch (error: any) {
    httpLogRes.http.response.body.content = JSON.stringify({ error }, [
           "error",
           ...Object.getOwnPropertyNames(error),
         ]);
         logger.error({
           message: `Error in getTechInstallAccountsService : ${traceId} - ${error.message}`,
           event: {
             ...logEvent,
             ...categoryOpt.webProcess,
             ...eventOpt.failureError,
           },
           error: {
             message: error?.message,
             code: error?.code,
             type: error?.constructor?.name,
           },
           ...httpLogRes,
           ...inboundLog,
         });

    throw error;
  }
};

/**
 * Aggregates discounted technician installation accounts by retrieving
 * accounts that received a Technician Installation Fee Discount along with
 * customer tenure, invoice history, and sales order details.
 */
export const getTechInstallDiscountedAccountsService = async (
  start: string,
  end: string,
  traceId:string
): Promise<TechInstallDiscountedAccount[]> => {
   const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getTechInstallDiscountedAccountsService";
  try {
    logger.info({
      event: "TECH_INSTALL_DISCOUNTED_ACCOUNTS_REQUEST_STARTED",
      start,
      end,
    });

    const sql = `
      WITH install_charges AS (
          SELECT
              ii.id AS item_id,
              ii.invoice_id,
              ii.billing_account_id,
              ii.created_on AS charge_date,
              ii.order_item_id
          FROM invoice_item ii
          WHERE ii.created_on >= '${start}'::DATE
            AND ii.created_on < DATEADD('day', 1, '${end}'::DATE)
            AND ii.description = 'Technician Installation'
            AND ii.total_amount = 90
      ),

      discounts AS (
          SELECT DISTINCT invoice_id
          FROM invoice_item
          WHERE created_on >= '${start}'::DATE
            AND created_on < DATEADD('day', 1, '${end}'::DATE)
            AND description = 'Technician Installation Fee Discount'
            AND total_amount = -90
      ),

      invoice_counts AS (
          SELECT
              billing_account_id,
              COUNT(*) AS invoice_count
          FROM invoice
          GROUP BY billing_account_id
      )

      SELECT
          ba.account_num,
          ba.billing_account_category AS category,
          ba.status,

          TO_CHAR(ic.charge_date,'YYYY-MM-DD') AS charge_date,

          DATEDIFF('day', ba.created_on, ic.charge_date) AS tenure_days,

          COALESCE(inv.invoice_count,0) AS invoice_count,

          CASE
              WHEN COALESCE(inv.invoice_count,0) <= 1 THEN 'New'
              WHEN COALESCE(inv.invoice_count,0) <= 3 THEN 'Early'
              WHEN COALESCE(inv.invoice_count,0) <= 12 THEN 'Established'
              ELSE 'Loyal'
          END AS customer_type,

          COALESCE(oh.sales_order_type,'Unknown') AS sales_order_type,

          oh.order_number,

          CASE
              WHEN UPPER(COALESCE(oh.sales_order_type,'')) IN ('NEW','NEW_CONNECT')
                  THEN 'New Install'

              WHEN UPPER(COALESCE(oh.sales_order_type,'')) IN
                  ('CHANGE','MODIFY','UPGRADE','DOWNGRADE')
                  THEN 'Change Order'

              WHEN DATEDIFF('day', ba.created_on, ic.charge_date) <= 30
                  THEN 'New Install'

              ELSE 'Change Order'
          END AS order_classification

      FROM install_charges ic

      JOIN billing_account ba
          ON ba.id = ic.billing_account_id

      JOIN discounts d
          ON d.invoice_id = ic.invoice_id

      LEFT JOIN invoice_counts inv
          ON inv.billing_account_id = ic.billing_account_id

      LEFT JOIN order_item oi
          ON oi.id = ic.order_item_id

      LEFT JOIN order_header oh
          ON oh.id = oi.order_id

      ORDER BY ic.charge_date DESC;
    `;

    // Aggregate discounted technician installation account details.
    const rows = await runQuery(sql);

    logger.info({
      event: "TECH_INSTALL_DISCOUNTED_ACCOUNTS_REQUEST_SUCCESS",
      rowCount: rows.length,
      timestamp: new Date().toISOString(),
    });

    return rows.map((row: any) => ({
      account_num: row.ACCOUNT_NUM,
      category: row.CATEGORY,
      status: row.STATUS,
      charge_date: row.CHARGE_DATE,
      tenure_days: Number(row.TENURE_DAYS),
      invoice_count: Number(row.INVOICE_COUNT),
      customer_type: row.CUSTOMER_TYPE,
      sales_order_type: row.SALES_ORDER_TYPE,
      order_number: row.ORDER_NUMBER,
      order_classification: row.ORDER_CLASSIFICATION,
    }));
  } catch (error: any) {
  httpLogRes.http.response.body.content = JSON.stringify({ error }, [
           "error",
           ...Object.getOwnPropertyNames(error),
         ]);
         logger.error({
           message: `Error in getTechInstallDiscountedAccountsService : ${traceId} - ${error.message}`,
           event: {
             ...logEvent,
             ...categoryOpt.webProcess,
             ...eventOpt.failureError,
           },
           error: {
             message: error?.message,
             code: error?.code,
             type: error?.constructor?.name,
           },
           ...httpLogRes,
           ...inboundLog,
         });

    throw error;
  }
};

/**
 * Aggregates AutoPay lateness analytics from Snowflake:
 * - Monthly established autopay trend with late fee tracking
 * - Active autopay snapshot with unpaid + late fee exposure
 * - Category-wise overdue balance breakdown
 */
export const getAutoPayLatenessTrendService =
  async (traceId:string): Promise<AutoPayLatenessTrendResponse> => {
     const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getAutoPayLatenessTrendService";
    try {
      /* -------------------- TREND QUERY -------------------- */
      

      const trendSql = `
        WITH all_autopay AS (
            SELECT DATE_TRUNC('month', p.created_on)::DATE AS pay_month,
                   pm.customer_account_id AS account_id
            FROM payment p
            JOIN payment_method pm ON pm.id = p.payment_method_id
            WHERE p.payment_source_type = 'BATCH'
              AND p.status = 'COMPLETED'
              AND p.created_on >= DATEADD('month', -13, DATE_TRUNC('month', CURRENT_DATE))
        ),
        established_autopay AS (
            SELECT curr.pay_month, curr.account_id
            FROM all_autopay curr
            JOIN all_autopay prev
              ON prev.account_id = curr.account_id
             AND prev.pay_month = DATEADD('month', -1, curr.pay_month)
        ),
        monthly_late_fee AS (
            SELECT DATE_TRUNC('month', ii.created_on)::DATE AS fee_month,
                   inv.billing_account_id AS account_id,
                   SUM(ii.total_amount) AS fee_amount
            FROM invoice_item ii
            JOIN invoice inv ON inv.id = ii.invoice_id
            WHERE ii.description ILIKE '%Late Fee%'
              AND ii.total_amount > 0
              AND ii.created_on >= DATEADD('month', -12, DATE_TRUNC('month', CURRENT_DATE))
            GROUP BY 1, 2
        )
        SELECT TO_CHAR(ea.pay_month, 'YYYY-MM') AS "month",
               COUNT(DISTINCT ea.account_id) AS "autopay_accounts",
               COUNT(DISTINCT lf.account_id) AS "autopay_with_late_fee",
               COALESCE(SUM(lf.fee_amount), 0) AS "late_fee_total",
               ROUND(
                 100.0 * COUNT(DISTINCT lf.account_id)
                 / NULLIF(COUNT(DISTINCT ea.account_id), 0),
                 2
               ) AS "pct_with_late_fee"
        FROM established_autopay ea
        LEFT JOIN monthly_late_fee lf
          ON lf.account_id = ea.account_id
         AND lf.fee_month = ea.pay_month
        GROUP BY ea.pay_month
        ORDER BY ea.pay_month;
      `;

      const trend = await runQuery(trendSql);

   

      /* -------------------- SNAPSHOT QUERY -------------------- */
      

      const snapshotSql = `
        WITH all_ap AS (
            SELECT DATE_TRUNC('month', p.created_on)::DATE AS pay_month,
                   pm.customer_account_id AS account_id
            FROM payment p
            JOIN payment_method pm ON pm.id = p.payment_method_id
            WHERE p.payment_source_type = 'BATCH'
              AND p.status = 'COMPLETED'
              AND p.created_on >= DATEADD('month', -4, CURRENT_DATE)
        ),
        autopay_active AS (
            SELECT DISTINCT curr.account_id
            FROM all_ap curr
            JOIN all_ap prev
              ON prev.account_id = curr.account_id
             AND prev.pay_month = DATEADD('month', -1, curr.pay_month)
            WHERE curr.pay_month >= DATEADD('month', -3, DATE_TRUNC('month', CURRENT_DATE))
        ),
        covered_invoices AS (
            SELECT DISTINCT pa.invoice_id
            FROM payment_application pa
            JOIN payment p ON p.id = pa.payment_id
            WHERE p.status = 'COMPLETED'
        ),
        old_unpaid AS (
            SELECT DISTINCT inv.billing_account_id AS account_id
            FROM invoice inv
            LEFT JOIN covered_invoices ci ON ci.invoice_id = inv.id
            WHERE ci.invoice_id IS NULL
              AND inv.due_date::DATE < DATEADD('month', -1, CURRENT_DATE)
        ),
        old_unpaid_balance AS (
            SELECT inv.billing_account_id AS account_id,
                   SUM(it.total_amount) AS old_balance
            FROM invoice inv
            JOIN invoice_item it
              ON it.invoice_id = inv.id
             AND it.total_amount > 0
            LEFT JOIN covered_invoices ci ON ci.invoice_id = inv.id
            WHERE ci.invoice_id IS NULL
              AND inv.due_date::DATE < DATEADD('month', -1, CURRENT_DATE)
            GROUP BY 1
        ),
        late_fee_ytd AS (
            SELECT DISTINCT inv.billing_account_id AS account_id
            FROM invoice_item ii
            JOIN invoice inv ON inv.id = ii.invoice_id
            WHERE ii.description ILIKE '%Late Fee%'
              AND ii.total_amount > 0
              AND ii.created_on >= DATE_TRUNC('year', CURRENT_DATE)
        )
        SELECT
            COUNT(DISTINCT aa.account_id) AS "autopay_active_accounts",
            COUNT(DISTINCT CASE WHEN ou.account_id IS NOT NULL THEN aa.account_id END) AS "also_have_old_unpaid",
            COALESCE(SUM(oub.old_balance), 0) AS "total_old_balance",
            COUNT(DISTINCT CASE WHEN lf.account_id IS NOT NULL THEN aa.account_id END) AS "also_charged_late_fee",
            COUNT(DISTINCT CASE WHEN ou.account_id IS NOT NULL
                                 AND lf.account_id IS NOT NULL THEN aa.account_id END) AS "old_unpaid_and_late_fee",
            ROUND(
              100.0 * COUNT(DISTINCT CASE WHEN ou.account_id IS NOT NULL THEN aa.account_id END)
              / NULLIF(COUNT(DISTINCT aa.account_id), 0),
              1
            ) AS "pct_with_old_unpaid",
            ROUND(
              100.0 * COUNT(DISTINCT CASE WHEN lf.account_id IS NOT NULL THEN aa.account_id END)
              / NULLIF(COUNT(DISTINCT aa.account_id), 0),
              1
            ) AS "pct_with_late_fee"
        FROM autopay_active aa
        LEFT JOIN old_unpaid ou ON ou.account_id = aa.account_id
        LEFT JOIN old_unpaid_balance oub ON oub.account_id = aa.account_id
        LEFT JOIN late_fee_ytd lf ON lf.account_id = aa.account_id;
      `;

      const snapshot = await runQuery(snapshotSql);

 

      /* -------------------- CATEGORY QUERY -------------------- */
    

      const categorySql = `
        WITH all_ap AS (
            SELECT DATE_TRUNC('month', p.created_on)::DATE AS pay_month,
                   pm.customer_account_id AS account_id
            FROM payment p
            JOIN payment_method pm ON pm.id = p.payment_method_id
            WHERE p.payment_source_type = 'BATCH'
              AND p.status = 'COMPLETED'
              AND p.created_on >= DATEADD('month', -4, CURRENT_DATE)
        ),
        autopay_active AS (
            SELECT DISTINCT curr.account_id
            FROM all_ap curr
            JOIN all_ap prev
              ON prev.account_id = curr.account_id
             AND prev.pay_month = DATEADD('month', -1, curr.pay_month)
            WHERE curr.pay_month >= DATEADD('month', -3, DATE_TRUNC('month', CURRENT_DATE))
        ),
        covered_invoices AS (
            SELECT DISTINCT pa.invoice_id
            FROM payment_application pa
            JOIN payment p ON p.id = pa.payment_id
            WHERE p.status = 'COMPLETED'
        ),
        old_unpaid_bal AS (
            SELECT inv.billing_account_id AS account_id,
                   SUM(it.total_amount) AS old_balance,
                   MAX(DATEDIFF('day', inv.due_date::DATE, CURRENT_DATE)) AS oldest_days
            FROM invoice inv
            JOIN invoice_item it
              ON it.invoice_id = inv.id
             AND it.total_amount > 0
            LEFT JOIN covered_invoices ci ON ci.invoice_id = inv.id
            WHERE ci.invoice_id IS NULL
              AND inv.due_date::DATE < DATEADD('month', -1, CURRENT_DATE)
            GROUP BY 1
        ),
        late_fee_ytd AS (
            SELECT DISTINCT inv.billing_account_id AS account_id
            FROM invoice_item ii
            JOIN invoice inv ON inv.id = ii.invoice_id
            WHERE ii.description ILIKE '%Late Fee%'
              AND ii.total_amount > 0
              AND ii.created_on >= DATE_TRUNC('year', CURRENT_DATE)
        )
        SELECT
            bad.billing_account_category AS "category",
            bad.status AS "status",
            COUNT(DISTINCT aa.account_id) AS "accounts",
            SUM(oub.old_balance) AS "total_old_balance",
            AVG(oub.old_balance) AS "avg_old_balance",
            AVG(oub.oldest_days) AS "avg_days_overdue"
        FROM autopay_active aa
        JOIN billing_account_detailed bad ON bad.id = aa.account_id
        JOIN old_unpaid_bal oub ON oub.account_id = aa.account_id
        JOIN late_fee_ytd lf ON lf.account_id = aa.account_id
        GROUP BY 1, 2
        ORDER BY "accounts" DESC;
      `;

      const category = await runQuery(categorySql);

   

      /* -------------------- RESPONSE -------------------- */
    

      return {
        trend,
        snapshot: snapshot?.[0] || {},
        category,
      };
    } catch (error: any) {
        httpLogRes.http.response.body.content = JSON.stringify({ error }, [
           "error",
           ...Object.getOwnPropertyNames(error),
         ]);
         logger.error({
           message: `Error in getAutoPayLatenessTrendService : ${traceId} - ${error.message}`,
           event: {
             ...logEvent,
             ...categoryOpt.webProcess,
             ...eventOpt.failureError,
           },
           error: {
             message: error?.message,
             code: error?.code,
             type: error?.constructor?.name,
           },
           ...httpLogRes,
           ...inboundLog,
         });
      throw error;
    }
  };

/**
 * Aggregates paperless adoption trend and discount distribution trends
 * from Snowflake billing + invoice data.
 */
export const getPaperlessDiscountTrendService =
  async (traceId:string): Promise<PaperlessDiscountTrendResponse> => {
     const logEvent = JSON.parse(JSON.stringify(eventData));
     logEvent.action = "getPaperlessDiscountTrendService";
    try {
      /* ---------------- PAPERLESS TREND ---------------- */
    

      const paperlessSql = `
        SELECT TO_CHAR(DATE_TRUNC('month', inv.created_on), 'YYYY-MM') AS "month",
               COUNT(DISTINCT bad.id) AS "total_customers",
               COUNT(DISTINCT CASE WHEN bad.bill_type != 'PAPER' THEN bad.id END) AS "paperless_customers",
               COUNT(DISTINCT CASE WHEN bad.bill_type = 'PAPER' THEN bad.id END) AS "paper_customers",
               ROUND(
                 100.0 * COUNT(DISTINCT CASE WHEN bad.bill_type != 'PAPER' THEN bad.id END)
                 / NULLIF(COUNT(DISTINCT bad.id), 0),
                 1
               ) AS "paperless_pct"
        FROM invoice inv
        JOIN billing_account_detailed bad ON bad.id = inv.billing_account_id
        WHERE inv.created_on >= DATEADD('month', -24, DATE_TRUNC('month', CURRENT_DATE))
        GROUP BY 1
        ORDER BY 1;
      `;

      const paperless = await runQuery(paperlessSql);

      logger.info({
        event: "PAPERLESS_TREND_QUERY_SUCCESS",
        rows: paperless.length,
      });

      /* ---------------- DISCOUNT TREND ---------------- */
      logger.info({
        event: "DISCOUNT_TREND_QUERY_STARTED",
      });

      const discountsSql = `
        SELECT TO_CHAR(DATE_TRUNC('month', inv.created_on), 'YYYY-MM') AS "month",
               CASE
                   WHEN ii.description ILIKE '%Paperless%' THEN 'Paperless'
                   WHEN ii.description ILIKE '%Credit Card Autopay%' THEN 'CC Autopay'
                   WHEN ii.description ILIKE '%Debit Card%'
                     OR ii.description ILIKE '%ACH Autopay%' THEN 'ACH/Debit Autopay'
                   WHEN ii.description ILIKE '%Federal Lifeline%' THEN 'Federal Lifeline'
                   WHEN ii.description ILIKE '%State Lifeline%' THEN 'State Lifeline'
                   WHEN ii.description ILIKE '%Tribal Lifeline%' THEN 'Tribal Lifeline'
                   WHEN ii.description ILIKE '%Fiber Lifeline%' THEN 'Fiber Lifeline'
                   WHEN ii.description ILIKE '%Lifeline Home Networking%' THEN 'Lifeline Networking'
                   WHEN ii.description ILIKE '%Tech%Install%' THEN 'Tech Install'
                   ELSE 'Other'
               END AS "discount_type",
               SUM(ABS(ii.total_amount)) AS "total_discounts",
               COUNT(DISTINCT inv.billing_account_id) AS "accounts_with_discount"
        FROM invoice inv
        JOIN invoice_item ii ON ii.invoice_id = inv.id
        WHERE inv.created_on >= DATEADD('month', -24, DATE_TRUNC('month', CURRENT_DATE))
          AND ii.total_amount < 0
          AND ii.description ILIKE '%discount%'
        GROUP BY 1, 2
        ORDER BY 1, 2;
      `;

      const discounts = await runQuery(discountsSql);

      logger.info({
        event: "DISCOUNT_TREND_QUERY_SUCCESS",
        rows: discounts.length,
      });

      /* ---------------- RESPONSE ---------------- */
      logger.info({
        event: "PAPERLESS_DISCOUNT_TREND_SUCCESS",
        duration: new Date().toISOString(),
      });

      return {
        paperless,
        discounts,
      };
    } catch (error: any) {
      httpLogRes.http.response.body.content = JSON.stringify({ error }, [
           "error",
           ...Object.getOwnPropertyNames(error),
         ]);
         logger.error({
           message: `Error in getPaperlessDiscountTrendService : ${traceId} - ${error.message}`,
           event: {
             ...logEvent,
             ...categoryOpt.webProcess,
             ...eventOpt.failureError,
           },
           error: {
             message: error?.message,
             code: error?.code,
             type: error?.constructor?.name,
           },
           ...httpLogRes,
           ...inboundLog,
         });

      throw error;
    }
  };

/**
 * Monthly surcharge trend from OTP/API payments.
 * Breaks down Residential vs SMB surcharge amounts.
 */
export const getSurchargeTrendService = async (traceId:string): Promise<SurchargeTrend[]> => {
  const logEvent = JSON.parse(JSON.stringify(eventData));
  logEvent.action = "getSurchargeTrendService";
  try {
    const sql = `
        WITH otp_surcharge AS (
            SELECT p.id AS payment_id,
                   DATE_TRUNC('month', p.created_on)::DATE AS pay_month,
                   CAST(pmcf_amt.value AS FLOAT) AS surcharge_amount,
                   bad.billing_account_category AS category
            FROM payment p
            JOIN payment_method pm ON pm.id = p.payment_method_id
            JOIN billing_account_detailed bad ON bad.id = pm.customer_account_id
            JOIN payment_method_custom_field_value pmcf_amt
                ON pmcf_amt.payment_method_id = p.payment_method_id
               AND pmcf_amt.name = 'Payment Surcharge Amount'
               AND TRIM(COALESCE(pmcf_amt.value, '')) != ''
            WHERE p.payment_source_type = 'API'
              AND p.status = 'COMPLETED'
              AND p.created_on >= DATEADD('month', -24, DATE_TRUNC('month', CURRENT_DATE))
        )
        SELECT
            TO_CHAR(pay_month, 'YYYY-MM') AS "month",
            COUNT(DISTINCT payment_id) AS "txn_count",
            SUM(surcharge_amount) AS "total_surcharge",
            SUM(CASE WHEN category != 'SMB' THEN surcharge_amount ELSE 0 END) AS "resi_surcharge",
            SUM(CASE WHEN category = 'SMB' THEN surcharge_amount ELSE 0 END) AS "smb_surcharge"
        FROM otp_surcharge
        GROUP BY pay_month
        ORDER BY pay_month;
      `;

    const rows = await runQuery(sql);

   

    return rows;
  } catch (error: any) {
     httpLogRes.http.response.body.content = JSON.stringify({ error }, [
           "error",
           ...Object.getOwnPropertyNames(error),
         ]);
         logger.error({
           message: `Error in getSurchargeTrendService : ${traceId} - ${error.message}`,
           event: {
             ...logEvent,
             ...categoryOpt.webProcess,
             ...eventOpt.failureError,
           },
           error: {
             message: error?.message,
             code: error?.code,
             type: error?.constructor?.name,
           },
           ...httpLogRes,
           ...inboundLog,
         });

    throw error;
  }
};
