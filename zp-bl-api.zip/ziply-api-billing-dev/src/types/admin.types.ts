export type PaginatedRowsResult<T> = {
  rows: T[];
  page: number;
  perPage: number;
  total: number;
  totalPages: number;
};

export type PaymentBatchFileFilters = {
  source?: string;
  fileStatus?: string;
};

export type PaymentBatchErrorRecordFilters = {
  fileId?: number;
};

export type PaymentBatchDpiAutopayRecordFilters = {
  status?: string;
  accountNum?: string;
  fileId?: number;
};

export type PaymentBatchTransFilters = {
  paymentId?: number;
  destination?: string;
  status?: string;
};

export type PaymentBatchSearchFilters = {
  fileName?: string;
  source?: string;
  createdBy?: string;
  dateFrom?: string;
  dateTo?: string;
};