export interface ARAging {
  segment: string;
  doc_type: string;
  curr: number;
  b1_30: number;
  b31_60: number;
  b61_90: number;
  b91_120: number;
  b121_150: number;
  b151_180: number;
  b181p: number;
}

export interface ARAgingParams {
  as_of: string;
  segment: string;
  aging_by: string;
  incl_dbt: string;
  traceId?:string
}
