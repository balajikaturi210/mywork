export interface GetAccountRequest {
  telephoneNumber: string;
  environment: "NW" | "CA";
  crisId?: number;
  crsid?: number;
  universalServiceNumber?: number;
  userId?: string;
  applicationId?: string;
  sequenceNumber?: number;
  trackingId?: string | number;
}

export interface GetAccountReceivableRequest {
  crisId: number;
  environment: "NW" | "CA";
  userId: string;
  workingTelephoneNumber: string;
  sequenceNumber?: number;
  includeAcctRcvDetail?: "Y" | "N";
  includeAcctRcvSummary?: "Y" | "N";
  includeCurrentBalance?: "Y" | "N";
  includePaymentHistory?: "Y" | "N";
  includeAdjustmentHistory?: "Y" | "N";
  maximumAdjustmentHistoryQty?: number;
  summaryNumberFlag_C_F01SUMF?: "Y" | "N";
}

export interface GetTreatmentRequest {
  crisId: number;
  environment: "NW" | "CA";
  userId?: string;
  workingTelephoneNumber?: string;
  universalServiceNumber?: number;
  sequenceNumber?: number;
  debugDelay?: number;
}

export interface GetPaymentMethodsRequest {
  billingAccountId: string;
  sort?: string;
}

export interface GetPaymentsRequest {
  billingAccountId: string;
}

export interface GetAccountHistoryRequest {
  billingAccountId: string;
}

export interface BillingServiceRequest {
  telephoneNumber: string;
  environment: "NW" | "CA";
  crisId: number;
  universalServiceNumber?: number;
  userId: string;
  applicationId: string;
  sequenceNumber: number;
  trackingId: string;
}

export interface BillingReceivableServiceRequest {
  crisId: number;
  environment: "NW" | "CA";
  userId: string;
  workingTelephoneNumber: string;
  sequenceNumber: number;
  includeAcctRcvDetail: "Y" | "N";
  includeAcctRcvSummary: "Y" | "N";
  includeCurrentBalance: "Y" | "N";
  includePaymentHistory: "Y" | "N";
  includeAdjustmentHistory: "Y" | "N";
  maximumAdjustmentHistoryQty: number;
  summaryNumberFlag_C_F01SUMF: "Y" | "N";
}

export interface BillingTreatmentServiceRequest {
  crisId: number;
  environment: "NW" | "CA";
  userId: string;
  workingTelephoneNumber?: string;
  universalServiceNumber?: number;
  sequenceNumber: number;
  debugDelay?: number;
}

export interface GetAccountResponse {
  meta: {
    return_code: string | number | null;
  };
  billing_account: Record<string, unknown>;
  payment: Record<string, unknown>;
  customer: Record<string, unknown>;
  network: Record<string, unknown>;
  tax_exemption: Record<string, unknown> | null;
  carriers: unknown[];
  billed_members: Array<{ phone: string | null; [key: string]: unknown }>;
  services: unknown[];
  contracts: unknown[];
  promotions: unknown[];
  pay_history: unknown[];
  raw: Record<string, unknown>;
}

export interface GetAccountReceivableResponse {
  meta: {
    return_code: string | number | null;
  };
  receivable_summary: unknown[];
  receivable_detail: unknown[];
  current_balance: Record<string, unknown> | null;
  payment_history: unknown[];
  adjustment_history: unknown[];
  raw: Record<string, unknown>;
}

export interface GetTreatmentResponse {
  meta: {
    return_code: string | number | null;
  };
  treatment: Record<string, unknown>;
  raw: Record<string, unknown>;
}

export type PaymentMethodsResponse = unknown;
export type PaymentsResponse = unknown;
export type AccountHistoryResponse = unknown;

export class BillingServiceError extends Error {
  statusCode: number;
  details?: unknown;

  constructor(message: string, statusCode: number, details?: unknown) {
    super(message);
    this.name = "BillingServiceError";
    this.statusCode = statusCode;
    this.details = details;
  }
}
