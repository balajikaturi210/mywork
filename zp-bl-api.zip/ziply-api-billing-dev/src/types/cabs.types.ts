export type CabsSnapshotStatus = "PROCESSING" | "READY" | "FAILED";

export interface CabsFilters {
  co?: string;
  ixc?: string;
  ban?: string;
  status?: string;
  critical?: string;
  min_past_due?: number;
  aging_bucket?: string;
  bdt_status?: string;
  search?: string;
}
