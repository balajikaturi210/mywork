export interface CustomerJourney {
  event_ts: string;
  event_type: string;
  event_label: string;
  amount: string | null;
  detail1: string | null;
  detail2: string | null;
  ref_id: string;
  description: string | null;
  pay_method: string;
  pay_method_type: string;
  failure_reason: string;
}
