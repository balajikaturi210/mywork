export interface DDCurrentRequest {
  min_bal: number;
  traceId?:string
}

export interface DDCurrent {
  bucket: string;
  segment: string;
  accounts: number;
  total_balance: number;
}

export interface DDResolutionRow {
  due_month: string;
  segment: "SMB" | "RESI" | "ALL";
  resolution: "ON TIME" | "DD+1-4" | "DD+5-12" | "DD+13+" | "UNPAID";
  invoice_count: number;
}

export interface DDResolutionSummaryItem {
  segment: "SMB" | "RESI" | "ALL";
  on_time: number;
  dd1_4: number;
  dd5_12: number;
  dd13p: number;
  unpaid: number;
  total: number;
  pct_dd4: number;
  pct_dd12: number;
}

export interface DDResolutionResponse {
  by_month: DDResolutionRow[];
  summary: DDResolutionSummaryItem[];
  months_range: number;
}

export interface DdCurrentDownloadQuery {
  bucket?: string;
  min_bal?: number;
  traceId?:string
}

export interface DdCurrentDownload {
  account_num: string;
  first_name: string;
  last_name: string;
  segment: string;
  category: string;
  balance: number;
  due_date: string;
  days_past_due: number;
  bucket: string;
  dunning_plan: string;
  bill_cycle: string;
}
