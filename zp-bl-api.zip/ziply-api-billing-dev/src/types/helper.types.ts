export interface DateRangeInput {
  from?: string;
  to?: string;
  days?: number;
  defaultDays?: number;
}

export interface DateRange {
  start: string;
  end: string;
  cacheKey: string;
}
