export interface NpdWriteoffTrend {
  writeoff_month: string;

  accounts: number;

  total_balance: number;

  smb_balance: number | null;

  resi_balance: number | null;
}

export interface NpdMissingWriteoffTrend {
  disconnect_month: string;

  missing_count: number;

  total_open_balance: number;

  smb_balance: number | null;

  resi_balance: number | null;
}

export interface NPDWriteoffAccount {
  account_num: string;
  status: string;
  category: string;
  autopay: string;
  writeoff_amount: number;
  writeoff_posted_on: string;
  was_suspended: boolean;
}

export interface WriteoffPayment {
  day: string;
  src: string;
  segment: string;
  pay_count: number;
  unique_accts: number;
  total_amount: number;
}


export interface NpdMissingWriteoffAccount {
  account_num: string;
  category: string;
  autopay: string;
  open_balance: number;
  open_inv_count: number;
  deactivated_on: string;
  days_disconnected: number;
}

export interface WriteoffDayAccount {
  account_num: string;
  category: string;
  balance: number;
  src: string;
  amount: number;
  created_on: string;
  payment_method_id: string;
}