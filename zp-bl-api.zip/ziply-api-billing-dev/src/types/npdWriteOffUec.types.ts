/** Write-off and unreturned equipment charge (UEC) by the month the account was closed. */
export interface NpdWriteoffUecTrend {
  month: string;
  accounts: number;
  total_writeoff: number;
  resi_amount: number;
  smb_amount: number;
  uec_amount: number;
  uec_pct: number | null;
}

/** Closed accounts with a balance, split by whether they are already in a write-off dunning plan. */
export interface NpdWriteoffBacklog {
  month: string;
  accounts: number;
  total_balance: number;
  already_flagged: number;
  pending: number;
  /** closed accounts with a balance that are not in a write-off plan yet */
  pending_accounts: number;
  /** unreturned equipment charge (Equipment Return - Debit) on those pending accounts */
  pending_uec: number;
}

/** Accounts that entered a write-off dunning plan in the month (audit log). */
export interface NpdWriteoffPlanEntry {
  month: string;
  accounts_entered: number;
  current_balance: number;
  /** median monthly entries across the window, for comparison */
  normal_monthly_entries: number;
  /** the write-off dunning job produced almost nothing this month although it normally does */
  stalled: boolean;
  /** the current month, still running */
  partial_month: boolean;
}
