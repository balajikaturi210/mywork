export interface Summary {
  active_accounts: number;
  autopay_on: number;
  main_billing: number;
  no_bill_pull: number;

  suspended: number;
  deactivated: number;
  final_bill: number;
  closed: number;
  disconnected: number;

  paper_bill: number;

  wo_pay_count: number;
  wo_pay_total: number;
  wo_pay_accts: number;

  api_fail_pct: number;
  batch_fail_pct: number;
}

export interface AutoPay {
  autopay: string;
  category: string;
  accounts: number;
}

export interface PaymentFailureDaily {
  day: string;
  src: string;
  completed: number;
  failed: number;
  voided: number;
}

export interface StatusTrend {
  day: string;
  status: string;
  cnt: number;
}

export interface Q1DeactivationBalance {
  total_disconnects: number;
  with_balance: number;
  total_open_balance: number;
  smb_balance: number;
  resi_balance: number;
}

export interface SuspendRestoreCohort {
  suspend_date: string;
  suspended: number;
  chargebacks: number;
  restored: number;
  r_d0: number;
  r_d1_7: number;
  r_d8_14: number;
  r_d15_30: number;
  r_d31p: number;
  temp_restored: number;
  to_deact: number;
  to_final_bill: number;
  to_closed: number;
  still_suspended: number;
}

export interface CohortAccount {
  account_num: string;
  category: string;
  current_status: string;
  next_status: string;
  days_elapsed: number | null;
  balance: number;
  autopay: string;
  dunning_plan: string;
  chargeback: string;
  chargeback_note: string | null;
}
