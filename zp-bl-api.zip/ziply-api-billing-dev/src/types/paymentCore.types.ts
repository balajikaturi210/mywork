export interface GetInvoicesRequest {
  accountNum: string;
  source?: string;
  apiKeyOverride?: string;
  authorizationOverride?: string;
}

export interface GetChargeBreakdownRequest {
  invoiceId: string;
  source?: string;
}

export interface AccountAdjustmentRequest {
  payload: Record<string, unknown>;
}

export interface GetAccountAdjustmentRequest {
  params: Record<string, string>;
  accountNumber?: string;
  adjustmentType: "CREDIT" | "DEBIT";
}

export interface GetAdjustmentReasonRequest {
  adjustmentType: "CREDIT" | "DEBIT";
}

export interface ReverseAccountAdjustmentRequest {
  payload: Record<string, unknown>;
}

export interface UpdateAdjustmentsRequest {
  payload: Record<string, unknown>;
}

export interface GetInvoicePdfRequest {
  invoiceId: string;
  accountNum?: string;
  apiKeyOverride?: string;
  authorizationOverride?: string;
}

export interface InvoicePdfResponse {
  data: Buffer;
  contentType: string;
  contentDisposition?: string;
}

export class PaymentCoreServiceError extends Error {
  statusCode: number;
  upstreamStatus?: number;
  details?: unknown;

  constructor(
    message: string,
    statusCode: number,
    upstreamStatus?: number,
    details?: unknown,
  ) {
    super(message);
    this.name = "PaymentCoreServiceError";
    this.statusCode = statusCode;
    this.upstreamStatus = upstreamStatus;
    this.details = details;
  }
}
