export interface Surcharge {
  day: string;

  segment: "SMB" | "RESI";

  has_surcharge: number;

  card_class: string;

  card_class_source: string;

  card_type: string | null;

  txn_count: number;

  total_surcharge: number;
}

export interface SurchargePmType {
  payment_type: string;
  payment_category_id: string;
  pm_count: number;

  field_270_name: string | null;
  field_270_values: string | null;

  field_188_name: string | null;
  field_188_values: string | null;

  field_187_name: string | null;
  field_187_values: string | null;
}

export interface SurchargeCardTypeMissing {
  account_num: string;
  status: string;
  segment: string;
  category: string;
  payment_date: string;
  amount: number;
  channel: string;
  payment_method_id: string;
  payment_category_id: string;
  payment_type: string;
  has_surcharge: number;
  surcharge_amount: number;
}

export interface DrillParams {
  bankId: string;
  mode: string;
  fromDate?: string;
  toDate?: string;
  traceId?:string
}

export interface BreakdownRow {
  surcharge_group: string;
  segment: string;
  pm_status: string;
  card_type_flag: string;
  bank_id_188: string;
  channel: string;
  pm_count: number;
}

export interface PmcfRow {
  surcharge_group: string;
  cf_name: string;
  cf_value: string;
  pm_count: number;
}

export interface CompareResponse {
  breakdown: BreakdownRow[];
  pmcf: PmcfRow[];
}




export interface SurchargeExportRequest {
  hasSurcharge?: string;
  segment?: string;
  cardClass: string;
  traceId?:string;
}


export interface SurchargeExportResponse {
  csv: string;
  filename: string;
}