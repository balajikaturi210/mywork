export interface SuspensionAging {
  account_num: string;
  category: string | null;
  autopay: string; // Snowflake returns VARCHAR
  balance: number;
  suspended_since: string; // YYYY-MM-DD
  days_suspended: number;
  dunning_plan: string;
  dunning_tier: string;
}

export interface DunningInvoiceAging {
  dunning_plan: string;

  total_accts: number;

  d0_24: number;
  d25_45: number;
  d46_74: number;
  d75p: number;

  avg_oldest_days: number;
  total_balance: number;
}

export interface PaidStillSuspended {
  billing_account_id: string;
  account_num: string;

  category: string;
  autopay: string;

  balance: number;

  suspended_since: string;
  days_suspended: number;

  payment_count: number;
  total_paid: number;

  last_payment_on: string;
  days_since_payment: number;
}




export interface DunningInvoiceAccount {
  account_num: string;
  category: string;
  acct_status: string;
  autopay: string;
  account_balance: number;
  oldest_due_date: string;
  oldest_age_days: number;
  open_invoice_count: number;
  total_open_balance: number;
}