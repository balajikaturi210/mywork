export interface TechInstallResponse {
  total_charged: number;
  net_paid: number;
  net_paid_with_fee_adj: number;
  discounted: number;
  fee_discount_adjustment: number;
  positive_refund: number;
  negative_refund: number;
  new_accounts_mtd: number;
  new_accounts_resi: number;
  new_accounts_biz: number;
}

export interface TechInstallTenure {
  tenure_bucket: string;
  accounts: number;
  avg_tenure_days: number;
  avg_invoice_count: number;
}

export interface TechInstallAccount {
  account_num: string;
  category: string;
  status: string;
  charge_date: string;
  tenure_days: number;
  invoice_count: number;
  customer_type: string;
  install_amount: number;
  fee_adj_amount: number;
  net_amount: number;
  has_fee_adj: string;
  sales_order_type: string;
  order_number: string;
  order_classification: string;
}

export interface TechInstallDiscountedAccount {
  account_num: string;
  category: string;
  status: string;
  charge_date: string;
  tenure_days: number;
  invoice_count: number;
  customer_type: string;
  sales_order_type: string;
  order_number: string;
  order_classification: string;
}

export interface AutoPayTrendRow {
  month: string;
  autopay_accounts: number;
  autopay_with_late_fee: number;
  late_fee_total: number;
  pct_with_late_fee: number;
}

export interface AutoPaySnapshot {
  autopay_active_accounts: number;
  also_have_old_unpaid: number;
  total_old_balance: number;
  also_charged_late_fee: number;
  old_unpaid_and_late_fee: number;
  pct_with_old_unpaid: number;
  pct_with_late_fee: number;
}

export interface AutoPayCategoryRow {
  category: string;
  status: string;
  accounts: number;
  total_old_balance: number;
  avg_old_balance: number;
  avg_days_overdue: number;
}

export interface AutoPayLatenessTrendResponse {
  trend: AutoPayTrendRow[];
  snapshot: AutoPaySnapshot;
  category: AutoPayCategoryRow[];
}

export interface PaperlessTrendRow {
  month: string;
  total_customers: number;
  paperless_customers: number;
  paper_customers: number;
  paperless_pct: number;
}

export interface DiscountTrendRow {
  month: string;
  discount_type: string;
  total_discounts: number;
  accounts_with_discount: number;
}

export interface PaperlessDiscountTrendResponse {
  paperless: PaperlessTrendRow[];
  discounts: DiscountTrendRow[];
}

export interface SurchargeTrend {
  month: string;
  txn_count: number;
  total_surcharge: number;
  resi_surcharge: number;
  smb_surcharge: number;
}
