import * as https from "https";
import { PaymentCoreServiceError } from "../types/paymentCore.types";

export type AccountAdjustmentOperation = "create" | "get" | "reverse";
export type AccountAdjustmentType = "CREDIT" | "DEBIT";

export type AccountAdjustmentConfig = {
  endpoint: string;
  timeout: number;
  headers: Record<string, string>;
  httpsAgent: https.Agent;
  useProxy: boolean;
};

type AccountAdjustmentOverrides = {
  apiKey?: string;
  authorization?: string;
};

const trimTrailingSlash = (value: string): string => value.replace(/\/+$/, "");

const hasV1Suffix = (value: string): boolean =>
  value.trim().toLowerCase().endsWith("/v1");

const getOperationPath = (
  operation: AccountAdjustmentOperation,
  adjustmentType?: AccountAdjustmentType,
): string => {
  if (operation === "reverse") {
    return "reverseAccountAdjustment";
  }

  if (operation === "create") {
    if (adjustmentType === "DEBIT") {
      return "debitadjustments";
    }
    if (adjustmentType === "CREDIT") {
      return "creditadjustment";
    }
    return "accountAdjustment";
  }

  if (adjustmentType === "DEBIT") {
    return "debitadjustment";
  }
  if (adjustmentType === "CREDIT") {
    return "creditadjustment";
  }

  return "getAccountAdjustment";
};

const buildPaymentCoreEndpoint = (
  operation: AccountAdjustmentOperation,
  adjustmentType?: AccountAdjustmentType,
): string => {
  const baseUrl = trimTrailingSlash(String(process.env.PAYMENT_CORE_BASE_URL || "").trim());
  if (!baseUrl) {
    return "";
  }

  const operationPath = getOperationPath(operation, adjustmentType);
  return `${baseUrl}${hasV1Suffix(baseUrl) ? "" : "/v1"}/${operationPath}`;
};

const getEndpointByOperation = (
  operation: AccountAdjustmentOperation,
  adjustmentType?: AccountAdjustmentType,
): string => {
  const createUrl = String(process.env.ACCOUNT_ADJUSTMENT_CREATE_URL || "").trim();
  const createCreditUrl = String(process.env.ACCOUNT_ADJUSTMENT_CREATE_CREDIT_URL || "").trim();
  const createDebitUrl = String(process.env.ACCOUNT_ADJUSTMENT_CREATE_DEBIT_URL || "").trim();
  const getUrl = String(process.env.ACCOUNT_ADJUSTMENT_GET_URL || "").trim();
  const getCreditUrl = String(process.env.ACCOUNT_ADJUSTMENT_GET_CREDIT_URL || "").trim();
  const getDebitUrl = String(process.env.ACCOUNT_ADJUSTMENT_GET_DEBIT_URL || "").trim();
  const reverseUrl = String(process.env.ACCOUNT_ADJUSTMENT_REVERSE_URL || "").trim();
  const useCustomUrls =
    String(process.env.ACCOUNT_ADJUSTMENT_USE_CUSTOM_URLS ?? "false")
      .trim()
      .toLowerCase() === "true";

  if (!useCustomUrls) {
    return buildPaymentCoreEndpoint(operation, adjustmentType);
  }

  switch (operation) {
    case "create":
      if (adjustmentType === "CREDIT" && createCreditUrl) {
        return createCreditUrl;
      }
      if (adjustmentType === "DEBIT" && createDebitUrl) {
        return createDebitUrl;
      }
      return createUrl;
    case "get":
      if (adjustmentType === "CREDIT" && getCreditUrl) {
        return getCreditUrl;
      }
      if (adjustmentType === "DEBIT" && getDebitUrl) {
        return getDebitUrl;
      }
      return getUrl;
    case "reverse":
      return reverseUrl;
    default:
      return "";
  }
};

export const getAccountAdjustmentConfig = (
  operation: AccountAdjustmentOperation,
  adjustmentType?: AccountAdjustmentType,
): AccountAdjustmentConfig => {
  const endpoint = getEndpointByOperation(operation, adjustmentType);
  const timeout = Number(
    process.env.ACCOUNT_ADJUSTMENT_TIMEOUT_MS || process.env.PAYMENT_CORE_TIMEOUT_MS || 15000,
  );
  const useProxy =
    String(
      process.env.ACCOUNT_ADJUSTMENT_USE_PROXY ?? process.env.PAYMENT_CORE_USE_PROXY ?? "false",
    )
      .trim()
      .toLowerCase() === "true";
  const tlsRejectUnauthorized =
    String(
      process.env.ACCOUNT_ADJUSTMENT_TLS_REJECT_UNAUTHORIZED ??
        process.env.PAYMENT_CORE_TLS_REJECT_UNAUTHORIZED ??
        "true",
    )
      .trim()
      .toLowerCase() !== "false";
  const isDevelopment = String(process.env.NODE_ENV || "").trim().toLowerCase() === "development";
  const effectiveRejectUnauthorized = isDevelopment ? false : tlsRejectUnauthorized;

  if (!endpoint) {
    throw new PaymentCoreServiceError(
      "Account adjustment service is currently unavailable. Please try again later",
      500,
    );
  }

 

  if (!Number.isFinite(timeout) || timeout <= 0) {
    throw new PaymentCoreServiceError(
      "Account adjustment service is currently unavailable. Please try again later",
      500,
    );
  }

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
  };

  
  const httpsAgent = new https.Agent({ rejectUnauthorized: effectiveRejectUnauthorized });

  return {
    endpoint,
    timeout,
    headers,
    httpsAgent,
    useProxy,
  };
};
