/** The most rows an export returns; the total still says how many matched. */
export const EXPORT_MAX_ROWS = 10000;

export type CustomerSearchCriteria = {
  accountNumber?: string;
  customerName?: string;
  primaryEmailAddress?: string;
  summaryAccountNumber?: string;
  firstName?: string;
  lastName?: string;
  telephoneNumber?: string;
  dateFrom?: string;
  dateTo?: string;
  days?: number;
};

export type CustomerSearchRequest = {
  criteria: CustomerSearchCriteria;
  page: number;
  perPage: number;
};

export class CustomerSearchValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "CustomerSearchValidationError";
  }
}

const criteriaKeys = [
  "accountNumber", "customerName", "primaryEmailAddress", "summaryAccountNumber",
  "firstName", "lastName", "telephoneNumber", "dateFrom", "dateTo",
] as const;

export const parseCustomerSearchQuery = (query: Record<string, unknown>): CustomerSearchRequest => {
  const criteria: CustomerSearchCriteria = {};
  for (const key of criteriaKeys) {
    const value = query[key];
    if (value === undefined) {
      continue;
    }
    if (typeof value !== "string") {
      throw new CustomerSearchValidationError(`${key} must be a single text value.`);
    }
    if (value.trim()) {
      criteria[key] = value.trim();
    }
  }

  if (query.days !== undefined && query.days !== "") {
    const value = query.days;
    if (typeof value !== "string" || !/^[1-9]\d*$/.test(value.trim()) || !Number.isSafeInteger(Number(value))) {
      throw new CustomerSearchValidationError("days must be a positive integer.");
    }
    criteria.days = Number(value);
  }
  if (Object.keys(criteria).length === 0) {
    throw new CustomerSearchValidationError("Enter at least one customer search field.");
  }

  for (const key of ["accountNumber", "summaryAccountNumber"] as const) {
    if (criteria[key] && !/^\d+$/.test(criteria[key])) {
      throw new CustomerSearchValidationError(`${key} must contain only digits.`);
    }
  }

  if (criteria.telephoneNumber) {
    if (!/^\d{10}$/.test(criteria.telephoneNumber)) {
      throw new CustomerSearchValidationError("telephoneNumber must contain exactly 10 digits.");
    }
  }

  for (const key of ["dateFrom", "dateTo"] as const) {
    const value = criteria[key];
    if (value && (
      !/^\d{4}-\d{2}-\d{2}$/.test(value)
      || value.startsWith("0000-")
      || Number.isNaN(Date.parse(value))
      || new Date(value).toISOString().slice(0, 10) !== value
    )) {
      throw new CustomerSearchValidationError(`${key} must be a valid date in YYYY-MM-DD format.`);
    }
  }
  if (criteria.dateFrom && criteria.dateTo && criteria.dateFrom > criteria.dateTo) {
    throw new CustomerSearchValidationError("Date From must be on or before Date To.");
  }

  const parsePageValue = (key: "page" | "perPage", fallback: number): number => {
    const value = query[key];
    if (value === undefined) {
      return fallback;
    }
    if (typeof value !== "string" || !/^[1-9]\d*$/.test(value) || !Number.isSafeInteger(Number(value))) {
      throw new CustomerSearchValidationError(`${key} must be a positive integer.`);
    }
    return Number(value);
  };
  // The export download asks for one large page of everything that matches.
  const forExport = query.export === "true";
  const page = forExport ? 1 : parsePageValue("page", 1);
  const perPage = forExport ? EXPORT_MAX_ROWS : parsePageValue("perPage", 10);
  if ((perPage > 100 && !forExport) || !Number.isSafeInteger((page - 1) * perPage)) {
    throw new CustomerSearchValidationError("perPage must not exceed 100 and the requested page must be valid.");
  }

  return { criteria, page, perPage };
};
