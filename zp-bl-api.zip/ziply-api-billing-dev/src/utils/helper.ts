import { DateRangeInput, DateRange } from "../types/helper.types";

export const getDateRange = ({
  from,
  to,
  days,
  defaultDays = 30,
}: DateRangeInput): DateRange => {
  // Case 1: explicit range
  if (from?.trim() && to?.trim()) {
    return {
      start: from.trim(),
      end: to.trim(),
      cacheKey: `${from.trim()}_${to.trim()}`,
    };
  }

  const resolvedDays = Number(days ?? defaultDays);

  const today = new Date();

  const startDate = new Date(today);
  startDate.setDate(today.getDate() - resolvedDays);

  const endDate = new Date(today);
  endDate.setDate(today.getDate() - 1); // yesterday

  const format = (d: Date) => d.toISOString().split("T")[0];

  return {
    start: format(startDate),
    end: format(endDate),
    cacheKey: String(resolvedDays),
  };
};

export const getISODate = (): string => {
  const now = new Date();

  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
};
