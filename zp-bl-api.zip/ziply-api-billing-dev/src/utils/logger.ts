
import { randomUUID } from "crypto";
import logger from "../logger/logger";

export { logger };

export const getTraceId = () => randomUUID();

export default logger;


