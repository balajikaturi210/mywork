import type { NpdWriteoffPlanEntry } from "../types/npdWriteOffUec.types";

export const DEFAULT_MONTHS = 12;
export const MAX_MONTHS = 36;

export class NpdWriteoffValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "NpdWriteoffValidationError";
  }
}

/** The `months` query parameter: a whole number from 1 to 36, 12 when it is not given. */
export const parseMonths = (raw: unknown, fallback = DEFAULT_MONTHS): number => {
  if (raw === undefined || raw === null || raw === "") return fallback;
  const text = String(raw).trim();
  if (!/^\d+$/.test(text)) throw new NpdWriteoffValidationError("months must be a whole number");
  const months = Number(text);
  if (months < 1 || months > MAX_MONTHS) {
    throw new NpdWriteoffValidationError(`months must be between 1 and ${MAX_MONTHS}`);
  }
  return months;
};

const monthKey = (year: number, monthIndex: number): string => {
  const d = new Date(Date.UTC(year, monthIndex, 1));
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
};

/** Every month from `months` back up to and including the current one, oldest first ("YYYY-MM"). */
export const monthWindow = (months: number, today: Date = new Date()): string[] => {
  const out: string[] = [];
  for (let back = months; back >= 0; back--) {
    out.push(monthKey(today.getUTCFullYear(), today.getUTCMonth() - back));
  }
  return out;
};

const median = (values: number[]): number => {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
};

/** A month counts as stalled when it has fewer entries than this share of a normal month. */
export const STALL_SHARE = 0.05;

/**
 * Turns the audit-log rows (months that had at least one write-off plan entry) into one row per month of the window
 * with zero for the quiet ones, and marks the months where the write-off dunning job stalled.
 *
 *   normal   = the median of the months that had entries
 *   stalled  = a past month with fewer entries than 5% of normal, AFTER an earlier month reached that level
 *              (so the months before the job ever ran are not flagged)
 *   partial  = the current month, which is never flagged because it is still running
 */
export const buildPlanEntries = (
  rows: Array<{ month: string; accounts_entered: number; current_balance: number }>,
  months: number,
  today: Date = new Date(),
): NpdWriteoffPlanEntry[] => {
  const byMonth = new Map(rows.map((r) => [r.month, r]));
  const window = monthWindow(months, today);
  const current = window[window.length - 1];
  const normal = median(rows.map((r) => r.accounts_entered).filter((n) => n > 0));
  const threshold = normal * STALL_SHARE;
  let jobHasRun = false;
  return window.map((month) => {
    const row = byMonth.get(month);
    const accounts = row?.accounts_entered ?? 0;
    const partial = month === current;
    const stalled = !partial && jobHasRun && accounts < threshold;
    if (accounts >= threshold && accounts > 0) jobHasRun = true;
    return {
      month,
      accounts_entered: accounts,
      current_balance: row?.current_balance ?? 0,
      normal_monthly_entries: Math.round(normal),
      stalled,
      partial_month: partial,
    };
  });
};
