import * as https from "https";
import { BillingServiceError } from "../types/billing.types";

export type PaymentCoreConfig = {
  baseUrl: string;
  timeout: number;
  headers: Record<string, string>;
  httpsAgent: https.Agent;
  tlsRejectUnauthorized: boolean;
  useProxy: boolean;
};

export const getPaymentCoreConfig = (): PaymentCoreConfig => {
  const baseUrl = (process.env.PAYMENT_CORE_BASE_URL || "").trim().replace(/\/$/, "");
  const timeout = Number(process.env.PAYMENT_CORE_TIMEOUT_MS || 15000);
  const useProxy =
    String(process.env.PAYMENT_CORE_USE_PROXY ?? "false").trim().toLowerCase() === "true";
  const tlsRejectUnauthorized =
    String(process.env.PAYMENT_CORE_TLS_REJECT_UNAUTHORIZED ?? "true")
      .trim()
      .toLowerCase() !== "false";

  if (!baseUrl) {
    throw new BillingServiceError(
      "Payment service is currently unavailable. Please try again later",
      500,
    );
  }

  const headers: Record<string, string> = {
    Accept: "application/json",
  };


  const httpsAgent = new https.Agent({ rejectUnauthorized: tlsRejectUnauthorized });

  return { baseUrl, timeout, headers, httpsAgent, tlsRejectUnauthorized, useProxy };
};

export const getUpstreamErrorMessage = (payload: unknown): string | undefined => {
  const record =
    payload && typeof payload === "object" ? (payload as Record<string, unknown>) : undefined;
  const error = record?.Error;
  if (!error || typeof error !== "object") return undefined;
  const message = (error as Record<string, unknown>).message;
  return typeof message === "string" && message.trim() ? message : undefined;
};
