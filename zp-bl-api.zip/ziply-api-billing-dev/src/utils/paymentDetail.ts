export class PaymentDetailValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PaymentDetailValidationError";
  }
}

/** The id in /payments/:paymentId: digits only, and small enough to be a real payment id. */
export const parsePaymentId = (raw: unknown): string => {
  const text = typeof raw === "string" ? raw.trim() : "";
  if (!/^\d{1,18}$/.test(text)) {
    throw new PaymentDetailValidationError("paymentId must contain only digits");
  }
  return text;
};

type Row = Record<string, unknown>;

const text = (value: unknown): string | null => {
  if (value === null || value === undefined) return null;
  const result = String(value).trim();
  return result === "" ? null : result;
};

const amount = (value: unknown): number | null => {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
};

const iso = (value: unknown): string | null => {
  if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value.toISOString();
  return text(value);
};

/** Payment Core shows card and account digits as "Last 4: 1234". */
const lastFourLabel = (digits: string | null): string | null => (digits && /^\d{4}$/.test(digits) ? `Last 4: ${digits}` : null);

/**
 * Turns a payment (with its account, payment method, custom fields and status history, as read from the database) into
 * the JSON shape Payment Core returns for one payment, so the page's existing mapping reads it unchanged.
 * The payment token is left out on purpose: no screen shows it.
 */
export const toPaymentCoreShape = (row: Row, customFields: Row[], statusHistory: Row[]) => {
  const cardLastFour = text(row.card_identifier_last_four);
  const bankLastFour = text(row.bank_account_number_last_four);
  const methodType = text(row.method_category) ?? text(row.method_payment_type) ?? text(row.payment_method_type);

  return {
    payment_type: "payment",
    id: String(row.id),
    amount: amount(row.amount),
    description: text(row.description),
    status: text(row.status),
    billing_account: {
      id: row.billing_account_id === null || row.billing_account_id === undefined ? null : String(row.billing_account_id),
      account_num: text(row.account_num),
      external_account_num: null,
      account_name: [text(row.account_first_name), text(row.account_last_name)].filter(Boolean).join(" ") || null,
    },
    payment_method: row.payment_method_id === null || row.payment_method_id === undefined ? null : {
      payment_method_type: methodType,
      id: String(row.payment_method_id),
      nickname: text(row.nickname),
      first_name: text(row.card_holder_firstname),
      last_name: text(row.card_holder_lastname),
      // Bank methods keep the holder's name in one column instead of first and last.
      account_holder_name: text(row.card_holder_name),
      card_type: text(row.card_type),
      identifier_number: lastFourLabel(cardLastFour) ?? lastFourLabel(bankLastFour),
      expiration_date: text(row.card_expiration),
      last_four: cardLastFour,
      account_type: text(row.bank_account_type),
      custom_field_values: customFields
        .filter((field) => field.custom_field_enabled !== false)
        .map((field) => ({
          id: String(field.id),
          value: text(field.value),
          custom_field: { id: field.custom_field_id === null || field.custom_field_id === undefined ? null : String(field.custom_field_id), name: text(field.name) },
        })),
    },
    occurred_on: iso(row.occurred_on),
    unapplied_amount: amount(row.unapplied_amount),
    refunded_amount: amount(row.refund_amount),
    canceled_amount: amount(row.cancel_amount),
    surcharge_amount: amount(row.surcharge_amount),
    currency_code: text(row.currency),
    payment_processor: text(row.payment_source_type) ? { type: null, id: text(row.payment_source_type) } : null,
    mark_for_settlement: row.mark_for_settlement === null || row.mark_for_settlement === undefined ? null : Boolean(row.mark_for_settlement),
    authorization: text(row.auth_code),
    reference: text(row.reference),
    transaction_id: text(row.transaction_number),
    current_status_entries: statusHistory.map((entry) => ({
      id: String(entry.id),
      status: text(entry.status_id),
      status_date: iso(entry.status_date),
      reason: text(entry.reason),
      reason_code: text(entry.reason_code),
      user_name: text(entry.created_by),
      change_type: "STATUS",
    })),
  };
};
