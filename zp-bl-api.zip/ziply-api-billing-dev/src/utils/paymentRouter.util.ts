import { getPaymentCoreConfig, PaymentCoreConfig } from "./paymentCore.util";
import { BillingServiceError } from "../types/billing.types";

export const getPaymentRouterConfig = (): PaymentCoreConfig => {
  const paymentCoreConfig = getPaymentCoreConfig();
  const baseUrl = String(process.env.PAYMENT_ROUTER_BASE_URL || "")
    .trim()
    .replace(/\/$/, "");

  if (!baseUrl) {
    throw new BillingServiceError(
      "Payment transaction history is currently unavailable. Please try again later",
      500,
    );
  }

  return {
    ...paymentCoreConfig,
    baseUrl,
  };
};
