export type PaymentStatusGroup = "success" | "failure" | "other";
export type PaymentTypeFilter = "recurring" | "one-time" | "validation";

export type PaymentSearchCriteria = {
  /**
   * Calendar days (UTC) ending today: 1 is today only, 7 is today and the six days before it.
   * The range is on when the payment was recorded (created_on, which is indexed), not on its payment date.
   * Left out, the search covers every date, which is only allowed together with an account number, name or billing account id.
   */
  days?: number;
  status?: PaymentStatusGroup;
  paymentType?: PaymentTypeFilter;
  accountNumber?: string;
  accountName?: string;
  /** one account, by its billing account id (the customer's Payments tab); an indexed lookup, so long ranges are cheap */
  billingAccountId?: string;
  minAmount?: number;
};

export type PaymentSearchRequest = {
  criteria: PaymentSearchCriteria;
  page: number;
  perPage: number;
  /** the export download asks for one large page of everything that matches */
  forExport: boolean;
};

export const DEFAULT_DAYS = 7;
/** 180 days summarises in under a second; a full year takes over a second on the largest table, so it is not offered. */
export const MAX_DAYS = 180;
/** One account's payments are read through an index, so its range may reach back ten years. */
export const MAX_ACCOUNT_DAYS = 3650;
export const DEFAULT_PER_PAGE = 25;
export const MAX_PER_PAGE = 100;
/** The most rows an export returns; the summary total still says how many matched. */
export const EXPORT_MAX_ROWS = 10000;
export const MIN_ACCOUNT_DIGITS = 5;
/** A name filter is a substring scan, so very short fragments would match (and scan) almost everything. */
export const MIN_ACCOUNT_NAME_LENGTH = 3;
/** The deepest row a page may start at: OFFSET cost grows with it, so people should narrow the filters instead. */
export const MAX_OFFSET = 100_000;

export class PaymentSearchValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "PaymentSearchValidationError";
  }
}

const STATUS_GROUPS: readonly PaymentStatusGroup[] = ["success", "failure", "other"];
const PAYMENT_TYPES: readonly PaymentTypeFilter[] = ["recurring", "one-time", "validation"];

const single = (query: Record<string, unknown>, key: string): string | undefined => {
  const value = query[key];
  if (value === undefined) return undefined;
  if (typeof value !== "string") throw new PaymentSearchValidationError(`${key} must be a single text value.`);
  const text = value.trim();
  return text === "" ? undefined : text;
};

const wholeNumber = (text: string | undefined, key: string, fallback: number, min: number, max: number): number => {
  if (text === undefined) return fallback;
  if (!/^\d+$/.test(text)) throw new PaymentSearchValidationError(`${key} must be a whole number.`);
  const value = Number(text);
  if (!Number.isSafeInteger(value) || value < min || value > max) {
    throw new PaymentSearchValidationError(`${key} must be between ${min} and ${max}.`);
  }
  return value;
};

/** Validates the query string of GET /payment/getPaymentSearch; every value reaches the database as a bind parameter. */
export const parsePaymentSearchQuery = (query: Record<string, unknown>): PaymentSearchRequest => {
  const daysText = single(query, "days");
  const allDates = daysText?.toLowerCase() === "all";
  const criteria: PaymentSearchCriteria = {};

  const billingAccountId = single(query, "billingAccountId");
  if (billingAccountId !== undefined) {
    if (!/^\d{1,18}$/.test(billingAccountId)) throw new PaymentSearchValidationError("billingAccountId must contain only digits.");
    criteria.billingAccountId = billingAccountId;
  }
  if (!allDates) {
    const maxDays = criteria.billingAccountId ? MAX_ACCOUNT_DAYS : MAX_DAYS;
    criteria.days = wholeNumber(daysText, "days", DEFAULT_DAYS, 1, maxDays);
  }

  const status = single(query, "status")?.toLowerCase();
  if (status !== undefined) {
    if (!STATUS_GROUPS.includes(status as PaymentStatusGroup)) {
      throw new PaymentSearchValidationError(`status must be one of ${STATUS_GROUPS.join(", ")}.`);
    }
    criteria.status = status as PaymentStatusGroup;
  }

  const paymentType = single(query, "paymentType")?.toLowerCase();
  if (paymentType !== undefined) {
    if (!PAYMENT_TYPES.includes(paymentType as PaymentTypeFilter)) {
      throw new PaymentSearchValidationError(`paymentType must be one of ${PAYMENT_TYPES.join(", ")}.`);
    }
    criteria.paymentType = paymentType as PaymentTypeFilter;
  }

  const accountNumber = single(query, "accountNumber");
  if (accountNumber !== undefined) {
    if (!/^\d+$/.test(accountNumber)) throw new PaymentSearchValidationError("accountNumber must contain only digits.");
    if (accountNumber.length < MIN_ACCOUNT_DIGITS) {
      throw new PaymentSearchValidationError(`accountNumber must have at least ${MIN_ACCOUNT_DIGITS} digits.`);
    }
    criteria.accountNumber = accountNumber;
  }

  const accountName = single(query, "accountName");
  if (accountName !== undefined) {
    if (accountName.length < MIN_ACCOUNT_NAME_LENGTH) {
      throw new PaymentSearchValidationError(`accountName must have at least ${MIN_ACCOUNT_NAME_LENGTH} characters.`);
    }
    if (accountName.length > 100) throw new PaymentSearchValidationError("accountName must not exceed 100 characters.");
    criteria.accountName = accountName;
  }

  const minAmount = single(query, "minAmount");
  if (minAmount !== undefined) {
    const value = Number(minAmount);
    if (!/^\d+(\.\d{1,2})?$/.test(minAmount) || !Number.isFinite(value)) {
      throw new PaymentSearchValidationError("minAmount must be a non-negative amount with at most two decimals.");
    }
    criteria.minAmount = value;
  }

  if (allDates && !criteria.accountNumber && !criteria.accountName && !criteria.billingAccountId) {
    throw new PaymentSearchValidationError("Searching all dates needs an account number or account name.");
  }

  const forExport = single(query, "export") === "true";
  const page = wholeNumber(single(query, "page"), "page", 1, 1, 1_000_000);
  const perPage = forExport
    ? EXPORT_MAX_ROWS
    : wholeNumber(single(query, "perPage"), "perPage", DEFAULT_PER_PAGE, 1, MAX_PER_PAGE);

  if ((page - 1) * perPage > MAX_OFFSET && !forExport) {
    throw new PaymentSearchValidationError(`Paging stops at ${MAX_OFFSET.toLocaleString("en-US")} rows; narrow the filters to reach older payments.`);
  }

  return { criteria, page: forExport ? 1 : page, perPage, forExport };
};

/**
 * "Recurring" for autopay runs and system batch payments, "Validation" for the $1 card checks, and "One Time" for
 * everything else, so every payment has exactly one type and the type filters always add up to the unfiltered total.
 */
export const PAYMENT_TYPE_SQL = `(CASE
          WHEN p.description ILIKE 'autopay%' THEN 'Recurring'
          WHEN p.description ILIKE 'auto-payment validation%' THEN 'Validation'
          WHEN NULLIF(BTRIM(p.description), '') IS NOT NULL THEN 'One Time'
          WHEN p.payment_source_type = 'BATCH' THEN 'Recurring'
          ELSE 'One Time'
        END)`;
