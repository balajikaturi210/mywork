import * as https from "https";
import { PaymentCoreServiceError } from "../types/paymentCore.types";

export type VpmConfig = {
  baseUrl: string;
  timeout: number;
  source: string;
  headers: Record<string, string>;
  auth?: {
    username: string;
    password: string;
  };
  httpsAgent: https.Agent;
  useProxy: boolean;
};

type VpmRuntimeOverrides = {
  apiKey?: string;
  authorization?: string;
};

export const getVpmConfig = (overrides?: VpmRuntimeOverrides): VpmConfig => {
  const baseUrl = String(process.env.VPM_BASE_URL || "")
    .trim()
    .replace(/\/+$/, "");
  const timeout = Number(process.env.VPM_TIMEOUT_MS || 15000);
  const source = String(process.env.VPM_INVOICE_SOURCE || "DPI").trim();
  const apiKey = String(
    overrides?.apiKey || process.env.VPM_API_KEY || "",
  ).trim();
  const apiKeyHeader = String(process.env.VPM_API_KEY_HEADER || "apikey").trim() || "apikey";
  const authorization = String(
    overrides?.authorization || process.env.VPM_AUTHORIZATION || "",
  ).trim();
  const username = String(process.env.VPM_BASIC_AUTH_USERNAME || "").trim();
  const password = String(process.env.VPM_BASIC_AUTH_PASSWORD || "").trim();
  const useProxy = String(process.env.VPM_USE_PROXY ?? "false").trim().toLowerCase() === "true";
  const tlsRejectUnauthorized =
    String(process.env.VPM_TLS_REJECT_UNAUTHORIZED ?? "true").trim().toLowerCase() !== "false";

  if (!baseUrl) {
    throw new PaymentCoreServiceError(
      "VPM_BASE_URL is missing or empty",
      500,
    );
  }

  if (!apiKey) {
    throw new PaymentCoreServiceError(
      "VPM_API_KEY is missing or empty",
      500,
    );
  }

  if (!Number.isFinite(timeout) || timeout <= 0) {
    throw new PaymentCoreServiceError(
      "VPM_TIMEOUT_MS must be a positive number",
      500,
    );
  }

  const headers: Record<string, string> = {
    [apiKeyHeader]: apiKey,
  };

  const normalizedApiKeyHeader = apiKeyHeader.toLowerCase();
  if (normalizedApiKeyHeader !== "apikey") {
    headers.apikey = apiKey;
  }
  if (normalizedApiKeyHeader !== "x-api-key") {
    headers["x-api-key"] = apiKey;
  }

  if (authorization) {
    headers.Authorization = authorization;
  }

  const auth = !authorization && username && password ? { username, password } : undefined;
  const httpsAgent = new https.Agent({ rejectUnauthorized: tlsRejectUnauthorized });

  return {
    baseUrl,
    timeout,
    source,
    headers,
    auth,
    httpsAgent,
    useProxy,
  };
};

export const getVpmUpstreamErrorMessage = (payload: unknown): string | undefined => {
  if (typeof payload === "string" && payload.trim()) {
    return payload;
  }

  if (!payload || typeof payload !== "object") {
    return undefined;
  }

  const record = payload as Record<string, unknown>;

  const asText = (value: unknown): string | undefined => {
    if (typeof value !== "string") return undefined;
    const normalized = value.trim();
    return normalized ? normalized : undefined;
  };

  const pickMessageFromObject = (obj: unknown): string | undefined => {
    if (!obj || typeof obj !== "object") return undefined;
    const typed = obj as Record<string, unknown>;
    return (
      asText(typed.message) ||
      asText(typed.detail) ||
      asText(typed.Text) ||
      asText(typed.faultstring)
    );
  };

  const detail = record.detail;
  if (typeof detail === "string" && detail.trim()) {
    return detail;
  }

  const message = record.message;
  if (typeof message === "string" && message.trim()) {
    return message;
  }

  const nestedErrorMessage = pickMessageFromObject(record.Error);
  if (nestedErrorMessage) {
    return nestedErrorMessage;
  }

  const nestedFaultMessage = pickMessageFromObject(record.fault);
  if (nestedFaultMessage) {
    return nestedFaultMessage;
  }

  return undefined;
};
