const assert = require('node:assert/strict');
const { readFileSync } = require('node:fs');
const test = require('node:test');
const { runInNewContext } = require('node:vm');
const ts = require('typescript');

function load(relativePath, dependencies = {}) {
  const source = readFileSync(require.resolve(relativePath), 'utf8');
  const compiled = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020, esModuleInterop: true },
  }).outputText;
  const exports = {};
  runInNewContext(compiled, {
    exports, Error,
    require: (name) => {
      assert.ok(Object.hasOwn(dependencies, name), `Unexpected dependency: ${name}`);
      return dependencies[name];
    },
  });
  return exports;
}

const types = load('../src/types/paymentCore.types.ts');
const logger = { info: () => {}, error: () => {} };
const commonDependencies = {
  '../utils/logger': { getTraceId: () => 'test-trace' },
  '../logger/logger': logger,
  '../types/paymentCore.types': types,
};

function controller(service) {
  return load('../src/controller/paymentCore.controller.ts', {
    ...commonDependencies,
    '../service/paymentCore.service': { getChargeBreakdownService: service },
  }).getChargeBreakdown;
}

function response() {
  return {
    status(code) { this.statusCode = code; return this; },
    json(body) { this.body = body; return this; },
  };
}

test('controller accepts both invoice ID aliases without truncation and normalizes source', async () => {
  for (const key of ['invoice_id', 'invoiceId']) {
    const payload = { charges: [] };
    const handler = controller(async (request) => {
      assert.equal(request.invoiceId, '0001234567890123');
      assert.equal(request.source, 'DPI');
      return payload;
    });
    const res = response();
    await handler({ query: { [key]: ' 0001234567890123 ', source: ' dpi ' } }, res);
    assert.equal(res.statusCode, 200);
    assert.equal(res.body, payload);
  }
});

test('controller rejects missing and invalid invoice IDs before calling VPM', async () => {
  const handler = controller(() => assert.fail('Unexpected service call'));
  for (const query of [{}, { invoice_id: '' }, { invoice_id: 'abc' }, { invoice_id: '12.3' }]) {
    const res = response();
    await handler({ query }, res);
    assert.equal(res.statusCode, 400);
    assert.match(res.body.message, /must contain only digits/);
  }
});

test('controller leaves omitted source to configuration and preserves service errors', async () => {
  const handler = controller(async (request) => {
    assert.equal(request.source, undefined);
    throw new types.PaymentCoreServiceError('Invalid invoice', 404, 404);
  });
  const res = response();
  await handler({ query: { invoice_id: '316382' } }, res);
  assert.equal(res.statusCode, 404);
  assert.equal(res.body.message, 'Invalid invoice');
  assert.equal(res.body.code, 404);
});

function service(get, overrides = {}) {
  const config = {
    baseUrl: 'https://vpm.example/VPMService/v1/bill', source: 'DPI',
    timeout: 15000, headers: { apikey: 'test-key' },
    auth: { username: 'test-user', password: 'test-password' },
    httpsAgent: {}, useProxy: false, ...overrides,
  };
  return load('../src/service/paymentCore.service.ts', {
    ...commonDependencies,
    axios: { get },
    '../config/zbpDb': {},
    '../utils/paymentCore.util': {},
    '../utils/accountAdjustment.util': {},
    '../service/helperUtil': {},
    '../utils/vpm.util': {
      getVpmConfig: () => config,
      getVpmUpstreamErrorMessage: (payload) => payload?.message,
    },
  }).getChargeBreakdownService;
}

test('service forwards query and connection configuration and returns upstream data', async () => {
  for (const source of [undefined, 'OTHER']) {
    const payload = { charges: [{ amount: 10 }] };
    const handler = service(async (endpoint, options) => {
      assert.equal(endpoint, 'https://vpm.example/VPMService/v1/bill/chargeBreakdown');
      assert.equal(options.params.invoice_id, '316382');
      assert.equal(options.params.source, source ?? 'DPI');
      assert.equal(options.headers.apikey, 'test-key');
      assert.equal(options.auth.username, 'test-user');
      assert.ok(options.httpsAgent);
      assert.equal(options.proxy, false);
      assert.equal(options.timeout, 15000);
      assert.equal(options.validateStatus(500), true);
      return { status: 200, data: payload };
    });
    assert.equal(await handler({ invoiceId: '316382', source }), payload);
  }
});

test('service preserves upstream client errors and maps server errors to 502', async () => {
  for (const status of [404, 500]) {
    const handler = service(async () => ({ status, data: {} }));
    await assert.rejects(handler({ invoiceId: '316382' }), (error) => {
      assert.ok(error instanceof types.PaymentCoreServiceError);
      assert.equal(error.statusCode, status === 500 ? 502 : 404);
      assert.equal(error.upstreamStatus, status);
      assert.equal(error.message, 'Unable to fetch charge breakdown');
      return true;
    });
  }
});

test('service maps timeouts to 504 and connection failures to 502', async () => {
  for (const code of ['ECONNABORTED', 'ECONNREFUSED']) {
    const handler = service(async () => { throw { code, message: 'Connection failed' }; });
    await assert.rejects(handler({ invoiceId: '316382' }), (error) => {
      assert.equal(error.statusCode, code === 'ECONNABORTED' ? 504 : 502);
      return true;
    });
  }
});