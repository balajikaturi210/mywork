const assert = require('node:assert/strict');
const { readFileSync } = require('node:fs');
const test = require('node:test');
const { runInNewContext } = require('node:vm');
const ts = require('typescript');

function load(relativePath, dependencies = {}) {
  const source = readFileSync(require.resolve(relativePath), 'utf8');
  const compiled = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020, esModuleInterop: true },
  }).outputText;
  const exports = {};
  runInNewContext(compiled, {
    exports, Error,
    require: (name) => {
      assert.ok(Object.hasOwn(dependencies, name), `Unexpected dependency: ${name}`);
      return dependencies[name];
    },
  });
  return exports;
}

const validation = load('../src/utils/customerSearch.ts');
const { parseCustomerSearchQuery, CustomerSearchValidationError } = validation;
const logger = { error: () => {} };

test('accepts every landing-page field alone and in combination', () => {
  const criteria = {
    firstName: ' Test ', lastName: ' Customer ', accountNumber: ' 00123 ',
    telephoneNumber: '(425) 555-0100', dateFrom: '2026-10-01', dateTo: '2026-10-31',
  };
  for (const [key, value] of Object.entries(criteria)) {
    assert.ok(parseCustomerSearchQuery({ [key]: value }).criteria[key]);
  }
  const parsed = parseCustomerSearchQuery({ ...criteria, page: '2', perPage: '25' });
  assert.equal(parsed.criteria.firstName, 'Test');
  assert.equal(parsed.criteria.telephoneNumber, '4255550100');
  assert.equal(parsed.page, 2);
  assert.equal(parsed.perPage, 25);
});

test('retains legacy search parameters', () => {
  for (const key of ['accountNumber', 'customerName', 'primaryEmailAddress', 'summaryAccountNumber']) {
    const value = key === 'accountNumber' || key === 'summaryAccountNumber' ? '00123' : 'legacy';
    assert.equal(parseCustomerSearchQuery({ [key]: value }).criteria[key], value);
  }
});

test('rejects empty, malformed, repeated, invalid-date and invalid-page criteria', () => {
  for (const query of [
    {}, { firstName: ' ' }, { firstName: ['Test', 'Other'] }, { firstName: {} },
    { telephoneNumber: 'letters' }, { telephoneNumber: '()' },
    { dateFrom: '2026-02-30' }, { dateTo: '2026-13-01' }, { dateFrom: '0000-01-01' },
    { dateFrom: '2026-10-31', dateTo: '2026-10-01' },
    { firstName: 'Test', page: '0' }, { firstName: 'Test', page: '1.5' },
    { firstName: 'Test', perPage: '101' }, { firstName: 'Test', perPage: ['10'] },
    { accountNumber: '12%' }, { summaryAccountNumber: 'letters' },
    { days: '0' }, { days: '-1' }, { days: '1.5' }, { days: ['10'] },
  ]) {
    assert.throws(() => parseCustomerSearchQuery(query), CustomerSearchValidationError);
  }
});

function serviceWithQuery(query) {
  return load('../src/service/report.services.ts', {
    '../utils/logger': { getTraceId: () => 'test-trace' },
    '../config/zbpDb': { query },
    '../logger/logger': logger,
    '../utils/paymentSearch': load('../src/utils/paymentSearch.ts'),
  });
}

test('binds every criterion with AND and uses inclusive UTC creation-date bounds', async () => {
  const calls = [];
  const { getCustomerSearchService } = serviceWithQuery(async (sql, values) => {
    calls.push({ sql, values });
    return sql.includes('COUNT(*)')
      ? { rows: [{ total: 2 }] }
      : { rows: [{ account_num: '0001234567890123' }, { account_num: '0001234567890124' }] };
  });
  const result = await getCustomerSearchService({
    firstName: "O'Neil", lastName: 'Customer', telephoneNumber: '4255550100',
    accountNumber: '00123', dateFrom: '2026-10-01', dateTo: '2026-10-31',
  }, 2, 10);
  assert.equal(calls.length, 2);
  assert.match(calls[0].sql, /ba\.account_num LIKE \$1 AND ba\.first_name ILIKE \$2 AND ba\.last_name ILIKE \$3/);
  assert.match(calls[0].sql, /REGEXP_REPLACE.*LIKE \$4/);
  assert.match(calls[0].sql, /ba\.created_on >= \(\$5::date::timestamp AT TIME ZONE 'UTC'\)/);
  assert.match(calls[0].sql, /ba\.created_on < \(\(\$6::date \+ 1\)::timestamp AT TIME ZONE 'UTC'\)/);
  assert.match(calls[0].sql, /LIMIT \$7 OFFSET \$8/);
  assert.doesNotMatch(calls[0].sql, /O'Neil|4255550100|2026-10-31/);
  assert.deepEqual(Array.from(calls[0].values), ['00123%', "%O'Neil%", '%Customer%', '%4255550100%', '2026-10-01', '2026-10-31', 10, 10]);
  assert.deepEqual(Array.from(calls[1].values), Array.from(calls[0].values).slice(0, 6));
  assert.equal(result.rows.length, 2);
  assert.equal(result.rows[0].dpi_account_num, '4567890123');
  assert.equal(result.total, 2);
});

test('supports one-sided date-only searches without requiring account number', async () => {
  for (const key of ['dateFrom', 'dateTo']) {
    const calls = [];
    const service = serviceWithQuery(async (sql, values) => {
      calls.push({ sql, values });
      return { rows: sql.includes('COUNT(*)') ? [{ total: 0 }] : [] };
    });
    const result = await service.getCustomerSearchService({ [key]: '2026-10-01' });
    assert.equal(result.total, 0);
    assert.equal(calls[0].values[0], '2026-10-01');
    assert.match(calls[0].sql, /WHERE ba\.created_on/);
    assert.doesNotMatch(calls[0].sql, /WHERE ba\.account_num/);
  }
});

test('does not execute an unfiltered customer query', async () => {
  const service = serviceWithQuery(() => assert.fail('No query expected'));
  await assert.rejects(service.getCustomerSearchService({}), /at least one criterion/);
});

test('retains incoming partial matching and days filters alongside explicit dates', async () => {
  const parsed = parseCustomerSearchQuery({
    summaryAccountNumber: '001', primaryEmailAddress: 'test',
    days: '30', dateFrom: '2026-10-01', dateTo: '2026-10-31',
  });
  assert.equal(parsed.criteria.days, 30);
  const calls = [];
  const service = serviceWithQuery(async (sql, values) => {
    calls.push({ sql, values });
    return { rows: sql.includes('COUNT(*)') ? [{ total: 0 }] : [] };
  });
  await service.getCustomerSearchService(parsed.criteria);
  assert.match(calls[0].sql, /ba\.account_num LIKE \$1 AND COALESCE\(ba\.primary_email, ''\) ILIKE \$2/);
  assert.match(calls[0].sql, /ba\.created_on >= NOW\(\) - \(\$5 \|\| ' days'\)::interval/);
  assert.match(calls[0].sql, /ba\.billing_ind/);
  assert.deepEqual(Array.from(calls[0].values), ['001%', '%test%', '2026-10-01', '2026-10-31', 30, 10, 0]);
});

function controller(service) {
  return load('../src/controller/report.controller.ts', {
    '../utils/logger': { getTraceId: () => 'test-trace' },
    '../service/report.services': { getCustomerSearchService: service },
    '../logger/logger': logger,
    '../config/zbpDb': {},
    '../utils/customerSearch': validation,
  }).getCustomerSearch;
}

async function invoke(handler, query) {
  let status;
  let body;
  await handler({ query }, {
    status(value) { status = value; return this; },
    json(value) { body = value; },
  });
  return { status, body };
}

test('controller returns all paged results while preserving legacy result', async () => {
  const rows = [{ account_num: '00123' }, { account_num: '00124' }];
  const handler = controller(async (criteria, page, perPage) => {
    assert.equal(criteria.firstName, 'Test');
    assert.equal(criteria.lastName, 'Customer');
    return { rows, total: 2, page, perPage };
  });
  const { status, body } = await invoke(handler, { firstName: 'Test', lastName: 'Customer', page: '1' });
  assert.equal(status, 200);
  assert.equal(body.rows.length, 2);
  assert.equal(body.result, rows[0]);
});

test('controller returns 200 empty pages for UI searches and legacy 404 for no match', async () => {
  const handler = controller(async () => ({ rows: [], total: 0, page: 1, perPage: 10 }));
  assert.equal((await invoke(handler, { accountNumber: '99999' })).status, 404);
  const paged = await invoke(handler, { firstName: 'missing', page: '1' });
  assert.equal(paged.status, 200);
  assert.equal(paged.body.rows.length, 0);
  assert.equal(paged.body.result, null);
});

test('controller exposes validation errors and returns failures explicitly', async () => {
  assert.equal((await invoke(controller(() => assert.fail('No service call expected')), {})).status, 400);
  const failure = await invoke(controller(async () => { throw new Error('test failure'); }), { firstName: 'Test' });
  assert.equal(failure.status, 500);
});

test('search results include the account start date so the Start Date column can show it', async () => {
  const calls = [];
  const { getCustomerSearchService } = serviceWithQuery(async (sql, values) => {
    calls.push({ sql, values });
    return sql.includes('COUNT(*)')
      ? { rows: [{ total: 1 }] }
      : { rows: [{ account_num: '0001234567890123', start_date: '2026-11-10T10:00:00.000Z' }] };
  });
  const result = await getCustomerSearchService({ dateFrom: '2026-11-07', dateTo: '2026-11-13' });
  assert.match(calls[0].sql, /\bba\.start_date,/);
  assert.equal(result.rows[0].start_date, '2026-11-10T10:00:00.000Z');
});

test('export asks for one page of up to 10,000 accounts; normal paging still stops at 100 per page', () => {
  const exported = parseCustomerSearchQuery({ lastName: 'Test', export: 'true', page: '7', perPage: '5' });
  assert.equal(exported.page, 1);
  assert.equal(exported.perPage, 10000);
  assert.throws(() => parseCustomerSearchQuery({ lastName: 'Test', perPage: '10000' }), CustomerSearchValidationError);
});
