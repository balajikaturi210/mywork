const assert = require('node:assert/strict');
const { readFileSync } = require('node:fs');
const test = require('node:test');
const { runInNewContext } = require('node:vm');
const ts = require('typescript');

function load(relativePath) {
  const source = readFileSync(require.resolve(relativePath), 'utf8');
  const compiled = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020, esModuleInterop: true },
  }).outputText;
  const exports = {};
  runInNewContext(compiled, { exports, Error, Date, Math, Map, Number, String, require: () => ({}) });
  return exports;
}

const { parseMonths, monthWindow, buildPlanEntries, NpdWriteoffValidationError } = load('../src/utils/npdWriteOffUec.ts');
const NOV_2026 = new Date(Date.UTC(2026, 10, 9));

test('parseMonths defaults to 12 and accepts 1 to 36', () => {
  assert.equal(parseMonths(undefined), 12);
  assert.equal(parseMonths(''), 12);
  assert.equal(parseMonths('6'), 6);
  assert.equal(parseMonths('36'), 36);
  assert.equal(parseMonths(undefined, 6), 6);
});

test('parseMonths rejects anything that is not a whole number from 1 to 36', () => {
  for (const bad of ['0', '37', '-1', '1.5', 'abc', '12; DROP TABLE x', '1e3', ' ']) {
    assert.throws(() => parseMonths(bad), (e) => e instanceof NpdWriteoffValidationError || e.name === 'NpdWriteoffValidationError', bad);
  }
});

test('monthWindow lists the months back from the current one, oldest first, across a year end', () => {
  assert.equal(JSON.stringify(monthWindow(3, NOV_2026)), JSON.stringify(['2026-08', '2026-09', '2026-10', '2026-11']));
  assert.equal(JSON.stringify(monthWindow(2, new Date(Date.UTC(2027, 0, 15)))), JSON.stringify(['2026-11', '2026-12', '2027-01']));
});

const entries = (rows, months = 8) =>
  buildPlanEntries(rows.map(([month, accounts_entered]) => ({ month, accounts_entered, current_balance: accounts_entered * 100 })), months, NOV_2026);

test('flags the quiet months after the job has run, fills missing months with zero, and never flags the current month', () => {
  // the real shape seen in production: big runs in Apr-Jul, nothing in Aug/Sep, a catch-up batch in Oct
  const out = entries([['2026-04', 17325], ['2026-05', 2517], ['2026-06', 7410], ['2026-07', 5654], ['2026-10', 4926]], 7);
  const by = Object.fromEntries(out.map((r) => [r.month, r]));
  assert.equal(out.length, 8);                       // window of 7 months + the current month
  assert.equal(by['2026-08'].accounts_entered, 0);   // missing month filled in
  assert.equal(by['2026-08'].stalled, true);
  assert.equal(by['2026-09'].stalled, true);
  assert.equal(by['2026-10'].stalled, false);
  assert.equal(by['2026-07'].stalled, false);
  assert.equal(by['2026-11'].partial_month, true);   // the current month is still running ...
  assert.equal(by['2026-11'].stalled, false);        // ... so it is not flagged
  assert.equal(by['2026-04'].normal_monthly_entries, by['2026-08'].normal_monthly_entries);
});

test('months before the job ever ran are not flagged as stalled', () => {
  const out = entries([['2026-03', 4], ['2026-04', 17325], ['2026-05', 2517], ['2026-06', 7410]], 8);
  const by = Object.fromEntries(out.map((r) => [r.month, r]));
  assert.equal(by['2026-03'].stalled, false);  // 4 entries, but the job had not started yet
  assert.equal(by['2026-04'].stalled, false);
});

test('no data at all gives an all-zero window with nothing flagged', () => {
  const out = entries([], 3);
  assert.equal(out.length, 4);
  assert.ok(out.every((r) => r.accounts_entered === 0 && !r.stalled));
});
