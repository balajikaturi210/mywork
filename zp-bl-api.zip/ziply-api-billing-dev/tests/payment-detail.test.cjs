const assert = require('node:assert/strict');
const { readFileSync } = require('node:fs');
const test = require('node:test');
const { runInNewContext } = require('node:vm');
const ts = require('typescript');

function load(relativePath, modules = {}) {
  const source = readFileSync(require.resolve(relativePath), 'utf8');
  const compiled = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020, esModuleInterop: true },
  }).outputText;
  const exports = {};
  runInNewContext(compiled, {
    exports, Error, Date, Math, Number, String, Array, Object, Promise, JSON, RegExp,
    require: (name) => {
      assert.ok(Object.hasOwn(modules, name), `Unexpected dependency: ${name}`);
      return modules[name];
    },
  });
  return exports;
}

const util = load('../src/utils/paymentDetail.ts');
const plain = (value) => JSON.parse(JSON.stringify(value));

const cardRow = (overrides = {}) => ({
  id: '9098922', billing_account_id: '5380930', payment_method_id: '8971999', payment_method_type: 'Credit Card',
  description: 'Credit Card Payment', status: 'POSTED', occurred_on: new Date('2026-11-13T17:46:19.018Z'),
  amount: '1.00', currency: 'USD', unapplied_amount: null, cancel_amount: null, refund_amount: '1.00', surcharge_amount: '0.15',
  payment_source_type: 'CHASE', reference: 'ref-1', auth_code: 'A100002', transaction_number: 'stub-txn-000002', mark_for_settlement: null,
  account_num: '14800092380526265', account_first_name: 'Test', account_last_name: 'Account',
  nickname: 'Credit Card Ending 1004', method_payment_type: 'tokenized-credit-card', method_category: 'tokenized-credit-card',
  card_holder_firstname: 'Dan', card_holder_lastname: 'Maier', card_holder_name: null, card_type: 'Visa', card_identifier_last_four: '1004',
  card_expiration: '12/2027', bank_account_number_last_four: null, bank_account_type: null, ...overrides,
});

test('a payment id is digits only and no longer than a real id', () => {
  assert.equal(util.parsePaymentId('9098922'), '9098922');
  assert.equal(util.parsePaymentId(' 42 '), '42');
  for (const bad of ['', 'abc', '12a', '1;DROP TABLE x', '-1', '1.5', '9'.repeat(19), undefined, null, ['1'], 12]) {
    assert.throws(() => util.parsePaymentId(bad), (error) => error.name === 'PaymentDetailValidationError', String(bad));
  }
});

test('a card payment maps to the shape Payment Core returns, with numbers, ISO dates and Last 4 labels', () => {
  const out = plain(util.toPaymentCoreShape(cardRow(), [], []));
  assert.equal(out.id, '9098922');
  assert.equal(out.payment_type, 'payment');
  assert.equal(out.amount, 1);
  assert.equal(out.refunded_amount, 1);
  assert.equal(out.surcharge_amount, 0.15);
  assert.equal(out.canceled_amount, null);
  assert.equal(out.occurred_on, '2026-11-13T17:46:19.018Z');
  assert.equal(out.authorization, 'A100002');
  assert.equal(out.transaction_id, 'stub-txn-000002');
  assert.equal(JSON.stringify(out.billing_account), JSON.stringify({ id: '5380930', account_num: '14800092380526265', external_account_num: null, account_name: 'Test Account' }));
  assert.equal(out.payment_method.payment_method_type, 'tokenized-credit-card');
  assert.equal(out.payment_method.nickname, 'Credit Card Ending 1004');
  assert.equal(out.payment_method.identifier_number, 'Last 4: 1004');
  assert.equal(out.payment_method.last_four, '1004');
  assert.equal(out.payment_method.first_name, 'Dan');
  assert.equal(out.payment_processor.id, 'CHASE');
});

test('the payment token is never part of the response', () => {
  const out = util.toPaymentCoreShape(cardRow({ token: 'secret-token', method_token: 'secret-token' }), [], []);
  assert.doesNotMatch(JSON.stringify(out), /secret-token/);
  assert.equal(Object.hasOwn(out.payment_method, 'token'), false);
});

test('a bank payment takes its holder name from the single name column and its last four from the bank column', () => {
  const out = plain(util.toPaymentCoreShape(cardRow({
    method_category: 'tokenized-bank', card_holder_firstname: null, card_holder_lastname: null, card_holder_name: 'Jane Smith',
    card_identifier_last_four: null, bank_account_number_last_four: '7588', bank_account_type: 'CHECKING', payment_method_type: 'Bank Draft',
  }), [], []));
  assert.equal(out.payment_method.payment_method_type, 'tokenized-bank');
  assert.equal(out.payment_method.account_holder_name, 'Jane Smith');
  assert.equal(out.payment_method.identifier_number, 'Last 4: 7588');
  assert.equal(out.payment_method.account_type, 'CHECKING');
  assert.equal(out.payment_method.last_four, null);
});

test('the method type falls back from the category description to the method type to the payment\'s own type', () => {
  assert.equal(util.toPaymentCoreShape(cardRow({ method_category: null }), [], []).payment_method.payment_method_type, 'tokenized-credit-card');
  assert.equal(util.toPaymentCoreShape(cardRow({ method_category: null, method_payment_type: null }), [], []).payment_method.payment_method_type, 'Credit Card');
});

test('blank and missing values become null, and a payment with no method or account is still returned', () => {
  const out = plain(util.toPaymentCoreShape(cardRow({
    payment_method_id: null, billing_account_id: null, account_num: null, account_first_name: null, account_last_name: null,
    description: '  ', amount: null, occurred_on: null, reference: '', auth_code: null, refund_amount: null,
  }), [], []));
  assert.equal(out.payment_method, null);
  assert.equal(out.billing_account.id, null);
  assert.equal(out.billing_account.account_name, null);
  assert.equal(out.description, null);
  assert.equal(out.amount, null);
  assert.equal(out.occurred_on, null);
  assert.equal(out.reference, null);
  assert.equal(out.refunded_amount, null);
});

test('custom fields keep the order given, skip disabled ones and use the shape the page reads', () => {
  const out = plain(util.toPaymentCoreShape(cardRow(), [
    { id: 1, custom_field_id: 10, name: 'Bank-ID', value: 'MTBROCH', custom_field_enabled: true },
    { id: 2, custom_field_id: 11, name: 'Hidden', value: 'x', custom_field_enabled: false },
    { id: 3, custom_field_id: null, name: 'Payment Channel', value: 'AUTOPAY', custom_field_enabled: null },
  ], []));
  assert.equal(JSON.stringify(out.payment_method.custom_field_values.map((f) => [f.custom_field.name, f.value])), JSON.stringify([['Bank-ID', 'MTBROCH'], ['Payment Channel', 'AUTOPAY']]));
  assert.equal(out.payment_method.custom_field_values[0].id, '1');
  assert.equal(out.payment_method.custom_field_values[1].custom_field.id, null);
});

test('status history becomes the status entries the transaction history reads, oldest first as given', () => {
  const out = plain(util.toPaymentCoreShape(cardRow(), [], [
    { id: 20000045, status_id: 'DRAFT', reason: 'Payment created before gateway call', reason_code: null, status_date: new Date('2026-11-13T17:46:19.021Z'), created_by: 'ZBP' },
    { id: 20000046, status_id: 'POSTED', reason: 'Gateway response received', reason_code: 'APPROVED', status_date: new Date('2026-11-13T17:46:20.268Z'), created_by: 'ZBP' },
  ]));
  assert.equal(out.current_status_entries.length, 2);
  assert.equal(JSON.stringify(out.current_status_entries[1]), JSON.stringify({
    id: '20000046', status: 'POSTED', status_date: '2026-11-13T17:46:20.268Z', reason: 'Gateway response received', reason_code: 'APPROVED', user_name: 'ZBP', change_type: 'STATUS',
  }));
});

function service(handlers) {
  const calls = [];
  const pool = { query: async (sql, params) => { calls.push({ sql, params }); return handlers(sql, params); } };
  const svc = load('../src/service/paymentDetail.services.ts', {
    '../config/zbpDb': { __esModule: true, default: pool },
    '../logger/logger': { __esModule: true, default: { error() {} } },
    '../utils/logger': { getTraceId: () => 'trace' },
    '../utils/paymentDetail': util,
  });
  return { svc, calls };
}

test('the service reads the payment, its custom fields and its history, all by bind parameter, and sorts the fields by name', async () => {
  const { svc, calls } = service((sql) => ({ rows: sql.includes('FROM zbp.payment p') ? [cardRow()] : [] }));
  const out = await svc.getPaymentDetailService('9098922');
  assert.equal(calls.length, 3);
  for (const call of calls) {
    assert.equal(JSON.stringify(call.params), JSON.stringify(['9098922']));
    assert.doesNotMatch(call.sql, /9098922/);
  }
  assert.match(calls.find((c) => c.sql.includes('custom_field_value')).sql, /ORDER BY v\.name, v\.id/);
  assert.match(calls.find((c) => c.sql.includes('payment_status_history')).sql, /ORDER BY h\.status_date, h\.id/);
  assert.equal(out.id, '9098922');
});

test('a payment that does not exist gives null, and a database failure reaches the caller', async () => {
  const none = service(() => ({ rows: [] }));
  assert.equal(await none.svc.getPaymentDetailService('1'), null);
  const failing = service(() => { throw new Error('boom'); });
  await assert.rejects(failing.svc.getPaymentDetailService('1'), /boom/);
});

function controllerWith(getPaymentDetailService) {
  return load('../src/controller/paymentDetail.controller.ts', {
    '../service/paymentDetail.services': { getPaymentDetailService },
    '../utils/paymentDetail': util,
  }).getPaymentDetail;
}
const fakeResponse = () => {
  const res = { statusCode: null, body: null };
  res.status = (code) => { res.statusCode = code; return res; };
  res.json = (body) => { res.body = body; return res; };
  return res;
};

test('the controller answers 400 for a bad id without touching the database, 404 when missing, 200 with the payment', async () => {
  const bad = fakeResponse();
  await controllerWith(() => assert.fail('no query expected'))({ params: { paymentId: '1; DROP TABLE x' } }, bad);
  assert.equal(bad.statusCode, 400);
  const missing = fakeResponse();
  await controllerWith(async () => null)({ params: { paymentId: '5' } }, missing);
  assert.equal(missing.statusCode, 404);
  assert.equal(missing.body.message, 'Payment not found');
  const found = fakeResponse();
  const payment = { id: '5' };
  await controllerWith(async (id) => { assert.equal(id, '5'); return payment; })({ params: { paymentId: '5' } }, found);
  assert.equal(found.statusCode, 200);
  assert.equal(found.body, payment);
});

test('a database failure answers a plain 500 that does not leak the error text', async () => {
  const res = fakeResponse();
  await controllerWith(async () => { throw new Error('relation "zbp.payment" does not exist at 10.0.0.5'); })({ params: { paymentId: '5' } }, res);
  assert.equal(res.statusCode, 500);
  assert.equal(JSON.stringify(res.body), JSON.stringify({ message: 'Failed to load payment' }));
});

// ---- bank details (from Payment Core) ---------------------------------------------------------

class FakePaymentCoreServiceError extends Error {
  constructor(message, statusCode, upstreamStatus) { super(message); this.name = 'PaymentCoreServiceError'; this.statusCode = statusCode; this.upstreamStatus = upstreamStatus; }
}

function bankService(axiosGet) {
  const logged = [];
  const svc = load('../src/service/paymentBankDetails.services.ts', {
    axios: { __esModule: true, default: { get: axiosGet } },
    '../logger/logger': { __esModule: true, default: { error: (entry) => logged.push(entry) } },
    '../types/paymentCore.types': { PaymentCoreServiceError: FakePaymentCoreServiceError },
    '../utils/logger': { getTraceId: () => 'trace' },
    '../utils/paymentCore.util': { getPaymentCoreConfig: () => ({ baseUrl: 'https://core.example/api/payment-core', timeout: 15000, headers: { Accept: 'application/json' }, httpsAgent: {}, useProxy: false }) },
  });
  return { svc, logged };
}

test('bank details ask Payment Core for the one payment by id, with a shorter timeout than the page-blocking calls', async () => {
  let call;
  const { svc } = bankService(async (url, options) => { call = { url, options }; return { status: 200, data: [{ payment_method: { bank_name: 'Test Bank', routing_number: '123456789' } }] }; });
  const out = await svc.getPaymentBankDetailsService('13315835');
  assert.equal(call.url, 'https://core.example/api/payment-core/v1/payment');
  assert.equal(JSON.stringify(call.options.params), JSON.stringify({ id: '13315835' }));
  assert.equal(call.options.timeout, 8000);
  assert.equal(JSON.stringify(out), JSON.stringify({ bank_name: 'Test Bank', routing_number: '123456789' }));
});

test('only the bank name and routing number are passed on; the account number, token and the rest of the record are not', async () => {
  const { svc } = bankService(async () => ({ status: 200, data: [{ id: '1', token: 'secret-token', payment_method: { bank_name: 'Test Bank', routing_number: '123456789', account_number: '****7588', token: 'secret-token', account_type: 'CHECKING' } }] }));
  const out = await svc.getPaymentBankDetailsService('1');
  assert.deepEqual(Object.keys(out).sort(), ['bank_name', 'routing_number']);
  assert.doesNotMatch(JSON.stringify(out), /secret-token|7588|CHECKING/);
});

test('missing or blank bank fields are null, and a payment Payment Core does not know gives null', async () => {
  const blank = bankService(async () => ({ status: 200, data: [{ payment_method: { bank_name: '  ', routing_number: null } }] }));
  assert.equal(JSON.stringify(await blank.svc.getPaymentBankDetailsService('1')), JSON.stringify({ bank_name: null, routing_number: null }));
  const none = bankService(async () => ({ status: 200, data: [] }));
  assert.equal(await none.svc.getPaymentBankDetailsService('1'), null);
  const noMethod = bankService(async () => ({ status: 200, data: [{ id: '1' }] }));
  assert.equal(await noMethod.svc.getPaymentBankDetailsService('1'), null);
  const notFound = bankService(async () => ({ status: 404, data: {} }));
  assert.equal(await notFound.svc.getPaymentBankDetailsService('1'), null);
});

test('a Payment Core error or timeout becomes a 502 or 504 and is logged without the response body', async () => {
  const bad = bankService(async () => ({ status: 500, data: { Error: 'internal detail 10.0.0.5' } }));
  await assert.rejects(bad.svc.getPaymentBankDetailsService('1'), (error) => error.statusCode === 502 && !/10\.0\.0\.5/.test(error.message));
  assert.equal(bad.logged.length, 1);
  assert.doesNotMatch(JSON.stringify(bad.logged), /10\.0\.0\.5/);
  const slow = bankService(async () => { throw Object.assign(new Error('timeout of 8000ms exceeded'), { code: 'ECONNABORTED' }); });
  await assert.rejects(slow.svc.getPaymentBankDetailsService('1'), (error) => error.statusCode === 504);
  const down = bankService(async () => { throw Object.assign(new Error('getaddrinfo ENOTFOUND'), { code: 'ENOTFOUND' }); });
  await assert.rejects(down.svc.getPaymentBankDetailsService('1'), (error) => error.statusCode === 502);
});

function bankControllerWith(getPaymentBankDetailsService) {
  return load('../src/controller/paymentBankDetails.controller.ts', {
    '../service/paymentBankDetails.services': { getPaymentBankDetailsService },
    '../types/paymentCore.types': { PaymentCoreServiceError: FakePaymentCoreServiceError },
    '../utils/paymentDetail': util,
  }).getPaymentBankDetails;
}

test('the bank details controller answers 400 for a bad id, 404 when none, 200 with the two fields, and a plain 502 or 504 otherwise', async () => {
  const bad = fakeResponse();
  await bankControllerWith(() => assert.fail('no call expected'))({ params: { paymentId: 'x' } }, bad);
  assert.equal(bad.statusCode, 400);
  const none = fakeResponse();
  await bankControllerWith(async () => null)({ params: { paymentId: '5' } }, none);
  assert.equal(none.statusCode, 404);
  const found = fakeResponse();
  const details = { bank_name: 'Test Bank', routing_number: '123456789' };
  await bankControllerWith(async () => details)({ params: { paymentId: '5' } }, found);
  assert.equal(found.statusCode, 200);
  assert.equal(found.body, details);
  const down = fakeResponse();
  await bankControllerWith(async () => { throw new FakePaymentCoreServiceError('Unable to reach Payment Core at 10.0.0.5', 502); })({ params: { paymentId: '5' } }, down);
  assert.equal(down.statusCode, 502);
  assert.equal(JSON.stringify(down.body), JSON.stringify({ message: 'Bank details are unavailable' }));
  const slow = fakeResponse();
  await bankControllerWith(async () => { throw new FakePaymentCoreServiceError('slow', 504); })({ params: { paymentId: '5' } }, slow);
  assert.equal(slow.statusCode, 504);
  const unexpected = fakeResponse();
  await bankControllerWith(async () => { throw new Error('anything'); })({ params: { paymentId: '5' } }, unexpected);
  assert.equal(unexpected.statusCode, 502);
});
