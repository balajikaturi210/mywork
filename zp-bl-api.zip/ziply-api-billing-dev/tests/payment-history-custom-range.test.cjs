const assert = require('node:assert/strict');
const { readFileSync } = require('node:fs');
const test = require('node:test');
const { runInNewContext } = require('node:vm');
const ts = require('typescript');

function loadUtil() {
  const source = readFileSync(require.resolve('../src/utils/paymentSearch.ts'), 'utf8');
  const compiled = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020, esModuleInterop: true } }).outputText;
  const exports = {};
  runInNewContext(compiled, { exports, Error, Number, String, Array, RegExp });
  return exports;
}

// Loads report.services.ts with the database pool replaced by one that records the query it is given.
function loadService(queries) {
  const source = readFileSync(require.resolve('../src/service/report.services.ts'), 'utf8');
  const compiled = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020, esModuleInterop: true },
  }).outputText;
  const pool = { query: async (sql, params) => { queries.push({ sql, params }); return { rows: [{ id: '1' }] }; } };
  const logger = { error() {}, info() {} };
  const modules = {
    '../utils/logger': { getTraceId: () => 'trace' },
    '../config/zbpDb': { __esModule: true, default: pool },
    '../logger/logger': { __esModule: true, default: logger },
    '../utils/paymentSearch': loadUtil(),
  };
  const exports = {};
  runInNewContext(compiled, {
    exports, Error, Date, Math, Map, Number, String, Array, Promise, JSON, Object,
    require: (name) => modules[name] ?? {},
  });
  return exports;
}

const columns = (sql) => {
  const select = sql.slice(sql.indexOf('SELECT') + 6, sql.indexOf('FROM'));
  return select.split(/,(?![^(]*\))/).map((c) => c.trim().split(/\s+AS\s+/i).pop().replace(/^\w+\./, ''));
};

test('custom range payments return the payment id, not the billing account id', async () => {
  const queries = [];
  const { getPaymentHistoryOnCustomRange } = loadService(queries);
  await getPaymentHistoryOnCustomRange(3, 0, 50);
  const { sql } = queries[0];
  assert.match(sql, /\bp\.id,/);
  assert.doesNotMatch(sql, /\bba\.id\b[^=]*,/, 'ba.id must not be selected as the row id');
  assert.ok(columns(sql).includes('id'));
});

test('custom range payments return every column the payments table reads', async () => {
  const queries = [];
  const { getPaymentHistoryOnCustomRange } = loadService(queries);
  await getPaymentHistoryOnCustomRange();
  const names = columns(queries[0].sql);
  for (const name of [
    'id', 'billing_account_id', 'account_num', 'account_name', 'occurred_on', 'status', 'payment_method_id',
    'payment_method_type', 'payment_method_type_description', 'payment_type', 'amount', 'unapplied_amount', 'cancel_amount',
    'refund_amount', 'surcharge_amount',
  ]) {
    assert.ok(names.includes(name), `missing column ${name}`);
  }
});

test('custom range payments page in a stable order and pass limit and skip as parameters', async () => {
  const queries = [];
  const { getPaymentHistoryOnCustomRange } = loadService(queries);
  await getPaymentHistoryOnCustomRange(1, 100, 25);
  const { sql, params } = queries[0];
  assert.match(sql, /ORDER BY p\.created_on DESC, p\.id DESC/);
  assert.equal(params[1], 25);
  assert.equal(params[2], 100);
});

// The payment type is derived from the payment's own description (zbp.payment has no such column).
test('custom range payments derive the payment type from the description, then the batch source', async () => {
  const queries = [];
  const { getPaymentHistoryOnCustomRange } = loadService(queries);
  await getPaymentHistoryOnCustomRange();
  const sql = queries[0].sql.replace(/\s+/g, ' ');
  const rules = [
    "WHEN p.description ILIKE 'autopay%' THEN 'Recurring'",
    "WHEN p.description ILIKE 'auto-payment validation%' THEN 'Validation'",
    "WHEN NULLIF(BTRIM(p.description), '') IS NOT NULL THEN 'One Time'",
    "WHEN p.payment_source_type = 'BATCH' THEN 'Recurring'",
  ];
  let at = -1;
  for (const rule of rules) {
    const next = sql.indexOf(rule);
    assert.ok(next > at, `rule missing or out of order: ${rule}`);
    at = next;
  }
});
