const assert = require('node:assert/strict');
const { readFileSync } = require('node:fs');
const test = require('node:test');
const { runInNewContext } = require('node:vm');
const ts = require('typescript');

function load(relativePath, modules = {}, globals = {}) {
  const source = readFileSync(require.resolve(relativePath), 'utf8');
  const compiled = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020, esModuleInterop: true },
  }).outputText;
  const exports = {};
  runInNewContext(compiled, {
    exports, Error, Date, Math, Number, String, Array, Object, Promise, JSON, RegExp,
    require: (name) => {
      assert.ok(Object.hasOwn(modules, name), `Unexpected dependency: ${name}`);
      return modules[name];
    },
    ...globals,
  });
  return exports;
}

const util = load('../src/utils/paymentSearch.ts');
const { parsePaymentSearchQuery, PaymentSearchValidationError } = util;

function service(rowsFor) {
  const calls = [];
  const state = { failWith: null };
  const searchPool = {
    query: async (sql, params) => {
      calls.push({ sql, params });
      if (state.failWith) throw state.failWith;
      if (sql.includes('failed_last_90_days')) return { rows: [rowsFor.highlights] };
      return sql.includes('COUNT(*)') ? { rows: [rowsFor.summary] } : { rows: rowsFor.rows };
    },
  };
  const mainPool = { query: async () => { throw new Error('searches must not use the main pool'); } };
  const svc = load('../src/service/paymentSearch.services.ts', {
    '../config/zbpDb': { __esModule: true, default: mainPool, zbpSearchPool: searchPool },
    '../logger/logger': { __esModule: true, default: { error() {} } },
    '../utils/logger': { getTraceId: () => 'trace' },
    '../utils/paymentSearch': util,
  });
  return { svc, calls, state };
}
const plain = (value) => JSON.parse(JSON.stringify(value));

test('defaults to the last 7 days, page 1 of 25, with no other filters', () => {
  const request = parsePaymentSearchQuery({});
  assert.equal(JSON.stringify(plain(request.criteria)), JSON.stringify({ days: 7 }));
  assert.equal(request.page, 1);
  assert.equal(request.perPage, 25);
  assert.equal(request.forExport, false);
});

test('the longest range offered is 180 days', () => {
  assert.equal(parsePaymentSearchQuery({ days: '180' }).criteria.days, 180);
  assert.throws(() => parsePaymentSearchQuery({ days: '181' }), (error) => /between 1 and 180/.test(error.message));
});

test('accepts every filter and trims text, lower-casing the enumerated ones', () => {
  const { criteria, page, perPage } = parsePaymentSearchQuery({
    days: '90', status: 'Failure', paymentType: 'One-Time', accountNumber: ' 00123 ', accountName: ' Test Customer ', minAmount: '150.5', page: '3', perPage: '50',
  });
  assert.equal(JSON.stringify(plain(criteria)), JSON.stringify({
    days: 90, status: 'failure', paymentType: 'one-time', accountNumber: '00123', accountName: 'Test Customer', minAmount: 150.5,
  }));
  assert.equal(page, 3);
  assert.equal(perPage, 50);
});

test('rejects malformed filters instead of ignoring them', () => {
  for (const query of [
    { days: '0' }, { days: '181' }, { days: '7.5' }, { days: 'x' }, { days: ['7'] },
    { status: 'bogus' }, { paymentType: 'weekly' }, { accountNumber: '12' }, { accountNumber: '12a45' }, { accountName: 'ab' },
    { minAmount: '-1' }, { minAmount: '1.234' }, { minAmount: 'abc' }, { accountName: 'x'.repeat(101) },
    { page: '0' }, { perPage: '0' }, { perPage: '101' }, { page: '1.5' },
  ]) {
    assert.throws(() => parsePaymentSearchQuery(query), (error) => error.name === 'PaymentSearchValidationError', JSON.stringify(query));
  }
});

test('an export asks for one page of up to 10,000 rows whatever page or perPage was sent', () => {
  const request = parsePaymentSearchQuery({ export: 'true', page: '5', perPage: '10' });
  assert.equal(request.forExport, true);
  assert.equal(request.page, 1);
  assert.equal(request.perPage, 10000);
});

test('the date range is whole UTC days ending today', () => {
  const { svc } = service({ rows: [], summary: {} });
  const now = new Date(Date.UTC(2026, 10, 13, 15, 30));
  assert.equal(svc.rangeStart(1, now).toISOString(), '2026-11-13T00:00:00.000Z');
  assert.equal(svc.rangeStart(7, now).toISOString(), '2026-11-07T00:00:00.000Z');
  assert.equal(svc.rangeStart(90, now).toISOString(), '2026-08-16T00:00:00.000Z');
});

test('with no payment type, validation attempts are left out; the Validation type shows only them', () => {
  const { svc } = service({ rows: [], summary: {} });
  const normal = svc.buildPaymentWhere({ days: 7 });
  assert.match(normal.where, /IS DISTINCT FROM 'Validation'/);
  assert.equal(normal.with, '', 'no account filter, no account lookup');
  const onlyValidation = svc.buildPaymentWhere({ days: 7, paymentType: 'validation' });
  assert.match(onlyValidation.where, /= 'Validation'/);
  assert.doesNotMatch(onlyValidation.where, /IS DISTINCT FROM/);
  assert.match(svc.buildPaymentWhere({ days: 7, paymentType: 'recurring' }).where, /= 'Recurring'/);
  assert.match(svc.buildPaymentWhere({ days: 7, paymentType: 'one-time' }).where, /= 'One Time'/);
});

test('every user value is a bind parameter, never part of the SQL text, and LIKE wildcards are escaped', () => {
  const { svc } = service({ rows: [], summary: {} });
  const built = svc.buildPaymentWhere({ days: 30, status: 'failure', accountNumber: '00123', accountName: "O'Neil_100%", minAmount: 150 });
  assert.doesNotMatch(built.where + built.with, /00123|O'Neil|150/);
  assert.match(built.where, /p\.status IN \('PROCESSING_ERROR', 'FAILED'\)/);
  assert.match(built.with, /ba\.account_num LIKE \$2/);
  assert.match(built.with, /ILIKE \$3/);
  assert.match(built.where, /p\.billing_account_id IN \(SELECT id FROM matched_accounts\)/);
  assert.match(built.where, /p\.amount >= \$4/);
  assert.equal(JSON.stringify(plain(built.binds.slice(1))), JSON.stringify(['00123%', "%O'Neil\\_100\\%%", 150]));
});

test('status groups: success is COMPLETED, failure is a processing error or failed, other is everything else', () => {
  const { svc } = service({ rows: [], summary: {} });
  assert.match(svc.buildPaymentWhere({ days: 7, status: 'success' }).where, /p\.status = 'COMPLETED'/);
  assert.match(svc.buildPaymentWhere({ days: 7, status: 'other' }).where, /p\.status NOT IN \('COMPLETED', 'PROCESSING_ERROR', 'FAILED'\)/);
});

test('returns the page, the paging bounds and a summary computed over the whole filtered range', async () => {
  const { svc, calls } = service({
    rows: [{ id: '1', payment_type: 'Recurring' }],
    summary: { total: '400', success: '300', failure: '60', amount_processed: '12345.60' },
  });
  const result = await svc.searchPaymentsService({ days: 7 }, 3, 25);
  assert.equal(calls.length, 2);
  const page = calls.find((call) => !call.sql.includes('COUNT(*)'));
  const summary = calls.find((call) => call.sql.includes('COUNT(*)'));
  assert.match(page.sql, /ORDER BY p\.created_on DESC, p\.id DESC\s+LIMIT \$2 OFFSET \$3/);
  assert.equal(JSON.stringify(plain(page.params.slice(1))), JSON.stringify([25, 50]));
  assert.equal(summary.params.length, 1, 'the summary uses only the filter binds, not paging');
  assert.doesNotMatch(summary.sql, /JOIN zbp\.billing_account|matched_accounts/, 'no account lookup when no account filter is used');
  assert.match(page.sql, /LEFT JOIN zbp\.billing_account ba/, 'a payment without an account is still listed, so the page can never be shorter than the total');
  assert.equal(result.total, 400);
  assert.equal(JSON.stringify(plain(result.summary)), JSON.stringify({ total: 400, success: 300, failure: 60, other: 40, amount_processed: 12345.6 }));
  assert.equal(result.rows[0].payment_type, 'Recurring');
  assert.match(page.sql, /AS payment_type/);
  assert.match(page.sql, /surcharge_amount/);
});

test('an account filter finds the accounts first (materialized) for both the page and the summary', async () => {
  const { svc, calls } = service({ rows: [], summary: { total: 0, success: 0, failure: 0, amount_processed: 0 } });
  await svc.searchPaymentsService({ days: 7, accountName: 'Test' }, 1, 25);
  for (const call of calls) assert.match(call.sql, /WITH matched_accounts AS MATERIALIZED \(SELECT ba\.id FROM zbp\.billing_account ba WHERE/);
});

test('all dates: no range condition and no date bind, but only with an account number or name', async () => {
  const request = util.parsePaymentSearchQuery({ days: 'all', accountNumber: '00123' });
  assert.equal(request.criteria.days, undefined);
  const built = svc2().buildPaymentWhere(request.criteria);
  assert.doesNotMatch(built.where, /created_on/);
  assert.equal(JSON.stringify(plain(built.binds)), JSON.stringify(['00123%']));
  assert.equal(util.parsePaymentSearchQuery({ days: 'ALL', accountName: 'Test' }).criteria.days, undefined);
  for (const query of [{ days: 'all' }, { days: 'all', status: 'failure', minAmount: '5' }]) {
    assert.throws(() => util.parsePaymentSearchQuery(query), (error) => /needs an account number or account name/.test(error.message));
  }
});

test('a date range together with an account filter keeps both', () => {
  const built = svc2().buildPaymentWhere({ days: 30, accountNumber: '00123' });
  assert.match(built.where, /p\.created_on >= \$1/);
  assert.match(built.with, /LIKE \$2/);
});

function svc2() { return service({ rows: [], summary: {} }).svc; }

function controllerWith(searchPaymentsService) {
  return load('../src/controller/paymentSearch.controller.ts', {
    '../service/paymentSearch.services': { searchPaymentsService },
    '../utils/paymentSearch': util,
  }).getPaymentSearch;
}
const fakeResponse = () => {
  const res = { statusCode: null, body: null };
  res.status = (code) => { res.statusCode = code; return res; };
  res.json = (body) => { res.body = body; return res; };
  return res;
};

test('the controller answers 400 with the validation message and never reaches the database', async () => {
  const res = fakeResponse();
  await controllerWith(() => assert.fail('no query expected'))({ query: { days: '999' } }, res);
  assert.equal(res.statusCode, 400);
  assert.match(res.body.message, /days must be between 1 and 180/);
});

test('the controller answers 200 with the page, total and summary', async () => {
  const res = fakeResponse();
  const payload = { rows: [], total: 0, page: 1, perPage: 25, summary: {} };
  let received;
  await controllerWith(async (criteria, page, perPage) => { received = { criteria: plain(criteria), page, perPage }; return payload; })({ query: { days: '30', page: '2' } }, res);
  assert.equal(res.statusCode, 200);
  assert.equal(res.body, payload);
  assert.equal(JSON.stringify(received), JSON.stringify({ criteria: { days: 30 }, page: 2, perPage: 25 }));
});

test('a database failure answers a plain 500 that does not leak the database error text', async () => {
  const res = fakeResponse();
  await controllerWith(async () => { throw new Error('relation "zbp.payment" does not exist at 10.0.0.5'); })({ query: {} }, res);
  assert.equal(res.statusCode, 500);
  assert.equal(JSON.stringify(res.body), JSON.stringify({ message: 'Failed to search payments' }));
});

test('the page and the summary always use the very same WHERE clause and binds', async () => {
  const { svc, calls } = service({ rows: [], summary: { total: 0, success: 0, failure: 0, amount_processed: 0 } });
  await svc.searchPaymentsService({ days: 30, status: 'failure', paymentType: 'recurring', accountNumber: '00123', accountName: 'Test', minAmount: 10 }, 1, 25);
  const where = (sql) => sql.split(/\n\s+WHERE /).at(-1).split('ORDER BY')[0].trim();
  const [page, summary] = [calls.find((c) => !c.sql.includes('COUNT(*)')), calls.find((c) => c.sql.includes('COUNT(*)'))];
  assert.equal(where(page.sql), where(summary.sql));
  assert.equal(JSON.stringify(plain(page.params.slice(0, summary.params.length))), JSON.stringify(plain(summary.params)));
});

test('statuses and types cannot fall through: a null status counts as other, and every payment has a type', () => {
  const { svc } = service({ rows: [], summary: {} });
  assert.match(svc.buildPaymentWhere({ days: 7, status: 'other' }).where, /p\.status IS NULL OR p\.status NOT IN/);
  assert.match(util.PAYMENT_TYPE_SQL, /ELSE 'One Time'/);
});

test('searches run on the dedicated search pool and let a database failure reach the caller', async () => {
  const { svc, state } = service({ rows: [], summary: { total: 0, success: 0, failure: 0, amount_processed: 0 } });
  await svc.searchPaymentsService({ days: 7 }, 1, 25);
  state.failWith = Object.assign(new Error('canceling statement due to statement timeout'), { code: '57014' });
  await assert.rejects(svc.searchPaymentsService({ days: 7 }, 1, 25), (error) => error.code === '57014');
});

test('the search pool is small, read-only and starts every connection with a statement timeout; the main pool is unchanged', () => {
  const pools = [];
  load('../src/config/zbpDb.ts', {
    pg: { Pool: class { constructor(config) { this.config = config; pools.push(this); } } },
    'dotenv/config': {},
  }, { process: { env: { ZBP_DB_NAME: 'payments', DB_HOST: 'db.example', DB_USER: 'u', DB_PASSWORD: 'p', DB_PORT: '5432' } } });
  const [main, search] = pools.map((pool) => pool.config);
  assert.equal(main.options, '-c search_path=zbp,public');
  assert.equal(main.statement_timeout, undefined);
  assert.equal(main.max, undefined);
  assert.equal(search.statement_timeout, 20000);
  assert.equal(search.max, 5);
  assert.match(search.options, /default_transaction_read_only=on/);
  assert.match(search.options, /search_path=zbp,public/);
  assert.equal(search.host, main.host);
  assert.equal(search.database, main.database);
});

test('a search that hits the statement timeout answers 504 with advice the user can act on', async () => {
  const res = fakeResponse();
  await controllerWith(async () => { throw Object.assign(new Error('canceling statement due to statement timeout'), { code: '57014' }); })({ query: {} }, res);
  assert.equal(res.statusCode, 504);
  assert.match(res.body.message, /shorter date range/);
  assert.doesNotMatch(JSON.stringify(res.body), /statement timeout/);
});

test('paging stops at 100,000 rows, but an export is not a page and is not affected', () => {
  assert.equal(parsePaymentSearchQuery({ page: '1000', perPage: '100' }).page, 1000);
  assert.throws(() => parsePaymentSearchQuery({ page: '1002', perPage: '100' }), (error) => /Paging stops at 100,000 rows/.test(error.message));
  assert.equal(parsePaymentSearchQuery({ export: 'true', page: '99999' }).perPage, 10000);
});

// ---- one account (the customer's Payments tab) ----------------------------------------------------

test('billingAccountId searches one account, and its range may reach back ten years', () => {
  const request = parsePaymentSearchQuery({ billingAccountId: ' 4882090 ', days: '365' });
  assert.equal(request.criteria.billingAccountId, '4882090');
  assert.equal(request.criteria.days, 365);
  assert.equal(parsePaymentSearchQuery({ billingAccountId: '4882090', days: '3650' }).criteria.days, 3650);
  assert.throws(() => parsePaymentSearchQuery({ billingAccountId: '4882090', days: '3651' }), (error) => /between 1 and 3650/.test(error.message));
  assert.throws(() => parsePaymentSearchQuery({ days: '365' }), (error) => /between 1 and 180/.test(error.message), 'without an account the limit stays 180');
});

test('billingAccountId must be digits only', () => {
  for (const bad of ['abc', '12 34', '1; DROP TABLE', '-5', '1.5', '1'.repeat(19)]) {
    assert.throws(() => parsePaymentSearchQuery({ billingAccountId: bad }), PaymentSearchValidationError, bad);
  }
});

test('all dates is allowed for one account by id, and for nothing else without a name or number', () => {
  const request = parsePaymentSearchQuery({ billingAccountId: '4882090', days: 'all' });
  assert.equal(request.criteria.days, undefined);
  assert.throws(() => parsePaymentSearchQuery({ days: 'all', status: 'failure' }), (error) => /needs an account number or account name/.test(error.message));
});

test('one account is a plain bind-parameter equality on the payment, with no account lookup', () => {
  const { svc } = service({ rows: [], summary: {} });
  const built = svc.buildPaymentWhere({ days: 365, billingAccountId: '4882090' });
  assert.match(built.where, /p\.billing_account_id = \$2/);
  assert.equal(built.with, '');
  assert.doesNotMatch(built.where, /4882090/);
  assert.equal(JSON.stringify(plain(built.binds.slice(1))), JSON.stringify(['4882090']));
  const all = svc.buildPaymentWhere({ billingAccountId: '4882090' });
  assert.doesNotMatch(all.where, /created_on/);
  assert.match(all.where, /p\.billing_account_id = \$1/);
});

test('a one-account search also returns the last payment and the failures of the last 90 days', async () => {
  const { svc, calls } = service({
    rows: [], summary: { total: 3, success: 2, failure: 1, amount_processed: '70.10' },
    highlights: { last_payment_amount: '36.05', last_payment_on: '2026-11-09T15:20:00.000Z', failed_last_90_days: '2' },
  });
  const result = await svc.searchPaymentsService({ days: 365, billingAccountId: '4882090' }, 1, 25);
  assert.equal(JSON.stringify(plain(result.account)), JSON.stringify({ last_payment_amount: 36.05, last_payment_on: '2026-11-09T15:20:00.000Z', failed_last_90_days: 2 }));
  const highlights = calls.find((call) => call.sql.includes('failed_last_90_days'));
  assert.equal(highlights.params[0], '4882090');
  assert.equal(highlights.params[1].toISOString().slice(11), '00:00:00.000Z', 'the 90 days start at the beginning of a UTC day');
  assert.match(highlights.sql, /IS DISTINCT FROM 'Validation'/);
  assert.doesNotMatch(highlights.sql, /4882090/);
});

test('an account with no completed payment has no last payment, and other searches carry no account block', async () => {
  const one = service({ rows: [], summary: {}, highlights: { last_payment_amount: null, last_payment_on: null, failed_last_90_days: 0 } });
  const result = await one.svc.searchPaymentsService({ days: 365, billingAccountId: '1' }, 1, 25);
  assert.equal(result.account.last_payment_amount, null);
  assert.equal(result.account.last_payment_on, null);
  const many = service({ rows: [], summary: {} });
  const plainResult = await many.svc.searchPaymentsService({ days: 7 }, 1, 25);
  assert.equal(Object.hasOwn(plainResult, 'account'), false);
  assert.equal(many.calls.length, 2);
});

test('each payment row also carries its account billing system and status, so the account can be opened correctly from the list', async () => {
  const { svc, calls } = service({ rows: [{ id: '1', billing_ind: 'GTV', account_status: 'BILLING_ACCOUNT_ACTIVE' }], summary: {} });
  const result = await svc.searchPaymentsService({ days: 7 }, 1, 25);
  const page = calls.find((call) => !call.sql.includes('COUNT(*)'));
  assert.match(page.sql, /ba\.billing_ind,/);
  assert.match(page.sql, /ba\.status AS account_status/);
  assert.match(page.sql, /LEFT JOIN zbp\.billing_account ba/, 'a payment without an account is still listed');
  assert.equal(result.rows[0].billing_ind, 'GTV');
});
